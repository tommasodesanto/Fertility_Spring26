#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates the timeseries in Figure 4
# and the event studies by 5-year interval in Appendix Figures A.6-A.8
  
#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Function to plot timeseries
plot_timeseries <- function(data, hetero, export=T){
  
# Run code to get penalties by time interval for each outcome
# This will also create the event studies
coef <- setDF(rbindlist(lapply(l.depvars, reg_es_hetero, data=data, hetero = {{hetero}},
                               return_final = "penalty", plotname = "child_penalties_time",
                               export = {{export}})))

  # Save dataframe of penalties
saveRDS(coef, file=file.path(wrkdir,paste0("penalties_",hetero,".rds")))

  # Clean up df
coef <- coef %>%
  rename(penalty = estimate) %>%
  rename(interval=hetero)


# Plot time series

  # Only plot time series for 5-year intervals

if(hetero == "yr5"){
  
  ggplot(coef, aes(y=penalty, x=interval, group=depvar_lab,color=depvar_lab))  +
    # display all x values on axis
    scale_x_discrete(labels=unique(coef$interval))+
    # y-axis
    coord_cartesian(ylim=c(0,0.7),clip = 'off')+
    scale_y_continuous(breaks=seq(0,0.7, by=0.1))+
    # axis labels
    labs(x="Year", y=paste("Child Penalty")) +
    # line and point sizes
    geom_point(aes(shape=depvar_lab,size=depvar_lab, color=depvar_lab)) +
    geom_line(linewidth=1)+
    # theme + grid lines
    theme_minimal() +
    theme(axis.line = element_line(colour = "black",linewidth=0.2),
          panel.grid.major.x = element_blank(),
          panel.grid.minor.y = element_blank(),
          legend.key.size = unit(3,"lines"),
          legend.position = "none", 
          legend.background=element_blank(),
          text=element_text(size=20),
          plot.margin = unit(c(0, 5, 0, 0), "cm"),
          axis.text.x = element_text(margin = unit(c(0.5,0,0,0), "cm")),
          axis.text.y = element_text(margin = unit(c(0,0.4,0,0), "cm")),
          axis.title.y = element_text(margin = margin(t = 0, r = 10, b = 0, l = 0)),
          axis.title.x = element_text(margin = margin(t = 10, r = 0, b = 0, l = 0))) +
    # Add labels for outcome next to line
    geom_text(data = filter(coef, interval == "2015-20"),
              aes(color=depvar_lab,
                  label=depvar_lab),position=
                position_nudge(x=0.1,y=0),
              size=7,hjust=0)+
    # Define color scheme + shapes for each outcome
    scale_color_manual(name="",values = c(rgb(186,17,17, maxColorValue = 255),"black",
                                          rgb(26,71,111, maxColorValue = 255)),
                       breaks=c("Earnings","Annual Employment","Weekly Employment"))+
    scale_shape_manual(values=c(15,16,17))+
    scale_size_manual(values=c(5,5,5))
  
  # save graph
  ggsave(paste0("child_penalties_timeseries", ".pdf"), plot=last_plot(), device="pdf",
         width=15, height=8, units="in",path=file.path(outdir,"Figures"))

}
return(coef)
}

# Load CPS and ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

# Define vector of outcomes of interest
l.depvars <- c("earnings_ly", "emp_lw","earn_ly")

# Create figures
plot_timeseries(data=cps_acs,hetero="yr5")
plot_timeseries(data=cps_acs,hetero="yr10", export=F)
