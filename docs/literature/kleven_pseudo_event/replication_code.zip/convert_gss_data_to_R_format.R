#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file converts GSS Data to an RDS file

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))


# load data and change to RDS format
read_dta(file.path(rawdir, "GSS/GSS7218_R1.dta")) %>% 
  saveRDS(file.path(rawdir, "GSS/GSS7218_R1.rds"))

gss_identifiers <- read_dta(file.path(rawdir, "GSS/cross7316geo.dta")) %>% 
  saveRDS(file.path(rawdir, "GSS/cross7316geo.rds"))
