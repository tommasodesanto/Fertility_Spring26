#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates Table 1 in the paper
# (Descriptive Statistics in the Cross-Section)

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Load combined CPS and ACS cross-section
cps_acs_pre <- readRDS(file.path(cleandir,"cps_acs_clean_aged20-50.rds"))

# Redefine cohort to equal year - age
cps_acs_pre <- cps_acs_pre %>%
  mutate(doby = doiy - age)

# Code for table

  # Columns for men and women
summary_tbl1 <- cps_acs_pre %>%
  # Parents vs non-parents by gender
  group_by(child,gender) %>%
  # Unweighted averages of labor market vars + other demographics
  # Get total # of obs in each group + number of obs with specific demographics
  summarise(
    `Annual Employment Rate` = mean(earn_ly, na.rm=T),
    `Weekly Employment Rate` = mean(emp_lw, na.rm=T),
    `Earnings` = round(mean(earnings_ly, na.rm=T)),
    `Fraction College` = mean(college, na.rm=T),
    `Age` = round(mean(age, na.rm=T),digits=2),
    `Cohort` = round(mean(doby, na.rm=T),digits=2),
    total = n(),
    total_hs = sum(edlevel %in% c("Below HS","HS grad"), na.rm=T),
    total_married = sum(married == "Married",na.rm=T),
    total_black = sum(race == "Black, non-hispanic", na.rm=T),
    total_white = sum(race == "White, non-hispanic",na.rm=T),
    total_hispanic = sum(race == "Hispanic", na.rm=T)) %>%
  # Calculate remaining fractions
  mutate(
    `Fraction High School or Below`= total_hs/total,
    `Fraction Married` = total_married/total,
    `Fraction Black` = total_black/total,
    `Fraction White` = total_white/total,
    `Fraction Hispanic` = total_hispanic/total) %>%
  mutate(`Number of Observations` = comma(total))


  # Columns for differences
      # Repeat same code for results by gender and parental status
diff_tbl <- cps_acs_pre %>%
  group_by(child,gender) %>%
  summarise(
    `Annual Employment Rate` = mean(earn_ly, na.rm=T),
    `Weekly Employment Rate` = mean(emp_lw, na.rm=T),
    `Earnings` = round(mean(earnings_ly, na.rm=T)),
    `Fraction College` = mean(college, na.rm=T),
    `Age` = round(mean(age, na.rm=T),digits=2),
    `Cohort` = round(mean(doby, na.rm=T),digits=2),
    total = n(),
    total_hs = sum(edlevel %in% c("Below HS","HS grad"), na.rm=T),
    total_married = sum(married == "Married",na.rm=T),
    total_black = sum(race == "Black, non-hispanic", na.rm=T),
    total_white = sum(race == "White, non-hispanic",na.rm=T),
    total_hispanic = sum(race == "Hispanic", na.rm=T)) %>%
  mutate(
    `Fraction High School or Below`= total_hs/total,
    `Fraction Married` = total_married/total,
    `Fraction Black` = total_black/total,
    `Fraction White` = total_white/total,
    `Fraction Hispanic` = total_hispanic/total) %>%
  dplyr::select(-contains("total")) %>%
      # reshape to get 4 separate cols with data
  pivot_longer(cols=-c(child,gender)) %>%
  pivot_wider(names_from=c("gender","child"),values_from = "value")%>%
      # get diff = parent - non-parent
  mutate(diff_Men = Men_1 - Men_0,
         diff_Women = Women_1 - Women_0) %>%
      # keep differences only
  subset(select=c(name, diff_Men, diff_Women)) %>%
  pivot_longer(cols=c(diff_Men, diff_Women), names_to="gender") %>%
  spread(name, value)

  # merge means and differences
summary_tbl <- bind_rows(summary_tbl1, diff_tbl)%>%
    # format numeric columns
  mutate(across(where(is.numeric), ~round(.,digits=2))) %>%
  mutate(`Earnings` = comma(round(`Earnings`)))%>%
  mutate(across(where(is.numeric), ~sprintf("%.2f", round(.,2))))%>%
  dplyr::select(-contains("total")) %>%
  pivot_longer(cols=-c(child,gender)) %>%
  pivot_wider(names_from=c("gender","child"),values_from = "value") %>%
    # format to add horizontal space in difference columns in latex
  mutate(diff_Women_NA = ifelse(diff_Women_NA < 0, paste0("\\hspace{0.1cm}",diff_Women_NA), 
                             paste0("\\hspace{0.2cm}",diff_Women_NA)),
         diff_Men_NA = ifelse(diff_Men_NA < 0, paste0("\\hspace{0.1cm}",diff_Men_NA), 
                           paste0("\\hspace{0.2cm}",diff_Men_NA))) %>%
  subset(select=c(name, Men_1, Men_0, diff_Men_NA, Women_1, Women_0, diff_Women_NA))

  # reorder rows
summary_tbl <- summary_tbl[c(1,2,3,7,4,8,9,10,11,5,6,12),]

  # don't show row numbers in table
row.names(summary_tbl) <- NULL

  # setting so any NA's in columns are blank in table
options(knitr.kable.NA = '')

  # create latex table
summary_tbl_tex <- kbl(summary_tbl, format="latex",linesep="",escape=F,booktabs=T,
                       align=c('l','c','c','c','c','c','c'),
                       col.names=c("","Child", "No Child","\\textbf{Difference}","Child", 
                                   "No Child", "\\textbf{Difference}")) %>%
  add_header_above(c(" " = 1, "Men" = 3, "Women" = 3)) %>%
  column_spec(c(4,7), bold=T) %>%
  row_spec(11, hline_after=T)

  # save latex
writeLines(summary_tbl_tex, file.path(outdir,"Tables","table_descriptive_stats_xsection.tex"))
