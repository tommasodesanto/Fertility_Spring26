#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates Figure 7 in the paper
# (Scatterplots of adjusted child penalties by state vs unadjusted penalties 
# and counterfactuals by state)
# This file uses penalties data created by "fig_state_eventstudy_heatmaps.R"

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

########## Function to plot scatters of adjusted vs unadjusted penalties
  # and adjusted penalties vs counterfactuals by state

plot_rate_cf <- function(data, depvar, hetero) {
  
  # Graph labels
  if({{depvar}}=="earn_ly"){
    depvarlbl <- "emp_annual"
  }
  if({{depvar}}=="emp_lw"){
    depvarlbl <- "emp_weekly"
  }
  
  # Load dataset with child penalties by state
  penalty <- readRDS(file=file.path(wrkdir,"penalties_state.rds")) %>%
    merge(xwalk, by=c("hetero","fips"), all.x=T) %>%
    filter(depvar == {{depvar}}) %>%
    rename(estimate = penalty)
  
  # Load dataset with unadjusted child penalties by state
  penalty_unadjust <- readRDS(file=file.path(wrkdir,"penalties_state_unadjusted.rds")) %>%
    filter(depvar == {{depvar}}) %>%
    rename(estimate_unadjust = estimate)
  
  # Get counterfactuals for mothers
  cf <- reg_es_state(data = data, depvar={{depvar}},
                               hetero = {{hetero}},interact="census",
                               return_coef="cf")

  
  # Merge dataframes
  rates <- penalty_unadjust %>%
    merge(cf,by=c("hetero","depvar")) %>%
    merge(penalty,by=c("hetero","depvar"))
  
  # Estimate slopes
  reg_penalty <- lm(estimate_unadjust ~ estimate, data = rates)
  reg_cf <- lm(mean_cf ~ estimate, data = rates)
  
  # Define which states to display labels for
  rates_line <- rates %>%
    mutate(greypt="grey",
           greypt_cf="grey")
  rates <- rates %>%
    mutate(hetero_lbl = case_when(hetero %in% c("Utah","California","New York",
                                                "Texas","Florida","Illinois","North Dakota",
                                                "South Dakota","Idaho",
                                                "Pennsylvania") ~ as.character(hetero),
                                  estimate_unadjust %in% c(max(rates$estimate_unadjust),min(rates$estimate_unadjust)) | 
                                    estimate %in% c(max(rates$estimate),min(rates$estimate))
                                                   ~ as.character(hetero),
                                  depvar == "emp_lw" & hetero %in% c("Iowa",
                                    "Wisconsin","Oregon","Kentucky","West Virginia",
                                   "New Jersey","Pennsylvania","Vermont",
                                    "Nebraska","Maryland")
                                  ~ as.character(hetero),
                                  depvar == "earn_ly" & hetero %in% c("Minnesota","Arkansas",
                                                                      "Wisconsin","Kansas",
                                                                      "New Jersey","Colorado","Pennsylvania","Vermont",
                                                                      "Nevada","Oregon","Washington","Nebraska")
                                  ~ as.character(hetero),
                                  hetero == "District of Columbia" ~ "D.C.")) %>%
    mutate(greypt = as.factor(ifelse(is.na(hetero_lbl), "grey", "black"))) %>%
    mutate(hetero_lbl_cf = case_when(hetero %in% c("Utah","California","New York",
                                                "Texas","Florida","Illinois",
                                                "Pennsylvania","Idaho") ~ as.character(hetero),
                                     estimate %in% c(max(rates$estimate),min(rates$estimate)) | 
                                       mean_cf %in% c(max(rates$mean_cf),min(rates$mean_cf))
                                                      ~ as.character(hetero),
                                     depvar == "emp_lw" & hetero %in% c("New Jersey","New Mexico","Minnesota",
                                                                       "Pennsylvania","Mississippi","Maine",
                                                                        "Arizona","District of Columbia",
                                                                        "North Dakota") ~ as.character(hetero),
                                     depvar == "earn_ly" & hetero %in% c("Massachusetts",
                                                                         "New Jersey","Wisconsin","Idaho",
                                                                         "Pennsylvania","Georgia",
                                                                         "District of Columbia","Hawaii",
                                                                         "Washington","Alabama","Arizona","Colorado","Tennessee") ~ as.character(hetero))) %>%
    mutate(hetero_lbl_cf = ifelse(hetero_lbl_cf == "District of Columbia", "D.C.", as.character(hetero_lbl_cf))) %>%
    mutate(greypt_cf = as.factor(ifelse(!is.na(hetero_lbl_cf), "black", "grey")))
  
  rates$greypt <- factor(rates$greypt, levels=c("grey","black"))
  rates$greypt_cf <- factor(rates$greypt_cf, levels=c("grey","black"))
  
  # Axis limits
  if(depvar == "emp_lw"){
    ynudge <- 0.006
    xnudge <- 0
    
    xmin <- 0.1
    xmax <- 0.4
    xskip <- 0.1
    
    ymin <- 0.1
    ymax <- 0.35
    yskip <- 0.05
    
    xpos <- ymin+(ymax-ymin)/3
  }
  if(depvar == "earn_ly"){
    ynudge <- 0.006
    xnudge <- 0
    
    xmin <- 0.1
    xmax <- 0.4
    xskip <- 0.1
    
    ymin <- 0.1
    ymax <- 0.35
    yskip <- 0.05
    
    xpos <- ymin+(ymax-ymin)/3
  
  }
  xtext <- 0.3281
  ytext <- 0.125
  
  # Plot child penalty vs unadjusted child penalty
  rates <- rates %>%
    arrange(greypt)
  scaleFUN <- function(x) sprintf("%.2f", x)
  
  ggplot(rates, aes(y=estimate_unadjust, x=estimate,group=greypt,color=greypt))  +
    stat_smooth(data=rates_line, aes(x=estimate, y=estimate_unadjust),method="lm",
                formula = y ~ x, se=F,color="#D11809") +
    # line and point sizes
    geom_point(size=3) +
    scale_colour_manual(values = c(grey = "#4591d3", black = rgb(26,71,111, maxColorValue = 255)))+
    coord_cartesian(xlim=c(xmin, xmax),ylim=c(ymin, ymax))+
    scale_x_continuous(breaks=seq(xmin, xmax, by=xskip),labels=scaleFUN)+
    scale_y_continuous(breaks=seq(ymin, ymax, by=yskip),labels=scaleFUN)+
    # axis labels
    labs(y="Unscaled Child Penalty (pp)", x=paste("Scaled Child Penalty (%)")) +
    theme_minimal() +
    geom_text(aes(label=hetero_lbl), size=4,position = 
                 position_nudge(x = case_when(
      depvar == "earn_ly" & rates$hetero_lbl == "Oregon" ~ 0.019,
      depvar == "earn_ly" & rates$hetero_lbl == "Colorado" ~ 0.024,
      depvar == "earn_ly" & rates$hetero_lbl == "Texas" ~ 0.013,
      depvar == "earn_ly" & rates$hetero_lbl == "Idaho" ~ 0.017,
      depvar == "earn_ly" & rates$hetero_lbl == "Nevada" ~ 0.019,
      depvar == "earn_ly" & rates$hetero_lbl == "Georgia" ~ 0.019,
      depvar == "earn_ly" & rates$hetero_lbl == "Arkansas" ~ 0.025,
      depvar == "earn_ly" & rates$hetero_lbl == "South Dakota" ~ 0.019,
      depvar == "earn_ly" & rates$hetero_lbl == "Nebraska" ~ 0.024,
      depvar == "earn_ly" & rates$hetero_lbl == "California" ~ -0.003,
      depvar == "earn_ly" & rates$hetero_lbl == "Wisconsin" ~ -0.003,
      depvar == "earn_ly" & rates$hetero_lbl == "Vermont" ~ -0.002,
      depvar == "earn_ly" & rates$hetero_lbl == "New York" ~ 0.001,
      depvar == "earn_ly" & rates$hetero_lbl == "D.C." ~ -0.002,
      depvar == "earn_ly" & rates$hetero_lbl == "Minnesota" ~ -0.002,
      depvar == "earn_ly" & rates$hetero_lbl == "Illinois" ~ 0.019,
      depvar == "earn_ly" & rates$hetero_lbl == "Utah" ~ 0.012,
      depvar == "emp_lw" & rates$hetero_lbl == "Oregon" ~ 0.01,
      depvar == "emp_lw" & rates$hetero_lbl == "Illinois" ~ 0.015,
      depvar == "emp_lw" & rates$hetero_lbl == "Wisconsin" ~ 0.023,
      depvar == "emp_lw" & rates$hetero_lbl == "Tennessee" ~ 0.029,
      depvar == "emp_lw" & rates$hetero_lbl == "Kentucky" ~ 0.025,
      depvar == "emp_lw" & rates$hetero_lbl == "West Virginia" ~ 0.031,
      depvar == "emp_lw" & rates$hetero_lbl == "Alabama" ~ 0.019,
      depvar == "emp_lw" & rates$hetero_lbl == "Nebraska" ~ 0.021,
      depvar == "emp_lw" & rates$hetero_lbl == "D.C." ~ 0.01,
      depvar == "emp_lw" & rates$hetero_lbl == "Idaho" ~ 0.017,
      depvar == "emp_lw" & rates$hetero_lbl == "New York" ~ 0,
      depvar == "emp_lw" & rates$hetero_lbl == "Pennsylvania" ~ -0.003,
      depvar == "emp_lw" & rates$hetero_lbl == "California" ~ -0.002,
      depvar == "emp_lw" & rates$hetero_lbl == "Texas" ~ -0.003,
      TRUE ~ xnudge),
                                                                      y=case_when(
      depvar == "earn_ly" & rates$hetero_lbl %in% c(
                            "South Dakota", "Delaware","Kentucky","Georgia",
                            "West Virginia","Nebraska") ~ -0.007,
      depvar == "earn_ly" & rates$hetero_lbl %in% c("California","Colorado",
                                                    "Illinois","Arkansas","Idaho") ~ 0,
      depvar == "earn_ly" & rates$hetero_lbl %in% c("Texas","Utah","Oregon") ~ -0.005,
      depvar == "earn_ly" & rates$hetero_lbl %in% c("Nevada") ~ -0.005,
      depvar == "earn_ly" & rates$hetero_lbl %in% c("Vermont","Minnesota") ~ 0.004,
      depvar == "earn_ly" & rates$hetero_lbl %in% c("D.C.") ~ 0.002,
      depvar == "earn_ly" & rates$hetero_lbl %in% c("Wisconsin") ~ 0.002,
      depvar == "emp_lw" & rates$hetero_lbl %in% c("Utah","Nebraska",
                                                   "Ohio","North Dakota",
                                                   "D.C.","Wisconsin",
                                                   "West Virginia") ~ -0.006,
      depvar == "emp_lw" & rates$hetero_lbl %in% c("Texas","Idaho") ~ 0,
      depvar == "emp_lw" & rates$hetero_lbl %in% c("Alabama","Illinois") ~ -0.005,
      depvar == "emp_lw" & rates$hetero_lbl %in% c("Kentucky") ~ -0.003,
      depvar == "emp_lw" & rates$hetero_lbl %in% c("New York","California") ~ 0.005,
      depvar == "emp_lw" & rates$hetero_lbl %in% c("Pennsylvania") ~ -0.002,
                                                                                  TRUE ~ ynudge)),hjust=1)+
    annotate("text",label=paste0("Slope = ",
                                 format(round(reg_penalty[["coefficients"]][["estimate"]],digits=3),nsmall=3),
                                 " (", format(round(coef(summary(reg_penalty))[,"Std. Error"][["estimate"]], digits=3),nsmall=3), ")"),
             x=xtext,y=ytext,
             size=8,color="black",check_overlap=T)+
    # theme + grid lines
    theme(axis.line = element_line(colour = "black",size=0.2)) +
    theme(panel.grid.minor.x = element_blank(),
          panel.grid.minor.y = element_blank(),
          legend.position = "none", legend.background=element_blank(),
          axis.text=element_text(size=18),
          axis.title=element_text(size=18))+
    theme(axis.text.x = element_text(vjust = -0.5),
          axis.text.y = element_text(margin = unit(c(0,0.4,0,0), "cm"))
    ) +
    theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)),
          axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)))
  
  ggsave(paste0("baseline_effects_unscaledCP", "_",depvarlbl,".pdf"), plot=last_plot(), device="pdf",
         width=11, height=8, units="in",path=file.path(outdir,"Figures"))
  
  
  # Plot child penalty against counterfactual
  rates <- rates %>%
    arrange(greypt_cf)
  if(depvar == "emp_lw"){
    ynudge <- 0.012
    xnudge <- 0.011
    
    ymin <- 0.5
    ymax <- 1
    yskip <- 0.1
  }
  if(depvar == "earn_ly"){
    ynudge <- 0.012
    xnudge <- 0.011
    
    ymin <- 0.5
    ymax <- 1
    yskip <- 0.1
    
  }
  xtext <- 0.331
  ytext <- 0.55
  
  ggplot(rates, aes(y=mean_cf, x=estimate,group=greypt_cf,color=greypt_cf))  +
    stat_smooth(data=rates_line, aes(x=estimate, y=mean_cf),method="lm",
                formula = y ~ x, se=F,color="#D11809") +
    # line and point sizes
    geom_point(size=3) +
    coord_cartesian(xlim=c(xmin, xmax),ylim=c(ymin, ymax))+
    scale_x_continuous(breaks=seq(xmin, xmax, by=xskip),labels=scaleFUN)+
    scale_y_continuous(breaks=seq(ymin, ymax, by=yskip),labels=scaleFUN)+
    scale_colour_manual(values = c(grey = "#4591d3", black = rgb(26,71,111, maxColorValue = 255)))+
    geom_hline(yintercept=1,linetype='dashed', col = 'black')+
    # axis labels
    labs(x="Scaled Child Penalty (%)", y=paste("Counterfactual Employment Rate for Mothers")) +
    geom_text(aes(label=hetero_lbl_cf), size=4,position = position_nudge(x = case_when(
      depvar == "earn_ly" & rates$hetero_lbl_cf == "Pennsylvania" ~ 0.034,
      depvar == "earn_ly" & rates$hetero_lbl_cf == "Washington" ~ 0.031,
      depvar == "earn_ly" & rates$hetero_lbl_cf == "D.C." ~ 0.008,
      depvar == "earn_ly" & rates$hetero_lbl_cf == "Colorado" ~ 0.02,
      depvar == "earn_ly" & rates$hetero_lbl_cf == "Hawaii" ~ -0.003,
      depvar == "earn_ly" & rates$hetero_lbl_cf == "California" ~ -0.003,
      depvar == "earn_ly" & rates$hetero_lbl_cf == "Georgia" ~ 0.007,
      depvar == "earn_ly" & rates$hetero_lbl_cf == "Idaho" ~ 0.003,
      depvar == "earn_ly" & rates$hetero_lbl_cf == "New York" ~ 0.007,
      depvar == "earn_ly" & rates$hetero_lbl_cf == "Illinois" ~ 0.003,
      depvar == "emp_lw" & rates$hetero_lbl_cf == "D.C." ~ 0.005,
      depvar == "emp_lw" & rates$hetero_lbl_cf == "Missouri" ~ 0.013,
      depvar == "emp_lw" & rates$hetero_lbl_cf == "Texas" ~ 0.003,
      depvar == "emp_lw" & rates$hetero_lbl_cf == "Maine" ~ 0.005,
      depvar == "emp_lw" & rates$hetero_lbl_cf == "Hawaii" ~ 0.002,
      depvar == "emp_lw" & rates$hetero_lbl_cf == "Ohio" ~ 0.006,
      depvar == "emp_lw" & rates$hetero_lbl_cf == "New Mexico" ~ 0.023,
      depvar == "emp_lw" & rates$hetero_lbl_cf == "New Jersey" ~ 0.027,
      depvar == "emp_lw" & rates$hetero_lbl_cf == "Florida" ~ 0.015,
      depvar == "emp_lw" & rates$hetero_lbl_cf == "Illinois" ~ 0.017,
      depvar == "emp_lw" & rates$hetero_lbl_cf == "California" ~ 0.026,
      depvar == "emp_lw" & rates$hetero_lbl_cf == "Pennsylvania" ~ 0.026,
      
                                                                                       TRUE ~ xnudge),
                                                                         y=case_when(
      depvar == "earn_ly" & rates$hetero_lbl_cf %in% c("Florida","Colorado","Alabama","D.C.",
                                                       "Texas","Idaho","Illinois",
                                                       "Utah","Tennessee","Georgia") ~ -0.01,
      depvar == "earn_ly" & rates$hetero_lbl_cf %in% c("Hawaii","Washington","Pennsylvania") ~ 0,
      depvar == "earn_ly" & rates$hetero_lbl_cf %in% c("Massachusetts") ~ 0.008,
      depvar == "earn_ly" & rates$hetero_lbl_cf %in% c("California") ~ 0.002,
      depvar == "emp_lw" & rates$hetero_lbl_cf %in% c("D.C.","Arizona","Utah","New Mexico",
                                                      "Ohio","Pennsylvania","Mississippi",
                                                      "Idaho") ~ -0.01,
      depvar == "emp_lw" & rates$hetero_lbl_cf %in% c("Illinois","California") ~ 0,
      depvar == "emp_lw" & rates$hetero_lbl_cf %in% c("Florida") ~ 0.008,
      depvar == "emp_lw" & rates$hetero_lbl_cf %in% c("Texas") ~ -0.006,
                                                                                     TRUE ~ ynudge)),hjust=1)+
    annotate("text",label=paste0("Slope = ",
                                 format(round(reg_cf[["coefficients"]][["estimate"]],digits=3),nsmall=3),
                                 " (", format(round(coef(summary(reg_cf))[,"Std. Error"][["estimate"]], digits=3),nsmall=3), ")"),
             x=xtext,y=ytext,
             size=8,color="black",check_overlap=T)+
    # theme + grid lines
    theme_minimal() +
    theme(axis.line = element_line(colour = "black",size=0.2)) +
    theme(panel.grid.minor.x = element_blank(),
          panel.grid.minor.y = element_blank(),
          legend.position = "none", legend.background=element_blank(),
          axis.text=element_text(size=18),
          axis.title=element_text(size=18)) +
    theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)),
          axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)))+
    theme(axis.text.x = element_text(vjust = -0.5))+
    theme(axis.text.y = element_text(margin = unit(c(0,0.4,0,0), "cm")))
  
  ggsave(paste0("baseline_effects_counterfactuals","_",depvarlbl,".pdf"), plot=last_plot(), device="pdf",
         width=11, height=8, units="in",path=file.path(outdir,"Figures"))
  
  
  return(rates)
}

# Load data
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

# Crosswalk of state names and fips codes
xwalk = data.frame(fips = ipums_val_labels(cps_acs$statefip)$val, hetero = ipums_val_labels(cps_acs$statefip)$lbl)
# Add state abbreviations
xwalk$abb <- state.abb[match(xwalk$hetero,state.name)]
xwalk <- xwalk %>%
  mutate(abb = ifelse(hetero == "District of Columbia", "DC", abb))

# Run function
lapply(c("emp_lw","earn_ly"),plot_rate_cf,data=subset(cps_acs,statefip<57),hetero="statename")
