#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file cleans CPS data

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))


#########################
#Load data
#########################

load(file.path(rawdir,"CPS", "raw_cps.RData"))
cps <- data
# foreign::write.dta(cps, file=file.path(rawdir,"CPS","raw_cps.dta"))
rm(data)

# variable names
names(cps) <- tolower(names(cps))

# drop double counted march asec obs
cps.clean <- cps %>%
  filter(asecflag != 2 | is.na(asecflag))

#########################
# 1. Demographics
#########################

#vignette("ipums-cps", package = "ipumsr")

cps.clean <- cps.clean %>%
  # 1.1 Children
  
  mutate(child = case_when(nchild > 0 ~ 1,
                           nchild == 0 ~ 0,
                           is.na(nchild) ~ NA_real_)) %>%
  
  mutate(age1b = ifelse(eldch != 99, age - eldch, NA_real_)) %>%
  
  mutate(ch1yob = ifelse(eldch != 99, year - eldch, NA_real_)) %>%
  
  mutate(chtot = nchild)

# 1.2 Education
  # edlevel has missings because cleaning ignores 0-1 (NIU or no schooling),
  # and 999 (missing or unknown)
cps.clean <- cps.clean %>%
  mutate(edlevel = as.factor(case_when(inrange(educ,2, 72) ~ "Below HS",
                                       inrange(educ, 73, 73) ~ "HS grad",
                                       inrange(educ, 80, 100) ~ "Some college",
                                       inrange(educ, 110, 125) ~ "College +"))) %>%
  mutate(edlevel_det = as.factor(case_when(inrange(educ,2, 72) ~ "Below HS",
                                           inrange(educ, 73, 73) ~ "HS grad",
                                           inrange(educ, 80,90) ~ "College dropout",
                                           inrange(educ,91,109) ~ "Associate's degree",
                                           inrange(educ, 110, 122) ~ "Bachelor's degree",
                                           inrange(educ, 123, 125) ~ "Post-graduate degree"))) %>%
  
  mutate(college = case_when(inrange(educ, 2, 100) ~ 0,
                             inrange(educ, 110, 125) ~ 1))

cps.clean <- cps.clean %>%
  mutate(hsandbelow = ifelse(edlevel %in% c("Below HS", "HS grad"), 1, 0))

# 1.3 Marital Status

cps.clean <- cps.clean %>%
  mutate(marst = replace(marst, marst==9, NA_real_)) %>%
  mutate(single = case_when(inrange(marst, 2, 7) ~ 1,
                            !inrange(marst, 2, 7) & !is.na(marst) ~ 0,
                            is.na(marst) ~ NA_real_)) %>%
  mutate(married = as.factor(case_when(marst %in% c(1,2) ~ "Married",
                                       !inrange(marst, 1,2) & !is.na(marst) ~ "Single"))) %>%
  mutate(marst_det = as.factor(case_when(marst == 1 ~ "Married, spouse present",
                                         marst == 2 ~ "Married, spouse absent",
                                         marst == 3 ~ "Separated",
                                         marst == 4 ~ "Divorced",
                                         marst == 5 ~ "Widowed",
                                         marst == 6 ~ "Never married/single",
                                         marst == 7 ~ "Widowed or divorced"))) %>%
  mutate(marst = as.factor(case_when(marst == 1 ~ "Married, spouse present",
                                     inrange(marst, 2,3) ~ "Married, spouse absent",
                                     marst %in% c(4) ~ "Divorced",
                                     marst == 5 ~ "Widowed",
                                     marst == 6 ~ "Never married/single",
                                     marst == 7 ~ "Widowed or divorced")))

# 1.4 Race and ethnicity

  # Hispanic dummy
cps.clean <- cps.clean %>%
  mutate(hispanic = ifelse(inrange(hispan, 100, 700), 1, 0))

names(cps.clean)[names(cps.clean) == 'race'] <- 'temp'

cps.clean <- cps.clean %>%
  # Create detailed race/ethnicity variable with 5 categories  
  mutate(raced = as.factor(case_when(temp == 100 & hispanic == 0 ~ "White, non-hispanic",
                                     temp == 200 & hispanic == 0 ~ "Black, non-hispanic",
                                     inrange(temp, 650, 652) & hispanic == 0 ~ "Asian/PI, non-hispanic",
                                     (temp == 300 | inrange(temp, 700, 830)) & hispanic == 0 ~ "Other, non-hispanic",
                                     hispanic == 1 ~ "Hispanic"))) %>%
    # Numeric version of same var
  mutate(raced.num = as.factor(case_when(temp == 100 & hispanic == 0 ~ 1,
                                         temp == 200 & hispanic == 0 ~ 2,
                                         inrange(temp, 650, 652) & hispanic == 0 ~ 3,
                                         (temp == 300 | inrange(temp, 700, 830)) & hispanic == 0 ~ 4,
                                         hispanic == 1 ~ 5))) %>%
  
  # Create race/ethnicity variable with only 4 categories
  mutate(race = as.factor(case_when(temp == 100 & hispanic == 0 ~ "White, non-hispanic",
                                    temp == 200 & hispanic == 0 ~ "Black, non-hispanic",
                                    inrange(temp, 300, 830) & hispanic == 0 ~ "Other, non-hispanic",
                                    hispanic == 1 ~ "Hispanic"))) %>%
  
  mutate(race.num = as.factor(case_when(temp == 100 & hispanic == 0 ~ 1,
                                        temp == 200 & hispanic == 0 ~ 2,
                                        inrange(temp, 300, 830) & hispanic == 0 ~ 3,
                                        hispanic == 1 ~ 4)))

  # Create race variable (Hispanic is not a separate category, 
    # i.e. Hispanic people are kept within their actual racial category)
cps.clean <- cps.clean %>%
  mutate(race_raw = as.factor(case_when(temp == 100 ~ "White",
                                        temp == 200 ~ "Black",
                                        inrange(temp, 300, 830) ~ "Other")))

  # Race dummies
cps.clean <- cps.clean %>%
  mutate(white = ifelse(race == "White, non-hispanic", 1,0),
         black = ifelse(race == "Black, non-hispanic", 1,0),
         white_hisp = ifelse(race_raw == "White", 1,0),
         black_hisp = ifelse(race_raw == "Black", 1,0))
  
  
# 1.5 Other
  # gender
  cps.clean <- cps.clean %>%
    mutate(gender = as.factor(ifelse(sex==2, "Women", "Men"))) %>%
    
  # age
    
    mutate(age = ifelse(age > 90 & !is.na(age), 90, age))  


  # Cohort
cps.clean <- cps.clean %>%
  
  mutate(doby = year - age) %>%
  
  # health
  
  mutate(health = ifelse(is.na(health), 0, health))

# 1.6 State of residence

cps.clean <- cps.clean %>%
  mutate(statefip = na_if(statefip, 99))

cps.clean$statename = factor(cps.clean$statefip, 
                             levels = ipums_val_labels(cps$statefip)$val, 
                             labels = ipums_val_labels(cps$statefip)$lbl)

#########################
# 2. Work and Income
#########################

# 2.1 Income from wages to create our earnings var
cps.clean <- cps.clean %>%
  mutate(incwage = ifelse(incwage %in% c(99999999, 99999998),NA_real_,
                          incwage)) %>%
  
  mutate(earnings_ly = incwage)

  # Annual employment is created using earnings var
cps.clean <- cps.clean %>%
  mutate(earn_ly = case_when(earnings_ly > 0 & !is.na(earnings_ly) ~ 1,
                             earnings_ly <= 0 & !is.na(earnings_ly) ~ 0,
                             is.na(earnings_ly) ~ NA_real_))

# 2.2 Labor Force Participation

cps.clean <- cps.clean %>%
  mutate(inlf_lw = case_when(inrange(empstat, 1, 22) ~ 1,
                             inrange(empstat, 30, 36) ~ 0,
                             inrange(age, 0, 15) ~ NA_real_)) %>%
  # Weekly employment var
  mutate(emp_lw = case_when(inrange(empstat, 1, 12) ~ 1,
                            inrange(empstat, 20, 36) ~ 0,
                            inrange(age, 0, 15) ~ NA_real_))
cps.clean <- cps.clean %>%
  mutate(unemp_lw = NA_real_) %>%
  mutate(unemp_lw = case_when(inrange(empstat, 20, 22) ~ 1,
                              inrange(empstat, 1, 12) ~ 0,
                              TRUE ~ unemp_lw))

# Usual hours worked per week: need to top code at 99 to match ACS
# 1994-1998 ASEC: 0 = hours vary, NIU, or no hours
# 1994-onward basic monthly or 1999-onward ASEC: 0 = no hours, 997 = hours vary, 999 = NIU
#cps.clean <- cps.clean %>%
#  mutate(uhrswork = uhrsworkt) %>%
#  mutate(uhrswork = case_when(inrange(year, 1994, 1998) & asecflag == 1 
#                              & uhrswork == 0 ~ NA_real_,
#                              year >= 1994 & is.na(asecflag) & uhrswork == 0 ~ 0,
#                              year >= 1994 & is.na(asecflag) 
#                              & uhrswork %in% c(997,999) ~ NA_real_,
#                              year >= 1999 & asecflag == 1 & uhrswork == 0 ~ 0,
#                              year >= 1999 & asecflag == 1 
#                              & uhrswork %in% c(997,999) ~ NA_real_,
#                              TRUE ~ as.numeric(uhrswork))) %>%
#  mutate(uhrswork = case_when(inrange(uhrswork, 100, 996) ~ 99,
#                              TRUE ~ as.numeric(uhrswork)))

# Usual hours worked per week (last yr), top coded at 99, 999 is NIU
cps.clean <- cps.clean %>%
  mutate(hrs_ly = ifelse(uhrsworkly == 999, NA_real_,
                           uhrsworkly))


# # 2.3 Structural transformation

# Self-Employed

# classwkr- 0: NIU, 10-14: self-employed, 20-28: wage/salary, 29: unpaid family worker, 99: missing/unknown
cps.clean <- cps.clean %>%
   mutate(classwkr = as.factor(case_when(inrange(classwkr,10,14) ~ "Self-employed",
                                         inrange(classwkr,20,28) ~ "Works for wages",
                                         classwkr %in% c(NA_real_, 0, 29, 99) ~ "Unknown or unemployed")))

# Works in agriculture

cps.clean <- cps.clean %>%
   mutate(agriculture = as.factor(case_when(ind1950 == 105 ~ "Agricultural worker",
                                         inrange(ind1950, 116, 936) ~ "Non-agricultural worker",
                                         ind1950 %in% c(NA_real_, 0, 997, 998) ~ "Unknown or unemployed")))

# Works in industry- 306-499 is manufacturing

cps.clean <- cps.clean %>%
  mutate(industry = as.factor(case_when(inrange(ind1950, 306, 499) ~ "Manufactural worker",
                                        inrange(ind1950, 105, 246) | inrange(ind1950, 506, 936) ~ "Non-manufactural worker",
                                        ind1950 %in% c(NA_real_, 0, 997, 998) ~ "Unknown or unemployed")))


##########################
# 3. Geographic
##########################


# 3.1 Residence

  # State groups

cps.clean <- cps.clean %>%
  mutate(stateagg = as.factor(case_when(
    statename %in% c("Georgia","North Carolina-South Carolina","North Carolina",
                     "South Carolina","South Carolina-Georgia") ~ "North Carolina-South Carolina-Georgia",
    statename %in% c("Kentucky","Tennessee") ~ "Kentucky-Tennessee",
    statename %in% c("Louisiana","Arkansas-Oklahoma", "Arkansas",
                     "Oklahoma") ~ "Arkansas-Louisiana-Oklahoma",
    statename %in% c("Maryland","West Virginia","Delaware-Virginia",
                     "Delaware","Virginia") ~ "Delaware-Maryland-Virginia-West Virginia",
    statename %in% c("Missouri","Minnesota-Iowa","Nebraska-North Dakota-South Dakota-Kansas",
                     "Minnesota","Iowa","Nebraska","North Dakota","South Dakota","Kansas")
    ~ "Iowa-N Dakota-S Dakota-Nebraska-Kansas-Minnesota-Missouri",
    statename %in% c("Oregon","Alaska-Washington-Hawaii", "Washington","Hawaii","Alaska")
    ~ "Washington-Oregon-Alaska-Hawaii",
    statename %in% c("New Hampshire-Maine-Vermont-Rhode Island", "Massachusetts",
                     "New Hampshire","Maine","Vermont","Rhode Island")
    ~ "Maine-Massachusetts-New Hampshire-Rhode Island-Vermont",
    statename %in% c("Arizona-New Mexico-Colorado","Idaho-Wyoming-Utah-Montana-Nevada",
                     "Montana","Wyoming","Colorado","New Mexico","Utah","Nevada",
                     "Arizona", "Idaho","Montana-Wyoming-Colorado-New Mexico-Utah-Nevada-Arizona")
    ~ "Montana-Wyoming-Colorado-New Mexico-Utah-Nevada-Arizona-Idaho",
    statename %in% c("Michigan","Wisconsin") ~ "Michigan-Wisconsin",
    statename %in% c("Alabama","Mississippi") ~ "Alabama-Mississippi"))) 

cps.clean <- cps.clean %>%
  mutate(stateagg = as.factor(ifelse(is.na(stateagg), as.character(statename),as.character(stateagg))))

  # census divisions and regions (based on census bureau definitions)

cps.clean <- cps.clean %>%
  mutate(census = as.factor(case_when(statename %in% c("Connecticut","Maine","Massachusetts",
                                                       "New Hampshire","Rhode Island","Vermont",
                                                       "Maine-Massachusetts-New Hampshire-Rhode Island-Vermont",
                                                       "New Hampshire-Maine-Vermont-Rhode Island") 
                                      ~ "New England",
                                      statename %in% c("New Jersey", "New York", "Pennsylvania")
                                      ~ "Mid-Atlantic",
                                      statename %in% c("Illinois","Indiana","Michigan",
                                                       "Ohio", "Wisconsin","Michigan-Wisconsin") 
                                      ~ "East North Central",
                                      statename %in% c("Iowa", "Kansas","Minnesota","Missouri",
                                                       "Nebraska","North Dakota","South Dakota","Minnesota-Iowa",
                                                       "Nebraska-North Dakota-South Dakota-Kansas",
                                                       "Iowa-N Dakota-S Dakota-Nebraska-Kansas-Minnesota-Missouri")
                                      ~ "West North Central",
                                      statename %in% c("Delaware","Florida","Georgia","Maryland",
                                                       "North Carolina","South Carolina","Virginia",
                                                       "District of Columbia", "West Virginia","Delaware-Virginia",
                                                       "North Carolina-South Carolina","South Carolina-Georgia",
                                                       "Delaware-Maryland-Virginia-West Virginia")
                                      ~ "South Atlantic",
                                      statename %in% c("Alabama","Kentucky","Mississippi",
                                                       "Tennessee","Alabama-Mississippi","Kentucky-Tennessee") 
                                      ~ "East South Central",
                                      statename %in% c("Arkansas","Louisiana","Oklahoma",
                                                       "Texas","Arkansas-Oklahoma","Arkansas-Louisiana-Oklahoma")
                                      ~ "West South Central",
                                      statename %in% c("Arizona","Colorado","Idaho",
                                                       "Montana","Nevada","New Mexico","Utah","Wyoming",
                                                       "Arizona-New Mexico-Colorado","Idaho-Wyoming-Utah-Montana-Nevada",
                                                       "Montana-Wyoming-Colorado-New Mexico-Utah-Nevada-Arizona")
                                      ~ "Mountain",
                                      statename %in% c("Alaska","California","Hawaii",
                                                       "Oregon","Washington","Alaska-Washington-Hawaii",
                                                       "Washington-Oregon-Alaska-Hawaii")
                                      ~ "Pacific"))) %>%
  mutate(region = as.factor(case_when(census == "New England" | census == "Mid-Atlantic"
                                      ~ "Northeast",
                                      census %in% c("East North Central", "West North Central")
                                      ~ "Midwest",
                                      census %in% c("South Atlantic","East South Central",
                                                    "West South Central") ~ "South",
                                      census %in% c("Mountain","Pacific") ~ "West")))

  ## modified census regions

cps.clean <- cps.clean %>%
  mutate(census_modified = as.factor(case_when(statename %in% c("Minnesota","Wisconsin","North Dakota", "South Dakota") 
                                               ~ "North Central",
                                               statename %in% c("Michigan", "Illinois","Indiana", "Ohio")
                                               ~ "Great Lakes",
                                               statename %in% c("New Jersey","New York","Pennsylvania","Delaware",
                                                                "Maryland","District of Columbia")
                                               ~ "Mid-Atlantic",
                                               statename %in% c("Connecticut","Maine","Massachusetts","New Hampshire",
                                                                "Rhode Island","Vermont") ~ "New England",
                                               statename %in% c("Alaska","Hawaii","California","Oregon","Washington") ~ "Pacific",
                                               statename %in% c("Utah","Colorado","Arizona","New Mexico","Nevada") ~
                                                 "Southwest",
                                               statename %in% c("Idaho","Wyoming","Montana") ~
                                                 "Northwest",
                                               statename %in% c("Nebraska","Iowa","Kansas","Missouri") ~
                                                 "Central",
                                               statename %in% c("Arkansas","Louisiana","Oklahoma","Texas","Alabama",
                                                                "Kentucky","Mississippi","Tennessee") ~
                                                 "South Central",
                                               statename %in% c("Virginia","West Virginia","Florida","Georgia",
                                                                "South Carolina","North Carolina") ~
                                                 "South Atlantic")))

  # Red, blue, swing states

cps.clean <- cps.clean %>%
  mutate(electoral = as.factor(case_when(statename %in% c("Washington","Oregon","California","Nevada","Colorado",
                                                          "New Mexico","Minnesota","Illinois","Virginia",
                                                          "Maine","New Hampshire","Vermont","Massachusetts",
                                                          "New York","Rhode Island","Connecticut",
                                                          "New Jersey","Delaware","Maryland","District of Columbia",
                                                          "Hawaii") ~ "Blue State",
                                         statename %in% c("Montana","Idaho","Wyoming","Utah","North Dakota",
                                                          "South Dakota","Nebraska","Kansas","Oklahoma",
                                                          "Texas","Arkansas","Mississippi","Alabama","Louisiana",
                                                          "Missouri","Kentucky","South Carolina","Alaska",
                                                          "West Virginia","Tennessee")
                                         ~ "Red State",
                                         statename %in% c("Arizona","Wisconsin","Michigan","Pennsylvania",
                                                          "Indiana","North Carolina","Florida","Iowa","Ohio",
                                                          "Georgia") ~
                                           "Swing State")))

  ## metro vs non-metro

cps.clean <- cps.clean %>%
  mutate(metro = as.factor(case_when(metro %in% c(2,3,4) ~ "Metro",
                                     metro == 1 ~ "Non-Metro",
                                     metro == 0 ~ NA_character_)))

## county
  # to preserve confidentiality only 45% of households in recent years have an identified county
  # comparable over time but doesn't account for boundary changes
  # format: statefip combined with 3 digit countyfip code
  # ACS does not have statefip before county code so they are not comparable as is

cps.clean <- cps.clean %>%
  mutate(county = ifelse(county == 0, NA_character_, str_pad(as.character(county),5,pad="0"))) %>%
  mutate(countyfip = substr(county, 3, 5))

# fix dade county change in florida (no other changes relevant to us based on census documentation)
cps.clean <- cps.clean %>%
  mutate(countyfip = ifelse(countyfip == "000", NA_character_, countyfip)) %>%
  mutate(county = ifelse(is.na(countyfip), NA_character_, county))

## 3.2 birth place

# bpl crosswalk to add name from ipums labels
xwalk_bpl <- data.frame(bpl = ipums_val_labels(cps.clean$bpl)$val,bpl_name = ipums_val_labels(cps.clean$bpl)$lbl)
cps.clean <- merge(cps.clean, xwalk_bpl, by="bpl", all.x=T)

# clean to get as close to ACS as possible
cps.clean <- cps.clean %>%
  mutate(bpl_region = as.factor(case_when(bpl==9900 ~ "United States",
                                          inrange(bpl, 10000, 10750) | inrange(bpl, 11500, 12090) ~ "US Outlying Areas/Territories",
                                          bpl == 11000 ~ "Latin America",
                                          inrange(bpl, 15000, 15000) ~ "North America",
                                          bpl == 16010 | bpl == 19900 ~ "North America",
                                          inrange(bpl, 20000, 20000) ~ "Latin America",
                                          inrange(bpl, 21010, 21010) ~ "Caribbean",
                                          inrange(bpl, 21020, 21070) ~ "Latin America",
                                          inrange(bpl, 21090, 21090) ~ "Other Central America", #Unknown
                                          inrange(bpl, 25000, 26020) ~ "Latin America",
                                          inrange(bpl, 26030, 26091) ~ "Caribbean",
                                          inrange(bpl, 30005, 30030) ~ "Latin America",
                                          inrange(bpl, 30040, 30040) ~ "Other South America", #Guyana,
                                          inrange(bpl, 30050, 30070) ~ "Latin America",
                                          inrange(bpl, 30090, 30090) ~ "Other South America",
                                          inrange(bpl, 31000, 31000) ~ "Other Americas",
                                          inrange(bpl, 40000, 49900) ~ "Europe",
                                          inrange(bpl, 50040, 52200) | inrange(bpl, 55100, 55500) ~ "Asia",
                                          inrange(bpl, 50000, 50010) ~ "Asia",
                                          inrange(bpl, 53000, 54700) ~ "Middle East",
                                          inrange(bpl, 59900, 59900) ~ "Asia",
                                          inrange(bpl, 60010, 60099) ~ "Africa",
                                          inrange(bpl, 70010, 72000) ~ "Oceania",
                                          bpl == 96000 ~ "Other or Unknown",
                                          bpl == 99999 ~ NA_character_
  )))


# create placeholder census division of birth var
cps.clean <- cps.clean %>%
  mutate(bpl_census = NA_character_)

# additional cleaning for country of birth var
cps.clean <- cps.clean %>%
  mutate(bpl_name = as.factor(case_when(bpl_name == "Azores" ~ "Portugal",
                              bpl_name == "Byelorussia" ~ "Belarus",
                              bpl_name == "Cambodia (Kampuchea)" ~ "Cambodia",
                              bpl_name == "Egypt/United Arab Rep." ~ "Egypt",
                              bpl_name == "Belize/British Honduras" ~ "Belize",
                              bpl_name == "Guyana/British Guiana" ~ "Guyana",
                              bpl_name %in% c("Burma (Myanmar)","Burma") ~ "Myanmar",
                              bpl_name %in% c("Israel/Palestine","Israel") ~ "Israel",
                              bpl_name == "Kirghizia" ~ "Kyrgyzstan",
                              bpl_name == "South Africa (Union of)" ~ "South Africa",
                              bpl_name == "Sri Lanka (Ceylon)" ~ "Sri Lanka",
                              bpl_name %in% c("Congo", "Zaire") ~ "Democratic Republic of Congo",
                              bpl_name %in% c("Africa, ns/nec", "Africa, n.s./n.e.c.") ~ "Africa, unknown",
                              bpl_name %in% c("Americas, ns", "Americas, n.s.") ~ "Americas, unknown",
                              bpl_name %in% c("Asia Minor, ns") ~ "Asia Minor, unknown",
                              bpl_name %in% c("Asia, nec/ns", "Asia, n.e.c./n.s.") ~ "Asia, unknown",
                              bpl_name %in% c("Caribbean, ns", "Caribbean, n.s.") ~ "Caribbean, unknown",
                              bpl_name %in% c("Central America, n.s.") ~ "Central America, unknown",
                              bpl_name %in% c("Central Africa") ~ "Central Africa, unknown",
                              bpl_name %in% c("East Asia, ns") ~ "East Asia, unknown",
                              bpl_name %in% c("Eastern Africa, nec/ns") ~ "East Africa, unknown",
                              bpl_name %in% c("Europe, ns.","Europe, n.s.") ~ "Europe, unknown",
                              bpl_name %in% c("Korea") ~ "South Korea",
                              bpl_name %in% c("North Africa, ns") ~ "North Africa, unknown",
                              bpl_name %in% c("North America, n.s.") ~ "North America, unknown",
                              bpl_name %in% c("Oceania, ns/nec") ~ "Oceania, unknown",
                              bpl_name %in% c("Other, n.e.c.","Other, n.e.c. and unknown", "Other n.e.c.") ~ "Other/Unknown",
                              bpl_name %in% c("South America, ns", "South America, n.s.") ~ "South America, unknown",
                              bpl_name %in% c("Southwest Asia, nec/ns") ~ "Southwest Asia, unknown",
                              bpl_name %in% c("USSR, ns", "Other USSR/Russia", "USSR, n.s.") ~ "Russia",
                              bpl_name %in% c("West Indies, ns") ~ "West Indies, unknown",
                              bpl_name %in% c("Western Africa, ns") ~ "West Africa, unknown",
                              bpl_name %in% c("Western Europe, ns") ~ "Western Europe, unknown",
                              bpl_name %in% c("Yemen Arab Republic (North)") ~ "Yemen",
                              bpl_name %in% c("Bosnia") ~ "Bosnia and Herzegovina",
                              bpl_name %in% c("Czechoslavakia","Czech Republic","Slovakia","Czechoslovakia") ~ "Czech/Slovakia",
                              bpl_name %in% c("Middle East, n.s.") ~ "Middle East, unknown",
                              bpl_name %in% c("Montenego") ~ "Montenegro",
                              bpl_name %in% c("Northern Africa") ~ "North Africa, unknown",
                              bpl_name == "St. Kitts--Nevis" ~ "St. Kitts-Nevis",
                              bpl_name == "St. Vincent and the Grenadi" ~ "St. Vincent",
                              bpl_name == "United States, n.s." ~ "United States, unknown",
                              bpl_name %in% c("U.S. outlying areas, n.s.") ~ "US Territories, unknown",
                              bpl_name %in% c("U.S. Virgin Islands","US Virgin Islands") ~ "US Virgin Islands",
                              bpl_name %in% c("Antigua-Barbuda") ~ "Antigua and Barbuda",
                              bpl_name %in% c("United Kingdom, ns", "United Kingdom, n.s.", "England", "Wales", "Scotland", "Northern Ireland") ~ "UK",
                              TRUE ~ as.character(bpl_name)
                              ))) %>%
  mutate(bpl_region = as.factor(ifelse(bpl_name == "Cyprus", "Europe", as.character(bpl_region)))) %>%
  mutate(bpl_name = as.factor(ifelse(bpl_name == "Georgia", "Republic of Georgia", as.character(bpl_name)))) %>%
  mutate(bpl_region = as.factor(ifelse(bpl_name == "Afghanistan", "Middle East", as.character(bpl_region))))

# Create separate country of birth and place of birth vars
cps.clean <- cps.clean %>%
  mutate(bpl_state = NA_character_) %>%
  mutate(bpl_country = as.factor(ifelse(bpl_region == "United States","United States",as.character(bpl_name))))%>%
  mutate(usmover = NA_character_,
         immigrant = as.factor(ifelse(bpl_region == "United States", "US-Born","Immigrant"))) %>%
  mutate(immigrant = as.factor(ifelse(is.na(bpl_region) | bpl == 96000| bpl_region == "Other or Unknown", NA_character_, as.character(immigrant))))

# 3.3 Parents' birthplace

  # Father's birthplace

xwalk_fbpl <- data.frame(fbpl = ipums_val_labels(cps.clean$fbpl)$val,fbpl_name = ipums_val_labels(cps.clean$fbpl)$lbl)

cps.clean <- merge(cps.clean, xwalk_fbpl, by="fbpl", all.x=T)

  # Mother's birthplace

  # Codes are the same as father's birthplace
xwalk_fbpl <- xwalk_fbpl %>%
  rename(mbpl = fbpl,
         mbpl_name = fbpl_name)

cps.clean <- merge(cps.clean, xwalk_fbpl, by="mbpl", all.x=T)

  # Clean both variables together

cps.clean <- cps.clean %>%
  mutate(across(c(mbpl_name, fbpl_name), .fns=list(cat = ~as.factor(case_when(. == "U.S., n.s." ~ "United States",
                                                              . == "Belize/British Honduras" ~ "Belize",
                                                              . == "North America, n.s." ~ "North America, unknown",
                                                              . == "Central America, n.s." ~ "Central America, unknown",
                                                              . == "Guyana/British Guiana" ~ "Guyana",
                                                              . == "Americas, n.s." ~ "Americas, unknown",
                                                              . %in% c("United Kingdom, n.s.","Northern Ireland",
                                                                       "England","Scotland","Wales") ~ "UK",
                                                              . == "Azores" ~ "Portugal",
                                                              . %in% c("Czechoslavakia","Slovakia","Czech Republic") ~ "Czech/Slovakia",
                                                              . %in% c("Other USSR/Russia","USSR, n.s.") ~ "Russia",
                                                              . == "Europe, n.s." ~ "Europe, unknown",
                                                              . %in% c("South Korea","Korea") ~ "South Korea",
                                                              . %in% c("Burma (Myanmar)","Burma") ~ "Myanmar",
                                                              . == "Middle East, n.s." ~ "Middle East, unknown",
                                                              . == "Georgia" ~ "Republic of Georgia",
                                                              . == "Asia, n.e.c, /n.s." ~ "Asia, unknown",
                                                              . == "Egypt/United Arab Rep." ~ "Egypt",
                                                              . == "Sengal" ~ "Senegal",
                                                              . == "South Africa (Union of)" ~ "South Africa",
                                                              . %in% c("Congo","Zaire") ~ "Democratic Republic of Congo",
                                                              . == "Other, n.e.c. and unknown" ~ "Other/Unknown",
                                                              . == "Africa, n.s./n.e.c." ~ "Africa, unknown",
                                                              . == "Caribbean, n.s." ~ "Caribbean, unknown",
                                                              . == "U.S. outlying aras, n.s." ~ "US outlying areas, unknown",
                                                              . == "West Indies" ~ "West Indies, unknown",
                                                              . == "Northern Africa" ~ "North Africa, unknown",
                                                              . == "Venezuala" ~ "Venezuela",
                                                              TRUE ~ as.character(.)))),
                .names = "{col}"))

###### 3.4 Ancestry

    # only seems to be available 1971-1975
xwalk_ancestry <- data.frame(ancestry = ipums_val_labels(cps.clean$ancestry)$val,
                             ancestry_name = ipums_val_labels(cps.clean$ancestry)$lbl)

cps.clean <- cps.clean %>%
  mutate(ancestry = NA_character_)



#########################
#4. Define sample,
#     ID, weights
#########################

cps.clean <- cps.clean %>%
  
  # 4.1 Unique ID
  
  mutate(asectag = ifelse(is.na(asecwt), 0, 1),
         asec_over_samp = ifelse(asectag == 1 & asecoverp %in% c(1, NA), 1, 0),
         cpsidp = replace(cpsidp, is.na(cpsidp), 0)) %>%
  group_by(year, serial, pernum) %>%
  dplyr::mutate(idasec = cur_group_id()) %>%
  ungroup() %>%
  mutate(idasec = ifelse(asec_over_samp == 1 
                         | (asec_over_samp == 0 & cpsidp == 0), idasec, 0)) %>%
  group_by(cpsidp,idasec,asec_over_samp) %>%
  dplyr::mutate(id = cur_group_id()) %>%
  ungroup()

# 4.2 Weight

cps.clean <- cps.clean %>%
  mutate(wgt = ifelse(is.na(asecwt), wtfinl, asecwt))

# 4.3 Year of interview

cps.clean <- cps.clean %>%
  mutate(doiy = year)

# interview year intervals
cps.clean <- cps.clean %>%
  mutate(yr5 = as.factor(case_when(
    inrange(doiy, 1970, 1979) ~ "1973-79",
    inrange(doiy, 1980, 1984) ~ "1980-84",
    inrange(doiy, 1985, 1989) ~ "1985-89",
    inrange(doiy, 1990, 1994) ~ "1990-94",
    inrange(doiy, 1995, 1999) ~ "1995-99",
    inrange(doiy, 2000, 2004) ~ "2000-04",
    inrange(doiy, 2005, 2009) ~ "2005-09",
    inrange(doiy, 2010, 2014) ~ "2010-14",
    inrange(doiy, 2015, 2021) ~ "2015-20")))

cps.clean <- cps.clean %>%
  mutate(yr10 = as.factor(case_when(
    inrange(doiy, 1970, 1979) ~ "1973-79",
    inrange(doiy, 1980, 1989) ~ "1980-89",
    inrange(doiy, 1990, 1999) ~ "1990-99",
    inrange(doiy, 2000, 2009) ~ "2000-09",
    inrange(doiy, 2010, 2021) ~ "2010-20")))

# interval year intervals around welfare reform
cps.clean <- cps.clean %>%
  mutate(yr5_reform = as.factor(case_when(
    inrange(doiy, 1973, 1979) ~ "1973-79",
    inrange(doiy, 1980, 1984) ~ "1980-84",
    inrange(doiy, 1985, 1989) ~ "1985-89",
    inrange(doiy, 1990, 1994) ~ "1990-94",
    inrange(doiy, 1995, 1999) ~ "1995-99",
    inrange(doiy, 2000, 2004) ~ "2000-04",
    inrange(doiy, 2005, 2009) ~ "2005-09",
    inrange(doiy, 2010, 2020) ~ "2010-20")))

cps.clean <- cps.clean %>%
  mutate(yr10_reform = as.factor(case_when(
    inrange(doiy, 1973, 1980) ~ "1973-1980",
    inrange(doiy, 1981, 1990) ~ "1981-1990",
    inrange(doiy, 1991, 2000) ~ "1991-2000",
    inrange(doiy, 2001, 2010) ~ "2000-2010",
    inrange(doiy, 2011, 2020) ~ "2011-2020")))

cps.clean <- cps.clean %>%
  mutate(post_reform = as.factor(case_when(
    doiy < 1990 ~ "pre-94",
    inrange(doiy, 1990, 1994) ~ "1990-94",
    doiy > 1994 ~ "post-94")))

# 4.4 Year of immigration
  # There are comparability issues for people who immigrated after 1991
  # Often grouped differently in different survey years
  # Each code represents an interval during which person migrated usually
  # Code itself is the last possible year they could have migrated to the US

# First year of interval
cps.clean <- cps.clean %>%
  mutate(yrimmig1 = case_when(yrimmig == 1949 ~ 1949,
                                        yrimmig == 1959 ~ 1950,
                                        yrimmig == 1964 ~ 1960,
                                        yrimmig == 1969 ~ 1965,
                                        yrimmig == 1974 ~ 1970,
                                        yrimmig == 1979 ~ 1975,
                                        inrange(yrimmig, 1981, 1993) ~ yrimmig - 1,
                                        yrimmig == 1994 ~ 1992,
                                        yrimmig == 1995 & doiy != 1995 ~ 1994,
                                        yrimmig == 1995 & doiy == 1995 ~ 1992,
                                        yrimmig == 1996 ~ 1994,
                                        yrimmig == 1997 & doiy != 1997 ~ 1996,
                                        yrimmig == 1997 & doiy == 1997 ~ 1994,
                                        yrimmig == 1998 & doiy != 2001 ~ 1996,
                                        yrimmig == 1998 & doiy == 2001 ~ 1998, # exact year
                                        yrimmig == 1999 & doiy != 1999 ~ 1998,
                                        yrimmig == 1999 & doiy == 1999 ~ 1996,
                                        yrimmig == 2000 ~ 1998,
                                        yrimmig == 2001 & doiy != 2001 ~ 2000,
                                        yrimmig == 2001 & doiy == 2001 ~ 1998,
                                        yrimmig == 2002 ~ 2000,
                                        yrimmig == 2003 & doiy != 2003 ~ 2002,
                                        yrimmig == 2003 & doiy == 2003 ~ 2000,
                                        yrimmig == 2004 ~ 2002,
                                        yrimmig == 2005 & doiy != 2005 ~ 2004,
                                        yrimmig == 2005 & doiy == 2005 ~ 2002,
                                        yrimmig == 2006 ~ 2004,
                                        yrimmig == 2007 & doiy < 2010 ~ 2004,
                                        yrimmig == 2007 & doiy >= 2010 ~ 2006,
                                        yrimmig == 2008 & !inrange(doiy, 2006, 2007)
                                        ~ 2006,
                                        yrimmig == 2008 & inrange(doiy, 2006, 2007)
                                        ~ 2004,
                                        yrimmig == 2009 & doiy < 2012 ~ 2006,
                                        yrimmig == 2009 & doiy >= 2012 ~ 2008,
                                        yrimmig == 2010 ~ 2008,
                                        yrimmig == 2011 & doiy < 2014 ~ 2008,
                                        yrimmig == 2011 & doiy >= 2014 ~ 2010,
                                        yrimmig == 2012 ~ 2010,
                                        yrimmig == 2013 & doiy < 2016 ~ 2010,
                                        yrimmig == 2013 & doiy >= 2016 ~ 2012,
                                        yrimmig == 2014 ~ 2012,
                                        yrimmig == 2015 & doiy < 2018 ~ 2012,
                                        yrimmig == 2015 & doiy >= 2018 ~ 2014,
                                        yrimmig == 2016 ~ 2014,
                                        yrimmig == 2017 & doiy < 2019 ~ 2014,
                                        yrimmig == 2017 & doiy >= 2019 ~ 2016,
                                        yrimmig == 2018 ~ 2016,
                                        yrimmig == 2019 ~ 2016,
                                        yrimmig == 2020 ~ 2018,
                                        yrimmig == 2021 ~ 2018,
                                        yrimmig == 0 ~ NA_real_))

# Final year of interval

cps.clean <- cps.clean %>%
  mutate(yrimmig2 = ifelse(yrimmig == 0, NA_real_, yrimmig))

# Calculate midpoint

cps.clean <- cps.clean %>%
  mutate(yrimmig = floor((yrimmig2 + yrimmig1)/2)) %>%
  mutate(ageimmig = yrimmig - doby)

# 4.5 Year of childbirth 

cps.clean <- cps.clean %>%
  mutate(ch1yob10 = as_factor(case_when(inrange(ch1yob, 1972, 1979) ~ "1972-79",
                                        inrange(ch1yob, 1980, 1989) ~ "1980-89",
                                        inrange(ch1yob, 1990, 1999) ~ "1990-99",
                                        inrange(ch1yob, 2000, 2009) ~ "2000-09",
                                        inrange(ch1yob, 2010, 2021) ~ "2010-20"))) %>%
  mutate(ch1yob5 = floor(ch1yob/5)*5)


# 4.6 Select Variables
cps.sample <- cps.clean %>%
  subset(select=c(doiy, month, serial, pernum, wgt, id, statefip, statename, stateagg,
                  age, gender, edlevel, college, hsandbelow,
                  eldch, age1b, marst, married, doby, ch1yob, race, race_raw,
                  white, black, white_hisp, black_hisp, hispanic, ch1yob5, ch1yob10,
                  emp_lw, earnings_ly, earn_ly,
                  child, nchild,fbpl_name, mbpl_name,ancestry,
                  bpl_census,bpl_state,bpl_country,immigrant, usmover,
                  yr5, yr10, yr5_reform, yr10_reform, post_reform,
                  census, region, metro,yrimmig, ageimmig, classwkr, agriculture, industry, hrs_ly))

# 4.6 Select years
cps.sample <- cps.sample %>%
  filter((inrange(doiy, 1968, 1988) & month == 3) | doiy > 1988) %>% # drop monthly files until 89
  filter(doiy < 2021)

  # Indicator for dataset
cps.sample <- cps.sample %>%
  mutate(dataset = as.factor("CPS")) %>%
  mutate(dataset = factor(dataset, levels = c("CPS", "ACS", "NLSY79", "PSID")))

  # Before full sample selection for summary tables
save(cps.sample, file=file.path(cleandir,"cps_preselect.RData"))

# 4.7 Remaining sample selection

  # Missing sample weights, matching variables
cps.sample <- cps.sample %>%
  subset(!(wgt<=0 | is.na(wgt)) & !is.na(statefip) & !is.na(child) & inrange(age, 15, 65)) %>%
  drop_na(edlevel, married)

rm(cps.clean, cps)

# 4.8 generate factor variables to use in regression for fixed effects 
cps <- cps.sample %>%
  mutate(age_factor = as.factor(age)) %>%
  mutate(doiy_factor = as.factor(doiy))  %>%
  mutate(age_gender = interaction(age_factor, gender)) %>%
  mutate(doiy_gender = interaction(doiy_factor, gender))


# save cleaned files
save(cps, file=file.path(cleandir,"cps_clean.RData"))

# Label variables
cps <- apply_labels(cps, emp_lw = "Weekly Employment", earn_ly = "Annual Employment",
                    earnings_ly = "Earnings", doiy = "Year of Intervew",
                    wgt = "Survey Weight", id = "Unique Identifier",
                    statefip = "State of Residence (FIPS)", statename = "State of Residence",
                    stateagg = "State of Residence Groups",
                    age1b = "Age at First Birth", ch1yob = "Year of Birth of Oldest Child",
                    child = "Indicator for Parents", fbpl_name = "Father's Place of Birth",
                    mbpl_name = "Mother's Place of Birth", bpl_census = "Census Division of Birth",
                    bpl_country = "Country of Birth", census = "Census Division of Residence",
                    yrimmig = "Year of Immigration", ageimmig = "Age at Immigration",
                    region = "Census Region of Residence")


# save cleaned files with labels
# save(cps, file=file.path(wrkdir,"cps_clean_labelled.RData"))
# foreign::write.dta(cps, file=file.path(wrkdir,"cps_clean_labelled.dta"))
