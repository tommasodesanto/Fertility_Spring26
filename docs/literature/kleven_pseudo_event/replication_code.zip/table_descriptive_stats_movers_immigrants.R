#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates Table 3 in the paper
# (Selection of Movers and Immigrants by Place of Birth)

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Function to produce row with avg of a variable by group and difference
check_significance <- function(data, depvar, hetero, totalobs=F,
                               immigrant=F) {
  
  # Prepare sample we want averages from
  if(!grepl("pooled",depvar)){
  data["depvar"] = data[{{depvar}}]
  data["t_es"] = data[paste0("t_es_",substr({{depvar}}, nchar({{depvar}})-1, nchar({{depvar}})))]
  data["post"] = data[paste0("post_",substr({{depvar}}, nchar({{depvar}})-1, nchar({{depvar}})))]
  data <- data %>%
    drop_na(depvar, age_factor, doiy_factor, t_es) %>%
    droplevels()
  
  } else {
    # if not using pooled employment, we want to use a maximized sample with both weekly emp and annual
      # for CPS our annual emp sample is a subset of weekly (march files vs all)
          # so we use the full CPS weekly emp sample
      # for ACS the annual emp sample is actually bigger so we take this sample
    data <- data %>%
      filter((dataset=="CPS" & !is.na(t_es_lw)) | (dataset=="ACS" & (!is.na(t_es_ly))))
  }
  
  # Add indicator for below or above median birth state based on stayers penalties
  if(immigrant){ # Foreign immigrant columns
    
    # keep foreign born only
    data <- data  %>%
      filter(immigrant == "Immigrant") %>%
      droplevels()
    
    # load cp atlas penalties (penalties IN country of birth) for immigrant sample
    pdata <- read_excel(file.path(rawdir,"Global Child Penalties","global_penalties.xlsx")) %>%
      rename(penalty_global = penalty) %>%
      filter(!(country %in% c("Czech Republic","Slovakia"))) %>%
      rename(bpl_country = country) %>%
      select(bpl_country,penalty_global)
    
    # read in pooled employment penalties
    pdata_us <- readRDS(file=file.path(wrkdir,"penalties_immigrants.rds")) %>%
      rename(bpl_country = hetero) %>%
      select(bpl_country,penalty)
    
    # merge
    pdata <- merge(pdata, pdata_us, by="bpl_country")%>%
      mutate(penalty_global = ifelse(penalty_global < 0, 0, penalty_global)) # treat negatives as 0
    
    # Re-order in ascending order of penalties for immigrants
    pdata <- arrange(pdata, penalty)
    
    # define high vs low penalty groups
      # high = top quartile of penalty in country of birth, low = bottom
    pdata <- pdata %>%
      mutate(med = ntile(penalty_global, n=4)) %>%
      filter(med %in% c(1,4)) %>%
      mutate(high_penalty = as.factor(ifelse(med == 4, "High Penalty", "Low Penalty"))) %>%
      select(bpl_country, penalty, penalty_global, high_penalty)
    
    # add high and low penalty indicator to full dataset
    data <- merge(data, pdata, by="bpl_country") %>%
      droplevels()
    
    # calculate average penalty in high penalty and low penalty countries (simple average)
    averages <- pdata %>%
      group_by(high_penalty) %>%
      summarize(
        mean_birth = mean(penalty_global),
        mean_movers = mean(penalty)) %>%
      pivot_longer(cols=c(mean_birth, mean_movers), names_to="hetero") %>%
      spread(high_penalty, value) %>%
      mutate(hetero = ifelse(hetero == "mean_movers", "Employment Penalty for Movers/Immigrants",
                             "Employment Penalty in Place of Birth")) %>%
      mutate(diff = round(`High Penalty` - `Low Penalty`, 2))
    
  } else { # US-Born
    
    # keep movers only for table
    data <- data  %>%
      filter(!is.na(bpl_state)) %>%
      droplevels()
    data <- data %>%
      filter(statename != bpl_state)
    
    # use us stayer penalties to define high vs low penalty groups
    pdata <- readRDS(file=file.path(wrkdir,"penalties_movers_vs_stayers_state_of_birth.rds"))%>%
      filter((grepl("stayers",spec_lbl) | grepl("movers",spec_lbl)) & depvar == {{depvar}}) %>%
      mutate(spec = ifelse(grepl("stayers",spec_lbl),"stayers","movers")) %>%
      select(hetero, penalty, spec) %>%
      spread(spec, penalty) %>%
      mutate(med = ntile(stayers, n=4)) %>%
      filter(med %in% c(1,4)) %>%
      rename(bpl_state = hetero) %>%
      mutate(high_penalty = as.factor(ifelse(med == 4, "High Penalty", "Low Penalty"))) %>%
      select(bpl_state, high_penalty, stayers, movers)
    
    data <- merge(data, pdata, by="bpl_state")
    
    # average penalty in high vs low penalty states
    averages <- pdata %>%
      group_by(high_penalty) %>%
      summarize(
        mean_birth = mean(stayers),
        mean_movers = mean(movers)) %>%
      pivot_longer(cols=c(mean_birth, mean_movers), names_to="hetero") %>%
      spread(high_penalty, value) %>%
      mutate(hetero = ifelse(hetero == "mean_movers", "Employment Penalty for Movers/Immigrants",
                             "Employment Penalty in Place of Birth")) %>%
      mutate(diff = round(`High Penalty` - `Low Penalty`, 2))
  }
  
  if(totalobs) { # Getting number of obs instead of mean of var
    
    counts <- data %>%
      count(high_penalty) %>%
      mutate(hetero = "Number of Observations") %>%
      spread(high_penalty, n) %>%
      mutate(diff = NA_character_)
    
    counts <- counts %>%
      mutate(across(where(is.numeric), ~as.character(comma(round(.)))))
    
  } else { # Getting avg of a variable for table
    
    if(!grepl("penalty",hetero)){
      
      if(hetero == "fraction_high") { # want fraction living in high penalty states rather than born
        
        pdata <- readRDS(file=file.path(wrkdir,"penalties_movers_vs_stayers_state_of_birth.rds"))%>%
          filter((grepl("stayers",spec_lbl) | grepl("movers",spec_lbl)) & depvar == {{depvar}}) %>%
          mutate(spec = ifelse(grepl("stayers",spec_lbl),"stayers","movers")) %>%
          select(hetero, penalty, spec) %>%
          spread(spec, penalty) %>%
          mutate(med = ntile(stayers, n=4)) %>%
          rename(statename = hetero) %>%
          mutate(hetero = ifelse(med == 4, 1, 0)) %>%
          select(statename, hetero)
        
        data <- merge(data, pdata, by="statename", all.x=T)
        
        counts <- data %>%
          group_by(high_penalty) %>%
          summarize(mean = weighted.mean(hetero, wgt_match)) %>%
          mutate(hetero = "Fraction in High-Penalty States") %>%
          spread(high_penalty, mean) %>%
          mutate(diff = round(`High Penalty` - `Low Penalty`, 2))
        
      } else { # all other vars: get mean by group
        
        data["hetero"] = data[{{hetero}}] 
        
        data <- data %>%
          drop_na(hetero) %>%
          droplevels()
        
        counts <- data %>%
          group_by(high_penalty) %>%
          summarize(mean = weighted.mean(hetero, wgt_match)) %>%
          mutate(hetero = var_label(data$hetero)) %>%
          spread(high_penalty, mean) %>%
          mutate(diff = round(`High Penalty` - `Low Penalty`, 2))
        
      }
      
    } else {
      counts <- averages
      
    }
    
    # format variables
    
    if(grepl("earnings",hetero)){
      counts <- counts %>%
        mutate(across(where(is.numeric), ~as.character(comma(round(.)))))
    } else {
      counts <- counts %>%
        mutate(across(where(is.numeric), ~sprintf("%.2f", round(ifelse(. == 0, 0, .), 2))))
    }
    
    counts <- counts %>%
      mutate(diff = ifelse(diff < 0, paste0("\\hspace{0.1cm}",diff), paste0("\\hspace{0.2cm}",diff)))
  }
  
  return(counts)
}

# Load CPS and ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

# Transform some factor variables to numeric for table
cps_acs <- cps_acs %>%
  mutate(married = ifelse(married == "Married",1,0))
cps_acs <- cps_acs %>%
  mutate(hsandbelow = ifelse(edlevel %in% c("Below HS","HS grad"), 1, 0))

# Redefine cohort for table to exactly be year - age
cps_acs <- cps_acs %>%
  mutate(doby = doiy - age)

# Label variables
cps_acs <- apply_labels(cps_acs, white_hisp = "Fraction White",
                        college = "Fraction College",
                        married = "Fraction Married",
                        age = "Age",
                        age1b = "Age at First Birth",
                        doiy = "Year",
                        doby = "Cohort",
                        nchild = "Fertility",
                        earn_ly = "Annual Employment Rate",
                        emp_lw = "Weekly Employment Rate", 
                        black_hisp = "Fraction Black",
                        hsandbelow = "Fraction High School or Below")

# keep parents only
cps_acs <- filter(cps_acs, child == 1)




# Create table

# use annual emp/maximized employment sample for us mover cols
# use pooled emp sample for immigrant cols
matched_diff_1 <- setDF(rbindlist(lapply(c("fraction_high","hsandbelow","college","married","black_hisp","white_hisp","nchild","age1b","age","doby"),
                                            check_significance,data=filter(cps_acs, gender=="Women"), depvar="earn_ly"),fill=TRUE)) %>%
  bind_rows(check_significance(data=filter(cps_acs, gender=="Women"),hetero="", totalobs=T, depvar="earn_ly"))%>%
  mutate(gender = "US") %>%
  bind_rows(setDF(rbindlist(lapply(c("fraction_high","hsandbelow","college","married","black_hisp","white_hisp","nchild","age1b","age","doby"),
                                   check_significance,data=filter(cps_acs, gender=="Women"), depvar="pooled_employment", immigrant=T),fill=TRUE))) %>%
  bind_rows(check_significance(data=filter(cps_acs, gender=="Women"),hetero="", totalobs=T, depvar="pooled_employment", immigrant=T))%>%
  mutate(gender = ifelse(is.na(gender),"Foreign",gender)) %>%
  rename(name = hetero)
matched_diff_1[,1] <- rep(c("Fraction in High-Penalty States","Fraction High School or Below","Fraction College","Fraction Married","Fraction Black",
                            "Fraction White","Fertility","Age at First Birth","Age","Cohort","Number of Observations"),times=2)

matched_tbl <- matched_diff_1 %>%
  pivot_wider(names_from=c("gender"),values_from = c("High Penalty", "Low Penalty","diff")) %>%
  subset(select=c(name,`High Penalty_US`, `Low Penalty_US`, diff_US,
                  `High Penalty_Foreign`, `Low Penalty_Foreign`, diff_Foreign))



row.names(matched_tbl) <- NULL


# Create latex table

options(knitr.kable.NA = '')
matched_tbl_tex <- kbl(matched_tbl, format="latex",
                        linesep="",
                        escape=F,
                        booktabs=T,
                        align=c('l','c','c','c','c','c','c'),
                        # caption="Descriptive Statistics in the Pseudo-Panel (Movers vs Stayers)",
                        row.names=NA,
                        col.names=c("","High-Penalty States", "Low-Penalty States",
                                    "\\textbf{Difference}","High-Penalty Countries", "Low-Penalty Countries",
                                    "\\textbf{Difference}")) %>%
  column_spec(column =2:4, width="0.5in") %>%
  column_spec(column =5:7, width="0.7in") %>%
  add_header_above(c(" " = 1, "A. Movers by State of Birth" = 3, 
                     "B. Immigrants by Country of Birth" = 3), bold=T) %>%
  row_spec(10, hline_after=T) %>%
  column_spec(c(4,7), bold=T)

# Save table
writeLines(matched_tbl_tex, file.path(outdir,"Tables","table_descriptive_stats_movers_vs_immigrants.tex"))


########### Tables for slides with separated panels

row.names(matched_tbl) <- NULL

# We have more room for text for tables in the slides
if ("Fraction in High-Penalty States" %in% matched_tbl$name){
  matched_tbl[matched_tbl$name=="Fraction in High-Penalty States","name"] <- "Fraction Living in High-Penalty States"
}


# A. US Movers
options(knitr.kable.NA = '')
matched_tbl_us <- kbl(subset(matched_tbl, select=c(name,`High Penalty_US`, `Low Penalty_US`, diff_US)), format="latex",
                       linesep="",
                       escape=F,
                       booktabs=T,
                       align=c('l','c','c','c'),
                       # caption="Descriptive Statistics in the Pseudo-Panel (Movers vs Stayers)",
                       row.names=NA,
                       col.names=c("","High-Penalty States", "Low-Penalty States",
                                   "\\textbf{Difference}")) %>%
  column_spec(column =2:7, width="1in") %>%
  add_header_above(c(" " = 1, "US Movers by State of Birth" = 3), bold=T) %>%
  row_spec(10, hline_after=T) %>%
  column_spec(c(4), bold=T) %>%
  pack_rows("Demographic Characteristics of Mothers:", 1, nrow(matched_tbl), italic=T,
            latex_gap_space="0.5em",extra_latex_after = "\\addlinespace[0.2em]")

writeLines(matched_tbl_us, file.path(outdir,"Tables","table_descriptive_stats_movers_slides.tex"))

# B. Foreign immigrants
options(knitr.kable.NA = '')
matched_tbl_imm <- kbl(subset(matched_tbl, select=c(name,
                                                      `High Penalty_Foreign`, `Low Penalty_Foreign`, diff_Foreign)), format="latex",
                        linesep="",
                        escape=F,
                        booktabs=T,
                        align=c('l','c','c','c'),
                        # caption="Descriptive Statistics in the Pseudo-Panel (Movers vs Stayers)",
                        row.names=NA,
                        col.names=c("","High-Penalty Countries", "Low-Penalty Countries",
                                    "\\textbf{Difference}")) %>%
  column_spec(column =2:7, width="1in") %>%
  add_header_above(c(" " = 1, 
                     "US Immigrants by Country of Birth" = 3), bold=T) %>%
  row_spec(10, hline_after=T) %>%
  column_spec(c(4), bold=T) %>%
  pack_rows("Demographic Characteristics of Mothers:", 1, nrow(matched_tbl), italic=T,
            latex_gap_space="0.5em",extra_latex_after = "\\addlinespace[0.2em]")

writeLines(matched_tbl_imm, file.path(outdir,"Tables","table_descriptive_stats_immigrants_slides.tex"))
