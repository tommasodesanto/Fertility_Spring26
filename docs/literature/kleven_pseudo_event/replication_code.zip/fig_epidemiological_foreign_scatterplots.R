#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates Figure A.22 and 16 in the paper
# (Scatterplots and Binscatters of Child Penalties for Immigrants)

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Function to create all plots
fig_foreign_scatter <- function(data, depvar, hetero, plotname="", spec="nocontrols",
                                weight_reg = "wgt_match", drop_hongkong = F, 
                                FEinteract_imm = T, FEinteract_movers = F,
                                final_filename = T) {
  
  
  # Graph labels
  depvarlbl <- "emp_pooled"
  
  # Permutation labels
  if (final_filename){
    imm_lbl <- ""
    movers_lbl <- ""
    imm_movers_lbl <- ""
  } else{
    if (FEinteract_imm){
      imm_perm_lbl <- "interact"
      if(weight_reg == "wgt"){
        imm_lbl <- "_reg_wgt_interact"
      }
      if (weight_reg == "wgt_match"){
        imm_lbl <- "_reg_wgtmatch_interact"
      }
    } else{
      imm_perm_lbl <- "nointeract"
      if(weight_reg == "wgt"){
        imm_lbl <- "_reg_wgt_nointeract"
      }
      if (weight_reg == "wgt_match"){
        imm_lbl <- "_reg_wgtmatch_nointeract"
      }
    }
    if (FEinteract_movers){
      movers_perm_lbl <- "interact"
      if(weight_reg == "wgt"){
        movers_lbl <- "_reg_wgt_interact"
      }
      if (weight_reg == "wgt_match"){
        movers_lbl <- "_reg_wgtmatch_interact"
      }
    } else{
      movers_perm_lbl <- "nointeract"
      if(weight_reg == "wgt"){
        movers_lbl <- "_reg_wgt_nointeract"
      }
      if (weight_reg == "wgt_match"){
        movers_lbl <- "_reg_wgtmatch_nointeract"
      }
    }
    
    imm_movers_lbl <- paste0("_imm_", imm_perm_lbl, "_movers_", movers_perm_lbl)
  }
  
  #Droplevels
  data <- droplevels(data)
  
  #Create Scandinavia as pooled observations of Denmark, Norway, and Sweden in CPS/ACS
  data <- data %>%
    mutate(bpl_country = case_when(bpl_country == "Denmark" | bpl_country == "Norway" | 
                                     bpl_country == "Sweden" ~ "Scandinavia",
                                   TRUE ~ as.character(bpl_country)))
  data$bpl_country <- as.factor(data$bpl_country)
  
  data["hetero"] <- data[{{hetero}}] 
  
  # Prepare dataset for pooled employment
  data <- data %>%
    mutate(pooled_employment = ifelse(!is.na(t_es_ly) & !is.na(earn_ly), 
                                      earn_ly, emp_lw),
           t_es = as.factor(ifelse(!is.na(t_es_ly) & !is.na(earn_ly), 
                                   as.character(t_es_ly), as.character(t_es_lw))))
  data <- apply_labels(data, pooled_employment="Employment")

  # Read in CP from Atlas Project (Penalties IN country of birth)
  if (drop_hongkong == F){
    global_penalties <- read_excel(file.path(rawdir,"Global Child Penalties","global_penalties.xlsx")) %>%
      filter(!(country %in% c("Czech Republic","Slovakia", "Denmark", "Norway", "Sweden"))) %>%
      rename(hetero = country) %>%
      rename(penalty_global = penalty) %>%
      subset(select=c(hetero,penalty_global))
  }
  if (drop_hongkong == T){
    global_penalties <- read_excel(file.path(rawdir,"Global Child Penalties","global_penalties.xlsx")) %>%
      rename(hetero = country) %>%
      rename(penalty_global = penalty) %>%
      filter(!(hetero %in% c("Czech Republic","Slovakia", "Hong Kong",
                             "Denmark", "Norway", "Sweden"))) %>%
      subset(select=c(hetero,penalty_global))
  }
  
  
  # Vector of countries we use
  l.countries <- unique(global_penalties$hetero)
  
  # Treat negative penalties as zero
  global_penalties <- global_penalties %>%
    mutate(penalty_global = ifelse(penalty_global < 0, 0, penalty_global))
  
  # Keep only selected countries in CPS/ACS data
  data <- data %>%
    filter(hetero %in% l.countries) %>%
    droplevels()
  
  # Load penalties for us immigrants
  if (drop_hongkong == F){
    penalty <- readRDS(file=file.path(wrkdir,paste0("penalties_immigrants",imm_lbl,".rds"))) %>%
      subset(select=-c(depvar, depvar_lab))%>%
      mutate(hetero = as.factor(as.character(hetero)))
  }
  if (drop_hongkong == T){
    penalty <- readRDS(file=file.path(wrkdir,paste0("penalties_immigrants_dropHK",imm_lbl,".rds"))) %>%
      subset(select=-c(depvar, depvar_lab))%>%
      mutate(hetero = as.factor(as.character(hetero)))
  }
  
  
  data["depvar"] <- data[{{depvar}}]
  
  ########## Scatterplots 
  
  # Merge us immigrant penalties and penalties in country of birth
  lab <- merge(global_penalties, penalty, by="hetero")
  
  speclbl <- spec
  
  if(spec == "nocontrols") { # No controls
    
    # Penalty var to use = raw penalties
    lab$penalty_res <- lab$penalty
  
    # Slope for line of best fit
    reg <- lm(penalty_res ~ penalty_global, data = lab)
    slope <- format(round(reg[["coefficients"]][["penalty_global"]],digits=3),nsmall=3)
    se <- format(round(coef(summary(reg))[,"Std. Error"][["penalty_global"]], digits=3),nsmall=3)
    
  } else { # Specifications with controls
    
    # Sample selection
    
      # Keep mothers only
      data_controls <- data %>%
        filter(gender == "Women" & child == 1)
    
    # Specification with all controls: education, age at first birth, marital status,
      # race, fertility, fraction living in high and low penalty states
      controlvars <- c("hsandbelow","college","age1b","frac_married",
                       "white_hisp","black_hisp","fertility","highpenalty","lowpenalty")
  
    # calculate average of all control var among immigrants from each country
    controls <- data_controls %>%
      filter(!is.na(depvar) & !is.na(t_es)) %>%
      group_by(hetero) %>%
      summarize(across(controlvars[!grepl("penalty",controlvars) & !grepl("fertility",controlvars)
                                   & !grepl("age1b",controlvars)], ~weighted.mean(., wgt_match)))
    
    # for some controls, regardless of which sample we have selected, we always want to use mothers only
    mother_controls <- data_controls %>%
      filter(gender == "Women" & child == 1) %>%
      group_by(hetero) %>%
      summarize(fertility = weighted.mean(nchild, wgt_match),
                age1b = weighted.mean(age1b, wgt_match))
    
    controls <- merge(controls, mother_controls, by=c("hetero"), all=T)
    
    # load penalties for movers and stayers
    penalties <- readRDS(file=file.path(wrkdir,paste0("penalties_movers_vs_stayers_state_of_birth",movers_lbl,".rds"))) 
      # keep stayer penalties only
    penalties <- penalties %>%
      filter(spec_lbl == "stayers" & depvar == {{depvar}})
    # define high and low penalty states as bottom and top quartile
    penalties <-  penalties %>%
      mutate(med = ntile(penalty, n=4)) %>%
      rename(statename=hetero) %>%
      mutate(lowpenalty=ifelse(med==1,1,0),
             highpenalty=ifelse(med==4,1,0))%>%
      subset(select=c(statename,highpenalty,lowpenalty))
    
    # add high and low penalty indicators to dataset
    data_controls <- merge(data_controls, penalties,by="statename",all.x=T)
    
    # calculate fraction of people born in each state living in low and high penalty states
    penaltycontrols <- data_controls %>%
      group_by(hetero)%>%
      summarize(lowpenalty=weighted.mean(lowpenalty, wgt_match),
                highpenalty=weighted.mean(highpenalty,wgt_match))
    
    # combine with rest of controls
    controls <- merge(controls, penaltycontrols, by="hetero",all.x=T)
 
    # Add controls to dataset of penalties for immigrants and by country of birth
  lab <- merge(lab, controls, by="hetero")
  
  ##### run regression with controls
  reg <- feols(as.formula(paste("penalty ~ penalty_global +", paste(controlvars, collapse ="+"), sep="")), data = lab)
  
  ##### residualize penalties
  
    # get residuals
  lab$residuals <- reg$residuals
  
    # add effect from global penalty and intercept back to residuals since we only want to residualize by controls
  lab <- lab %>%
    mutate(penalty_res = residuals + reg[["coefficients"]][["penalty_global"]]*penalty_global
           + reg[["coefficients"]][["(Intercept)"]])
  
  ##### add average effect of all controls back
      lab$penalty_res <- lab$penalty_res + (mean(lab$hsandbelow)*reg[["coefficients"]][["hsandbelow"]])
      lab$penalty_res <- lab$penalty_res + (mean(lab$college)*reg[["coefficients"]][["college"]])
      lab$penalty_res <- lab$penalty_res + (mean(lab$frac_married)*reg[["coefficients"]][["frac_married"]])  
      lab$penalty_res <- lab$penalty_res + (mean(lab$age1b)*reg[["coefficients"]][["age1b"]]) 
      lab$penalty_res <- lab$penalty_res + (mean(lab$fertility)*reg[["coefficients"]][["fertility"]]) 
      lab$penalty_res <- lab$penalty_res + (mean(lab$white_hisp)*reg[["coefficients"]][["white_hisp"]])  
      lab$penalty_res <- lab$penalty_res + (mean(lab$black_hisp)*reg[["coefficients"]][["black_hisp"]])  
      lab$penalty_res <- lab$penalty_res + (mean(lab$highpenalty)*reg[["coefficients"]][["highpenalty"]])  
      lab$penalty_res <- lab$penalty_res + (mean(lab$lowpenalty)*reg[["coefficients"]][["lowpenalty"]]) 
  
  }
  
  ##### Plot

  # need a separate df for line of best fit for R to not give error
  data_line <- lab  %>%
    mutate(greypt = "grey")
  
  # define which countries to show labels for
  if (drop_hongkong == F){
    lab <- lab %>%
      mutate(hetero_lbl = case_when(spec == "nocontrols" &
                                      !(hetero %in% c("Belgium", "Switzerland", "Bulgaria", "Austria",
                                                      "Greece","Guatemala", "Lithuania", "Iraq", "Canada",
                                                      "Hong Kong","Bolivia","Guyana", "Chile", "Afghanistan",
                                                      "Costa Rica","Trinidad and Tobago", "Cambodia", "Albania",
                                                      "Honduras", "Romania","Belarus", "Indonesia", "Puerto Rico",
                                                      "Ireland","Taiwan", "Latvia", "Poland", "Finland",
                                                      "Colombia","Venezuela", "Myanmar",
                                                      "Nicaragua","Ecuador","Honduras")) ~ as.character(hetero),
                                    spec %in% c("controls","deciles","quartiles","quintiles") & 
                                      !(hetero %in% c("Belgium", "Lithuania", "Guatemala",
                                                      "Canada","Jamaica", "Latvia", "Haiti",
                                                      "Hong Kong","Bolivia","Afghanistan","Guyana",
                                                      "Trinidad and Tobago","Puerto Rico", "Panama",
                                                      "Greece", "Finland", "Switzerland", "El Salvador",
                                                      "Honduras","Netherlands", "Austria",
                                                      "Romania","Myanmar", "Poland", "Chile",
                                                      "Ireland","Taiwan", "Iraq", "Indonesia",
                                                      "Colombia", "Venezuela", "Bulgaria",
                                                      "Nicaragua","Ecuador","Honduras")) ~ as.character(hetero)
      )) %>%
      mutate(greypt = as.factor(ifelse(is.na(hetero_lbl), "grey", "black")))
  }
  if (drop_hongkong == T){
    lab <- lab %>%
      mutate(hetero_lbl = case_when(spec == "nocontrols" &
                                      !(hetero %in% c("UK","Haiti","Philippines","Belgium",
                                                      "Greece","Australia","France","Canada",
                                                      #"Hong Kong",
                                                      "Bolivia","Afghanistan","Guyana",
                                                      "Costa Rica","Trinidad and Tobago",
                                                      "Peru","Kenya","Honduras","Netherlands",
                                                      "Romania","Myanmar","Ireland","Taiwan",
                                                      "Colombia","Argentina","Venezuela",
                                                      "Nicaragua","Ecuador","Honduras","Brazil")) ~ as.character(hetero),
                                    spec %in% c("controls","deciles","quartiles","quintiles") & 
                                      !(hetero %in% c("UK","Haiti","Philippines","Belgium",
                                                      "Canada","Egypt","Jamaica",
                                                      #"Hong Kong",
                                                      "Bolivia","Afghanistan","Guyana",
                                                      "Trinidad and Tobago","Puerto Rico",
                                                      "Greece","Australia","France",
                                                      "Peru","Honduras","Netherlands",
                                                      "Romania","Myanmar","Ireland","Taiwan",
                                                      "Colombia","Argentina","Venezuela",
                                                      "Nicaragua","Ecuador","Honduras")) ~ as.character(hetero)
      )) %>%
      mutate(greypt = as.factor(ifelse(is.na(hetero_lbl), "grey", "black")))
  }
  
  lab$greypt <- factor(lab$greypt, levels=c("grey","black"))
  
  lab <- lab %>%
    arrange(greypt)
  
  # min and max labels for axes
  ymin <- 0
  ymax <- 0.7
  xmin <- 0
  xmax <- 0.7

  # Default placement of labels on scatterplot
  ynudge <- 0.022
  xnudge <- 0.005
  
  # Check that slope of residualized penalties vs penalties in country of birth matches slope
    # of initial regression that we used to get residualized penalties
  reg2 <- lm(penalty_res ~ penalty_global, data=lab)
  print(paste("Slope with controls:", as.character(round(reg[["coefficients"]][["penalty_global"]],digits=3)),
              ",",
              "Residualized slope:", as.character(round(reg2[["coefficients"]][["penalty_global"]],digits=3))))
  
  # Slope and standard error for plot
  slope <- format(round(reg2[["coefficients"]][["penalty_global"]],digits=3),nsmall=3)
  se <- format(round(coef(summary(reg2))[,"Std. Error"][["penalty_global"]], digits=3),nsmall=3)
  
  # Function for rounded text to use for axes labels
  scaleFUN <- function(x) sprintf("%.2f", x)
  
  # Plot
  ggplot(data=lab, aes(x = penalty_global, y = penalty_res
                       ,group=greypt,color=greypt
                       )) +
    # fitted line using raw data
    stat_smooth(data=data_line, color="#D11809",aes(x=penalty_global, y=penalty_res),method="lm",
                formula = y ~ x, se=F, linewidth=1)  +
    # Point sizes
    geom_point(size=3) +
    # Scale for different point colors
    scale_colour_manual(values = c(grey = "#4591d3", black = rgb(26,71,111, maxColorValue = 255)))+
    # Axes labels
    labs(y = paste("Child Penalty for Immigrants by Country of Birth"), x = "Child Penalty in Country of Birth")+
    # Axes
    coord_cartesian(ylim=c(ymin-0.03,ymax+0.03),xlim=c(xmin-0.03,xmax+0.03))+
    scale_x_continuous(breaks=seq(xmin, xmax, by = 0.1))+
    scale_y_continuous(breaks=seq(ymin, ymax, by = 0.1))+#,labels=scaleFUN)+
    # Theme
    theme_minimal() +
    # Scatter plot label positions
    geom_text(aes(label=hetero_lbl), size=4,
              position = position_nudge(
                x = case_when(
                  #No controls
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Algeria") ~ 0.05,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Argentina") ~ 0.035,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Armenia") ~ 0.058,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Australia") ~ 0.056,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Bangladesh") ~ 0.038,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Brazil") ~ 0.04,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("China") ~ 0.045,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Colombia") ~ 0.05,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Cuba") ~ 0.04,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Czech/Slovakia") ~ 0.094,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Dominican Republic") ~ 0.125,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Ecuador") ~ 0.03,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Egypt") ~ 0.015,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("El Salvador") ~ 0.073,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Ethiopia") ~ -0.008,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("France") ~ 0.048,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Ghana") ~ 0.048,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Germany") ~ 0.062,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Guatemala") ~ 0.028,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Haiti") ~ 0.035,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Hungary") ~ -0.008,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("India") ~ 0.012,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Indonesia") ~ 0.013,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Iran") ~ -0.008,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Iraq") ~ 0.01,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Ireland") ~ 0.04,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Israel") ~ -0.008,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Italy") ~ -0.01,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Jamaica") ~ 0.057,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Japan") ~ 0.045,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Jordan") ~ 0.023,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Kenya") ~ 0.045,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Laos") ~ 0.038,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Malaysia") ~ 0.062,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Mexico") ~ 0.022,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Morocco") ~ -0.008,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Nepal") ~ 0.042,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Netherlands") ~ 0.035,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Nicaragua") ~ -0.006,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Nigeria") ~ -0.01,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Pakistan") ~ 0.023,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Panama") ~ -0.008,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Peru") ~ 0.034,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Philippines") ~ 0.072,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Portugal") ~ 0.058,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Puerto Rico") ~ 0.01,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Russia") ~ -0.008,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Scandinavia") ~ -0.008,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("South Africa") ~ 0.036,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("South Korea") ~ 0.08,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Spain") ~ -0.005,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Sudan") ~ 0.047,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Switzerland") ~ 0.01,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Taiwan") ~ 0,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Thailand") ~ -0.01,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Turkey") ~ 0.02,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Venezuela") ~ 0.025,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Vietnam") ~ 0.055,
                  
                  #Controls
                  spec == "controls" & lab$hetero_lbl %in% c("Albania") ~ 0.05,
                  spec == "controls" & lab$hetero_lbl %in% c("Algeria") ~ 0.05,
                  spec == "controls" & lab$hetero_lbl %in% c("Argentina") ~ 0.064,
                  spec == "controls" & lab$hetero_lbl %in% c("Armenia") ~ 0.058,
                  spec == "controls" & lab$hetero_lbl %in% c("Australia") ~ 0.03,
                  spec == "controls" & lab$hetero_lbl %in% c("Bangladesh") ~ 0.04,
                  spec == "controls" & lab$hetero_lbl %in% c("Belarus") ~ 0.052,
                  spec == "controls" & lab$hetero_lbl %in% c("Belgium") ~ 0.025,
                  spec == "controls" & lab$hetero_lbl %in% c("Brazil") ~ 0.015,
                  spec == "controls" & lab$hetero_lbl %in% c("Bulgaria") ~ 0.02,
                  spec == "controls" & lab$hetero_lbl %in% c("Canada") ~ 0.047,
                  spec == "controls" & lab$hetero_lbl %in% c("Chile") ~ 0.01,
                  spec == "controls" & lab$hetero_lbl %in% c("China") ~ 0.017,
                  spec == "controls" & lab$hetero_lbl %in% c("Colombia") ~ 0.03,
                  spec == "controls" & lab$hetero_lbl %in% c("Costa Rica") ~ 0.072,
                  spec == "controls" & lab$hetero_lbl %in% c("Cuba") ~ -0.005,
                  spec == "controls" & lab$hetero_lbl %in% c("Czech/Slovakia") ~ 0.094,
                  spec == "controls" & lab$hetero_lbl %in% c("Dominican Republic") ~ 0.052,
                  spec == "controls" & lab$hetero_lbl %in% c("Ecuador") ~ 0.05,
                  spec == "controls" & lab$hetero_lbl %in% c("Egypt") ~ 0.038,
                  spec == "controls" & lab$hetero_lbl %in% c("El Salvador") ~ 0.067,
                  spec == "controls" & lab$hetero_lbl %in% c("Ethiopia") ~ 0.025,
                  spec == "controls" & lab$hetero_lbl %in% c("France") ~ 0.048,
                  spec == "controls" & lab$hetero_lbl %in% c("Germany") ~ 0.062,
                  spec == "controls" & lab$hetero_lbl %in% c("Ghana") ~ 0.048,
                  spec == "controls" & lab$hetero_lbl %in% c("Guatemala") ~ 0.043,
                  spec == "controls" & lab$hetero_lbl %in% c("Honduras") ~ 0.03,
                  spec == "controls" & lab$hetero_lbl %in% c("Hungary") ~ -0.008,
                  spec == "controls" & lab$hetero_lbl %in% c("India") ~ 0.013,
                  spec == "controls" & lab$hetero_lbl %in% c("Indonesia") ~ 0.025,
                  spec == "controls" & lab$hetero_lbl %in% c("Iran") ~ -0.006,
                  spec == "controls" & lab$hetero_lbl %in% c("Iraq") ~ 0.027,
                  spec == "controls" & lab$hetero_lbl %in% c("Israel") ~ 0.04,
                  spec == "controls" & lab$hetero_lbl %in% c("Italy") ~ 0.023,
                  spec == "controls" & lab$hetero_lbl %in% c("Jamaica") ~ 0.035,
                  spec == "controls" & lab$hetero_lbl %in% c("Japan") ~ -0.01,
                  spec == "controls" & lab$hetero_lbl %in% c("Jordan") ~ 0.05,
                  spec == "controls" & lab$hetero_lbl %in% c("Kenya") ~ 0.019,
                  spec == "controls" & lab$hetero_lbl %in% c("Laos") ~ 0.038,
                  spec == "controls" & lab$hetero_lbl %in% c("Malaysia") ~ 0.062,
                  spec == "controls" & lab$hetero_lbl %in% c("Mexico") ~ 0.022,
                  spec == "controls" & lab$hetero_lbl %in% c("Morocco") ~ -0.008,
                  spec == "controls" & lab$hetero_lbl %in% c("Nigeria") ~ -0.01,
                  spec == "controls" & lab$hetero_lbl %in% c("Netherlands") ~ 0.04,
                  spec == "controls" & lab$hetero_lbl %in% c("Pakistan") ~ 0.023,
                  spec == "controls" & lab$hetero_lbl %in% c("Peru") ~ 0.034,
                  spec == "controls" & lab$hetero_lbl %in% c("Philippines") ~ 0.072,
                  spec == "controls" & lab$hetero_lbl %in% c("Poland") ~ 0.02,
                  spec == "controls" & lab$hetero_lbl %in% c("Portugal") ~ 0.058,
                  spec == "controls" & lab$hetero_lbl %in% c("Puerto Rico") ~ 0.022,
                  spec == "controls" & lab$hetero_lbl %in% c("Russia") ~ 0.025,
                  spec == "controls" & lab$hetero_lbl %in% c("Scandinavia") ~ -0.008,
                  spec == "controls" & lab$hetero_lbl %in% c("South Africa") ~ 0.057,
                  spec == "controls" & lab$hetero_lbl %in% c("South Korea") ~ 0.08,
                  spec == "controls" & lab$hetero_lbl %in% c("Sudan") ~ 0.02,
                  spec == "controls" & lab$hetero_lbl %in% c("Switzerland") ~ 0.005,
                  spec == "controls" & lab$hetero_lbl %in% c("Spain") ~ 0.042,
                  spec == "controls" & lab$hetero_lbl %in% c("Taiwan") ~ 0.03,
                  spec == "controls" & lab$hetero_lbl %in% c("Thailand") ~ -0.01,
                  spec == "controls" & lab$hetero_lbl %in% c("Turkey") ~ 0.02,
                  spec == "controls" & lab$hetero_lbl %in% c("UK") ~ -0.006,
                  spec == "controls" & lab$hetero_lbl %in% c("Venezuela") ~ 0.02,
                  spec == "controls" & lab$hetero_lbl %in% c("Vietnam") ~ 0.055,
                  TRUE ~ xnudge),
                y=case_when(
                  #No controls
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Algeria", "Armenia", "Australia",
                                                               "China", "Cuba","Ethiopia", "Germany",
                                                               "Ghana", "Haiti", "Israel", "Italy",
                                                               "Jamaica", "Japan", "Kenya", "Laos",
                                                               "Malaysia", "Morocco", "Nigeria",
                                                               "Philippines", "Portugal", "Russia",
                                                               "Scandinavia", "South Korea", "Sudan",
                                                               "Thailand", "Vietnam") ~ 0,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Argentina") ~ -0.02,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Bangladesh") ~ -0.02,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Brazil") ~ -0.005,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Colombia") ~ -0.015,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Czech/Slovakia") ~ 0.012,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Dominican Republic") ~ -0.007,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("El Salvador") ~ -0.013,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("France") ~ 0.003,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Hungary") ~ 0.002,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Iran") ~ -0.008,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Iraq") ~ -0.02,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Ireland") ~ -0.02,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Jordan") ~ -0.02,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Mexico") ~ -0.02,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Nepal") ~ -0.008,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Netherlands") ~ 0.02,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Nicaragua") ~ -0.002,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Panama") ~ -0.002,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Peru") ~ -0.009,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Puerto Rico") ~ -0.02,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Spain") ~ -0.008,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("South Africa") ~ 0.02,
                  spec == "nocontrols" & lab$hetero_lbl %in% c("Venezuela") ~ -0.015,
                  
                  #Controls
                  spec == "controls" & lab$hetero_lbl %in% c("Albania", "Algeria", "Armenia",
                                                             "Belarus", "Costa Rica", "El Salvador", 
                                                             "France", "Germany", "Ghana",
                                                             "Iraq","Israel","Japan", "Jordan",
                                                             "Laos", "Malaysia", "Morocco","Nigeria",
                                                             "Philippines","Portugal",
                                                             "South Korea", "Spain", "Thailand",
                                                             "Vietnam") ~ 0,
                  spec == "controls" & lab$hetero_lbl %in% c("Bangladesh","Bulgaria",
                                                            "China","Colombia","Haiti","Honduras",
                                                             "Puerto Rico", "Russia","Venezuela") ~ -0.02,
                  spec == "controls" & lab$hetero_lbl %in% c("Argentina") ~ 0.005,
                  spec == "controls" & lab$hetero_lbl %in% c("Australia") ~ -0.016,
                  spec == "controls" & lab$hetero_lbl %in% c("Brazil") ~ 0.017,
                  spec == "controls" & lab$hetero_lbl %in% c("Canada") ~ 0.002,
                  spec == "controls" & lab$hetero_lbl %in% c("China") ~ -0.003,
                  spec == "controls" & lab$hetero_lbl %in% c("Cuba") ~ 0.017,
                  spec == "controls" & lab$hetero_lbl %in% c("Czech/Slovakia") ~ 0.012,
                  spec == "controls" & lab$hetero_lbl %in% c("Ecuador") ~ 0,
                  spec == "controls" & lab$hetero_lbl %in% c("Egypt") ~ 0.012,
                  spec == "controls" & lab$hetero_lbl %in% c("Ethiopia") ~ 0.02,
                  spec == "controls" & lab$hetero_lbl %in% c("Guatemala") ~ -0.02,
                  spec == "controls" & lab$hetero_lbl %in% c("Hungary") ~ 0.002,
                  spec == "controls" & lab$hetero_lbl %in% c("Iran") ~ -0.006,
                  spec == "controls" & lab$hetero_lbl %in% c("Italy") ~ -0.017,
                  spec == "controls" & lab$hetero_lbl %in% c("Kenya") ~ 0.02,
                  spec == "controls" & lab$hetero_lbl %in% c("Peru") ~ -0.009,
                  spec == "controls" & lab$hetero_lbl %in% c("Scandinavia") ~ 0.002,
                  spec == "controls" & lab$hetero_lbl %in% c("South Africa") ~ 0.018,
                  spec == "controls" & lab$hetero_lbl %in% c("UK") ~ -0.008,
                  TRUE ~ ynudge)),
              hjust=1)+
    # Slope text
    annotate("text", x=0.45,y=ymax-0.68,
             label=paste0("Slope = ",slope,
                          " (", se, ")"),
             size=8,color="black",hjust=0)+
    # Other theme adjustments
    theme(axis.line = element_line(colour = "black",linewidth=0.2)) +
    theme(panel.grid.minor.x = element_blank(),
          panel.grid.minor.y = element_blank(),
          axis.text=element_text(size=18),
          axis.title=element_text(size=18),
          legend.position = "none",
          legend.key.height = unit(1, "cm"),
          legend.key.size = unit(2, "cm"),
          legend.text = element_text(size=25))+
    theme(
      axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)),
      axis.text.x = element_text(vjust = -0.5),
          axis.text.y = element_text(margin = unit(c(0,0.4,0,0), "cm"))
    ) +
    theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)))
  # Save
  if (drop_hongkong == F){
    ggsave(paste0("epidemiological_immigrants_rawscatter_",spec,"_",depvarlbl,
                  imm_movers_lbl, ".pdf"), 
           plot=last_plot(), device="pdf",
           width=11, height=8, units="in",path=file.path(outdir,"Figures"))
  }
  if (drop_hongkong == T){
    ggsave(paste0("epidemiological_immigrants_rawscatter_",spec,"_",depvarlbl,"_dropHK",
                  imm_movers_lbl, ".pdf"), 
           plot=last_plot(), device="pdf",
           width=11, height=8, units="in",path=file.path(outdir,"Figures"))
  }
  
  
  ######### Binscatter
  
  lab_binned <- lab
    # Split x into deciles
  lab_binned <- arrange(lab_binned, penalty_res)
  lab_binned$decile <- ntile(lab_binned$penalty_global, 10)
  
    # calculate average of x and y within each decile of x
  lab_binned <- lab_binned %>%
    group_by(decile) %>%
    summarize(penalty_global = mean(penalty_global),
              penalty_res = mean(penalty_res))
  
    # line of best fit for binscatter
  reg_binned <- lm(penalty_res ~ penalty_global, data=lab_binned)
  se_binned <- format(round(coef(summary(reg_binned))[,"Std. Error"][["penalty_global"]], digits=3),nsmall=3)
  
  # bootstrapped regression for shaded confidence intervals
  fn_boot <- function(data, index){
    reg <- lm(penalty_res ~ penalty_global, data=data[index,])
    preds <- predict(reg, data)
    return(preds)
  }
  
  # set seed
  set.seed(seed.val)
  # prediction from line of best fit
  lab_binned$prediction <- predict(reg_binned, lab_binned)
  # bootstrap prediction 200 times
  bootreg <-boot(lab_binned, fn_boot, R=200)
  # get confidence intervals from bootstrapping
  bootreg <- as.data.frame(tidy(bootreg)) %>%
    mutate(conf.low = statistic - bias + qnorm(0.025, 0, 1)*std.error,
           conf.high = statistic - bias + qnorm(0.975, 0, 1)*std.error)
  lab_binned <- merge(lab_binned, bootreg, by.x="prediction", by.y="statistic", all=T)
  
  # plot binscatter
  ggplot(data=lab_binned, aes(x = penalty_global, y = penalty_res
  )) +
    # fitted line using raw data
    stat_smooth(data=lab_binned, color="#D11809",aes(x=penalty_global, y=penalty_res),method="lm",
                formula = y ~ x, se=F, linewidth=1)  +
    # confidence intervals
    geom_ribbon(aes(ymin=conf.low,ymax=conf.high),alpha=0.3,show.legend = F,
                colour = NA, fill="#D11809") +
    # point size and colour
    geom_point(size=4, color=rgb(26,71,111, maxColorValue = 255)) +
    # axes labels
    labs(y = paste("Child Penalty for Immigrants by Country of Birth"), x = "Decile of Child Penalty in Country of Birth")+
    # axes
    coord_cartesian(ylim=c(0,0.53),xlim=c(0,0.53))+
    scale_x_continuous(breaks=seq(0, 0.5, by = 0.1))+
    scale_y_continuous(breaks=seq(0, 0.5, by = 0.1))+#,labels=scaleFUN)+
    theme_minimal() +
    # Slope text
    annotate("text",x=0.311,y=0.04,
             label=paste0("Slope = ",
                          format(round(reg_binned[["coefficients"]][["penalty_global"]],digits=3),nsmall=3),
                          " (", se_binned, ")"),
             size=7,color="black",hjust=0)+
    # Other theme adjustments
    theme(axis.line = element_line(colour = "black",linewidth=0.2)) +
    theme(panel.grid.minor.x = element_blank(),
          panel.grid.minor.y = element_blank(),
          axis.text=element_text(size=18),
          axis.title=element_text(size=18),
          legend.position = "none",
          legend.key.height = unit(1, "cm"),
          legend.key.size = unit(2, "cm"),
          legend.text = element_text(size=25))+
    theme(
      axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)),
      axis.text.x = element_text(vjust = -0.5),
      axis.text.y = element_text(margin = unit(c(0,0.4,0,0), "cm"))
    ) +
    theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)))
  # Save
  if (drop_hongkong == F){
    ggsave(paste0("epidemiological_immigrants_binscatter_", spec,"_",depvarlbl,
                  imm_movers_lbl, ".pdf"), 
           plot=last_plot(), device="pdf",
           width=11, height=8, units="in",path=file.path(outdir,"Figures"))
  }
  if (drop_hongkong == T){
    ggsave(paste0("epidemiological_immigrants_binscatter_", spec,"_",depvarlbl,"_dropHK",
                  imm_movers_lbl, ".pdf"), 
           plot=last_plot(), device="pdf",
           width=11, height=8, units="in",path=file.path(outdir,"Figures"))
  }
}

weights_function <- function(drop_hongkong = F, FEinteract_imm = T, FEinteract_movers = F,
                             weight_reg = "wgt_match", final_filename = T){
  # Load CPS and ACS pseudo-panel
  cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))
  
  # Filter out to only keep foreign born people
  cps_acs <- cps_acs %>%
    filter(immigrant == "Immigrant")
  
  # Define vars to use as controls
  cps_acs <- cps_acs %>%
    mutate(frac_married = ifelse(married == "Married", 1,0))%>%
    mutate(hsandbelow=ifelse(edlevel %in% c("Below HS","HS grad"),1,0))
  
  # Raw data (Panel A in both figures)
  fig_foreign_scatter(data=cps_acs,
                      spec="nocontrols", hetero="bpl_country", depvar="pooled_employment",
                      plotname="", drop_hongkong = {{drop_hongkong}}, FEinteract_imm = {{FEinteract_imm}}, 
                      FEinteract_movers = {{FEinteract_movers}}, weight_reg = {{weight_reg}}, 
                      final_filename = {{final_filename}})
  
  # Specification with controls (Panel B in both figures)
  fig_foreign_scatter(data=cps_acs,
                      spec="controls", hetero="bpl_country", depvar="pooled_employment",
                      plotname="", drop_hongkong = {{drop_hongkong}}, FEinteract_imm = {{FEinteract_imm}}, 
                      FEinteract_movers = {{FEinteract_movers}}, weight_reg = {{weight_reg}}, 
                      final_filename = {{final_filename}})
}

# Run function
# Immigrants FE by country, movers FE uninteracted, regression weight = wgt_match
weights_function(drop_hongkong = F, FEinteract_imm = T, FEinteract_movers = F, 
                 weight_reg = "wgt_match", final_filename = T)
