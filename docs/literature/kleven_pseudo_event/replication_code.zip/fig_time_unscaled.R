#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates the timeseries figures in Figure A.9

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Function to plot timeseries
plot_timeseries <- function(data, hetero, run, preadjust=T,
                            export=T, final_filename = T){
  
  if (final_filename){
    reg_wgt_lbl <- ""
  } 
  
  if (run == "penalty"){
    # Run code to get penalties by time interval for each outcome
    coef <- setDF(rbindlist(lapply(l.depvars, reg_es_hetero, data=data, hetero = {{hetero}},
                                   return_final = {{run}}, plotname = "child_penalties_time",
                                   preadjust = {{preadjust}}, export = F, 
                                   return_coef = "unadjust")))
    # Save dataframe of penalties
    saveRDS(coef, file=file.path(wrkdir,paste0("penalties_",hetero, "_unadjust", ".rds")))
  }
  if (run == "cf"){
    coef <- setDF(rbindlist(lapply(l.depvars, reg_es_hetero, data=data, hetero = {{hetero}},
                                  return_coef = "cf", plotname = "child_penalties_time",
                                  preadjust = {{preadjust}}, export = F)))%>%
      rename(estimate = mean_cf)%>%
      select(-c("gender"))
    
    # Save dataframe of penalties
    saveRDS(coef, file=file.path(wrkdir,paste0("counterfactuals_",hetero, "_unadjust", ".rds")))
  }
  
  # First scale earnings
  coef_sub <- subset(coef, depvar == "earnings_ly")
  
  # Load cleaned CPS data
  load(file.path(cleandir,"cps_clean.RData"))

  # Only keep people aged 25-60
  cps <- cps %>%
    filter(inrange(age, 25, 60))
  
  # Add midpoint years
  coef_sub$doiy <- c(1976, 1982, 1987, 1992, 1997, 2002, 2007, 2012, 2017)
  
  # Get weighted average of earnings for each relevant year
  averages <- cps %>%
    filter(doiy %in% c(1976, 1982, 1987, 1992, 1997, 2002, 2007, 2012, 2017)) %>%
    group_by(doiy) %>%
    summarise(mean_earnings = weighted.mean(earnings_ly, wgt, na.rm=TRUE))
  
  # Get average in 2020 for reference year
  averages_2020 <- cps %>%
    filter(doiy == 2020) %>%
    group_by(doiy) %>%
    summarise(mean_earnings = weighted.mean(earnings_ly, wgt, na.rm=TRUE))
  
  # Add to coef_sub, calculate factor, and get adjusted earnings penalties
  coef_sub <- coef_sub %>%
    merge(averages, by = "doiy")%>%
    mutate(earnings_2020 = averages_2020$mean_earnings)%>%
    mutate(factor = earnings_2020/mean_earnings)%>%
    mutate(`estimate*factor` = estimate*factor)%>%
    select("hetero", "estimate*factor", "depvar", "depvar_lab")%>%
    rename(estimate=`estimate*factor`)
  
  if (run == "penalty"){
    coef_sub <- coef_sub %>%
      mutate(estimate=estimate/70000)
  }
  if (run == "cf"){
    coef_sub <- coef_sub %>%
      mutate(estimate=(estimate+30000)/100000)
  }
  
  # Add adjusted earnings penalties back to main dataset
  coef <- coef %>%
    subset(depvar != "earnings_ly")%>%
    rbind(coef_sub)
  
  # Different formatting for plots
  if (run == "penalty"){
    ymin_main <- 0
    ymax_main <- 0.6
    by_main <- 0.1
    ymin_sec <- 0
    ymax_sec <- 42000
    by_sec <- 7000
    labels_sec <- c("0","7,000","14,000","21,000","28,000","35,000","42,000")
    main_lab <- "Unscaled Employment Penalty (pp)"
    sec_lab <- "Unscaled Earnings Penalty (2020 $)"
    transpose <- 70000
  }
  if(run == "cf"){
    ymin_main <- 0.5
    ymax_main <- 1
    by_main <- 0.1
    ymin_sec <- 0.5
    ymax_sec <- 1
    by_sec <- 0.1
    labels_sec <- c("20,000","30,000","40,000","50,000","60,000","70,000")
    main_lab <- "Counterfactual Employment Rate for Mothers"
    sec_lab <- "Counterfactual Earnings for Mothers (2020 $)"
    transpose <- 1
  }
  
  # Clean up coef dataframe
  coef$depvar_lab <- factor(coef$depvar_lab,levels=c("Earnings","Weekly Employment","Annual Employment"))
  coef <- coef[order(coef$depvar_lab),]
  
  ggplot(coef, aes(y=estimate, x=hetero, group=depvar_lab,color=depvar_lab, shape = depvar_lab))  +
    # display all x values on axis
    scale_x_discrete(labels=unique(coef$hetero))+
    # y-axis
    coord_cartesian(ylim=c(ymin_main,ymax_main),clip = 'off')+
    scale_y_continuous(breaks=seq(ymin_main,ymax_main, by=by_main),
                       sec.axis = sec_axis( transform=~.*transpose, name=sec_lab,
                                            breaks = seq(ymin_sec,ymax_sec, by=by_sec),
                                            labels=labels_sec))+
    # axis labels
    labs(x="Year", y=main_lab) +
    # line and point sizes
    geom_line(linewidth=1)+
    geom_point(size = 5) +
    # theme + grid lines
    theme_minimal() +
    theme(axis.line = element_line(colour = "black",linewidth=0.2),
          panel.grid.major.x = element_blank(),
          panel.grid.minor.y = element_blank(),
          legend.key.size = unit(3,"lines"),
          legend.position = "bottom", 
          legend.background=element_blank(),
          text=element_text(size=20),
          #plot.margin = unit(c(0, 5, 0, 0), "cm"),
          axis.text.x = element_text(margin = unit(c(0.5,0,0,0), "cm")),
          axis.text.y = element_text(margin = unit(c(0,0.4,0,0), "cm")),
          axis.title.y = element_text(margin = margin(t = 0, r = 10, b = 0, l = 0)),
          axis.title.x = element_text(margin = margin(t = 10, r = 0, b = 0, l = 0))) +
    # Define color scheme + shapes for each outcome
    scale_color_manual(name="",values = c("black",rgb(26,71,111, maxColorValue = 255),
                                          rgb(186,17,17, maxColorValue = 255)),
                       breaks=c("Annual Employment","Weekly Employment","Earnings"))+
    scale_shape_manual(name ="", values=c(15,17,16),
                       breaks=c("Annual Employment","Weekly Employment","Earnings"))
  
  # save graph
  if (run == "penalty"){
    ggsave(paste0("child_penalties_timeseries_unadjusted", reg_wgt_lbl,".pdf"), plot=last_plot(),
           device="pdf", width=15, height=8, units="in",path=file.path(outdir,"Figures"))
  }
  if (run == "cf"){
    ggsave(paste0("counterfactuals_timeseries_unadjusted", reg_wgt_lbl,".pdf"), plot=last_plot(),
           device="pdf", width=15, height=8, units="in",path=file.path(outdir,"Figures"))
  }
      
    
  return(coef)
}

# Load CPS and ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

# Define vector of outcomes of interest
l.depvars <- c("emp_lw","earn_ly", "earnings_ly")

# Create timeseries for penalties
plot_timeseries(data=cps_acs,hetero="yr5", run = "penalty",
                final_filename = T)
  
# Create timeseries for counterfactuals
plot_timeseries(data=cps_acs,hetero="yr5", run = "cf",
                final_filename = T)
