#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# (validation of Pseudo-Event Study approach using CPS and ACS)
# Section 1 creates the left panels of Figure 1 and Panel D in Figure A.1-A.3
# Section 2 creates the right panels of Figures 1 and 2

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Define vector of outcome variables 
l.depvars <- c("earn_ly","earnings_ly","emp_lw")

#########################################
# 1. CPS and ACS

#########################################

# Load CPS and ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))


# Results for Figure 1
coef.pseudo <- setDF(rbindlist(lapply(l.depvars, reg_es, data = cps_acs,
                                     plotname = "validation_pseudo_cps_acs")))

# Results for panel D of A.1-A.3
lapply(l.depvars, reg_es, data = cps_acs, plotname = "matching_spec4", appendix=T)

#########################################
# 2. PSID and NLSY79

#########################################

# Load files
load(file.path(cleandir,paste0("psid_clean_restricted",".RData")))
load(file.path(cleandir,paste0("nlsy79_clean_restricted",".RData")))

# Append and create matching wgt = 1 since there is no matching for panel
psid_nlsy <- bind_rows(nlsy79, psid) %>%
  mutate(wgt_match = 1)
psid_nlsy <- psid_nlsy %>%
  mutate(id_original = id) %>%
  group_by(id, dataset) %>%
  dplyr::mutate(id = cur_group_id()) %>%
  ungroup()


# Run event studies for Panels B, D, F of Figure 1 and 2
coef.panel <- setDF(rbindlist(lapply(l.depvars, reg_es, data = psid_nlsy,
                                     preadjust = F, plotname = "validation_actual_psid_nlsy")))
