#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file sets up the file paths, 
# and defines some parameters used throughout the code.

#############################################################################################

############################################
# Functions, file paths, and packages
############################################

# loading packages
library(ROCR)
library(grid)
library(broom)
library(scales)
library(ggplot2)
library(ggthemes)
library(gridExtra)
library(data.table)
library(e1071)
library(haven)
library(here)
library(foreign)
library(purrr)
library(plm)
library(survey)
library(multcomp)
library(car)
library(ipumsr)
library(fixest)
library(xtable)
library(RColorBrewer)
library(lubridate)
library(MatchIt)
library(easyPSID)
library(Matching)
library(stargazer)
library(mlr)
library(tigris)
library(sf)
library("rnaturalearth")
library("rnaturalearthdata")
library(labelled)
library(kableExtra)
library(AER)
library(DT)
library(RStata)
library(directlabels)
library(boot)
library(matrixStats)
library(usmap)
library(readxl)
library(gridGraphics)
library(binsreg)
library(cowplot)
library(conflicted)
library(plyr)
library(tidyr)
library(tidyverse)
library(dplyr)
library(ggtext)
library(maps)


conflicted::conflict_prefer(name="summarise",winner="dplyr")
conflicted::conflict_prefer(name="summarize",winner="dplyr")
conflicted::conflict_prefer(name="rename",winner="dplyr")
conflicted::conflict_prefer(name="count",winner="dplyr")
conflicted::conflict_prefer(name="na_if",winner="dplyr")
conflicted::conflict_prefer(name="filter",winner="dplyr")
conflicted::conflict_prefer(name="mutate", winner="dplyr")
conflicted::conflict_prefer(name="arrange", winner="dplyr")
conflicted::conflict_prefer(name="lag",winner="dplyr")
conflicted::conflict_prefer(name="month",winner="lubridate")
conflicted::conflict_prefer(name="select",winner="dplyr")
conflicted::conflict_prefer(name="vars",winner="dplyr")
conflicted::conflict_prefer(name="here",winner="here")
conflicted::conflict_prefer(name="melt",winner="data.table")
conflicted::conflict_prefer(name="contains",winner="dplyr")
conflicted::conflict_prefer(name="setdiff",winner="dplyr")

# set file paths

wrkdir <- file.path(here::here("Data","Working_Data"))
outdir <- file.path(here::here("Output"))
rawdir <- file.path(here::here("Data","Raw_Data"))
cleandir <- file.path(here::here("Data","Cleaned_Data"))
codedir <- file.path(here::here("Code"))

############################################
# Parameters
############################################

max.age <- 45
min.age <- 25
t.min <- -5
t.max <- 10
ref <- "-2"
age.cutoff <- max.age -1
seed.val <- 9746290

# Don't use scientific notation
options(scipen = 999)

############################################
# Functions
############################################
source(file.path(codedir,"functions.R")) # run file with functions

############################################
# Data availability flags
############################################

process.gss  <- FALSE
process.psid <- FALSE

if (file.exists(file.path(rawdir,"GSS/cross7316geo.dta"))) {
  process.gss <- TRUE
}

if (file.exists(file.path(rawdir,"PSID","RDS Files","J30305267.rds")) &
    file.exists(file.path(rawdir,"PSID","cah85_19","CAH85_19.dta"))){
  process.psid <- TRUE
}
