#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates the EB Shrinkage plots shown in 
# Figures A.15-A.16

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Define vector of outcome vars
l.depvars <- c("earnings_ly", "emp_lw","earn_ly")

# Load CPS and ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

# Function to run regression and give coefficients
coef_es_st <- function(data) {
  
  data <- droplevels(data)
  
  # regression and prediction
  #if we want to weight the regression
  reg <- feols(depvar ~ hetero:gender + hetero + post:hetero + post:gender:hetero | age_gender + doiy_gender + age_factor + doiy_factor, 
                 data, weights=~wgt, se="hetero")
  
  # clean up df to add event time and hetero
  reg.coefs <- as.data.frame(tidy(reg))%>%
  mutate(hetero = gsub(".*hetero(.+):.*", "\\1", term)) %>%
  mutate(t_es = sub(".*t_es","",term))
    
  # clean the dataset to be returned
  coef <- reg.coefs %>%
    mutate(conf.low = estimate + qnorm(0.025, 0, 1)*std.error,
           conf.high = estimate + qnorm(0.975, 0, 1)*std.error) %>%
      subset(select=c(t_es,hetero,estimate,conf.low,conf.high, std.error))
    
   return(coef)

}

# Function to create rawscatters
fn_scatter_epi <- function(data, depvar, hetero="statename", interact="census",
                           plotname="", final_filename = T) {
  
  
  ## clean up data, add interactions
  
  data["depvar"] = data[{{depvar}}]
  data["hetero"] = data[{{hetero}}] 
  data["t_es"] = data[paste0("t_es_",substr({{depvar}}, nchar({{depvar}})-1, nchar({{depvar}})))]
  
  # Creating post dummies
  data <- data %>%
    mutate(post = case_when(!is.na(data$t_es) & as.numeric(data$t_es) >= 6 ~ 1,
                            !is.na(data$t_es) & as.numeric(data$t_es) < 6 ~ 0,
                            is.na(data$t_es) ~ NA_real_))
  
  # variable within which we want to interact fes
  data["interact"] = data[{{interact}}]
  
  data <- data %>%
    drop_na(depvar, age_factor, doiy_factor, post, hetero) %>%
    mutate(age_gender = interaction(age_factor, gender)) %>%
    mutate(doiy_gender = interaction(doiy_factor, gender)) 
  
  data <- droplevels(data)
  
  # Graph labels
  if({{depvar}}=="earn_ly"){
    depvarlbl <- "emp_annual"
  }
  if({{depvar}}=="emp_lw"){
    depvarlbl <- "emp_weekly"
  }
  if({{depvar}}=="earnings_ly"){
    depvarlbl <- "earnings"
  }
  if(grepl("pooled",depvar)){
    depvarlbl <- "emp_pooled"
  }
  
  data <- droplevels(data)
  
  coef <- setDF(rbindlist(lapply(split(data, list(data$interact)),coef_es_st))) %>%
    mutate(depvar_lab = var_label(data$depvar),
           depvar = {{depvar}})
  
}

# Interacted by census division, regression weight = wgt, counterfactuals weighted by wgt_match
es.state <- setDF(rbindlist(lapply(c("earn_ly", "emp_lw", "earnings_ly"),
                                   fn_scatter_epi, data=subset(cps_acs, statefip < 57),
                                   hetero="statename", interact="census",
                                   plotname="child_penalties_state",
                                   final_filename = T)))

# Function to plot OLS vs EB Shrinkage Estimates
fn_plot <- function(data, depvar, plotname = "", final_filename = T) {
  
  # Graph labels
  if (depvar == "earn_ly") {
    depvarlbl <- "emp_annual"
  }
  if (depvar == "emp_lw") {
    depvarlbl <- "emp_weekly"
  }
  if (depvar == "earnings_ly") {
    depvarlbl <- "earnings"
  }
  
  # Dataset with Shrunk Estimates
  
  df <- data %>%
    filter(grepl("hetero", t_es, ignore.case = TRUE) &
             grepl("gender", t_es, ignore.case = TRUE) &
             grepl("post", t_es, ignore.case = TRUE))
  
  df <- df %>% select(hetero, estimate, std.error, depvar) 
  
  df <- df %>%
    mutate(hetero = str_extract(hetero, "^[^:]+"))
  
  # Filter for the specified depvar
  df <- df %>% filter(depvar == {{depvar}})
  
  # Compute estimators for the hyperparameters
  df <- df %>% mutate(mu = mean(estimate, na.rm = TRUE),
                      var = sum((estimate - mu)^2 - std.error^2) / 51,
                      tot_noise = var + std.error^2,
                      beta_var = std.error^2)
  
  data <- df %>% mutate(shrunk_estimate = (var / tot_noise) * estimate + (beta_var / tot_noise) * mu,
                        shrunk_var = beta_var * var / tot_noise,
                        shrunk_se = sqrt(shrunk_var),
                        se = std.error,
                        estimate = -1 * estimate,
                        shrunk_estimate = -1 * shrunk_estimate) %>%
    select(hetero, estimate, se, shrunk_estimate, shrunk_se)
  
  data <- data %>% mutate(conf.low = estimate - 1.96 * se,
                          conf.high = estimate + 1.96 * se,
                          shrunk.conf.low = shrunk_estimate - 1.96 * shrunk_se,
                          shrunk.conf.high = shrunk_estimate + 1.96 * shrunk_se)
  
  # Reshape the data to long format
  data_long <- data %>%
    pivot_longer(cols = c(estimate, shrunk_estimate), names_to = "type", values_to = "estimate_value") %>%
    pivot_longer(cols = c(se, shrunk_se), names_to = "type_se", values_to = "se_value") %>%
    pivot_longer(cols = c(conf.low, shrunk.conf.low), names_to = "type_conf.low", values_to = "conf.low_value") %>%
    pivot_longer(cols = c(conf.high, shrunk.conf.high), names_to = "type_conf.high", values_to = "conf.high_value") %>%
    filter((type == "estimate" & type_se == "se" & type_conf.low == "conf.low" & type_conf.high == "conf.high") |
             (type == "shrunk_estimate" & type_se == "shrunk_se" & type_conf.low == "shrunk.conf.low" & type_conf.high == "shrunk.conf.high")) %>%
    mutate(type = ifelse(type == "estimate", "Paper", "Shrunk")) %>%
    select(hetero, type, estimate_value, se_value, conf.low_value, conf.high_value)
  
  
  # Preparing data for plotting
  
  # axis labels
  xlbl <- "Unscaled Child Penalty"
  
  # axis ranges
  if(depvar == "emp_lw"){
    xmin2 <- 0.0
    xmin <- 0.0
    xmax <- 0.35
    xmax2 <- 0.35
    by.x <- 0.05
  }
  if(depvar == 'earn_ly'){
    xmin2 <- 0.0
    xmin <- 0.0
    xmax <- 0.35
    xmax2 <- 0.35
    by.x <- 0.05
  }
  if(depvar == 'earnings_ly'){
    xmin2 <- 0
    xmin <- 0
    xmax <- 30000
    xmax2 <- 30000
    by.x <- 5000
  }
  
  data_long <- data_long %>%
    mutate(hetero = fct_reorder(hetero, estimate_value))
  
  # Define colors for the estimates
  colors <- c("Paper" = "black", "Shrunk" = rgb(193,5,52, maxColorValue = 255))
  
  # Plot
  plot <- ggplot(data_long, aes(y = hetero, x = estimate_value, color = type, shape = type)) +
    geom_point(position = position_dodge(width = 0.5)) +
    geom_errorbarh(aes(xmin = conf.low_value, xmax = conf.high_value), height = 0.227, position = position_dodge(width = 0.5)) +
    labs(y = "State",
         x = xlbl,
         color = "Gender",
         shape = "Gender") +
    scale_x_continuous(breaks=seq(xmin, xmax, by = by.x), labels = comma) +
    coord_cartesian(xlim=c(xmin2,xmax2)) +
    scale_color_manual(labels = c("OLS", "EB Shrinkage"), values = c("black", rgb(193,5,52, maxColorValue = 255))) +
    scale_shape_manual(labels = c("OLS", "EB Shrinkage"), values = c(16, 17)) + # 16 for dots, 17 for triangles
    theme_minimal() +
    theme(legend.position = "bottom",
          legend.key.size = unit(0.8, "cm"),
          legend.text = element_text(size=12),
          legend.title= element_blank()) +
    theme(
      axis.title.x = element_text(margin = margin(t = 8, r = 0, b = -2, l = 0),
                                  size = 14),
      axis.text.x = element_text(vjust = -0.5, size = 11),
      axis.text.y = element_text(margin = unit(c(0,0.1,0,0), "cm"))
    ) +
    theme(axis.title.y = element_text(margin = margin(t = 0, r = 2, b = 0, l = 0),
                                      size = 14))
  
  
  print(plot)
  
  ggsave(paste0("shrinkage_unscaled", "", "_", depvarlbl,
                "", ".pdf"),
         plot = plot, device = "pdf",
         width = 11, height = 8, units = "in", path = file.path(outdir, "Figures"))
  
  # Scatter Plotting 
  
  # R^2 calculation
  reg <- lm(data=data, as.numeric(shrunk_estimate) ~ as.numeric(estimate))
  summary(reg)
  r2 <- summary(reg)$r.squared
  rsquared <- sprintf('%.3f',r2)
  print(rsquared)

  # coef$rsquared <- rsquared

  if({{depvar}}=="earn_ly" | {{depvar}}=="emp_lw"){
    min <- .1
    max <- .4
    labs <- c("0.10","0.15","0.20","0.25","0.30","0.35","0.40")
    x45 <- 0.381
    y45 <- 0.409
    xr2 <- 0.3323
    yr2 <- 0.1137
    jumps <- .05
    space <- 0.015
  }
  if({{depvar}}=="earnings_ly"){
    min <- 5000
    max <- 25000
    labs <- c("5,000","10,000","15,000","20,000","25,000")
    x45 <- 23650
    y45 <- 25600
    xr2 <- 20500
    yr2 <- 5500
    jumps <- 5000
    space <- 1500
  }
  
  # Graph
  ggplot(data=data, aes(x = estimate, y = shrunk_estimate)) +
    # 45-degree line
    geom_abline(intercept = 0, slope = 1, linewidth = 0.5, color=rgb(193,5,52, maxColorValue = 255))+
    geom_point(size = 3, color=rgb(26,71,111, maxColorValue = 255))+
    # Axes labels
    labs(y = "Unscaled Child Penalty (EB Shrinkage)", x = "Unscaled Child Penalty (OLS)")+
    # Axes
    coord_cartesian(ylim=c(min-space,max+space),xlim=c(min-space,max+space))+
    scale_x_continuous(breaks=seq(min, max, by = jumps), labels=labs)+
    scale_y_continuous(breaks=seq(min, max, by = jumps), labels=labs)+
    # Theme
    theme_minimal()+
    # Other theme adjustments
    theme(axis.line = element_line(colour = "black",size=0.2)) +
    theme(panel.grid.minor.x = element_blank(),
          panel.grid.minor.y = element_blank(),
          axis.text=element_text(size=18),
          axis.title=element_text(size=18),
          legend.position = "bottom",
          legend.title = element_blank(),
          #legend.key.height = unit(1, "cm"),
          #legend.key.size = unit(2, "cm"),
          legend.text = element_text(size=15))+
    guides(fill = guide_legend(override.aes = aes(label = "")))+
    theme(
      axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)),
      axis.text.x = element_text(vjust = -0.5),
      axis.text.y = element_text(margin = unit(c(0,0.4,0,0), "cm"))
    ) +
    theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)))+
    # 45-degree
    annotate("text",x=x45, y=y45, label="45\u00B0 Line", size = 7, color=rgb(193,5,52, maxColorValue = 255))+
    # R^2
    annotate("text", x = xr2, y = yr2, label = paste0("R^2 ==", deparse(rsquared)), size = 8, parse = TRUE, color = "black")
  
  ggsave(paste0("shrinkage_scatter", "_", depvarlbl, ".pdf"), 
         plot=last_plot(), device="pdf",
         width=11, height=8, units="in",path=file.path(outdir,"Figures"))
  
}

# List of dependent variables
l.depvars <- c('earn_ly', 'emp_lw', 'earnings_ly')

# Figures A.15 and A.16
lapply(l.depvars, fn_plot, data = es.state)
