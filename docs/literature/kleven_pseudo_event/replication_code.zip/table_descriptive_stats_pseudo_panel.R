#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates Table 2 in the paper
# (Descriptive Statistics in the Pseudo-Panel)

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Function to get each row of table
# This will produce a dataframe that contains the average of some variable ("hetero")
# at t = 0 and a specified negative event time (-1 or -2) or over the full pre-period
# as well as the difference between both

# If totalobs = T it will give the number of observations at the event times
# instead of an average of the hetero var

# "depvar" needs to be defined to either select the annual or weekly pseudo-panel sample

check_significance <- function(data, depvar, hetero, totalobs=F) {
  
  # Define outcome var and corresponding event time var
  data["depvar"] = data[{{depvar}}]
  data["t_es"] = data[paste0("t_es_",substr({{depvar}}, nchar({{depvar}})-1, nchar({{depvar}})))]
  data["post"] = data[paste0("post_",substr({{depvar}}, nchar({{depvar}})-1, nchar({{depvar}})))]
  
  
  # Drop parents at t=0 who are unmatched at t = -1
  if(grepl("lw", depvar)){
    # If weekly var and showing t== -1 in table, 
    # drop parents who are unmatched 1 year before, 1 year younger
    data <- data %>%
      filter(matched1 == 1 | is.na(matched1))
  }
  
  if(totalobs) { # for row in table with number of observations
    # keep only desired sample for table
    data <- data %>%
      drop_na(depvar, age_factor, doiy_factor, t_es,post) %>%
      filter(t_es %in% c("-1","0")) %>%
      droplevels()
    
    # Take sum of wgt_match (matching weight) in pre and post period
    # to avoid double-counting people in the negative event times who were matched with ties
    counts <- data %>%
      group_by(post) %>%
      summarize(n = sum(wgt_match)) %>%
      mutate(hetero = "Number of Observations") %>%
      spread(post, n) %>%
      mutate(diff = NA_character_)
    
    counts <- counts %>%
      mutate(across(where(is.numeric), ~as.character(comma(round(.)))))
    
  } else { # for all other rows where we want mean/fraction of hetero var
    
    # define hetero var in dataframe
    data["hetero"] = data[{{hetero}}] 
    print({{hetero}})
    
    # keep only desired sample for table
    data <- data %>%
      drop_na(depvar, age_factor, doiy_factor, t_es, hetero,post) %>%
      filter(t_es %in% c("-1","0")) %>%
      droplevels()
    
    # Take average weighted by wgt_match (matching weight) in pre and post period
    # to avoid double-counting people in the negative event times who were matched with ties
    counts <- data %>%
      group_by(post) %>%
      summarize(mean =weighted.mean(hetero, wgt_match)) %>%
      mutate(hetero = var_label(data$hetero)) %>%
      spread(post, mean) %>%
      mutate(diff = round(post - pre, 2))
    
    # Formatting of cells for table
    if(grepl("earnings",hetero) | totalobs == T){
      counts <- counts %>%
        mutate(across(where(is.numeric), ~as.character(comma(round(.)))))
    } else {
      counts <- counts %>%
        mutate(across(where(is.numeric), ~sprintf("%.2f", round(.,2))))
    }
    
    counts <- counts %>%
      mutate(diff = ifelse(diff < 0, paste0("\\hspace{0.1cm}",diff), paste0("\\hspace{0.2cm}",diff)))
  }
  
  return(counts)
}

# Function to create entire table

fn_table_pseudo_panel <- function(data) {
  # Get table
  # Note: use weekly employment pseudo-panel sample for everything except 
  # annual employment and earnings mean
  
  # Results for men only first for all vars
  matched_diff <- setDF(rbindlist(lapply(c("earn_ly"),check_significance,data=filter(data, gender == "Men"),
                                         depvar="earnings_ly")))%>%
    bind_rows(check_significance(data=filter(data, gender=="Men"),hetero="emp_lw",
                                 depvar="emp_lw"))%>%
    bind_rows(check_significance(data=filter(data, gender=="Men"),hetero="earnings_ly",
                                 depvar="earnings_ly"))%>%
    bind_rows(setDF(rbindlist(lapply(c("hsandbelow","college","married","black","white","hispanic","age1b","age","doby"),check_significance,
                                     data=filter(data, gender=="Men"),
                                     depvar="emp_lw"))))%>%
    bind_rows(check_significance(data=filter(data, gender=="Men"),hetero="", totalobs=T,
                                 depvar="emp_lw"))%>%
    mutate(gender = "Men") %>%
    # Results for women only next
    bind_rows(setDF(rbindlist(lapply(c("earn_ly"),check_significance,data=filter(data, gender == "Women"),
                                     depvar="earnings_ly")))) %>%
    bind_rows(check_significance(data=filter(data, gender=="Women"),hetero="emp_lw",
                                 depvar="emp_lw"))%>%
    bind_rows(check_significance(data=filter(data, gender=="Women"),hetero="earnings_ly",
                                 depvar="earnings_ly"))%>%
    bind_rows(setDF(rbindlist(lapply(c("hsandbelow","college","married","black","white","hispanic","age1b","age","doby"),
                                     check_significance,data=filter(data, gender=="Women"),
                                     depvar="emp_lw")))) %>%
    bind_rows(check_significance(data=filter(data, gender=="Women"),hetero="", totalobs=T,
                                 depvar="emp_lw"))%>%
    mutate(gender = ifelse(is.na(gender),"Women",gender)) %>%
    rename(name = hetero)
  
  # Reshape wide by gender
  matched_tbl <- matched_diff %>%
    pivot_wider(names_from=c("gender"),values_from = c("pre","post","diff"))%>%
    subset(select=c(name,post_Men,pre_Men, diff_Men, post_Women, pre_Women, diff_Women))
  
  row.names(matched_tbl) <- NULL
  
  #### Generate latex table
  options(knitr.kable.NA = '')
  
  # Name columns based on negative event time used
  matched_tbl_tex <- kbl(matched_tbl, format="latex",linesep="",escape=F,
                         booktabs=T,
                         align=c('l','c','c','c','c','c','c'),
                         row.names=NA,
                         col.names= c("", "$\\tau=0$","$\\tau=-1$",
                                      "\\textbf{Difference}", "$\\tau=0$","$\\tau=-1$",
                                      "\\textbf{Difference}")) %>%
    add_header_above(c(" " = 1, "Matched Men" = 3, "Matched Women" = 3)) %>%
    row_spec(12, hline_after=T) %>%
    column_spec(c(4,7), bold=T)
  
  # Save table
  writeLines(matched_tbl_tex, file.path(outdir,"Tables",paste0("table_descriptive_stats_pseudo_panel",".tex")))
  
  # Change spacing in table for slides
  matched_tbl$`diff_Men` <- gsub("0.2cm","0.18cm",matched_tbl$`diff_Men`)
  
  matched_tbl$`diff_Women` <- gsub("0.2cm","0.18cm",matched_tbl$`diff_Women`)
  
  # Re-create new table for slides
  matched_tbl_tex <- kbl(matched_tbl, format="latex",linesep="",escape=F,
                         booktabs=T,
                         align=c('l','c','c','c','c','c','c'),
                         row.names=NA,
                         col.names= c("", "$\\tau=0$","$\\tau=-1$",
                                      "\\textbf{Difference}", "$\\tau=0$","$\\tau=-1$",
                                      "\\textbf{Difference}")) %>%
    # column_spec(column =1, width="2.6in") %>%
    add_header_above(c(" " = 1, "Matched Men" = 3, "Matched Women" = 3)) %>%
    #add_header_above(c(" " =1, " "=6)) %>%
    row_spec(12, hline_after=T) %>%
    column_spec(c(4,7), bold=T)
  
  # Save table for slides
  writeLines(matched_tbl_tex, file.path(outdir,"Tables",paste0("table_descriptive_stats_pseudo_panel","_slides.tex")))
  
  
  return(matched_tbl)
}


# Load CPS and ACS pseudo-panel
cps_acs <- readRDS(file=file.path(wrkdir,paste0("cps_acs_pseudo-panel",".rds")))

# Create some numeric demographic variables to get fractions easily
cps_acs <- cps_acs %>%
  mutate(hispanic = ifelse(race == "Hispanic", 1, 0),
         married = ifelse(married == "Married",1,0)) %>%
  mutate(hsandbelow = ifelse(edlevel %in% c("Below HS","HS grad"), 1, 0))

# Re-define cohort for table to equal year - age
cps_acs <- cps_acs %>%
  mutate(doby = doiy - age)

# Add variable labels for use in table
cps_acs <- apply_labels(cps_acs, black = "Fraction Black",
                        hsandbelow = "Fraction High School or Below", 
                        white = "Fraction White",
                        hispanic = "Fraction Hispanic",
                        college = "Fraction College",
                        married = "Fraction Married",
                        age = "Age",
                        age1b = "Age at First Birth",
                        doiy = "Year",
                        doby = "Cohort",
                        earn_ly = "Annual Employment Rate",
                        emp_lw = "Weekly Employment Rate")

# Create and save table
fn_table_pseudo_panel(data=cps_acs)
