#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file adds variable labels to GSS data

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# load data

gss_raw <- read_dta(file.path(rawdir, "GSS/GSS7218_R1.dta")) %>% 
  rename_with(~ tolower(.x))

relevant_gender_var <- c("fehome", "fework", "fechld", "mawrkwrm", "fehelp", "fepresch", "kidsuffr", "fefam", "famsuffr",
                         "hapifwrk", "homekid", "fejobind", "twoincs", "hubbywrk", "wrkbaby", "wrksch", 
                         "hubbywk1", "mrmom", "tradmod", "fekids1", "fekids5", "mekdcare", "feworkif", "era", "eratell")

fn <- function(var) { 
  lab <- attributes(gss_raw[[{{var}}]])$label
  return(lab)
}

labs <- purrr::map(relevant_gender_var, fn) %>% 
  set_names(relevant_gender_var) %>% 
  bind_rows() %>% 
  t() %>% 
  as.data.frame() %>% 
  rownames_to_column("var") %>% 
  rename("lab" = "V1") %>% 
  mutate(lab = case_when(
    var=="fehome" ~ "Women shld take care of home, men take care of country",
    var == "fework" ~"Should women work if husband can support her",
    var == "fechld" ~ "Working mom can have warm relation with kids",
    var == "mawrkwrm" ~ "Working mom can have warm relation with kids (2)",
    var == "kidsuffr" ~ "Preschool kids suffer if mother works (2)",
    var == "fefam" ~ "Better for man to work, women tend home and family",
    var == "fejobind" ~ "Job is best way for woman to be independent",
    var == "twoincs" ~ "Husband & Wife should contribute to family income",
    var == "hubbywrk" ~"Husbands job to earn, wife's job look after home & fam",
    var=="wrkbaby" ~ "Shld women with chld under school age work",
    var == "wrksch" ~"Shld women work after youngest in school",
    var == "hubbywk1" ~ "Mans job to earn, women's job look after home & fam",
    var == "mrmom" ~ "Not good if man stays at home and women goes to work",
    var == "tradmod" ~ "Prefer man works and women stays home or equal share",
    var == "fekids1" ~ "Women biologicaly suited to care for children, how important",
    var == "fekids5" ~ "Gods will women care for children, how important",
    var == "mekdcare" ~ "Men ought to do more childcare than they do now",
    var == "feworkif" ~ "Shld married women work if jobs limited and husb can support",
    var == "era" ~ "Favor or oppose ERA",
    var == "eratell" ~ "Favor or oppose ERA (after info given)",
    TRUE ~ as.character(lab)))

labs %>% 
  saveRDS(file.path(wrkdir,"gss_var_labels.rds"))
