#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates Figure 15 of the paper
# (Child Penalties for Immigrants by Decile of Birth-Country Penalties)
# Event studies for men and women are run by decile of the child penalty
# in their country of birth

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Function to create event studies by decile/quartile of penalty in country of birth
fig_foreign_deciles <- function(data, depvar, plotname="") {

  
  # Graph labels
  depvarlbl <- "emp_pooled"
  
  # Read in penalties in birth country
  country_penalties <- read_excel(file.path(rawdir,"Global Child Penalties","global_penalties.xlsx")) %>%
    filter(!(country %in% c("Czech Republic","Slovakia", "Denmark", "Norway", "Sweden"))) %>%
    rename(penalty_global = penalty) %>%
    rename(bpl_country = country) %>%
    subset(select=c(bpl_country,penalty_global))
  
  # Treat negative penalties as zero
  country_penalties <- country_penalties %>%
    mutate(penalty_global = ifelse(penalty_global < 0, 0, penalty_global))
  
  # Merge with our child penalties for immigrants
  penalty <- readRDS(file=file.path(wrkdir,"penalties_immigrants.rds")) %>%
    subset(select=-c(depvar, depvar_lab))%>%
    mutate(hetero = as.factor(as.character(hetero)))
  
  country_penalties <- merge(country_penalties, penalty, by.x="bpl_country", by.y="hetero")
  
  
  #Create Scandinavia as pooled observations of Denmark, Norway, and Sweden in CPS/ACS
  data <- data %>%
    mutate(bpl_country = case_when(bpl_country == "Denmark" | bpl_country == "Norway" | 
                                     bpl_country == "Sweden" ~ "Scandinavia",
                                   TRUE ~ as.character(bpl_country)))
  data$bpl_country <- as.factor(data$bpl_country)
    
  # Sample for dependent variable: pooled employment
  data <- data %>%
    mutate(pooled_employment = ifelse(!is.na(t_es_ly) & !is.na(earn_ly), 
                                      earn_ly, emp_lw),
           t_es = as.factor(ifelse(!is.na(t_es_ly) & !is.na(earn_ly), 
                                   as.character(t_es_ly), as.character(t_es_lw))))
  data <- apply_labels(data, pooled_employment="Employment")
  
  data$t_es = factor(data$t_es, # re-order levels
                     levels=c("-2","-5", "-4", "-3", "-1",
                              "0", "1", "2", "3","4", "5", "6",
                              "7", "8", "9", "10"))
  
  # Split into deciles based on penalties in birth country
    # Re-order in ascending order of penalties for immigrants
  country_penalties <- arrange(country_penalties, penalty)
  
  country_penalties$decile <- as.factor(paste("Decile", as.character(ntile(country_penalties$penalty_global, 10))))
  xpos <- 8
  
  country_penalties <- country_penalties %>%
    subset(select=-c(penalty))
  
  # Get average penalty in country of origin in each decile/quantile
    # Weight by fraction of people in each decile/quantile from each country
  data <- merge(data, country_penalties, by="bpl_country") %>%
    subset(select=-c(penalty_global))
  
    # Number of people born in each country
  xwalk <- data %>%
    group_by(decile, bpl_country) %>%
    summarize(n = sum(wgt_match))
  
    # Number of people born in all countries in each decile
  xwalk2 <- data %>%
    group_by(decile) %>%
    summarize(n_total = sum(wgt_match))
  
    # Calculate fraction 
  xwalk <- merge(xwalk, xwalk2, by="decile") %>%
    mutate(frac = n/n_total) %>%
    subset(select=c(bpl_country, decile, frac))
  
    # Calculate weighted average of penalty in country of birth
  country_penalties <- merge(country_penalties, xwalk, by=c("bpl_country", "decile"))
  deciles <- country_penalties %>%
    group_by(decile) %>%
    summarize(decile_mid = weighted.mean(penalty_global, frac))
  
  # Event study regressions within each decile
  coef <- setDF(rbindlist(lapply(split(data, data$decile), reg_es_immigrant, depvar = {{depvar}},
                                 splitvar="decile", export=F))) %>%
    mutate(hetero = as.factor(as.character(hetero)))
  
  coef$t_es = factor(coef$t_es, # re-order levels
                     levels=c("-5", "-4", "-3", "-2", "-1",
                              "0", "1", "2", "3","4", "5", "6",
                              "7", "8", "9", "10"))
  
  # Prep for plot (labels and penalty text)
  lab <- data.frame(x = rep("10", length(levels(coef$hetero))), # x is in levels, needs quotes
                    y = rep(-.85, length(levels(coef$hetero))), 
                    dplyr::count(coef, hetero))
  
  # Calculate penalty (with pre-period adjustment)
  coef <- coef %>%
    mutate(post = ifelse(t_es %in% c("-5","-4","-3","-2","-1"), 0, 1))
  
  data["depvar"] <- data[{{depvar}}]
  post_mean <- aggregate(estimate ~  gender+post+hetero, 
                         data=coef ,
                         mean)
  post_mean <- post_mean %>%
    spread(post, estimate) %>%
    mutate(estimate=`1`-`0`)
  penalty <- post_mean %>%
    subset(select=-c(`1`,`0`)) %>%
    spread(gender, estimate) %>%
    mutate(penalty = `Men` - `Women`) %>%
    subset(select=c(hetero,penalty)) %>%
    mutate(depvar = {{depvar}},
           depvar_lab = var_label(data$depvar))
  
  # Add penalties to dataset of labels
  lab <- merge(lab, penalty, by=c("hetero"))
  lab$txt = sprintf("Child Penalty: %1.0f%%", (lab$penalty)*100)
  lab <- merge(lab, deciles, by.x="hetero",by.y="decile")
  coef <- merge(coef, deciles, by.x="hetero",by.y="decile")
  coef$hetero <- fct_reorder(coef$hetero, coef$decile_mid)
  
  # Reorder rows for plotting
  coef <- coef[order(coef$hetero,coef$gender, coef$t_es),]
  
  data["depvar"] <- data[{{depvar}}]
  
  # x axis labels
  mylabels <- c("","-4","","-2","","0","", "2","", "4","", "6","", "8","", "10")
  
    ylabels <- c("-1.0","-0.8","-0.6","-0.4","-0.2","0.0",
                  "0.2","0.4")
    ymin <- -1
    
  # y-axis label 
  if(depvar == "emp_lw"){
    ylab <- "Weekly Employment"
  }
  if(depvar == "earnings_ly"){
    ylab <- "Earnings"
  }
  if(depvar == "earn_ly"){
    ylab <- "Annual Employment"
  }
  if(depvar == "pooled_employment"){
    ylab <- "Employment"
  }
  
  for(st in c("Decile 1","Decile 10")){ # Plot deciles individually
    # Take spaces out of plot name
    stname <- tolower(gsub(" ", "", st, fixed = TRUE))
    
    ggplot(coef[coef$hetero==st,], aes(y=estimate, x=t_es, color=gender, group=gender))  + 
      # display all x values on axis
      scale_x_discrete(labels=as.character(coef[coef$hetero==st,"t_es"]), breaks=coef[coef$hetero==st,"t_es"])+
      # add confience intervals
      geom_ribbon(aes(ymin=conf.low,ymax=conf.high,fill=gender),alpha=0.3,show.legend = F,
                  colour = NA) +
      # line and point sizes
      geom_line(linewidth=1) + 
      geom_point(size=4) +
      # y-scale
      scale_y_continuous(labels=ylabels,
                         breaks=seq(ymin, 0.4, by=0.2), limits=c(ymin,0.45))+# axis labels# axis labels
      labs(x="Event Time (Years)", y=paste(ylab,"Impact (%)")) +
      # line at t=-0.5
      geom_vline(xintercept = 5.5, linetype="solid", color = "#D11809",linewidth=1.2) +
      # theme + grid lines
      theme_minimal() + 
      theme(axis.line = element_line(colour = "black",linewidth=0.4)) +
      theme(panel.grid.major.x = element_blank(),
            panel.grid.minor.y = element_blank(),
            legend.position = "bottom",
            panel.spacing = unit(-.2, "lines"),
            legend.key.size = unit(3,"lines")) +
      # label next to line
      geom_text(aes(x=6.9,
                    label="First Child",y=0.45),
                size=8.5,color="grey25",check_overlap=T)+
      theme(axis.text.x = element_text(vjust = -0.5),
      ) +
      theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)),
            axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)))+
      theme(text=element_text(size=25)
      ) +
      # line color and legend labels
      scale_color_manual(name="",
                         breaks=c("Men","Women"),
                         values=c("black",rgb(193,5,52, maxColorValue = 255)),
                         labels=c("Men","Women")) +
      scale_fill_manual(values=c("black",
                                 rgb(193,5,52, maxColorValue = 255)),
                        breaks=c("Men","Women"),
                        name="")+
      geom_text(aes(x=8.92, y=ymin+0.34, label=paste0("Child Penalty:"), group=NULL), 
                size = 8,color="black", fontface="bold",hjust=0,check_overlap=T, data=lab)+
      geom_text(aes(x=8.92, y=ymin+0.21, group=NULL,label=paste0(
      "US Immigrants: ",
      round(penalty*100),
      "%")),size = 8,color="black",check_overlap = T,hjust=0, data=lab[lab$hetero==st,])+
      geom_text(aes(x=8.92, y=ymin+0.08, group=NULL,label=paste0(
        "Country of Birth: ",round(decile_mid*100), "%")), 
        size = 8,color="black",check_overlap = T,hjust=0, data=lab[lab$hetero==st,])
    ggsave(paste0(plotname,"_",stname,"_",depvarlbl, ".pdf"), plot=last_plot(), device="pdf",
           width=11, height=8, units="in",path=file.path(outdir,"Figures"))
    
  }
}

# Load CPS and ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

# Only keep foreign-born people
cps_acs <- cps_acs %>%
  filter(immigrant == "Immigrant")

# Create Figure 15
fig_foreign_deciles(data=cps_acs, depvar="pooled_employment", plotname = "epidemiological_immigrants")
