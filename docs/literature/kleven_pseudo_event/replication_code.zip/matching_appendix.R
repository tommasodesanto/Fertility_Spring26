#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file produces Panels A-C of Figures A.1-A.3 in the Paper
# (Pseudo-Event Studies Under Different Matching Specifications)

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))


#------ Main matching function ------#

run_match <- function(data) {
  # skip bin if we don't have both a childless person and parent
  
  if(length(unique(data$child)) == 2) {
    
    # set seed
    set.seed(seed.val)
    
    # treatment variable: indicator for having a child or not
    
    match_out  <- Match(Y=NULL, Tr=data$child,
                        
                        # subset variables that we are matching on 
                          # don't really need all these vars listed b/c we have already
                          # split dfs into list by vars we want to match on
                        
                        X=subset(data, select=c(gender.num,age,doiy,matching_vars))
                        # replace = T and ties = F for matching with replacement, exact = T not really necessary
                          # b/c bins are split already
                        ,replace=T,ties=F,exact=T)
    
    # return dataset with both child == 0 and child == 1 observations
    
    matched <- data[c(match_out$index.treated, match_out$index.control),]
    
    # add an id variable for each matched_pair (within a given bin)
    
    matched$pair <- factor(rep(match_out$index.treated, 2))
    
    return(matched)
  }
}


#------- Function to create matched dataset --------#
# Will run either the 1st, 2nd, or 3rd matching specification
  # as used in Figures A.1-A.3 to show progression towards final
  # matching specification

match_age1b_steps <- function(df, name, spec, tvar) {
  
  # create numeric variable for every var we want to match on
  
  df <- df %>%
    mutate(gender.num = as.numeric(gender),
           marst.num = as.numeric(marst),
           edlevel.num = as.numeric(edlevel),
           race.num = as.numeric(race),
           stateagg.num = as.numeric(stateagg)) %>%
    
    # keep parents within selected age range and save first 5 years
    # if we match parents starting in min(interview year), we will not have t = -5
    # matches, and so on until min + 5, so we start at min + 5
    
    filter((child == 1 & inrange(age1b, min.age, max.age) & doiy >= min(doiy) + 5) 
           | (child == 0))
  
  # format statefip code
  
  df <- df %>%
    mutate(statefip.num = sprintf("%02d",statefip))
  
  # filter out missings
  if(grepl("ly",tvar)) {
    df <- df %>%
      filter(!is.na(earnings_ly))
  } else {
    df <- df %>%
      filter(!is.na(emp_lw))
  }
  
  # sort to uniquely identify so seed works
  
  df <- df[
    with(df, order(doiy, month, serial, pernum)),
  ]
  
  # sample of parents we use for matching (child aged 0)
  
  child0 <- df %>%
    filter(eldch == 0) %>%
    droplevels() %>%
    dplyr::rename(doiy_actual = doiy) %>%
    dplyr::rename(age_actual = age)
  
  # create variables for age and interview year - i, where i is from 0 to 5
  
  for(i in 0:5) {
    agevar <- paste0("agerange",as.character(i))
    doiyvar <- paste0("doiyrange",as.character(i))
    child0[agevar] <- child0["age1b"] - i
    child0[doiyvar] <- child0["doiy_actual"] - i
  }
  
  # reshape long to get column with each age - i and year - i where i is 0:5
  # we repeat each parent 6 times so that we can more easily match each parent 6 times
  # to childless person 1 year younger 1 year earlier, 2 years younger 2 years earlier etc.
  # also want to keep their current age and year in using i = 0 to get a match for t = -1 for earnings
  
  child0 <- reshape(as.data.frame(child0), varying = 
                      list(c("agerange0","agerange1","agerange2",
                             "agerange3","agerange4","agerange5"),
                           c("doiyrange0","doiyrange1",
                             "doiyrange2","doiyrange3","doiyrange4","doiyrange5")), 
                    v.names=c("age","doiy"), new.row.names = 1:(nrow(child0)*6),
                    timevar="t_minus", 
                    direction="long")
  
  # t variable starts at 1 not 0, correct
  
  child0 <- child0 %>%
    mutate(t_minus = t_minus -1)
  
  # dataframe of childless observations we use for matches
  
  childless <- df %>%
    filter(child == 0 & inrange(age, 20, 45))
  
  # combine these dataframes
  
  combined <- bind_rows(child0, childless)
  
  #### FIRST SPECIFICATION: gender, age, calendar year
  
  if(spec == "1") {
    combined <- combined %>%
      # id for variables we match on
      group_by(doiy, age, gender.num) %>%
      dplyr::mutate(matching_vars = cur_group_id()) %>%
      ungroup()
    
    # split df into list by bin
    
    combined_bin <-  dlply(combined,.(doiy,age,gender.num))
    
    # apply matching function to each list element separately (match within bin), bind rows
    matched <- setDF(rbindlist(lapply(combined_bin, run_match)))
    matched <- matched %>%
      group_by(gender.num, doiy, age, pair) %>%
      dplyr::mutate(match_bin = cur_group_id()) %>%  # unique id for each matched pair within each bin
      ungroup()
  }
  
  #### SECOND SPEC: gender, age, calendar year, education
  # repeat same process as above with added variable
  
  if(spec == "2") {
    combined <- combined %>%
      group_by(doiy, age, gender.num,edlevel.num) %>%
      dplyr::mutate(matching_vars = cur_group_id()) %>%
      ungroup()
    combined_bin <-  dlply(combined,.(doiy,age,gender.num, edlevel.num))
    
    matched <- setDF(rbindlist(lapply(combined_bin, run_match))) # match each bin separately, bind all dataframes into one
    matched <- matched %>%
      group_by(gender.num, doiy, age, edlevel.num, pair) %>%
      dplyr::mutate(match_bin = cur_group_id()) %>%  # unique id for each matched pair within each bin
      ungroup()  
  }
  
  #### THIRD SPEC: gender, age, calendar year, education, marital status
  # repeat same process as above
  
  if(spec == "3"){
    combined <- combined %>%
      group_by(doiy, age, gender.num,marst.num,edlevel.num) %>%
      dplyr::mutate(matching_vars = cur_group_id()) %>%
      ungroup()
    combined_bin <-  dlply(combined,.(doiy,age,gender.num, marst.num,edlevel.num))
    
    matched <- setDF(rbindlist(lapply(combined_bin, run_match))) # match each bin separately, bind all dataframes into one
    matched <- matched %>%
      group_by(gender.num, doiy, age, marst.num, edlevel.num, pair) %>%
      dplyr::mutate(match_bin = cur_group_id()) %>%  # unique id for each matched pair within each bin
      ungroup()   
  }
  
  # childless people we have matched
  
  matched_childless <- matched %>%
    filter(child == 0)
  
  
  matched_child <- matched %>%
    filter(child == 1) %>%
    subset(select=c(age1b,nchild,match_bin,
                    metro)) %>%
    dplyr::rename(syn_age1b = age1b,
           syn_nchild = nchild,
           syn_metro = metro)
  
  # add matched age at first birth to childless df
  # we do all of this so that we can ignore the 6x multiplied parent obs and just extract age1b
  
  matched_final <- merge(matched_child, matched_childless,by="match_bin",all.x=T)
  
  # combine childless obs with original parent obs
  
  matched_final <- bind_rows(matched_final,subset(df,child==1))
  
  # sample selection variables
  
  matched_final <- matched_final %>%
    mutate(sample_childless = ifelse(inrange(syn_age1b, min.age, max.age),1, 0)) %>%
    mutate(sample = ifelse(sample_childless == 1 | (child == 1 & inrange(age1b,min.age,max.age)), 1, 0)) %>%
    mutate(age1b = ifelse(child==0 & sample_childless == 1, syn_age1b, age1b)) %>%
    subset(select=-c(gender.num,race.num,marst.num,edlevel.num)) %>%
    mutate(wgt_match = 1)
  
  # event time
  if(grepl("lw",tvar)){
    matched_final <- matched_final %>%
      mutate(eldch = as.numeric(unclass(eldch))) %>% 
      # define event time
      mutate(t_temp = as.numeric(case_when(child == 1 ~ eldch,
                                           child == 0 & (age - age1b != 0) ~ age - age1b,
                                           child == 0 & (age - age1b == 0) ~ NA_real_)))
    suffix <- "lw"
  } else {
    matched_final <- matched_final %>%
      mutate(eldch = as.numeric(unclass(eldch))) %>% 
      # define event time
      mutate(t_temp = as.numeric(case_when(child == 1 & inrange(eldch, 1, 98) ~ eldch - 1,
                                           child == 0~ age - age1b - 1)))
    suffix <- "ly"
    
  }
  
  matched_final <- matched_final %>%
    # cap event times - 6 and 11
    mutate(t_temp = case_when(t_temp<=-6 ~ NA_real_,
                              t_temp>=11 ~ NA_real_,
                              TRUE ~ t_temp)) %>%
    # convert to factor
    mutate(t_temp = as.factor(t_temp)) %>%
    # set -2 as first factor to omit it
    within(t_temp <- relevel(t_temp, ref = ref)) %>% 
    drop_na(t_temp) %>%
    # post variable
    mutate(post_temp = fct_collapse(t_temp, pre = c("-5", "-4", "-3", "-2","-1"), 
                                    post = c("0", "1", "2", "3","4", "5", "6", "7", "8", "9", "10")))
  
  matched_final[tvar] <- matched_final["t_temp"]
  matched_final[paste0("post_",suffix)] <- matched_final["post_temp"]
  
  matched_final <- matched_final %>%
    subset(select=-c(t_temp, post_temp))
  
  assign({{name}},matched_final)
  return(matched_final)
}

#-------Function to run matching and create event studies for Figures A.1-A.3--------#

reg_matching_steps <- function(spec,df_cps,df_acs) {
  
  # CPS annual matching
  df_cps_earn <- match_age1b_steps(df=df_cps, name="cps_earn",spec={{spec}}, tvar="t_es_ly")
  
  # CPS weekly matching
  df_cps_matched <- match_age1b_steps(df=df_cps, name="cps",spec={{spec}}, tvar="t_es_lw")
  
  # ACS weekly matching
  df_acs_matched <- match_age1b_steps(df=df_acs, name="acs",spec={{spec}}, tvar="t_es_lw")
  
  # ACS annual matching
  df_acs_earn <- match_age1b_steps(df=df_acs, name="acs_earn",spec={{spec}}, tvar="t_es_ly")
  
  # combine dataframes, define additional variables
  final <- bind_rows(df_acs_matched,df_cps_matched)
  final <- bind_rows(final, df_cps_earn) %>%
    bind_rows(df_acs_earn)
  
  # it's easier to combine our matched datasets together, but for CPS march and monthly
  # we will have some of the same observations repeated but matched differently
  # want to make sure to not double count them in our various analyses
  
  final <- final %>%
    filter(!is.na(age1b)) %>%
    filter(!(is.na(t_es_lw) & is.na(t_es_ly)))
  
  # label variables
  final <- apply_labels(final, earnings_ly = "Earnings", emp_lw = "Weekly Employment", earn_ly = "Annual Employment")
  
  # generate event studies
  coef_both_steps <- lapply(c("emp_lw","earn_ly","earnings_ly"), reg_es, data = final, 
                            plotname = paste0("matching_spec",{{spec}}), appendix=T)
}


#-------------------- Run different matching specifications for CPS/ACS ------------------------#

  # Load CPS

load(file.path(cleandir,"cps_clean.RData"))

  # prep df of CPS 1995-1999 with non-missing earnings obs to match ACS 2000-2004 to
cps_merge <- cps %>%
  filter(child == 0 & inrange(doiy, 1995,1999)) %>%
  subset(select = -c(dataset)) %>%
  mutate(dataset = as.factor("ACS")) %>%
  mutate(dataset = factor(dataset, levels = c("CPS", "ACS", "NLSY79", "PSID"))) %>%
  mutate(from_cps = 1) 

  # Load ACS
load(file.path(cleandir,"acs_clean.RData"))

  # Combine with CPS 1995-99
acs <- bind_rows(cps_merge,acs)
rm(cps_merge)

  # Create figures to show progressive improvement of matching
lapply(c("1","2","3"),reg_matching_steps,df_cps=cps, df_acs=acs)
