#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates all the exhibits in the paper.
# We are unable to redistribute PSID and GSS geocode data. 
# Code sections using restricted-access data are executed conditionally, depending on whether 
# the corresponding data files are available locally. 
# We provide derived GSS datasets with which all Figures based on GSS data can be drawn.

#############################################################################################

tictoc::tic()

# Initialize log file
logdir <- here::here("Output", "Logs")
dir.create(logdir, recursive = TRUE, showWarnings = FALSE)

logfile <- file.path(logdir, "log.txt")
log_con <- file(logfile, open = "wt")

sink(log_con, split = TRUE)
sink(log_con, type = "message")

on.exit({
  cat("\n\n===== SESSION INFO =====\n")
  print(sessionInfo())
  sink(type = "message")
  sink()
  close(log_con)
}, add = TRUE)

cat("Replication log started:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"), "\n")
cat("Project directory:", here::here(), "\n\n")

# Clear environment, set up data availability flags
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"), echo = TRUE)


################ Label and Create Raw Data Files #####################

    #### GSS
    # convert to rds and add variable labels to GSS data
    if (process.gss){
      message("Found GSS Geofile - processing GSS data")
      source(here::here("Code","convert_gss_data_to_R_format.R"), echo = TRUE)
      source(here::here("Code","create_gss_var_label_data.R"), echo = TRUE)
    }else{
      message("Skipping GSS processing")
    }

############### Data Cleaning ########################################

    # Current Population Survey (CPS)
    source(here::here("Code","clean_cps.R"), echo = TRUE)
    
    # American Community Survey (ACS)
    source(here::here("Code","clean_acs.R"), echo = TRUE)
    
    # Combined CPS and ACS Cross-Section
    source(here::here("Code","dataset_cps_acs_pre.R"), echo = TRUE)
    
    # Panel Study of Income Dynamics (PSID)
    if (process.psid){
      message("Found PSID data - processing and using PSID data")
      source(here::here("Code","clean_psid.R"), echo = TRUE)
    }else{
      message("Skipping PSID processing and usage")
    }

    # National Longitudinal Survey of Youth (1979 Cohort) (NLSY79)
    source(here::here("Code","clean_nlsy79.R"), echo = TRUE)
    
    # General Social Survey (GSS)
    if (process.gss){
      source(here::here("Code","clean_gss.R"), echo = TRUE)
    }
    
    # US Census Population Data
    source(here::here("Code","clean_us_state_population.R"), echo = TRUE)


#####################################################################

############## Matching ############################################

    # Create CPS and ACS pseudo-panel
    source(here::here("Code","matching.R"), echo = TRUE)

####################################################################


#############  Results #############################################

#------------------- Descriptive Statistics Tables ----------------#
    # Table 1
    source(here::here("Code","table_descriptive_stats_xsection.R"), echo = TRUE)
    # Table 2
    source(here::here("Code","table_descriptive_stats_pseudo_panel.R"), echo = TRUE)

#------------------- Validation of Method ------------ #
    # Figure 1: CPS and ACS pseudo-event study vs actual PSID and NLSY event study
    # Also produces Panel D of Figures A.1-A.3
    if (process.psid){
      source(here::here("Code","fig_validation_eventstudy.R"), echo = TRUE)
    }
    
    # Figure 2: PSID and NLSY pseudo-panel
    if (process.psid){
      source(here::here("Code","matching_panel.R"), echo = TRUE)
    }
    
    # Hausman Test
    if (process.psid){
      source(here::here("Code","hausman_test.R"), echo = TRUE)
    }

    # Table A.1: Test of assumption 3 in panel data
    if (process.psid){
      source(here::here("Code","table_validation_assumption_conditional_independence.R"), echo = TRUE)
    }

    # Figure 3: Within-panel validation in subsamples
    if (process.psid){
      source(here::here("Code","fig_validation_within-panel_scatter.R"), echo = TRUE)
    }
    
    # Figures A.1-A.3, Panels A-C
    source(here::here("Code","matching_appendix.R"), echo = TRUE)
    
    # Figure A.4: Quality of fertility prediction
    if (process.psid){
      source(here::here("Code","fig_validation_histogram.R"), echo = TRUE)
    }
    
    # Figure A.5; Panels B,D,F: Robustness to heterogeneous treatment effects
    source(here::here("Code","fig_validation_age1b.R"), echo = TRUE)

#----------------- Child Penalties Over Time --------------#
    # Figures 4, A.6-A.8: Child penalties over time
    source(here::here("Code","fig_time.R"), echo = TRUE)
    
    # Figure A.9: Unscaled child penalties and counterfactuals over time
    source(here::here("Code","fig_time_unscaled.R"), echo = TRUE)
    
    # Figure A.10: Fraction of gaps explained over time
    source(here::here("Code","fig_time_pct_exp.R"), echo = TRUE)

#---------------- Child Penalties Over Space ----------------#

    # Figures 5-6, A.11-A.13: Event studies and heat maps by state
    source(here::here("Code","fig_state_eventstudy_heatmaps.R"), echo = TRUE)
    
    # Figure A.14: Scatterplots of raw gender gaps vs child penalties
    source(here::here("Code","fig_state_scatterplots_gender_gaps.R"), echo = TRUE)
    
    # Figure 7: Scatterplots of unadjusted child penalties and counterfactuals
    source(here::here("Code","fig_state_scatterplots_unadjusted.R"), echo = TRUE)
    
    # Figures A.15-A.16: EB vs OLS estimates of child penalties by state
    source(here::here("Code","fig_shrinkage.R"), echo = TRUE)

#------------ Child Penalties by Demographics ---------#
    # Figure 8: Event studies by education, race, and marital status
    source(here::here("Code","fig_eventstudy_demographics.R"), echo = TRUE)

#------------- The Effect of Elicited Gender Norms on Penalties -------------#

    ### Additional preparation of GSS data
    # Get weights for GSS averages over states using pseudo-panel data
    source(here::here("Code","dataset_gss_reweighting.R"), echo = TRUE)
    
    # Create GSS state-by-time dataset
    if (process.gss){
      source(here::here("Code","dataset_gss_collapsed.R"), echo = TRUE)
    }
    
    # Impute missing GSS state-decade combinations and create new GSS datasets
    if (process.gss){
      source(here::here("Code","dataset_gss_imputed_collapsed.R"), echo = TRUE)
    }
    
    ### Additional preparation of child penalties data
    # Get child penalties by state and decade
    source(here::here("Code","dataset_penalties_state_time.R"), echo = TRUE)
    
    # Get control variables for penalties vs GSS analysis
    source(here::here("Code","dataset_gss_vs_penalties_controls.R"), echo = TRUE)
    
    ### Summary of GSS data
    # Figure 9: Heat map of Gender Progressivity Index (GPI)
    source(here::here("Code","fig_gss_heatmaps_state.R"), echo = TRUE)
    
    # Figure 10: Time series of child penalties vs GPI
    source(here::here("Code","fig_gss_vs_penalties_timeseries.R"), echo = TRUE)
    
    # Figure A.17: GPI by state and time
    source(here::here("Code","fig_gss_timeseries_by_state.R"), echo = TRUE)
    
    # Figure 11: Binscatters of child penalties vs GPI by state and time
    source(here::here("Code","fig_gss_vs_penalties_scatterplots_state_time.R"), echo = TRUE)

#----------- Epidemiological Approach: US Movers -----------#

    # Get event study coefficients for movers vs stayers
    source(here::here("Code","dataset_epidemiological_us_eventstudy_movers_vs_stayers.R"), echo = TRUE)
    
    # Figures 12, A.18-A.19: Estimate penalties for mover and stayer women
    # and plot event studies
    source(here::here("Code","fig_epidemiological_us_eventstudy_movers_vs_stayers.R"), echo = TRUE)
    
    # Figure 13, Figure A.20: Scatterplots of penalties for US movers vs stayers
    # in state of birth and state of residence
    source(here::here("Code","fig_epidemiological_us_scatterplots.R"), echo = TRUE)

#---------- Epidemiological Approach: Foreign Immigrants ------------#

    # Figure 14, Figure A.21: Event studies by country of birth
    source(here::here("Code","fig_epidemiological_foreign_eventstudy_birth_country.R"), echo = TRUE)
    
    # Figure 15: Event studies for immigrants by decile of penalty in birth-country
    source(here::here("Code","fig_epidemiological_foreign_eventstudy_deciles.R"), echo = TRUE)
    
    # Figure 16, Figure A.22: Scatterplots of child penalties for immigrants
    source(here::here("Code","fig_epidemiological_foreign_scatterplots.R"), echo = TRUE)
    
    # Figure A.23: Event studies by education for immigrants
    source(here::here("Code","fig_epidemiological_foreign_eventstudy_education.R"), echo = TRUE)
    
    # Figure A.24: Cultural assimilation of immigrants
    source(here::here("Code","fig_epidemiological_foreign_eventstudy_cultural.R"), echo = TRUE)
    
    # Table 3: Selection of movers and immigrants by place of birth
    source(here::here("Code","table_descriptive_stats_movers_immigrants.R"), echo = TRUE)

###################################################################

tictoc::toc()
