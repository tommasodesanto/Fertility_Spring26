#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates the binscatters in Figure 11
# (Child Penalties vs Gender Progressivity Across States and Time)
# Section 1 defines a function to create binscatters
# Section 2 defines a function that adds controls and calls the 
# binscatter function in section 1
# Section 3 loads all necessary data and calls the function
# from Section 2 to create all plots

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))


###################################
# 1. Function For Binscatters

###################################


binscatter <- function(data,d, plotname="", ymin=0.05,ymax=0.45,
                       xmin=-0.75,xmax=0.5,xskip=0.25, ar2) {
  
  
  # Graph labels
  if({{d}}=="earn_ly"){
    depvarlbl <- "emp_annual"
  }
  if({{d}}=="emp_lw"){
    depvarlbl <- "emp_weekly"
  }
  if({{d}}=="earnings_ly"){
    depvarlbl <- "earnings"
  }
  
  ########### Get deciles for binscatter
  
  # get decile of x 
  data <- data %>%
    arrange(xvar_plot) %>% 
    mutate(decile_rank = ntile(xvar_plot,10),
           decile_rank_y = ntile(yvar_plot,10))
  
  # get mean of y (penalty) within each decile
  bins_mean <- data %>%
    group_by(decile_rank) %>%
    dplyr::summarise(mean_y = mean(yvar_plot, na.rm=T),
                     mean_decile_y = mean(decile_rank_y, na.rm=T),
                     x_mid = mean(xvar_plot, na.rm=T)) %>% 
    ungroup()
  
  ## Regressions for text on graph
  # Binned data: binscatter, avg residualized penalty within decile vs. midpoint of decile of norms measure
  binreg <- lm(mean_y ~ x_mid, data = bins_mean)
  # Slope text
  slope <- binreg[["coefficients"]][["x_mid"]]
  slope <- sprintf("%.3f", slope)
  se <- coef(summary(binreg))[,"Std. Error"][["x_mid"]]
  se <- sprintf("%.3f", se)
  txt <- paste0("Slope == ",slope,
                "~(", deparse(se), ")")
  
  # Adjusted R-squared text
  txt_ar <- paste0("Adj.~R^2 == ", ar2)

  ##  Function for bootstrapping
  # bootstrapped regression
  fn_boot <- function(data, index){
    reg <- lm(mean_y ~ x_mid, data=bins_mean[index,])
    preds <- predict(reg, bins_mean)
    return(preds)
  }
  
  # Set seed
  set.seed(seed.val)
  
  # Predicted values based on line of best fit
  bins_mean$prediction <- predict(binreg, bins_mean)
  
  # Bootstrap prediction from regression
  bootreg <-boot(bins_mean, fn_boot, R=200)
  
  # Get bootstrapped confidence intervals
  bootreg <- as.data.frame(tidy(bootreg)) %>%
    mutate(conf.low = statistic - bias + qnorm(0.025, 0, 1)*std.error,
           conf.high = statistic - bias + qnorm(0.975, 0, 1)*std.error)
  
  # Add boostrapped values to dataset
  bins_mean <- merge(bins_mean, bootreg, by.x="prediction", by.y="statistic", all=T)
  
  # Plot binscatter
    
  # position of slope text
  if(max(bins_mean$mean_y)-min(bins_mean$mean_y)<0.06) {
    ytext <- ymax-0.001  
  } else {
    ytext <- ymax-0.03
  }
  xtext <- xmax - 0.03
  # ytext2 <- ytext-((ymax - ymin)/15)
  
  # position of adjusted R-squared text
  if({{d}}=="earn_ly"){
    ytext_ar2 <- 0.43
  }
  if({{d}}=="emp_lw"){
    ytext_ar2 <- 0.52
  }
  if({{d}}=="earnings_ly"){
    ytext_ar2 <- 0.75
  }
  xtext_ar2 <- xtext - 0.20
  
  # x and y labels
  if(grepl("first",plotname)){ 
    ylab <- "First Difference of Child Penalty"
    xlab <- "First Difference of GPI"
  } else {
    ylab <- "Child Penalty"
    xlab <- "Gender Progressivity Index"
  }
  
  # transformation function for axis labels
  scaleFUN <- function(x) sprintf("%.2f", x)
  
  # Plot
  ggplot(bins_mean, aes(x=x_mid,y=mean_y)) +
    # fitted line using bins
    stat_smooth(data=bins_mean, aes(x=x_mid, y=mean_y),method="lm",
                formula = y ~ x, se=F, color="#D11809") +
    geom_ribbon(aes(ymin=conf.low,ymax=conf.high),alpha=0.3,show.legend = F,
                colour = NA, fill="#D11809") +
    # point size and color
    geom_point(size=6, color= rgb(26,71,111, maxColorValue = 255)) +
    # axes
    coord_cartesian(ylim=c(ymin,ymax),xlim=c(xmin,xmax))+
    scale_y_continuous(breaks=seq(ymin, ymax, by = 0.1), labels=scaleFUN)+
    scale_x_continuous(breaks=seq(xmin, xmax, by = xskip))+
    labs(y = ylab, x = xlab)+
    # slope text
    annotate("text", x=xtext,y=ytext,
             label=txt, size=9, parse = TRUE, color="black",hjust=1)+
    # Adjusted R-squared text
    annotate("text", x = xtext_ar2, y = ytext_ar2, 
             label = txt_ar, size = 9, 
             parse = TRUE, color = "black", hjust = 1)+
    # theme
    theme_minimal() +
    theme(axis.line = element_line(colour = "black",size=0.2)) +
    theme(panel.grid.minor.x = element_blank(),
          panel.grid.minor.y = element_blank(),
          axis.text=element_text(size=25),
          axis.title=element_text(size=25),
          legend.position="none",
          legend.key.height = unit(1, "cm"),
          legend.key.size = unit(2, "cm"),
          legend.text = element_text(size=25))+
    theme(axis.text.x = element_text(margin = unit(c(0.7,0,0,0), "cm")),
          axis.text.y = element_text(margin = unit(c(0,0.7,0,0), "cm"))
    ) +
    theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)),
          axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)))
  
  # save
  ggsave(paste0("gss_state_by_time_",
                      # fe,
                      plotname,"_",depvarlbl,".pdf"), 
         plot=last_plot(), device="pdf",
         width=11, height=8, units="in",path=file.path(outdir,"Figures"))
    
  
}

###################################
# 2. Function to prep data
# and create plots
###################################

state_time_resid <-  function(data, d, xvar, yvar, plotname="", ymin, ymax, xmin,
                              controls="") {
  
  
  # Graph labels
  if({{d}}=="earn_ly"){
    depvarlbl <- "emp_annual"
  }
  if({{d}}=="emp_lw"){
    depvarlbl <- "emp_weekly"
  }
  if({{d}}=="earnings_ly"){
    depvarlbl <- "earnings"
  }
  
  data["xvar"] <- data[{{xvar}}]
  data["yvar"] <- data[{{yvar}}]
  
  data <- data %>%
    filter(depvar == {{d}}) %>%
    drop_na(xvar,yvar) %>%
    droplevels()
    
  data$yvar_plot <- data$yvar
  data$xvar_plot <- data$xvar
    
    # 1. State FE only
    if(controls=="stateFE"){
      # regression
      reg_1stage <- feols(yvar_plot ~ xvar_plot | statename, data = data)
      
      # prediction based on state FE
      data$sumFE <- reg_1stage$sumFE
      
      # residualize by state FE and all other controls
      data <- data %>%
        mutate(yvar_plot = yvar_plot - sumFE)
      
      # add average effect of state fe back to residualized penalties
      data$yvar_plot <- data$yvar_plot + mean(fixef(reg_1stage)$statename)
      
      # storing Adjusted R-squared for the graph
      ar2_num <- r2(reg_1stage, "ar2")["ar2"]
      ar2_num <- sprintf("%.3f", ar2_num)
    }
    
    # 2. All demographic controls: final control specification
    if(controls=="stateFE_demo"){
      reg_1stage <- feols(yvar_plot ~ xvar_plot + hsandbelow + college + frac_married + white_hisp + black_hisp | statename, data = data)
      data$sumFE <- reg_1stage$sumFE
      
      # residualize by state FE and all other controls
      data <- data %>%
        mutate(yvar_plot = yvar_plot- sumFE  
               - reg_1stage[["coefficients"]][["college"]]*college
               - reg_1stage[["coefficients"]][["hsandbelow"]]*hsandbelow
               - reg_1stage[["coefficients"]][["frac_married"]]*frac_married
               - reg_1stage[["coefficients"]][["white_hisp"]]*white_hisp
               - reg_1stage[["coefficients"]][["black_hisp"]]*black_hisp)
      
      # add average impact of controls back to residualized penalties
      data$yvar_plot <- data$yvar_plot + mean(fixef(reg_1stage)$statename)
      data$yvar_plot <- data$yvar_plot + (mean(data$college)*reg_1stage[["coefficients"]][["college"]])
      data$yvar_plot <- data$yvar_plot + (mean(data$hsandbelow)*reg_1stage[["coefficients"]][["hsandbelow"]])
      data$yvar_plot <- data$yvar_plot + (mean(data$frac_married)*reg_1stage[["coefficients"]][["frac_married"]])
      data$yvar_plot <- data$yvar_plot + (mean(data$white_hisp)*reg_1stage[["coefficients"]][["white_hisp"]])
      data$yvar_plot <- data$yvar_plot + (mean(data$black_hisp)*reg_1stage[["coefficients"]][["black_hisp"]])
      
      # storing Adjusted R-squared for the graph
      ar2_num <- r2(reg_1stage, "ar2")["ar2"]
      ar2_num <- sprintf("%.3f", ar2_num)
    }
  
  # Create bin and rank scatter
      if(d == "earnings_ly"){
        binscatter(data,d, plotname=controls, ymin=0.2,ymax=0.85,xskip=0.25,
                   xmin=-0.75,xmax=0.5, ar2 = ar2_num)
      }
      if(d == "earn_ly"){
        binscatter(data,d, plotname=controls, ymin=0.1,ymax=0.5,xskip=0.25,
                   xmin=-0.75,xmax=0.5, ar2 = ar2_num)
      }
      if(d == "emp_lw"){
        binscatter(data,d, plotname=controls, ymin=0.1,ymax=0.6,xskip=0.25,
                   xmin=-0.75,xmax=0.5, ar2 = ar2_num)
      }

}

##################################
# 3. Load data and run functions
##################################

##### Load state by decade datasets

# Child penalties
cp_state_10yr <- read_rds(file.path(wrkdir, "penalties_state_by_decade.rds")) %>%
  rename(interval = yr10)

# GSS
gss_state_10yr  <- read_rds(file.path(wrkdir, "gss_imputed_state_by_decade.rds")) %>%
  mutate(statename = as.factor(as.character(statename)))

# Merge
cp_gss_state_10yr <- merge(cp_state_10yr, gss_state_10yr, by=c("statename", "interval"))

# Apply labels

cp_gss_state_10yr <- apply_labels(cp_gss_state_10yr,
                                  interval = "yr10")
# Topcode child penalty at 1

cp_gss_state_10yr <- cp_gss_state_10yr %>%
  mutate(penalty = ifelse(penalty > 1, 1, penalty))

# Load controls
state_time_controls <-  read_rds(file.path(wrkdir, "gss_controls_from_pseudo-panel.rds")) %>%
  rename(interval=yr10) %>%
  mutate(hsandbelow = ifelse(is.na(hsandbelow),0,hsandbelow))

# Merge controls with main data
cp_gss_state_10yr <- cp_gss_state_10yr %>%
  merge(state_time_controls, by=c("statename","interval","depvar"), all.x=T)


# Run function on all outcome vars
  # Panel A: "state" (state FE only)
  # Panel B: "demo" (state FE, education, marital status, and race)

args <- expand_grid(d = unique(cp_gss_state_10yr$depvar),yvar=c("penalty"),
                     xvar=c("index_ad"), controls=c("stateFE","stateFE_demo"))
pmap(args, state_time_resid, data = cp_gss_state_10yr)

