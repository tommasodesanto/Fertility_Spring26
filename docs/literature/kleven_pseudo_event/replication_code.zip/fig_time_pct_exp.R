#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates the timeseries in Figure A.10
# (Fraction of Raw Gender Gaps Explained by Child Penalites)
# plot_timeseries is the function used to create a timeseries graph
# gender_gap_time is the function used to calculate the fraction explained
# and runs plot_timeseries within it
# Then, data is loaded and we run gender_gap_time

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

  # General function for time series plots
plot_timeseries <- function(data, yvar, plotname = ""){
  
  coef <- data
  
  # Variable names
  coef["yvar"] <- coef[{{yvar}}]
  coef <- coef %>%
    rename(interval=hetero)
  

  # Plots
  ymax <- 1.1
  ymin <- 0
  
  # All variables
  
  ggplot(coef, aes(y=yvar, x=interval, group=depvar_lab,color=depvar_lab))  +
    # display all x values on axis
    scale_x_discrete(labels=levels(coef$interval))+
    coord_cartesian(ylim=c(ymin,ymax),clip = 'off')+
    # line and point sizes
    geom_point(aes(shape=depvar_lab,size=depvar_lab, color=depvar_lab)) +
    geom_line(linewidth=1)+
    # axis labels
    labs(x="Year", y=var_label(coef$yvar)) +
    # theme + grid lines
    theme_minimal() +
    theme(axis.line = element_line(colour = "black",linewidth=0.2),
          panel.grid.major.x = element_blank(),
          panel.grid.minor.y = element_blank(),
          legend.key.size = unit(3,"lines"),
          legend.position = "none", legend.background=element_blank())  +
    theme(
      text=element_text(size=20)
    ) +
    geom_text(data = filter(coef, interval == "2015-20"),
              aes(color=depvar_lab,
                  label=depvar_lab),position=
                position_nudge(x=0.1,y=case_when(coef$depvar_lab=="Annual Employment" ~ 0.04,
                                                 coef$depvar_lab=="Weekly Employment" ~ -0.02,
                                                 TRUE ~ 0)),
              size=7,hjust=0)+
    scale_color_manual(name="",values = c(rgb(186,17,17, maxColorValue = 255),"black",
                                          rgb(26,71,111, maxColorValue = 255)),
                       breaks=c("Earnings","Annual Employment","Weekly Employment"))+
    scale_shape_manual(values=c(15,16,17))+
    scale_size_manual(values=c(5,5,5))+
    theme(legend.position = 'none',
          plot.margin = unit(c(0, 5, 0, 0), "cm"))+ 
    theme(axis.text.x = element_text(margin = unit(c(0.5,0,0,0), "cm")),
          axis.text.y = element_text(margin = unit(c(0,0.4,0,0), "cm"))
    ) +
    theme(axis.title.y = element_text(margin = margin(t = 0, r = 10, b = 0, l = 0)),
          axis.title.x = element_text(margin = margin(t = 10, r = 0, b = 0, l = 0)))+
    scale_y_continuous(breaks=seq(ymin,ymax, by=0.1),labels = function(x) paste0(x*100, "%"))
  
  ggsave(paste0(plotname,".pdf"), plot=last_plot(), device="pdf",
         width=15, height=8, units="in",path=file.path(outdir,"Figures"))
}

  # Function to calculate fraction of gaps explained by penalties and plot
gender_gap_time <- function(data, hetero) {
  
  # get counterfactuals for women from event study regression by hetero
  coef <- setDF(rbindlist(lapply(l.depvars, reg_es_hetero, data=data,
                                 hetero={{hetero}}, return_coef="cf", export=F))) %>%
    rename(cf_mother = mean_cf)
  
  data["hetero"] <- data[{{hetero}}]
  
  # Get fraction of women with kids in each outcome's sample
  frac_ly <- data %>%
    subset(!is.na(earnings_ly) & !is.na(t_es_ly)) %>%
    subset(gender=="Women") %>%
    group_by(hetero) %>%
    summarize(earn_ly = weighted.mean(child, wgt),
              earnings_ly = weighted.mean(child,wgt))
  
  frac_lw <- data %>%
    subset(!is.na(emp_lw) & !is.na(t_es_lw)) %>%
    subset(gender=="Women") %>%
    group_by(hetero) %>%
    summarize(emp_lw = weighted.mean(child, wgt))
  
  frac <- merge(frac_ly, frac_lw, by="hetero") %>%
    pivot_longer(cols=c("emp_lw","earnings_ly","earn_ly"),names_to="depvar",
                 values_to="frac")
  
  # Keep parents only
  data <- subset(data, child == 1)

  # Average of each outcome for men and women by hetero
  gaps_ly <- data %>%
    subset(!is.na(earnings_ly) & !is.na(t_es_ly)) %>%
    group_by(gender, hetero)%>%
    summarize(earn_ly = weighted.mean(earn_ly, wgt),
              earnings_ly = weighted.mean(earnings_ly, wgt))
  
  gaps_lw <- data %>%
    subset(!is.na(emp_lw) & !is.na(t_es_lw)) %>%
    group_by(gender,hetero) %>%
    summarize(emp_lw = weighted.mean(emp_lw, wgt))
  
  # Calculate gender gap in each outcome
  gaps <- merge(gaps_lw, gaps_ly, by=c("gender","hetero")) %>%
    pivot_longer(cols=c("emp_lw","earnings_ly","earn_ly"),names_to="depvar",
                 values_to="y") %>%
    spread(gender,y) %>%
    mutate(gap=(Men-Women)/Men) %>%
    rename(y_father=Men)
  
  # Get child penalties
  cp <- readRDS(file=file.path(wrkdir,paste0("penalties_",hetero,".rds"))) %>%
    rename(penalty = estimate)
  
  # Merge all results
  coef <- merge(coef, cp, by=c("hetero","depvar",'depvar_lab')) %>%
    merge(gaps, by=c("hetero","depvar"))%>%
    merge(frac, by=c("hetero","depvar"))
  
  # percent explained = child penalty *(counterfactual for mothers/outcome for fathers)
    # all divided by the raw gender gap
  coef <- coef %>%
    mutate(pct_exp = (penalty*(cf_mother/y_father))/(gap))%>%
    rename(gender_gap = gap) %>%
    mutate(parents=1)
  
  # Add variable labels
  coef <- apply_labels(coef,
                       penalty = "Child Penalty",
                       gender_gap = "Gender Gap",
                       pct_exp = "Percent Explained")
  
  # Plot time series graphs
  lapply(c("pct_exp"), plot_timeseries, data=coef, plotname= "fraction_explained_timeseries")
  
  return(coef)
}


# Load CPS and ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

# Define vector of outcomes of interest
l.depvars <- c("earnings_ly", "emp_lw","earn_ly")

# Run function to produce plot
gender_gap_time(data=cps_acs, hetero="yr5")
