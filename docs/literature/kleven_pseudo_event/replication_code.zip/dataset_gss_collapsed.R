#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates a dataset of the Gender Progressivity Index (GPI)
# by state and time using GSS data by taking averages of the GPI
# by state and decade

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# load cleaned GSS data
gss <- read_rds(file.path(cleandir, "gss_clean.rds"))  

# Create variables -------------------------------
# Year Intervals by State
gss <- gss %>% 
  # Create 5-year intervals
  mutate(five_year_interval = floor(year/5)*5) %>% 
  mutate(five_year_interval = as.factor(paste0(five_year_interval, "-", substr(five_year_interval+4, 3, 4)))) %>% 
  mutate(five_year_interval = as.factor(case_when(
    year>=1972&year<=1979 ~ "1972-79",
    year>=2015 ~ "2015-20",
    TRUE ~ as.character(five_year_interval)))) %>% 
  # Create 10-year intervals
  mutate(ten_year_interval = floor(year/10)*10) %>% 
  mutate(ten_year_interval = as.factor(paste0(ten_year_interval, "-", substr(ten_year_interval+9, 3, 4)))) %>% 
  mutate(ten_year_interval = as.factor(case_when(
    year>=1972&year<=1979 ~ "1972-79",
    year>=2010 ~ "2010-20",
    TRUE ~ as.character(ten_year_interval))))  

# residualise index variables 
fn_resid <- function(indexvar) {
  
  gss_2 <- gss %>% 
    mutate(indexvar = !!sym(indexvar))
  
  mod <- lm(indexvar ~ as.factor(stfips), data = gss_2, na.action = na.exclude)
  res <- residuals(mod, newdata =gss_2)
  
  return(res)
}
res <- purrr::map(list("index_all", "index_cp", "index_ad", "fefam"), fn_resid)
names(res) <- c("index_all_res", "index_cp_res", "index_ad_res", "fefam_res")

gss_2 <- gss %>% 
  cbind(res) %>% 
  dplyr::select(id, stfips, stname, stabbr, year, five_year_interval, ten_year_interval, wtssall,
         starts_with("index_"), starts_with("fefam"), -fefam_orig)

ind_var <- c("index_all", "index_all_res", "index_cp", "index_cp_res", "index_ad", "index_ad_res", 
             "fefam", "fefam_res")

# create state by time data for 5 and 10 year intervals
create_dat <- function(interval) {
  groupdata<- gss_2 %>% 
    drop_na(stfips) %>%
    group_by(fips=stfips,state=stname,interval =!!sym(interval)) %>% 
    summarise(across(all_of(ind_var),
                     ~weighted.mean(.x, wtssall, na.rm=T)))  %>% 
    ungroup() %>% 
    mutate(across(all_of(ind_var), ~if_else(is.na(.x), NA_real_, .x)))
  
  saveRDS(groupdata, file= file.path(file.path(wrkdir,paste0("gss_state_by_", interval, ".rds"))))
}

intervallist <- list("ten_year_interval")
walk(intervallist, create_dat)
