#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates Figure A.17, the timeseries of GPI by state and time.

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# load data
gss <- read_rds(file.path(wrkdir, "gss_imputed_state_by_decade.rds"))  

gss <- gss %>%
  mutate(imputed_val = imputed) %>%
  mutate(imputed = ifelse(is.na(quant), "Imputed", "Actual"))

gss_state <- gss %>%
  group_by(statename) %>%
  summarise(mean_var = mean(index_ad))

gss <- merge(gss, gss_state, all=T)
gss <- gss %>%
  mutate(interval_old = interval) %>%
  mutate(interval = as.factor(case_when(interval_old == "1972-79" ~ "70s",
                                                 interval_old == "1980-89" ~ "80s",
                                                 interval_old == "1990-99" ~ "90s",
                                                 interval_old == "2000-09" ~ "00s",
                                                 interval_old == "2010-20" ~ "10s")))
gss <- gss %>%
  mutate(interval_num = as.numeric(interval_old))

gss$interval <- fct_reorder(gss$interval, gss$interval_num)

# Function to plot figure--------------------
fn_time_by_st <- function(var) {
  
  
  groupdata<- gss %>% 
    mutate(varmean = !!sym(var))  %>%
    mutate(intorder = as.numeric(interval)) %>%
    mutate(interval_full = interval)
  
  intbreaks <- seq(1,5,1)
  
  groupdata <-  groupdata[order(groupdata$statename, groupdata$intorder),]
  
  # Figure 
  ggplot(data=groupdata,aes(x=intorder, y = varmean))+
    geom_hline(data=groupdata, aes(yintercept=mean_var),linetype = "dashed",
               size=.4,show.legend=F,color="#D11809")+
    geom_line(show.legend = F) +
    geom_point(aes(fill=imputed),color="black",size=2, shape=21, show.legend = F) +
    facet_wrap(~statename, scales = "free") +
    theme_minimal() +
    theme(axis.line = element_line(colour = "black",size=0.2),
          panel.grid.major.x = element_blank(),
          panel.grid.minor.x = element_blank(),
          panel.grid.minor.y = element_blank(),
          legend.position = "bottom",
          panel.spacing = unit(-.2, "lines"),
          legend.key.size = unit(2,"lines"),
          axis.text.x=element_text(size = 6),
          axis.text.y = element_text(size=6))+
    scale_fill_manual(breaks=c("Actual","Imputed"),
                       values=c("black","white"), name="")+
    labs(x = "Year", y = "Gender Progressivity Index") +
    scale_x_continuous(breaks= intbreaks, labels=unique(groupdata$interval)) +
    ylim(-0.9,0.6)
  
  
  ggsave(paste0("gss_timeseries_by_state", ".pdf"), path = file.path(outdir,"Figures"), plot=last_plot(),
         width = 11, height = 8, units = "in")
  
  
  }

# Run function
fn_time_by_st("index_ad")
