#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# Test of assumption 3 (conditional independence) in panel data
# This code creates Table A.1

#############################################################################################

#######################################################
# Clear environment, set up paths 
#######################################################

rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

#######################################################
# Load in data 
#######################################################

# Note: This code only uses pooled PSID/NLSY data

# Load in pseudo panel
pseudo_panel <- readRDS(file.path(wrkdir,"psid_nlsy_pseudo-panel.rds")) 

# Create actual panel 
load(file.path(cleandir,"psid_clean_restricted.RData")) # load in psid
load(file.path(cleandir,"nlsy79_clean_restricted.RData")) # load in nlsy
actual_panel <- bind_rows(psid,nlsy79) # combine psid and nlsy
actual_panel$wgt_match <- 1 # no matching weights for actual event studies (can be treated as 1)
# reorder the levels of the factors to get correct order in coefficient variable
actual_panel$t_es_lw <- factor(actual_panel$t_es_lw,levels=c("-2","-5","-4","-3","-1","0","1","2","3","4","5","6","7","8","9","10")) 
actual_panel$t_es_ly <- factor(actual_panel$t_es_ly,levels=c("-2","-5","-4","-3","-1","0","1","2","3","4","5","6","7","8","9","10"))

#######################################################
# Scale earnings by mean counterfactual in actual panel
#######################################################

# Calculate mean seperately by sex
sex <- c("Women","Men") 
mcf <- c(NaN,NaN) # stores mean counterfactual
i <- 1 # element counter
for(s in sex){ # use mean by gender 
  # Perform regression
  suppressMessages(suppressWarnings({ # supress notes from feols() - these notes are irrelevant in this case
    reg_res <- feols(earnings_ly~t_es_ly|age_factor+doiy_factor,data=filter(actual_panel,gender==s),weights=~wgt,se="hetero") 
  }))
  # Calculate average counterfactual
  reg_data <- data.frame(cf=reg_res$sumFE,
                         wgt_match=fixest_data(reg_res,sample="estimation")[["wgt_match"]])
  mcf[i] <- weighted.mean(reg_data$cf,reg_data$wgt_match) # use mean across all event times 
  i <- i + 1
}

# Scale earnings in both samples by mean 
actual_panel <- mutate(actual_panel,searnings = case_when(gender=="Men" ~ earnings_ly/mcf[2],
                                                        gender=="Women" ~ earnings_ly/mcf[1]))
pseudo_panel <- mutate(pseudo_panel,searnings = case_when(gender=="Men" ~ earnings_ly/mcf[2],
                                                          gender=="Women" ~ earnings_ly/mcf[1]))

#######################################################
# Drop non-matched parents
#######################################################

# Defintion of non-matched: 
# Parents with no match at any t < 0 and parents matched at only one t < 0 
# 
# Dropping procedure: 
# - Drop non-matched parents in all event times in the actual panel
# - Drop non-matched parents in all non-negative event times in the pseudo panel

# Identify non-matched parents
# Load and prepare pseudo data (only need matched columns and time vars)
pseudo <- readRDS(file.path(wrkdir, "psid_nlsy_pseudo-panel.rds")) %>%
  mutate(
    across(where(~ "labelled" %in% class(.)), unclass),
    t_es_lw = as.numeric(as.character(t_es_lw)),
    t_es_ly = as.numeric(as.character(t_es_ly))
  ) %>%
  rename_with(., 
              ~ str_replace(.x, "matched-(\\d+)", "matched_m\\1"),
              .cols = starts_with("matched-")
  )
# Create empty list to store IDs
ids <- list()
# Process each outcome
for (outcome in c("emp_lw", "earnings_ly", "earn_ly")) {
  time_var <- if(outcome == "emp_lw") "t_es_lw" else "t_es_ly"
  # Get IDs where n_matched = 0 or only once 1 at tau=0
  ids[[outcome]] <- pseudo %>%
    filter(!!sym(time_var) == 0) %>%
    mutate(n_matched = matched_m1 + matched_m2 + matched_m3 + matched_m4 + matched_m5) %>%
    filter(n_matched <= 1) %>%
    pull(id) %>%
    unique()
  cat(sprintf("%s: %d IDs\n", outcome, length(ids[[outcome]])))
}

# Create dropped samples
actual_paneld_earn_ly <- filter(actual_panel,!id%in%ids[["earn_ly"]])
actual_paneld_emp_lw <- filter(actual_panel,!id%in%ids[["emp_lw"]])
actual_paneld_searnings <- filter(actual_panel,!id%in%ids[["earnings_ly"]])
pseudo_paneld_earn_ly <- filter(pseudo_panel,!(id %in% ids[["earn_ly"]] & as.numeric(as.character(t_es_ly)) >= 0))
pseudo_paneld_emp_lw <- filter(pseudo_panel,!(id %in% ids[["emp_lw"]] & as.numeric(as.character(t_es_lw)) >= 0))
pseudo_paneld_searnings <- filter(pseudo_panel,!(id %in% ids[["earnings_ly"]] & as.numeric(as.character(t_es_ly)) >= 0))

#######################################################
# Calculate point estimates
#######################################################

# Calculate levels by data set 
y <- list() # stores results
i <- 1 # initialize progress print
# Load in ids to drop  
data <- c("actual_paneld_earn_ly","actual_paneld_emp_lw","actual_paneld_searnings", # put here data sets to consider
          "pseudo_paneld_earn_ly","pseudo_paneld_emp_lw","pseudo_paneld_searnings") 
n <- length(data) * length(sex)  # number of regressions
for(d in data){ # loop over data
  
  # Define outcomes 
  if(d%in%c("actual_paneld_earn_ly","pseudo_paneld_earn_ly")){
    outcome <- "earn_ly"
  }else if(d%in%c("actual_paneld_emp_lw","pseudo_paneld_emp_lw")){
    outcome <- "emp_lw"
  }else{
    outcome <- "searnings"
  }
  
  for(o in outcome){ # loop over outcomes
    t <- if(o=="emp_lw") "t_es_lw" else "t_es_ly"
    for(s in sex){ # loop over sex
      
      # Perform regression 
      suppressMessages(suppressWarnings({ # supress notes from feols() - these notes are irrelevant in this case
        reg_res <- feols(as.formula(paste0(o,"~",t,"|age_factor+doiy_factor")),data=subset(get(d),gender==s),weights=~wgt,se="hetero")
      }))
      # Calculate "counterfactuals"
      reg_data <- data.frame(cf=reg_res$sumFE,
                             t=fixest_data(reg_res,sample="estimation")[[t]],
                             wgt_match=fixest_data(reg_res,sample="estimation")[["wgt_match"]])
      cf <- summarize(group_by(reg_data,t),c = weighted.mean(cf,wgt_match)) 
      cf$t <- as.numeric(as.character(cf$t))
      cf <- cf %>%
        filter(t<0) %>%
        arrange(desc(t)) %>%
        pull(c)
      
      # Calculate levels  
      # by t 
      y[[paste0("pe_",d,"_",o,"_",s)]] <- c(reg_res$coefficients[paste0(t,-1)],0,reg_res$coefficients[paste0(t,-3:-5)]) + cf[2] 
      # mean across t 
      y[[paste0("m_pe_",d,"_",o,"_",s)]] <- mean(y[[paste0("pe_",d,"_",o,"_",s)]]) # point estimates
      
      # Print progress 
      cat("\rFinished",i,"of",n,"regressions") # print progress
      i <- i + 1
      
    }
  }
}

# Calculate difference across datasets
outcome <- c("emp_lw","earn_ly","searnings")
for(o in outcome){
  for(s in sex){

      # by t
      y[[paste0("delta_drop_pe_",o,"_",s)]] <- y[[paste0("pe_pseudo_paneld_",o,"_",o,"_",s)]] - 
                                               y[[paste0("pe_actual_paneld_",o,"_",o,"_",s)]] 

      # mean across t
      y[[paste0("delta_drop_m_pe_",o,"_",s)]] <- y[[paste0("m_pe_pseudo_paneld_",o,"_",o,"_",s)]] - 
                                                 y[[paste0("m_pe_actual_paneld_",o,"_",o,"_",s)]] 
      
  }
}

#######################################################
# Calculate standard errors 
#######################################################

# Put data sets created above into a list
datal <- list( # put here data sets created above
  actual_paneld_earn_ly = actual_paneld_earn_ly,
  actual_paneld_emp_lw = actual_paneld_emp_lw,
  actual_paneld_searnings = actual_paneld_searnings,
  pseudo_paneld_earn_ly = pseudo_paneld_earn_ly,
  pseudo_paneld_emp_lw = pseudo_paneld_emp_lw,
  pseudo_paneld_searnings = pseudo_paneld_searnings
) 

# Set seed and number of bootstrap replications
set.seed(72839251) # seed was taken from the serial number of a random dollar bill
reps <- 200

# Bootstrap
y_bs <- list() # stores results
i <- 1 # initialize progress print
j <- 1
m <- length(names(datal))
mm <- reps
for(d in names(datal)){ # loop over data
  
  # Extract relevant data (transform into data.table and keep only relevant variables to speed up calculations)
  df <- as.data.table(datal[[d]][,c("emp_lw","earn_ly","searnings","gender","t_es_lw","t_es_ly",
                                    "wgt","wgt_match","age_factor","doiy_factor","id")]) 
  n <- nrow(df) 
  
  # Define outcomes 
  if(d%in%c("actual_paneld_earn_ly","pseudo_paneld_earn_ly")){
    outcome <- "earn_ly"
  }else if(d%in%c("actual_paneld_emp_lw","pseudo_paneld_emp_lw")){
    outcome <- "emp_lw"
  }else{
    outcome <- "searnings"
  }
  
  for(r in 1:reps){ # bootstrap loop
    
    # Get bootstrap sample (drawing rows)
    indices <- sample(1:n,size=n,replace=TRUE) # indices of data
    data_rs <- df[indices] # get resampled data
    
    # Calculate point estimates  
    for(o in outcome){ # loop over outcomes
      t <- if(o=="emp_lw") "t_es_lw" else "t_es_ly"
      for(s in sex){ # loop over sex
        
        # Perform regression 
        suppressMessages(suppressWarnings({ # supress notes from feols() - these notes are irrelevant in this case
          reg_res <- feols(as.formula(paste0(o,"~",t,"|age_factor+doiy_factor")),data=subset(data_rs,gender==s),weights=~wgt,se="hetero")
        }))
        # Calculate "counterfactuals"
        est_sample <- fixest_data(reg_res,sample="estimation")
        reg_data <- data.table(cf=reg_res$sumFE,
                               t=est_sample[[t]],
                               wgt_match=est_sample[["wgt_match"]])
        cf <- summarize(group_by(reg_data,t),c = weighted.mean(cf,wgt_match)) 
        cf$t <- as.numeric(as.character(cf$t))
        cf <- cf %>%
          filter(t<0) %>%
          arrange(desc(t)) %>%
          pull(c)
        
        # Calculate levels  
        # by t 
        y_bs[[paste0("pe_",d,"_",o,"_",s,"_",r)]] <- c(reg_res$coefficients[paste0(t,-1)],0,reg_res$coefficients[paste0(t,-3:-5)]) + cf[2] 
        # mean across t 
        y_bs[[paste0("m_pe_",d,"_",o,"_",s,"_",r)]] <- mean(y_bs[[paste0("pe_",d,"_",o,"_",s,"_",r)]]) # point estimates
        
        
      }
    }
    # Print progress
    cat("\rFinished",j,"of",mm,"bootstrap replications for",i,"of",m,"data sets")
    j <- j + 1
  }
  i <- i + 1
  j <- 1
}

# Calculate standard errors within each sample
for(d in names(datal)){
    
  # Define outcomes 
  if(d%in%c("actual_paneld_earn_ly","pseudo_paneld_earn_ly")){
    outcome <- "earn_ly"
  }else if(d%in%c("actual_paneld_emp_lw","pseudo_paneld_emp_lw")){
    outcome <- "emp_lw"
  }else{
    outcome <- "searnings"
  }
    
  # Calculate standard errors
  for(o in outcome){
    # ses of point estimates by sex
    for(s in sex){
      y_bs[[paste0("se_",d,"_",o,"_",s)]] <- sd(sapply(y_bs[paste0("pe_",d,"_",o,"_",s,"_",1:reps)], `[`, 2)) # t = -2
      y_bs[[paste0("m_se_",d,"_",o,"_",s)]] <- sd(unlist(y_bs[paste0("m_pe_",d,"_",o,"_",s,"_",1:reps)])) # t < 0
    }
    # ses of point estimates for sex difference
    y_bs[[paste0("se_",d,"_",o)]] <- sd(sapply(y_bs[paste0("pe_",d,"_",o,"_Men_",1:reps)], `[`, 2) - 
                                        sapply(y_bs[paste0("pe_",d,"_",o,"_Women_",1:reps)], `[`, 2)) # t = -2
    y_bs[[paste0("m_se_",d,"_",o)]] <- sd(unlist(y_bs[paste0("m_pe_",d,"_",o,"_Men_",1:reps)]) - 
                                          unlist(y_bs[paste0("m_pe_",d,"_",o,"_Women_",1:reps)])) # t < 0
  }
}

# Calculate standard errors across samples
outcome <- c("emp_lw","earn_ly","searnings")
for(o in outcome){
  # ses of point estimates by sex
  for(s in sex){
    y_bs[[paste0("deltad_se_",o,"_",s)]] <- sd(sapply(y_bs[paste0("pe_pseudo_paneld_",o,"_",o,"_",s,"_",1:reps)],`[`, 2) - 
                                                  sapply(y_bs[paste0("pe_actual_paneld_",o,"_",o,"_",s,"_",1:reps)],`[`, 2)) # t = -2
    y_bs[[paste0("deltad_m_se_",o,"_",s)]] <- sd(unlist(y_bs[paste0("m_pe_pseudo_paneld_",o,"_",o,"_",s,"_",1:reps)]) - 
                                                    unlist(y_bs[paste0("m_pe_actual_paneld_",o,"_",o,"_",s,"_",1:reps)])) # t < 0
  }
  # ses of point estimates for sex difference
  y_bs[[paste0("deltad_se_",o)]] <- sd(sapply(y_bs[paste0("pe_pseudo_paneld_",o,"_",o,"_Men_",1:reps)],`[`, 2) - 
                                          sapply(y_bs[paste0("pe_actual_paneld_",o,"_",o,"_Men_",1:reps)],`[`, 2) - # t = -2
                                          (sapply(y_bs[paste0("pe_pseudo_paneld_",o,"_",o,"_Women_",1:reps)],`[`, 2) - 
                                          sapply(y_bs[paste0("pe_actual_paneld_",o,"_",o,"_Women_",1:reps)],`[`, 2)))
  y_bs[[paste0("deltad_m_se_",o)]] <- sd(unlist(y_bs[paste0("m_pe_pseudo_paneld_",o,"_",o,"_Men_",1:reps)]) - 
                                            unlist(y_bs[paste0("m_pe_actual_paneld_",o,"_",o,"_Men_",1:reps)]) - 
                                            (unlist(y_bs[paste0("m_pe_pseudo_paneld_",o,"_",o,"_Women_",1:reps)]) -
                                            unlist(y_bs[paste0("m_pe_actual_paneld_",o,"_",o,"_Women_",1:reps)]))) # t < 0
}


#######################################################
# Collect results in matrix 
#######################################################

# Create matrix
test_ass_3 <- matrix(NaN,nrow=18,ncol=6)
rownames(test_ass_3) <- c("M_earn_ly_t-2","M_earn_ly_t<0","M_emp_lw_t-2","M_emp_lw_t<0","M_searnings_t-2","M_searnings_t<0",
                          "W_earn_ly_t-2","W_earn_ly_t<0","W_emp_lw_t-2","W_emp_lw_t<0","W_searnings_t-2","W_searnings_t<0",
                          "M-W_earn_ly_t-2","M-W_earn_ly_t<0","M-W_emp_lw_t-2","M-W_emp_lw_t<0","M-W_searnings_t-2","M-W_searnings_t<0")
colnames(test_ass_3) <- c("panel_pe","panel_se","pseudo_pe","pseudo_se","delta_pe","delta_se")
  
# Fill matrix 
# Column 1 (panel_pe)
test_ass_3[1,1] <- y[[paste0("pe_actual_paneld_earn_ly_earn_ly_Men")]][2] # Men
test_ass_3[2,1] <- y[[paste0("m_pe_actual_paneld_earn_ly_earn_ly_Men")]]
test_ass_3[3,1] <- y[[paste0("pe_actual_paneld_emp_lw_emp_lw_Men")]][2]
test_ass_3[4,1] <- y[[paste0("m_pe_actual_paneld_emp_lw_emp_lw_Men")]]
test_ass_3[5,1] <- y[[paste0("pe_actual_paneld_searnings_searnings_Men")]][2]
test_ass_3[6,1] <- y[[paste0("m_pe_actual_paneld_searnings_searnings_Men")]]
test_ass_3[7,1] <- y[[paste0("pe_actual_paneld_earn_ly_earn_ly_Women")]][2] # Women
test_ass_3[8,1] <- y[[paste0("m_pe_actual_paneld_earn_ly_earn_ly_Women")]]
test_ass_3[9,1] <- y[[paste0("pe_actual_paneld_emp_lw_emp_lw_Women")]][2]
test_ass_3[10,1] <- y[[paste0("m_pe_actual_paneld_emp_lw_emp_lw_Women")]]
test_ass_3[11,1] <- y[[paste0("pe_actual_paneld_searnings_searnings_Women")]][2]
test_ass_3[12,1] <- y[[paste0("m_pe_actual_paneld_searnings_searnings_Women")]]
test_ass_3[13,1] <- test_ass_3[1,1] - test_ass_3[7,1] # Men - Women
test_ass_3[14,1] <- test_ass_3[2,1] - test_ass_3[8,1]
test_ass_3[15,1] <- test_ass_3[3,1] - test_ass_3[9,1]
test_ass_3[16,1] <- test_ass_3[4,1] - test_ass_3[10,1]
test_ass_3[17,1] <- test_ass_3[5,1] - test_ass_3[11,1]
test_ass_3[18,1] <- test_ass_3[6,1] - test_ass_3[12,1]
# Column 2 (panel_se)
test_ass_3[1,2] <- y_bs[[paste0("se_actual_paneld_earn_ly_earn_ly_Men")]] # Men
test_ass_3[2,2] <- y_bs[[paste0("m_se_actual_paneld_earn_ly_earn_ly_Men")]]
test_ass_3[3,2] <- y_bs[[paste0("se_actual_paneld_emp_lw_emp_lw_Men")]] 
test_ass_3[4,2] <- y_bs[[paste0("m_se_actual_paneld_emp_lw_emp_lw_Men")]]
test_ass_3[5,2] <- y_bs[[paste0("se_actual_paneld_searnings_searnings_Men")]]
test_ass_3[6,2] <- y_bs[[paste0("m_se_actual_paneld_searnings_searnings_Men")]]
test_ass_3[7,2] <- y_bs[[paste0("se_actual_paneld_earn_ly_earn_ly_Women")]] # Women
test_ass_3[8,2] <- y_bs[[paste0("m_se_actual_paneld_earn_ly_earn_ly_Women")]]
test_ass_3[9,2] <- y_bs[[paste0("se_actual_paneld_emp_lw_emp_lw_Women")]]
test_ass_3[10,2] <- y_bs[[paste0("m_se_actual_paneld_emp_lw_emp_lw_Women")]]
test_ass_3[11,2] <- y_bs[[paste0("se_actual_paneld_searnings_searnings_Women")]] 
test_ass_3[12,2] <- y_bs[[paste0("m_se_actual_paneld_searnings_searnings_Women")]]
test_ass_3[13,2] <- y_bs[[paste0("se_actual_paneld_earn_ly_earn_ly")]] # Men - Women
test_ass_3[14,2] <- y_bs[[paste0("m_se_actual_paneld_earn_ly_earn_ly")]]
test_ass_3[15,2] <- y_bs[[paste0("se_actual_paneld_emp_lw_emp_lw")]]
test_ass_3[16,2] <- y_bs[[paste0("m_se_actual_paneld_emp_lw_emp_lw")]]
test_ass_3[17,2] <- y_bs[[paste0("se_actual_paneld_searnings_searnings")]]
test_ass_3[18,2] <- y_bs[[paste0("m_se_actual_paneld_searnings_searnings")]]
# Column 3 (pseudo_pe)
test_ass_3[1,3] <- y[[paste0("pe_pseudo_paneld_earn_ly_earn_ly_Men")]][2] # Men
test_ass_3[2,3] <- y[[paste0("m_pe_pseudo_paneld_earn_ly_earn_ly_Men")]]
test_ass_3[3,3] <- y[[paste0("pe_pseudo_paneld_emp_lw_emp_lw_Men")]][2]
test_ass_3[4,3] <- y[[paste0("m_pe_pseudo_paneld_emp_lw_emp_lw_Men")]]
test_ass_3[5,3] <- y[[paste0("pe_pseudo_paneld_searnings_searnings_Men")]][2]
test_ass_3[6,3] <- y[[paste0("m_pe_pseudo_paneld_searnings_searnings_Men")]]
test_ass_3[7,3] <- y[[paste0("pe_pseudo_paneld_earn_ly_earn_ly_Women")]][2] # Women
test_ass_3[8,3] <- y[[paste0("m_pe_pseudo_paneld_earn_ly_earn_ly_Women")]]
test_ass_3[9,3] <- y[[paste0("pe_pseudo_paneld_emp_lw_emp_lw_Women")]][2]
test_ass_3[10,3] <- y[[paste0("m_pe_pseudo_paneld_emp_lw_emp_lw_Women")]]
test_ass_3[11,3] <- y[[paste0("pe_pseudo_paneld_searnings_searnings_Women")]][2]
test_ass_3[12,3] <- y[[paste0("m_pe_pseudo_paneld_searnings_searnings_Women")]]
test_ass_3[13,3] <- test_ass_3[1,3] - test_ass_3[7,3] # Men - Women
test_ass_3[14,3] <- test_ass_3[2,3] - test_ass_3[8,3]
test_ass_3[15,3] <- test_ass_3[3,3] - test_ass_3[9,3]
test_ass_3[16,3] <- test_ass_3[4,3] - test_ass_3[10,3]
test_ass_3[17,3] <- test_ass_3[5,3] - test_ass_3[11,3]
test_ass_3[18,3] <- test_ass_3[6,3] - test_ass_3[12,3]
# Column 4 (pseudo_se)
test_ass_3[1,4] <- y_bs[[paste0("se_pseudo_paneld_earn_ly_earn_ly_Men")]] # Men
test_ass_3[2,4] <- y_bs[[paste0("m_se_pseudo_paneld_earn_ly_earn_ly_Men")]]
test_ass_3[3,4] <- y_bs[[paste0("se_pseudo_paneld_emp_lw_emp_lw_Men")]] 
test_ass_3[4,4] <- y_bs[[paste0("m_se_pseudo_paneld_emp_lw_emp_lw_Men")]]
test_ass_3[5,4] <- y_bs[[paste0("se_pseudo_paneld_searnings_searnings_Men")]]
test_ass_3[6,4] <- y_bs[[paste0("m_se_pseudo_paneld_searnings_searnings_Men")]]
test_ass_3[7,4] <- y_bs[[paste0("se_pseudo_paneld_earn_ly_earn_ly_Women")]] # Women
test_ass_3[8,4] <- y_bs[[paste0("m_se_pseudo_paneld_earn_ly_earn_ly_Women")]]
test_ass_3[9,4] <- y_bs[[paste0("se_pseudo_paneld_emp_lw_emp_lw_Women")]]
test_ass_3[10,4] <- y_bs[[paste0("m_se_pseudo_paneld_emp_lw_emp_lw_Women")]]
test_ass_3[11,4] <- y_bs[[paste0("se_pseudo_paneld_searnings_searnings_Women")]] 
test_ass_3[12,4] <- y_bs[[paste0("m_se_pseudo_paneld_searnings_searnings_Women")]]
test_ass_3[13,4] <- y_bs[[paste0("se_pseudo_paneld_earn_ly_earn_ly")]] # Men - Women
test_ass_3[14,4] <- y_bs[[paste0("m_se_pseudo_paneld_earn_ly_earn_ly")]]
test_ass_3[15,4] <- y_bs[[paste0("se_pseudo_paneld_emp_lw_emp_lw")]]
test_ass_3[16,4] <- y_bs[[paste0("m_se_pseudo_paneld_emp_lw_emp_lw")]]
test_ass_3[17,4] <- y_bs[[paste0("se_pseudo_paneld_searnings_searnings")]]
test_ass_3[18,4] <- y_bs[[paste0("m_se_pseudo_paneld_searnings_searnings")]]
# Column 5 (delta_pe)
test_ass_3[1,5] <- y[[paste0("delta_drop_pe_earn_ly_Men")]][2] # Men
test_ass_3[2,5] <- y[[paste0("delta_drop_m_pe_earn_ly_Men")]]
test_ass_3[3,5] <- y[[paste0("delta_drop_pe_emp_lw_Men")]][2]
test_ass_3[4,5] <- y[[paste0("delta_drop_m_pe_emp_lw_Men")]]
test_ass_3[5,5] <- y[[paste0("delta_drop_pe_searnings_Men")]][2]
test_ass_3[6,5] <- y[[paste0("delta_drop_m_pe_searnings_Men")]]
test_ass_3[7,5] <- y[[paste0("delta_drop_pe_earn_ly_Women")]][2] # Women
test_ass_3[8,5] <- y[[paste0("delta_drop_m_pe_earn_ly_Women")]]
test_ass_3[9,5] <- y[[paste0("delta_drop_pe_emp_lw_Women")]][2]
test_ass_3[10,5] <- y[[paste0("delta_drop_m_pe_emp_lw_Women")]]
test_ass_3[11,5] <- y[[paste0("delta_drop_pe_searnings_Women")]][2]
test_ass_3[12,5] <- y[[paste0("delta_drop_m_pe_searnings_Women")]]
test_ass_3[13,5] <- test_ass_3[1,5] - test_ass_3[7,5] # Men - Women
test_ass_3[14,5] <- test_ass_3[2,5] - test_ass_3[8,5]
test_ass_3[15,5] <- test_ass_3[3,5] - test_ass_3[9,5]
test_ass_3[16,5] <- test_ass_3[4,5] - test_ass_3[10,5]
test_ass_3[17,5] <- test_ass_3[5,5] - test_ass_3[11,5]
test_ass_3[18,5] <- test_ass_3[6,5] - test_ass_3[12,5]
# Column 6 (delta_se)
test_ass_3[1,6] <- y_bs[[paste0("deltad_se_earn_ly_Men")]] # Men
test_ass_3[2,6] <- y_bs[[paste0("deltad_m_se_earn_ly_Men")]]
test_ass_3[3,6] <- y_bs[[paste0("deltad_se_emp_lw_Men")]] 
test_ass_3[4,6] <- y_bs[[paste0("deltad_m_se_emp_lw_Men")]]
test_ass_3[5,6] <- y_bs[[paste0("deltad_se_searnings_Men")]] 
test_ass_3[6,6] <- y_bs[[paste0("deltad_m_se_searnings_Men")]]
test_ass_3[7,6] <- y_bs[[paste0("deltad_se_earn_ly_Women")]] # Women
test_ass_3[8,6] <- y_bs[[paste0("deltad_m_se_earn_ly_Women")]]
test_ass_3[9,6] <- y_bs[[paste0("deltad_se_emp_lw_Women")]] 
test_ass_3[10,6] <- y_bs[[paste0("deltad_m_se_emp_lw_Women")]]
test_ass_3[11,6] <- y_bs[[paste0("deltad_se_searnings_Women")]]
test_ass_3[12,6] <- y_bs[[paste0("deltad_m_se_searnings_Women")]]
test_ass_3[13,6] <- y_bs[[paste0("deltad_se_earn_ly")]] # Men - Women
test_ass_3[14,6] <- y_bs[[paste0("deltad_m_se_earn_ly")]]
test_ass_3[15,6] <- y_bs[[paste0("deltad_se_emp_lw")]]
test_ass_3[16,6] <- y_bs[[paste0("deltad_m_se_emp_lw")]]
test_ass_3[17,6] <- y_bs[[paste0("deltad_se_searnings")]]
test_ass_3[18,6] <- y_bs[[paste0("deltad_m_se_searnings")]]

#######################################################
# Write latex table
#######################################################

# Format matrix for table
formatted_mat <- matrix(NA,nrow(test_ass_3),ncol=3)
for(i in 1:3){
  est <- format(round(test_ass_3[,2*i-1],3),nsmall=3)
  se <- format(round(test_ass_3[,2*i],3),nsmall=3)
  formatted_mat[,i] <- paste0(est," (",se,")")
}
# Add empty rows for the panel and outcome row labels
formatted_mat <- rbind(matrix(rep("",6),nrow=2,ncol=3),formatted_mat)
formatted_mat <- rbind(formatted_mat[1:4,],
                       matrix(rep("",3),nrow=1,ncol=3),
                       formatted_mat[5:nrow(formatted_mat),])
formatted_mat <- rbind(formatted_mat[1:7,],
                       matrix(rep("",3),nrow=1,ncol=3),
                       formatted_mat[8:nrow(formatted_mat),])
formatted_mat <- rbind(formatted_mat[1:10,],
                       matrix(rep("",6),nrow=2,ncol=3),
                       formatted_mat[11:nrow(formatted_mat),])
formatted_mat <- rbind(formatted_mat[1:14,],
                       matrix(rep("",3),nrow=1,ncol=3),
                       formatted_mat[15:nrow(formatted_mat),])
formatted_mat <- rbind(formatted_mat[1:17,],
                       matrix(rep("",3),nrow=1,ncol=3),
                       formatted_mat[18:nrow(formatted_mat),])
formatted_mat <- rbind(formatted_mat[1:20,],
                       matrix(rep("",6),nrow=2,ncol=3),
                       formatted_mat[21:nrow(formatted_mat),])
formatted_mat <- rbind(formatted_mat[1:24,],
                       matrix(rep("",3),nrow=1,ncol=3),
                       formatted_mat[25:nrow(formatted_mat),])
formatted_mat <- rbind(formatted_mat[1:27,],
                       matrix(rep("",3),nrow=1,ncol=3),
                       formatted_mat[28:nrow(formatted_mat),])
# Add phantom space before positive point estimates to align number vertically around the decimal point
formatted_mat <- apply(formatted_mat, c(1,2), function(x) {
  if(x == "") return(x)
  x <- sub("^([ ]*)(?!-)", "\\1\\\\phantom{-}", x, perl=TRUE)
  return(x)
})


# Row labels
rlabels <- c(
    "\\textbf{Panel A: Men}",
    "\\textit{Annual Employment Rate}",
    "\\hspace{1em}Event Time $\\tau$ = -2",
    "\\hspace{1em}Event Times $\\tau$ < 0",
    "\\textit{Weekly Employment Rate}",
    "\\hspace{1em}Event Time $\\tau$ = -2",
    "\\hspace{1em}Event Times $\\tau$ < 0",
    "\\textit{Earnings (Normalized)}",
    "\\hspace{1em}Event Time $\\tau$ = -2",
    "\\hspace{1em}Event Times $\\tau$ < 0",
    "\\textbf{Panel B: Women}",
    "\\textit{Annual Employment Rate}",
    "\\hspace{1em}Event Time $\\tau$ = -2",
    "\\hspace{1em}Event Times $\\tau$ < 0",
    "\\textit{Weekly Employment Rate}",
    "\\hspace{1em}Event Time $\\tau$ = -2",
    "\\hspace{1em}Event Times $\\tau$ < 0",
    "\\textit{Earnings (Normalized)}",
    "\\hspace{1em}Event Time $\\tau$ = -2",
    "\\hspace{1em}Event Times $\\tau$ < 0",
    "\\textbf{Panel C: Men Minus Women}",
    "\\textit{Annual Employment Rate}",
    "\\hspace{1em}Event Time $\\tau$ = -2",
    "\\hspace{1em}Event Times $\\tau$ < 0",
    "\\textit{Weekly Employment Rate}",
    "\\hspace{1em}Event Time $\\tau$ = -2",
    "\\hspace{1em}Event Times $\\tau$ < 0",
    "\\textit{Earnings (Normalized)}",
    "\\hspace{1em}Event Time $\\tau$ = -2",
    "\\hspace{1em}Event Times $\\tau$ < 0"
)

# Convert matrix to data frame
df <- as.data.frame(formatted_mat)
df <- cbind(label=rlabels, df)

# Create the LaTeX table
tbl_tex <- kbl(
  df,
  format = "latex",
  linesep = "",
  escape = FALSE,
  booktabs = TRUE,
  align = c("l", "c", "c", "c"),
  col.names = NULL
) %>%
  # Add column labels
  add_header_above(  
    c(" " = 1, 
      "Observed Values" = 1, 
      "Synthetic Values" = 1, 
      " " = 1),
    escape = FALSE,
    line = FALSE
  ) %>%
  add_header_above(
    c(" " = 1, 
      "\\textbf{Panel:}" = 1, 
      "\\textbf{Pseudo-Panel:}" = 1, 
      "\\multirow{2}{*}{\\textbf{\\hspace*{-0.125em}Difference}}" = 1),
    escape = FALSE,
    line = FALSE
  ) 
# add horizontal space before last column
tbl_tex <- gsub( 
  pattern = "\\\\begin\\{tabular\\}\\[t\\]\\{lccc\\}",
  replacement = "\\\\begin{tabular}[t]{lcc@{\\\\hspace{3.5em}}c}",
  x = tbl_tex
)
# change font size
tbl_tex <- sub(
  "(?=\\\\begin\\{tabular\\}\\[t\\])",
  "{\\\\fontsize{5}{7}\\\\selectfont\n",
  tbl_tex,
  perl = TRUE
)
tbl_tex <- sub(
  "\\\\end\\{tabular\\}",
  "\\\\end{tabular}\n}",
  tbl_tex
)
# change toprule and bottomrule
tbl_tex <- gsub(
  "\\\\toprule",
  "\\\\addlinespace[0.5ex]\n\\\\Xhline{0.5pt}\n\\\\addlinespace[0.5ex]",
  tbl_tex
)
tbl_tex <- gsub(
  "\\\\bottomrule",
  "\\\\addlinespace[0.5ex]\n\\\\Xhline{0.5pt}\n\\\\addlinespace[0.5ex]",
  tbl_tex
)
# Insert modified midrule 
tbl_tex <- sub(
  "(\\\\multicolumn\\{1\\}\\{c\\}\\{ \\} & \\\\multicolumn\\{1\\}\\{c\\}\\{Observed Values\\} & \\\\multicolumn\\{1\\}\\{c\\}\\{Synthetic Values\\} & \\\\multicolumn\\{1\\}\\{c\\}\\{ \\} \\\\\\\\)",
  "\\1\n\\\\addlinespace[0.5ex]\n\\\\Xhline{0.3125pt}\n\\\\addlinespace[0.5ex]",
  tbl_tex
)
# Add vertical space between panels
tbl_tex <- sub(
  fixed = TRUE,
  "\\hspace{1em}Event Times $\\tau$ < 0 & \\phantom{-}0.675 (0.012) & \\phantom{-}0.678 (0.009) & \\phantom{-}0.003 (0.016)\\\\",
  "\\hspace{1em}Event Times $\\tau$ < 0 & \\phantom{-}0.675 (0.012) & \\phantom{-}0.678 (0.009) & \\phantom{-}0.003 (0.016)\\\\[0.7em]",
  tbl_tex
)
tbl_tex <- gsub(
  fixed = TRUE,
  "\\hspace{1em}Event Times $\\tau$ < 0 & \\phantom{-}0.742 (0.013) & \\phantom{-}0.704 (0.009) & -0.038 (0.015)\\\\",
  "\\hspace{1em}Event Times $\\tau$ < 0 & \\phantom{-}0.742 (0.013) & \\phantom{-}0.704 (0.009) & -0.038 (0.015)\\\\[0.7em]",
  tbl_tex
)
# Change column labels
# Replace first header line (multicolumn to simple header)
tbl_tex <- sub(
  fixed = TRUE,
  "\\multicolumn{1}{c}{ } & \\multicolumn{1}{c}{textbf{Panel:}} & \\multicolumn{1}{c}{textbf{Pseudo-Panel:}} & \\multicolumn{1}{c}{multirow{2}{*}{textbf{hspace*{-0.125em}Difference}}} \\\\",
  "& \\textbf{Panel:} & \\textbf{Pseudo-Panel:} & \\multirow{2}{*}{\\textbf{\\hspace*{-0.125em}Difference}} \\\\",
  tbl_tex
)

# Replace second header line (multicolumn to simple header)
tbl_tex <- sub(
  fixed = TRUE,
  "\\multicolumn{1}{c}{ } & \\multicolumn{1}{c}{Observed Values} & \\multicolumn{1}{c}{Synthetic Values} & \\multicolumn{1}{c}{ } \\\\",
  "& Observed Values & Synthetic Values & \\\\",
  tbl_tex
)

# Export the LaTeX table
writeLines(tbl_tex, file.path(outdir,"Tables","table_assumption3_test.tex"))



rm(list=c("r","reps","outcome","sex","o","s","t","reg_res","i","n","data","datal","d","y","reg_data","cf","actual_paneld_earn_ly",
          "actual_paneld_emp_lw","actual_paneld_searnings","pseudo_panel","actual_panel","pseudo_paneld_earn_ly","pseudo_paneld_emp_lw",
          "pseudo_paneld_searnings","mcf","psid","nlsy79","df","data_rs","est_sample","y_bs","indices","j","m","mm","formatted_mat",
          "est","se","rlabels","tbl_tex"))
