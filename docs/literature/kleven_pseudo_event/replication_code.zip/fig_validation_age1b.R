#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates Figure A.5; Panels B, D, F
# (Robustness to Heterogeneous Treatment Effects)

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Define vector of outcome vars to run functions over
l.depvars <- c("earnings_ly", "emp_lw","earn_ly")

# Load CPS and ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

#########################

# Run event studies

#########################

reg_es_age1b <- function(data, depvar, preadjust, plotname, final_filename){
  
  data["depvar"] = data[{{depvar}}]
  if(!grepl("pooled",depvar)){
    data["t_es"] = data[paste0("t_es_",substr({{depvar}}, nchar({{depvar}})-1, nchar({{depvar}})))]
  }
  
  
  # Graph labels
  if({{depvar}}=="earn_ly"){
    depvarlbl <- "emp_annual"
  }
  if({{depvar}}=="emp_lw"){
    depvarlbl <- "emp_weekly"
  }
  if({{depvar}}=="earnings_ly"){
    depvarlbl <- "earnings"
  }

  
  # create interactions for event studies
  data <- data %>%
    drop_na(depvar, age_factor, doiy_factor, t_es, age1b)%>%
    droplevels()
  
  data <- data %>%
    mutate(age1b_group = as.factor(case_when(inrange(age1b, 25, 28) ~ "Group 1",
                                          inrange(age1b, 29, 32) ~ "Group 2",
                                          inrange(age1b, 33, 36) ~ "Group 3",
                                          inrange(age1b, 37, 45) ~ "Group 4")))
  
  # Save age1b groups in a table
  groups <- data %>%
    group_by(age1b_group)%>%
    summarise_at(vars(age1b),
                 list(min = min, max = max))%>%
    mutate(age1b = paste0(min, "-", max))%>%
    rename(hetero = age1b_group)
  
  # Find the percentage of each group in the data
  age1b_groups <- as.data.frame(table(data$age1b_group))%>%
    rename(hetero = Var1)%>%
    mutate(depvar = {{depvar}})%>%
    mutate(perc = Freq/sum(Freq))%>%
    merge(groups, by=c("hetero"))%>%
    select(c("depvar", "hetero", "age1b", "perc", "Freq"))
  
  
  # Get event studies for each age1b group
  coef_age1b <- reg_es_hetero(data = data, depvar = {{depvar}},preadjust={{preadjust}},
                                 hetero="age1b_group", plotname = {{plotname}},
                                 export=F, return_coef="coef")
  
  
  # Make a graph that is the average of the four age1b graphs
  
  # Calculate standard errors
  coef_age1b_se <- coef_age1b %>%
    select(-c("estimate", "conf.low", "conf.high"))%>%
    spread(key = "hetero", value = "std.error")%>%
    mutate(wgt1 = age1b_groups$perc[1])%>%
    mutate(wgt2 = age1b_groups$perc[2])%>%
    mutate(wgt3 = age1b_groups$perc[3])%>%
    mutate(wgt4 = age1b_groups$perc[4])%>%
    mutate(std.error = sqrt(wgt1^2*(`Group 1`)^2+wgt2^2*(`Group 2`)^2+wgt3^2*(`Group 3`)^2+wgt4^2*(`Group 4`)^2))%>%
    select(-c("Group 1", "Group 2", "Group 3", "Group 4", "wgt1", "wgt2", "wgt3", "wgt4"))
  
  
  # Take average of estimates, merge in standard errors, calculate confidence intervals
  coef_age1b_avg <- coef_age1b %>%
    select(-c("conf.low", "conf.high", "std.error"))%>%
    spread(key = "hetero", value = "estimate")%>%
    mutate(wgt1 = age1b_groups$perc[1])%>%
    mutate(wgt2 = age1b_groups$perc[2])%>%
    mutate(wgt3 = age1b_groups$perc[3])%>%
    mutate(wgt4 = age1b_groups$perc[4])%>%
    mutate(estimate = wgt1*(`Group 1`)+wgt2*(`Group 2`)+wgt3*(`Group 3`)+wgt4*(`Group 4`))%>%
    select(-c("Group 1", "Group 2", "Group 3", "Group 4", "wgt1", "wgt2", "wgt3", "wgt4"))%>%
    merge(coef_age1b_se, by=c("depvar","depvar_lab", "gender","t_es", "post"))%>%
    mutate(conf.low = estimate + qnorm(0.025, 0, 1)*std.error)%>%
    mutate(conf.high = estimate + qnorm(0.975, 0, 1)*std.error)
  
  post_mean <- aggregate(estimate ~  gender+post, 
                         data=coef_age1b_avg ,
                         mean)
  post_mean <- post_mean %>%
    spread(post, estimate) %>%
    mutate(estimate=`1`-`0`)
  
  penalty <- post_mean %>%
    subset(select=-c(`1`,`0`)) %>%
    spread(gender, estimate) %>%
    mutate(estimate = `Men` - `Women`) %>%
    subset(select=c(estimate)) %>%
    mutate(depvar = {{depvar}},
           depvar_lab = var_label(data$depvar))
  
  # label for child penalty
  lab <- penalty
  lab$txt = sprintf("Child Penalty: %1.0f%%", (lab$estimate)*100)
  
  # Plot the graph
  mylabels <- c("-0.8","-0.6","-0.4","-0.2","0.0","0.2","0.4")
  mybreaks <- c(-0.8, -0.6, -0.4, -0.2, 0.0, 0.2, 0.4)
  ymin <- -0.8
  ymax <- 0.4
  
  # Clean up data
  coef_age1b_avg$gender <- factor(coef_age1b_avg$gender,levels=c("Women","Men")) # Ensure that Men are drawn above Women
  coef_age1b_avg <- coef_age1b_avg[order(coef_age1b_avg$gender, coef_age1b_avg$t_es),]
  
  ggplot(coef_age1b_avg, aes(y=estimate, x=t_es, color=gender, group=gender))  + 
          # display all x values on axis
          scale_x_discrete(labels=levels(coef_age1b_avg$t_es), breaks=levels(coef_age1b_avg$t_es))+
          # add confience intervals
          geom_ribbon(aes(ymin=conf.low,ymax=conf.high,fill=gender),alpha=0.3,show.legend = F,
                      colour = NA) +
          # line and point sizes
          geom_line(linewidth=1) + 
          geom_point(size=4) +
          # y-scale
          scale_y_continuous(labels = mylabels,breaks=mybreaks)+
          coord_cartesian(ylim=c(ymin,ymax+0.05))+
          # axis labels
          labs(x="Event Time (Years)", y=paste(var_label(data$depvar),"Impact (%)")) +
          # line at t=-0.5
          geom_vline(xintercept = 5.5, linetype="solid", color = "#D11809",linewidth=1.2) +
          # theme + grid lines
          theme_minimal() + 
          theme(axis.line = element_line(colour = "black",linewidth=0.4)) +
          theme(panel.grid.major.x = element_blank(),
                panel.grid.minor.y = element_blank(),
                legend.position = "bottom",
                panel.spacing = unit(-.2, "lines"),
                legend.key.size = unit(3,"lines")) +
          # label next to line
          geom_text(aes(x=6.9,
                        label="First Child",y=ymax+0.05),
                    size=8.5,color="grey25",check_overlap=T)+
          theme(axis.text.x = element_text(vjust = -0.5),
                # axis.text.y = element_text(hjust = -0.5)
          ) +
          theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)),
                axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)))+
          theme(text=element_text(size=25)
          ) +
          # line color and legend labels
          scale_color_manual(name="",
                             breaks=c("Men","Women"),
                             values=c("black",rgb(193,5,52, maxColorValue = 255)),
                             labels=c("Men","Women")) +
          scale_fill_manual(values=c("black",
                                     rgb(193,5,52, maxColorValue = 255)),
                            breaks=c("Men","Women"),
                            name="")+
          # panel labels
          geom_text(aes(16.23, -0.7, label=txt, group=NULL,fontface=2), size = 11, 
                    color = "black", hjust = 1, data=lab)
        ggsave(paste0(plotname, "_", {{depvarlbl}}, ".pdf"), plot=last_plot(), device="pdf",
               width=11, height=8, units="in",path=file.path(outdir,"Figures")) 
  
  return(age1b_groups)
}

# Run the function
coef_age1b <- setDF(rbindlist(lapply(l.depvars, reg_es_age1b, data = cps_acs,
                                        preadjust = T,
                                        plotname = "heterogeneity_age1b", final_filename = T)))
