#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates Figure A.24 in the paper (Cultural Assimilation of Immigrants)
# Event studies are run separately for first and later generation immigrant
  # women by quartile of the child penalty in their country of origin
# Event studies for all immigrant men are run by quartile of child penalty in country
  # of origin as well

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Create event study for first gen vs later generation immigrants
reg_es_immigrant_generations <- function(data, depvar, plotname="") {
  
  # Graph label
  depvarlbl <- "emp_pooled"
  
  # Prepare sample
  data <- data %>%
    mutate(pooled_employment = ifelse(!is.na(t_es_ly) & !is.na(earn_ly), 
                                      earn_ly, emp_lw),
           t_es = as.factor(ifelse(!is.na(t_es_ly) & !is.na(earn_ly), 
                                   as.character(t_es_ly), as.character(t_es_lw))))
  data <- apply_labels(data, pooled_employment="Employment")
  
  data$t_es = factor(data$t_es, # re-order levels
                     levels=c("-2","-5", "-4", "-3", "-1",
                              "0", "1", "2", "3","4", "5", "6",
                              "7", "8", "9", "10"))
  
  # Create Scandinavia as pooled observations of Denmark, Norway, and Sweden in CPS/ACS
  # Country of birth
  data <- data %>%
    mutate(bpl_country = case_when(bpl_country == "Denmark" | bpl_country == "Norway" | 
                                     bpl_country == "Sweden" ~ "Scandinavia",
                                   TRUE ~ as.character(bpl_country)))
  data$bpl_country <- as.factor(data$bpl_country)
  
  # Ancestry
  data <- data %>%
    mutate(ancestry = case_when(ancestry == "Denmark" | ancestry == "Norway" | 
                                  ancestry == "Sweden" ~ "Scandinavia",
                                TRUE ~ as.character(ancestry)))
  data$ancestry <- as.factor(data$ancestry)
  
  # Read in CP Atlas penalties (Penalties IN country of birth)
  country_penalties <- read_excel(file.path(rawdir,"Global Child Penalties","global_penalties.xlsx")) %>%
    rename(penalty_global = penalty) %>%
    filter(!(country %in% c("Czech Republic","Slovakia"))) %>%
    subset(select=c(country,penalty_global))
  
  # Merge with our child penalties for immigrants
  penalty <- readRDS(file=file.path(wrkdir,"penalties_immigrants.rds")) %>%
    subset(select=-c(depvar, depvar_lab))%>%
    mutate(hetero = as.factor(as.character(hetero)))
  
  country_penalties <- merge(country_penalties, penalty, by.x="country", by.y="hetero")
  
  # Treat negative penalties as zero
  country_penalties <- country_penalties %>%
    mutate(penalty_global = ifelse(penalty_global < 0, 0, penalty_global))
  
  # Split penalty in country of birth into deciles, median, or quartile based on penalty in country of birth
  
    # Re-order in ascending order of penalties for immigrants
  country_penalties <- arrange(country_penalties, penalty)
  
   
    # Quartiles
  country_penalties$decile <- as.factor(paste("Quartile", as.character(ntile(country_penalties$penalty_global, 4))))
  xpos <- 9.7
  
  country_penalties <- country_penalties %>%
    subset(select=-c(penalty))
  
  # Combine datasets for first gen and all others
  
    # first gen: foreign born
    data_firstgen <- data %>%
      filter(immigrant == "Immigrant") %>%
      droplevels() %>%
      merge(country_penalties, by.x="bpl_country", by.y="country") %>%
      mutate(generation="First Generation")
    
    # second gen and above: born in the US but their ancestry is foreign
    data_ancestry <- data %>%
      filter(bpl_country == "United States") %>%
      droplevels() %>%
      merge(country_penalties, by.x="ancestry",by.y="country")%>%
      mutate(generation="Above First Generation")
    
    data <- bind_rows(data_firstgen, data_ancestry) %>%
      mutate(generation=as.factor(as.character(generation)))
    
  # weighted avg of penalties from CP Atlas paper for plot
  
    # Number of people born in each foreign country
    xwalk <- data_firstgen %>%
      group_by(decile, bpl_country) %>%
      summarize(n=sum(wgt_match))
    
    # Number of people born in each decile
    xwalk2 <- data_firstgen %>%
      group_by(decile) %>%
      summarize(n_total = sum(wgt_match))
    
    # Calculate fraction 
    xwalk <- merge(xwalk, xwalk2, by="decile") %>%
      mutate(frac = n/n_total) %>%
      subset(select=c(bpl_country, decile, frac))
    
    # Calculate weighted average of penalty in country of birth
    country_penalties <- merge(country_penalties, xwalk, by.x=c("country","decile"), by.y=c("bpl_country", "decile"))
    deciles <- country_penalties %>%
      group_by(decile) %>%
      summarize(decile_mid = weighted.mean(penalty_global, frac))
    
  # Event studies
    
    # Separately by decile for first gen for women
    coef_firstgen <- setDF(rbindlist(lapply(split(data_firstgen, data_firstgen$decile), reg_es_immigrant, 
                                            depvar = {{depvar}}, splitvar="decile", export=F))) %>%
      subset(gender=="Women")
    
    # Separately by decile for later gen women
    coef_ancestry <- setDF(rbindlist(lapply(split(data_ancestry, data_ancestry$decile), reg_es_immigrant, 
                                            depvar = {{depvar}}, splitvar="decile", export=F))) %>%
      subset(gender=="Women")
    
    # All first or later generation men by decile
    coef_men <- setDF(rbindlist(lapply(split(data, data$decile), reg_es_immigrant, 
                                       depvar = {{depvar}}, splitvar="decile", export=F))) %>%
      subset(gender=="Men")
    
    coef_firstgen <- bind_rows(coef_firstgen, coef_men) %>%
      mutate(generation="First Generation")
    
    coef_ancestry <- bind_rows(coef_ancestry, coef_men) %>%
      mutate(generation="Above First Generation")
    
    coef <- bind_rows(coef_firstgen, coef_ancestry)
    
    coef <- coef %>%
      mutate(hetero = as.factor(as.character(hetero))) %>%
      merge(deciles, by.x="hetero", by.y="decile")
    
    coef$hetero <- fct_reorder(coef$hetero, coef$decile_mid)
    
    coef$t_es = factor(coef$t_es, # re-order levels
                       levels=c("-5", "-4", "-3", "-2", "-1",
                                "0", "1", "2", "3","4", "5", "6",
                                "7", "8", "9", "10"))
    
    # Long-run penalty calculation
    # Calculate penalties relative to all men
    t_penalty <- c("5","6", "7", "8", "9", "10")
    text_penalty <- "Long-Run Penalty:"
    coef <- coef %>%
      mutate(post = case_when(t_es %in% t_penalty ~ 1,
                              grepl("-",t_es) ~ 0))
    # with pre-period adjustment
    penalty <- aggregate(estimate ~  gender + generation + hetero + post, 
                         data=subset(coef, !is.na(post)) ,
                         mean) %>%
      spread(post,estimate)  %>%
      mutate(estimate=`1`-`0`) %>%
      subset(select=-c(`1`,`0`)) %>%
      spread(gender, estimate) %>%
      mutate(estimate = `Men` - `Women`) %>%
      subset(select=c(hetero,generation,estimate))  %>%
      mutate(gender = paste(generation))
  
  # Prep for plot (labels and penalty text)
    coef <- coef %>%
      filter((generation== levels(data$generation)[1] & gender == "Men") | gender == "Women") %>%
      mutate(gender = as.factor(ifelse(gender == "Men", "Men", paste(generation))))
    
    coef$gender <- factor(coef$gender, levels=c("Above First Generation","First Generation","Men"))
    
    coef <- coef[order(coef$hetero, coef$gender, coef$t_es),] # sort by hetero, gender, time
    
    penalty <- penalty %>%
      subset(select=c(gender, estimate, hetero)) %>%
      spread(gender, estimate)
    
    penalty <- penalty %>%
      mutate(label = paste0(
                            "First Generation", ": ",(round(`First Generation`,digits=2))*100,"% \n",
                            "Later Generation", ": ",(round(`Above First Generation`,digits=2))*100,"%"))
    nlevels = length(levels(coef$hetero))
    size <- max(3, 10/nlevels)
    sizeb <- size - 0.1
    
    data["depvar"] <- data[{{depvar}}]
    
    # y-axis label 
    if(depvar == "emp_lw"){
      ylab <- "Weekly Employment"
    }
    if(depvar == "earnings_ly"){
      ylab <- "Earnings"
    }
    if(depvar == "earn_ly"){
      ylab <- "Annual Employment"
    }
    if(depvar == "pooled_employment"){
      ylab <- "Employment"
    }
    
    ## plot all deciles separately
    
    for(st in c("Quartile 1","Quartile 4")){
      stname <- tolower(gsub(" ", "", st, fixed = TRUE))
    ggplot(coef[coef$hetero==st,], aes(y=estimate, x=t_es, color=gender, group=gender))  +
      geom_ribbon(aes(ymin=conf.low,ymax=conf.high,fill=gender),alpha=0.3,show.legend = F,
                  colour = NA)  +
      # line and point sizes
      geom_line(linewidth=1) + 
      geom_point(size=4) +
      scale_fill_manual(breaks=c("Men",
                                 "First Generation",
                                 "Above First Generation"),
                        values=c("black",
                                 rgb(26,71,111, maxColorValue = 255),
                                 rgb(193,5,52, maxColorValue = 255)))+
      # line color and legend labels
      scale_color_manual(name="",
                         breaks=c("Men",
                                  "First Generation",
                                  "Above First Generation"),
                         values=c("black",
                                  rgb(26,71,111, maxColorValue = 255),
                                  rgb(193,5,52, maxColorValue = 255)),
                         labels=c("Immigrant Men",
                                  "First-Generation Immigrant Women",
                                  "Later-Generation Immigrant Women"),
                         guide=guide_legend(override.aes = 
                                              list(shape = c("Men" = 16, "Above First Generation" = 16,
                                                             "First Generation" = 16)))) +
      # display all x values on axis
      scale_x_discrete(labels=as.character(coef[coef$hetero==st,"t_es"]), breaks=coef[coef$hetero==st,"t_es"])+
      # y-scale
      scale_y_continuous(labels=c("-0.8","-0.6","-0.4","-0.2","0.0",
                                  "0.2","0.4"),
                         breaks=seq(-0.8, 0.4, by=0.2), limits=c(-0.8,0.45))+
      geom_text(aes(x=6.9,
                    label="First Child",y=0.45),
                size=8.5,color="grey25",check_overlap=T)+
      geom_vline(xintercept = 5.5, linetype="solid", color = "#D11809",linewidth=1.2)+
      # panel labels
      geom_text(aes(x=8.92, y=-0.53, label=paste0(text_penalty)), 
                size=8,color="black",fontface="bold",hjust=0,check_overlap=T)+
      geom_text(aes(x=8.92, y=-0.64, label=paste0("First Generation: ", (round(`First Generation`,digits=2))*100, "%"), group=NULL), 
                size=8,color="black",check_overlap = T,hjust=0, data=penalty[penalty$hetero==st,])+
      geom_text(aes(x=8.92, y=-0.74, label=paste0("Later Generation: ", (round(`Above First Generation`,digits=2))*100, "%"), group=NULL), 
                size=8,color="black",check_overlap = T,hjust=0, data=penalty[penalty$hetero==st,])+
      # theme + grid lines
      theme_minimal() + 
      theme(axis.line = element_line(colour = "black",linewidth=0.4)) +
      theme(panel.grid.major.x = element_blank(),
            panel.grid.minor.y = element_blank(),
            legend.position = "bottom",
            panel.spacing = unit(-.2, "lines"),
            legend.key.size = unit(2.7,"lines")) +
      theme(axis.text.x = element_text(vjust = -0.5)
      ) +
      theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)),
            axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)))+
      theme(text=element_text(size=25)
      ) +
      theme(legend.text=element_text(size=13))+
      # axis labels
      labs(x="Event Time (Years)", y=paste(ylab, "Impact (%)"))
    ggsave(paste0(plotname, "_", stname, "_",{{depvarlbl}},".pdf"), plot=last_plot(), device="pdf",
           width=11, height=8, units="in",path=file.path(outdir,"Figures"))
    
    }
}

# Load CPS and ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

# Create Figure A.24
reg_es_immigrant_generations(data=cps_acs, depvar="pooled_employment", plotname = "epidemiological_immigrants_assimilation")
