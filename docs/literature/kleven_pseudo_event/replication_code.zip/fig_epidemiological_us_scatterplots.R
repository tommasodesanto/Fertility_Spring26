#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates Figures 13 and A.20
# (Scatterplots and binscatters of child penalties for US-born movers vs stayers)

#############################################################################################

# Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Function to create rawscatters
fn_scatter_epi <- function(data, depvar, var="penalty", filtervar="spec_lbl", 
                           ysample="movers", xsample="stayers", spec="", plotname="", st_var, final_filename = T) {
  
  
  # Graph labels
  if({{depvar}}=="earn_ly"){
    depvarlbl <- "emp_annual"
  }
  if({{depvar}}=="emp_lw"){
    depvarlbl <- "emp_weekly"
  }
  
  # statename
  if(st_var == "bpl_state") {
    other_st_var <- "statename"
  } else {
    other_st_var <- "bpl_state"
  }
  
  # Load penalties for movers and stayers
  # read in stayer penalties
  if(st_var == "bpl_state") {
    allpenalties <- readRDS(file=file.path(wrkdir, paste0("penalties_movers_vs_stayers_state_of_birth",
                                                          ".rds")))
  } else {
    allpenalties <- readRDS(file=file.path(wrkdir, paste0("penalties_movers_vs_stayers_state_of_residence",
                                                          ".rds")))
  }
  
  # Cross-walk of fips codes and state names
  xwalk = data.frame(fips = ipums_val_labels(data$statefip)$val, hetero = ipums_val_labels(data$statefip)$lbl)
  xwalk$abb <- state.abb[match(xwalk$hetero,state.name)]
  xwalk <- xwalk %>%
    mutate(abb = ifelse(hetero == "District of Columbia", "DC", abb))
  
  # Filter out data to only keep US-born people
  data <- data %>%
    filter(!is.na(bpl_state)) %>%
    droplevels()
  
  # Redefine marital status control to be numeric
  data <- data %>%
    mutate(frac_married = ifelse(married == "Married", 1,0))
  
  # Merge crosswalk with child penalty dataset
  allpenalties <- merge(allpenalties, xwalk, by=c("hetero"), all.x=T)
  
  #Renaming
  pdata <- allpenalties
  
  # prep data
  data["t_es"] = data[paste0("t_es_",substr({{depvar}}, nchar({{depvar}})-1, 
                                            nchar({{depvar}})))]
  data["post"] = data[paste0("post_",substr({{depvar}}, nchar({{depvar}})-1, 
                                            nchar({{depvar}})))]
  
  data["depvar"] = data[{{depvar}}]
  data <- data %>%
    drop_na(depvar, age_factor, doiy_factor, t_es) %>%
    filter(wgt_match!=0) %>%
    droplevels()
  
  # prep stayer and mover penalty data
  pdata["var"] <- pdata[{{var}}]
  pdata["filtervar"] <- pdata[{{filtervar}}]
  
  pdata <- pdata %>%
    filter(depvar == {{depvar}})
    
  xdata <- pdata %>%
    filter(grepl({{xsample}}, filtervar)) %>%
    subset(select=c(hetero, var)) %>%
    rename(xvar = var)
  
  ydata <- pdata %>%
    filter(grepl({{ysample}}, filtervar)) %>%
    subset(select=c(hetero, abb, var)) %>%
    rename(yvar = var)
  
  pdata <- merge(xdata, ydata, by=c("hetero"))
  
  
  # Get controls
  if(spec == "nocontrols") { # no controls
    
    pdata$penalty_res <- pdata$yvar
    # line of best fit
    reg <- lm(yvar ~ xvar, data = pdata)
    se <- format(round(coef(summary(reg))[,"Std. Error"][["xvar"]], digits=3),nsmall=3)
    
    # slope text
    slope <- format(round(reg[["coefficients"]][["xvar"]],digits=3),nsmall=3)
    txt <- paste0("Slope == ",slope,
                  "~(", deparse(se), ")")
    
    # adjusted r-squared
    r2 <- summary(reg)$adj.r.squared
    rsquared <- sprintf('%.3f',r2)
    txt_ar <- paste0("Adj.~R^2 == ", rsquared)
    
  } else { # with controls
    
    pdata$penalty_res <- pdata$yvar
    
    # Keep mothers only
    data_controls <- data %>%
      filter(gender == "Women" & child == 1)
      
    # Movers only
    data_controls <- data_controls %>%
      filter(statename != bpl_state)
      
    # read in stayer penalties
    if(st_var == "bpl_state") {
      penalties <- readRDS(file=file.path(wrkdir,paste0("penalties_movers_vs_stayers_state_of_birth",
                                                        ".rds"))) 
    } else {
      penalties <- readRDS(file=file.path(wrkdir,paste0("penalties_movers_vs_stayers_state_of_residence",
                                                        ".rds"))) 
    }
    
    penalties <- penalties %>%
      filter(grepl("stayers",spec_lbl) & depvar == {{depvar}})
    
    if(st_var == "bpl_state") {
      penalties$bpl_state <- penalties$hetero
    } else {
      penalties$statename <- penalties$hetero
    }
    
    data_controls <- merge(data_controls, penalties,by=st_var,all.x=T)
      
    # Calculate weighted fractions of people born in each state living in each decile
    state_totals <- data_controls %>%
      group_by(!!sym(st_var)) %>%
      summarize(total = sum(wgt_match))
    controls <- data_controls %>%
      group_by(statename, bpl_state) %>%
      summarize(count = sum(wgt_match)) %>%
      merge(state_totals, by=st_var) %>%
      mutate(frac = count/total) 
    
    # List of variables to use as controls
    controlvars <- unique(controls$bpl_state)
    
    # Reshape the data
    controls_wide <- controls %>% select(statename, bpl_state, frac) %>%
      pivot_wider(names_from = !!sym(other_st_var), values_from = frac)
    
    controls_wide <- merge(penalties, controls_wide, by=st_var)
    
    pen <- penalties %>% select(!!sym(st_var), penalty) %>% 
      pivot_wider(names_from = !!sym(st_var), values_from = penalty)
    
    pen <- pen %>%
      rename_with(~ paste0("pen_", .))
    
    controls_wide <- cbind(controls_wide, pen)
    
    # Define the state and penalty variable names
    state_vars <- c("Alabama", "Alaska", "Arizona", "Arkansas", "California", 
                    "Colorado", "Connecticut", "Delaware", "District of Columbia", 
                    "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", 
                    "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", 
                    "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", 
                    "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", 
                    "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", 
                    "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", 
                    "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", 
                    "Washington", "West Virginia", "Wisconsin", "Wyoming")
    
    pen_vars <- paste0("pen_", state_vars)
    
    # Compute the predicted_penalty
    controls_wide$predicted_penalty <- rowSums(controls_wide[state_vars] * controls_wide[pen_vars], na.rm = TRUE)
    
    control <- controls_wide %>% select(!!sym(st_var), predicted_penalty)
    
    control <- control %>% rename(hetero = !!sym(st_var))
    
    regdata <- merge(pdata, control, by="hetero")
    
    # run regression with controls
    reg <- feols(as.formula(paste("yvar ~ xvar +", paste("predicted_penalty"), sep="")), data = regdata)
    
    # residualize
    # get residuals
    regdata$residuals <- reg$residuals
    
    # add effect from global penalty and intercept back since we only residualize by controls
    regdata <- regdata %>%
      mutate(penalty_res = residuals + reg[["coefficients"]][["xvar"]]*xvar
             + reg[["coefficients"]][["(Intercept)"]])
    
    # add average effect of controls back
    regdata$penalty_res <- regdata$penalty_res + (mean(regdata$predicted_penalty)*reg[["coefficients"]][["predicted_penalty"]])
    
    pdata <- regdata
    
    # save se for plot
    se <- round(reg[["se"]][["xvar"]], digits=3)
    
    # slope text
    slope <- format(round(reg[["coefficients"]][["xvar"]],digits=3),nsmall=3)
    txt <- paste0("Slope == ",slope,
                  "~(", deparse(se), ")")
    
    # adjusted r-squared
    r2 <- r2(reg, type = "ar2")
    rsquared <- sprintf('%.3f',r2)
    txt_ar <- paste0("Adj.~R^2 == ", rsquared)
  }
  
  # define which state labels to show on plot
  data_line <- pdata %>%
    mutate(greypt="#4591d3")
  pdata <- pdata %>%
    mutate(hetero_lbl = case_when(hetero %in% c("Utah", "Texas", "Florida", "New Jersey",
                                                "California","New York") ~ as.character(hetero),
                                  depvar == "emp_lw" & st_var == "bpl_state" & hetero %in% c("Idaho","Oregon","South Carolina", "Illinois",
                                                                                             "Rhode Island","South Dakota", "Indiana",
                                                                                             "North Dakota","Nevada", "Pennsylvania",
                                                                                             "District of Columbia","Washington","Arizona",
                                                                                             "Louisiana","Alaska","West Virginia", "Hawaii")
                                  ~ as.character(hetero),
                                  depvar == "emp_lw" & st_var == "statename" & hetero %in% c("Idaho","Oregon","South Carolina", "Illinois",
                                                                                             "South Dakota", "District of Columbia","Arizona",
                                                                                             "North Dakota","Nevada", "New Mexico", "Washington",
                                                                                             "Louisiana","West Virginia", "Hawaii", "Delaware")
                                  ~ as.character(hetero),
                                  depvar == "earn_ly" & st_var == "bpl_state" & hetero %in% c("West Virginia","Idaho","South Dakota", "Illinois",
                                                                                              "Oregon","North Dakota", "Mississippi", "Iowa",
                                                                                              "South Dakota","Nevada","Montana","New Hampshire",
                                                                                              "Washington","Alaska","Arkansas", "District of Columbia",
                                                                                              "Hawaii", "North Carolina")
                                  ~ as.character(hetero),
                                  depvar == "earn_ly" & st_var == "statename" & hetero %in% c("West Virginia","Idaho", "Illinois", "Vermont",
                                                                                              "North Dakota", "Iowa", "Oregon", "Nevada",
                                                                                              "Arkansas", "District of Columbia", "Rhode Island",
                                                                                              "Hawaii", "Connecticut", "New Mexico",
                                                                                              "South Dakota")
                                  ~ as.character(hetero))) %>%
    mutate(hetero_lbl = ifelse(hetero_lbl == "District of Columbia", "D.C.", as.character(hetero_lbl))) %>%
    mutate(greypt = as.factor(ifelse(is.na(hetero_lbl),"#4591d3" , rgb(26,71,111, maxColorValue = 255))))
  pdata$greypt <- factor(pdata$greypt, levels=c("#4591d3",rgb(26,71,111, maxColorValue = 255)))
  
  pdata <- pdata %>%
    arrange(greypt)
  
  # axis ranges
  if(depvar == "emp_lw"){
    ymin <- 0.1
    ymax <- 0.4
    xmin <- 0.1
    xmax <- 0.43
    ymax2 <- 0.43
  }
  if(depvar == 'earn_ly'){
    ymin <- 0.1
    ymax <- 0.4
    xmin <- 0.1
    xmax <- 0.43
    ymax2 <- 0.43
  }
  
  # axis labels
  if(st_var == "bpl_state") {
    xlbl <- "Child Penalty for Stayers in State of Birth"
  } else {
    xlbl <- "Child Penalty for Stayers in State of Residence"
  }
  if(st_var == "bpl_state") {
    ylbl <- "Child Penalty for Movers by State of Birth"
  } else {
    ylbl <- "Child Penalty for Movers by State of Residence"
  }
  
  # default position of labels on points
  ymin2 <- 0.06
  xmin2 <- 0.06
  ynudge <- 0.007
  xnudge <- -0.001
  
  # Slope text position
  xlblpos <- xmax-.015
  ylblpos <- ymin+.03
  
  data <- pdata
  data$yvar <- data$penalty_res
  
  # test that slope of residualized penalty against global penalty is same as regression with controls
  testreg <- lm(yvar ~ xvar, data=data)
  print(paste("Control slope:",format(round(reg[["coefficients"]][["xvar"]],digits=3),nsmall=3),
              ", Line slope:", format(round(testreg[["coefficients"]][["xvar"]],digits=3),nsmall=3)))
  
  # plot
  ggplot(data=data, aes(x = xvar, y = yvar,group=greypt,color=greypt)) +
    # fitted line using raw data
    stat_smooth(data=data_line,color="#D11809", aes(x=xvar, y=yvar),method="lm",
                formula = y ~ x, se=F, show.legend=F, linewidth=1) +
    # point size
    geom_point(size=3) +
    # point colors
    scale_colour_manual(breaks = data$greypt,
                        values = as.character(data$greypt))+
    # axes
    labs(y = paste(ylbl), x = paste(xlbl))+
    scale_x_continuous(breaks=seq(xmin, xmax, by = 0.1))+
    scale_y_continuous(breaks=seq(ymin, ymax, by = 0.1)) +
    coord_cartesian(ylim=c(ymin2,ymax2),xlim=c(xmin2,xmax))+
    theme_minimal() +
    # position for text on points
    geom_text(aes(label=hetero_lbl), size=4,
              position = position_nudge(
                x = case_when(
                  #weekly employment, state of birth
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Alaska") ~ 0.023,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Arizona") ~ -0.004,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("California") ~ -0.004,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("D.C.") ~ 0.008,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Florida") ~ 0.012,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Hawaii") ~ -0.004,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Idaho") ~ 0.008,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Illinois") ~ 0.001,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Indiana") ~ 0.025,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Louisiana") ~ -0.004,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Nevada") ~ 0.026,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("New Jersey") ~ 0.037,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("New York") ~ 0.005,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("North Dakota") ~ 0.041,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Oregon") ~ 0.015,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Pennsylvania") ~ 0.042,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Rhode Island") ~ -0.004,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("South Carolina") ~ -0.004,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("South Dakota") ~ -0.003,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Texas") ~ -0.003,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Utah") ~ 0.016,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Washington") ~ 0.012,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("West Virginia") ~ 0.015,
                  
                  #weekly employment, state of residence
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Arizona") ~ 0.009,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("California") ~ 0.030,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("D.C.") ~ 0.008,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Delaware") ~ -0.003,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Florida") ~ 0.023,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Hawaii") ~ -0.004,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Idaho") ~ 0.019,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Illinois") ~ -0.004,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Louisiana") ~ -0.004,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Nevada") ~ 0.026,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("New Jersey") ~ 0.037,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("New Mexico") ~ -0.004,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("New York") ~ 0.031,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("North Dakota") ~ -0.004,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Oregon") ~ 0.024,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("South Carolina") ~ -0.003,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("South Dakota") ~ -0.003,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Texas") ~ -0.003,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Utah") ~ 0.016,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Washington") ~ 0.012,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("West Virginia") ~ 0.018,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Wyoming") ~ -0.003,
                  
                  #annual employment, state of birth
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Alaska") ~ 0.024,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Arkansas") ~ -0.004,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("California") ~ -0.003,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("D.C.") ~ 0.008,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Florida") ~ 0.012,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Hawaii") ~ -0.004,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Idaho") ~ 0.008,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Illinois") ~ 0.022,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Iowa") ~ 0.015,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Mississippi") ~ -0.001,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Montana") ~ 0.029,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Nevada") ~ 0.026,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("New Hampshire") ~ 0.05,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("New Jersey") ~ 0.038,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("New York") ~ 0.03,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("North Carolina") ~ 0.002,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("North Dakota") ~ 0.021,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Oregon") ~ 0.015,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("South Dakota") ~ -0.003,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Texas") ~ -0.005,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Utah") ~ 0.016,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Washington") ~ 0.038,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("West Virginia") ~ 0.042,
                  
                  #annual employment, state of residence
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Alaska") ~ 0.024,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Arkansas") ~ 0.004,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("California") ~ -0.005,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("California") ~ 0.025,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Connecticut") ~ -0.005,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("D.C.") ~ -0.004,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Florida") ~ 0.024,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Hawaii") ~ 0.025,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("Idaho") ~ 0.008,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("Idaho") ~ 0.02,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("Illinois") ~ -0.005,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("Illinois") ~ -0.002,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("Iowa") ~ 0.015,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("Iowa") ~ -0.002,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Mississippi") ~ -0.001,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Montana") ~ 0.029,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Nevada") ~ 0.026,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("New Hampshire") ~ 0.05,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("New Jersey") ~ 0,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("New Jersey") ~ 0.015,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("New York") ~ -0.002,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("New York") ~ -0.004,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("North Carolina") ~ 0.001,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("North Dakota") ~ 0.021,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("North Dakota") ~ -0.005,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("Oregon") ~ 0.026,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("Oregon") ~ 0.005,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("Rhode Island") ~ -0.003,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("South Dakota") ~ -0.003,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("Texas") ~ 0.02,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("Texas") ~ -0.005,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Utah") ~ 0.020,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Vermont") ~ 0.012,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Washington") ~ 0.038,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("West Virginia") ~ 0.042,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("West Virginia") ~ 0.038,
                  TRUE ~ xnudge), 
                y=case_when(
                  #weekly employment, state of birth
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Alaska") ~ -0.001,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Arizona") ~ 0,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("California") ~ -0.002,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("D.C.") ~ -0.008,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Florida") ~ 0.009,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Hawaii") ~ 0,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Idaho") ~ 0.009,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Illinois") ~ -0.008, 
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Indiana") ~ 0,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Louisiana") ~ 0.001,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Nevada") ~ 0,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("New Jersey") ~ 0,
                  depvar == "emp_lw" & st_var == "bpl_state" & spec == "nocontrols" & data$hetero_lbl %in% c("New York") ~ -0.008,
                  depvar == "emp_lw" & st_var == "bpl_state" & spec == "controls" & data$hetero_lbl %in% c("New York") ~ -0.006,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("North Dakota") ~ -0.004, 
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Oregon") ~ 0.009,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Pennsylvania") ~ 0,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Rhode Island") ~ 0,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("South Carolina") ~ 0.001, 
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("South Dakota") ~ 0.007, 
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Utah") ~ -0.006,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Texas") ~ 0.005,
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("Washington") ~ 0.01, 
                  depvar == "emp_lw" & st_var == "bpl_state" & data$hetero_lbl %in% c("West Virginia") ~ -0.01, 
                  
                  #weekly employment, state of residence
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Arizona") ~ -0.006,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("California") ~ -0.004,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("D.C.") ~ -0.008,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Delaware") ~ 0.005,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Florida") ~ 0,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Hawaii") ~ 0,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Idaho") ~ -0.0065,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Illinois") ~ -0.003,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Louisiana") ~ 0.002,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Nevada") ~ 0,
                  depvar == "emp_lw" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("New Jersey") ~ -0.003,
                  depvar == "emp_lw" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("New Jersey") ~ -0.004,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("New Mexico") ~ 0.003,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("New York") ~ -0.004,
                  depvar == "emp_lw" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("North Dakota") ~ 0.000, 
                  depvar == "emp_lw" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("North Dakota") ~ -0.003, 
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Oregon") ~ 0.006,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("South Carolina") ~ 0.005, 
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("South Dakota") ~ -0.006, 
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Utah") ~ -0.006,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Texas") ~ 0.005,
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Washington") ~ 0.01, 
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("West Virginia") ~ -0.01, 
                  depvar == "emp_lw" & st_var == "statename" & data$hetero_lbl %in% c("Wyoming") ~ 0.005,
                  
                  #annual employment, state of birth
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Alaska") ~ 0,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Arkansas") ~ 0.001,
                  depvar == "earn_ly" & st_var == "bpl_state" & spec == "nocontrols" & data$hetero_lbl %in% c("California") ~ -0.001,
                  depvar == "earn_ly" & st_var == "bpl_state" & spec == "controls" & data$hetero_lbl %in% c("California") ~ 0.002,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("D.C.") ~ -0.008,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Florida") ~ 0.009,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Hawaii") ~ 0,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Idaho") ~ 0.009,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Illinois") ~ -0.003,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Iowa") ~ -0.007,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Mississippi") ~ 0.008,
                  depvar == "earn_ly" & st_var == "bpl_state" & spec == "nocontrols" & data$hetero_lbl %in% c("Montana") ~ 0,
                  depvar == "earn_ly" & st_var == "bpl_state" & spec == "controls" & data$hetero_lbl %in% c("Montana") ~ 0.001,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Nevada") ~ 0,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("New Hampshire") ~ 0,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("New Jersey") ~ -0.001,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("New York") ~ 0.006,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("North Carolina") ~ 0.009,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("North Dakota") ~ -0.008,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Oregon") ~ 0.009,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("South Dakota") ~ 0.007,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Texas") ~ 0,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Utah") ~ -0.006,
                  depvar == "earn_ly" & st_var == "bpl_state" & data$hetero_lbl %in% c("Washington") ~ -0.003,
                  depvar == "earn_ly" & st_var == "bpl_state" & spec == "nocontrols" & data$hetero_lbl %in% c("West Virginia") ~ -0.003,
                  depvar == "earn_ly" & st_var == "bpl_state" & spec == "controls" & data$hetero_lbl %in% c("West Virginia") ~ -0.004,
                  
                  #annual employment, state of residence
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Alaska") ~ 0,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Arkansas") ~ 0.01,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("California") ~ 0.002,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("California") ~ -0.009,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Connecticut") ~ 0,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("D.C.") ~ 0,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Florida") ~ 0,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Hawaii") ~ 0,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("Idaho") ~ 0.009,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("Idaho") ~ 0,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("Illinois") ~ 0.002,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("Illinois") ~ -0.006,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("Iowa") ~ -0.007,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("Iowa") ~ 0.006,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Mississippi") ~ 0.008,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Montana") ~ 0,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Nevada") ~ 0,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("New Hampshire") ~ 0,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("New Jersey") ~ 0.009,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("New York") ~ 0.006,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("New York") ~ 0.002,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("North Carolina") ~ 0.007,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("North Dakota") ~ -0.009,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("North Dakota") ~ 0,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("Oregon") ~ 0,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("Oregon") ~ 0.009,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("Rhode Island") ~ -0.008,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("Rhode Island") ~ 0,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("South Dakota") ~ -0.005,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("South Dakota") ~ 0.005,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("Texas") ~ -0.008,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("Texas") ~ 0,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Utah") ~ 0,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Vermont") ~ -0.01,
                  depvar == "earn_ly" & st_var == "statename" & data$hetero_lbl %in% c("Washington") ~ -0.003,
                  depvar == "earn_ly" & st_var == "statename" & spec == "nocontrols" & data$hetero_lbl %in% c("West Virginia") ~ -0.004,
                  depvar == "earn_ly" & st_var == "statename" & spec == "controls" & data$hetero_lbl %in% c("West Virginia") ~ -0.008,
                  TRUE ~ ynudge)),
              hjust=1)+
    # slope text
    annotate("text", x=xlblpos,y=ylblpos,
             label=txt, parse = T,
             size=7,color="black",hjust=1)+
    # r^2 text
    annotate("text", x=xlblpos-0.035,y=ylblpos-0.02,
             label= txt_ar, parse = T,
             size=7,color="black",hjust=1)+
    # theme
    theme(axis.line = element_line(colour = "black",linewidth=0.2)) +
    theme(panel.grid.minor.x = element_blank(),
          panel.grid.minor.y = element_blank(),
          axis.text=element_text(size=18),
          axis.title=element_text(size=18),
          legend.position = "none",
          legend.key.height = unit(1, "cm"),
          legend.key.size = unit(2, "cm"),
          legend.text = element_text(size=25))+
    theme(
      axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)),
      axis.text.x = element_text(vjust = -0.5),
      axis.text.y = element_text(margin = unit(c(0,0.4,0,0), "cm"))
    ) +
    theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)))
  # save
  if(st_var == "bpl_state") {
    ggsave(paste0("epidemiological_movers_vs_stayers_rawscatter_st_birth",plotname,"_",depvarlbl,
                  ".pdf"), 
           plot=last_plot(), device="pdf",
           width=11, height=8, units="in",path=file.path(outdir,"Figures"))
  } else {
    ggsave(paste0("epidemiological_movers_vs_stayers_rawscatter_st_res",plotname,"_",depvarlbl,
                  ".pdf"), 
           plot=last_plot(), device="pdf",
           width=11, height=8, units="in",path=file.path(outdir,"Figures"))
  }
  
  return(data)
}

# Define vector of outcome vars to run functions over
l.depvars <- c("emp_lw","earn_ly")
# Define vector of state vars to run functions over
l.state <- c("bpl_state","statename")

# Load CPS/ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))


# Figure 13 (left panels), state of birth
lapply(l.depvars, fn_scatter_epi,
       data = cps_acs,
       ysample="movers", xsample = "stayers", var="penalty",
       filtervar="spec_lbl", spec="nocontrols", plotname="", final_filename = T,
       st_var = "bpl_state")
# Appendix figure (left panels), state of residence
lapply(l.depvars, fn_scatter_epi,
       data = cps_acs,
       ysample="movers", xsample = "stayers", var="penalty",
       filtervar="spec_lbl", spec="nocontrols", plotname="", final_filename = T,
       st_var = "statename")

# Figure 13 (right panels), state of birth
lapply(l.depvars, fn_scatter_epi,
       data = cps_acs,
       ysample="movers", xsample = "stayers", var="penalty",
       filtervar="spec_lbl", spec="controls", plotname="_controls", final_filename = T,
       st_var = "bpl_state")
# Appendix figure (right panels), state of residence
lapply(l.depvars, fn_scatter_epi,
       data = cps_acs,
       ysample="movers", xsample = "stayers", var="penalty",
       filtervar="spec_lbl", spec="controls", plotname="_controls", final_filename = T,
       st_var = "statename")
