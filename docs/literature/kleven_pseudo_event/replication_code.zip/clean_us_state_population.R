#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file calculates the share of the 2019 US population that lives
  # in each state using Census Bureau population data

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Read data

pop <- read.csv(file=file.path(rawdir, "Census Bureau Population Data", "nst-est2019-alldata.csv"))
names(pop) <- tolower(names(pop))

# rename vars, select year and states we need
pop <- pop %>%
  rename(statename = name,
         fips=state) %>%
  subset(select=c(statename,fips,popestimate2019)) %>%
  filter(inrange(fips, 1, 56) | statename == "United States")

# calculate fraction of us pop living in each state
pop <- pop %>%
  mutate(totalpop = pop[pop$fips==0, "popestimate2019"][1]) %>%
  filter(fips > 0) %>%
  mutate(frac_stpop2019 = popestimate2019/totalpop) %>%
  subset(select=c(statename, frac_stpop2019))

# save data
saveRDS(pop, file=file.path(cleandir, "popweights_2019.rds"))
