#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file takes the collapsed GPI by state and decade
# and imputes the GPI for state-decade combinations that are missing in the GSS data

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# load collapsed GSS data by state and decade
gss_unimputed <- read_rds(file.path(wrkdir, "gss_state_by_ten_year_interval.rds"))  

# keep index_ad only for now
gss <- gss_unimputed %>%
  subset(select=c(fips, state, interval, index_ad)) %>%
  rename(statename=state) %>%
  drop_na(statename, index_ad)

# get pctile of gss value for each state within each interval 
  # (pctile of each state within a given decade)
gss <- gss %>%
  group_by(interval) %>%
  mutate_at(dplyr::vars(index_ad), list(quant= ~ ecdf(.)(.))) %>%
  ungroup()

# get avg pctile of gss in each state
  # (on avg, which pctile is each state in across all decades it appears in)
pctile_means <- aggregate(quant ~ statename, gss, mean) %>%
  rename(mean_quant = quant)

# add missing state-interval combinations to df
  # df of all possible combinations
allobs <- expand.grid(statename = unique(gss$statename), interval=unique(gss$interval))
  # crosswalk of state names and fips codes
xwalk <- gss %>%
  count(statename, fips) %>%
  subset(select=-c(n))
  # add fips codes to df of combinations
allobs <- merge(allobs, xwalk, by="statename")
  # add missing combinations to df
gss <- merge(gss, allobs, by=c("statename","interval","fips"), all=T)
  # add avg percentile to dff
gss <- merge(gss, pctile_means, by="statename")

# function to get imputed gss measure

get_quantile <- function(data, var, y, qvar) {
  
  # variable to base percentiles on (gpi var)
  data["var"] <- data[{{var}}]
  # variable with average percentiles
  data["qvar"] <- data[{{qvar}}]
  
  # keep only interval of interest
  data <- data %>%
    filter(interval == {{y}})
  # vector of all percentiles in that interval
  q <- data$qvar
  
  # this gives the value of "var" that corresponds to the percentile in q
    # so for a value of q of 0.3, the variable imputed will indicate
    # what value of "var" would represent the 30th percentile
  data <- within(data, imputed <- quantile(var, c(q), na.rm=T)) %>%
    subset(select=-c(qvar, var))
  
  return(data)
}

# apply function over each interval separately
gss_imputed <- setDF(rbindlist(lapply(unique(gss$interval), get_quantile, data=gss, var = "index_ad", qvar = "mean_quant")))

# replace missing gpi values with imputed value based on avg percentile
gss_imputed <- gss_imputed %>%
  mutate(index_ad = ifelse(is.na(index_ad), imputed, index_ad))

# save imputed gss values
saveRDS(gss_imputed, file=file.path(wrkdir, "gss_imputed_state_by_decade.rds"))

########### Collapse imputed values to create dataset of GPI by state

# load weights from cps/acs
birthweights <- read_rds(file.path(wrkdir, "gss_reweighting_gpi.rds"))

# merge
gss_imputed <- merge(gss_imputed, birthweights, by=c("statename","interval"))

# Imputed gss by state
gss_imputed_st <- gss_imputed %>%
  group_by(statename, fips) %>%
  summarise(mean_index_ad = mean(index_ad),
            index_ad_stwgt = weighted.mean(index_ad, birthwgt_st),
            index_ad_natwgt = weighted.mean(index_ad, birthwgt_nat)) %>%
  rename(index_ad = mean_index_ad)

saveRDS(gss_imputed_st, file=file.path(wrkdir, "gss_imputed_state.rds"))
