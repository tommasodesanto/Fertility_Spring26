#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file cleans PSID data

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

  # Read data
psid_raw <- readRDS(file.path(rawdir,"PSID","RDS Files","J30305267.rds"))
psid <- psid_raw

########## Childbirth and adoption history 
  # read file
cah <- read_dta(file=file.path(rawdir,"PSID","cah85_19","CAH85_19.dta"))

  ####### Parent identifier
  cah <- cah %>%
    rename(hhid68 = CAH3, # 1968 interview number of parent
           pid = CAH4) %>% # person number of parent
    mutate(hhid68 = round(hhid68),
           pid = round(pid)) %>%
    mutate(id68 = round((hhid68*1000)+pid)) # gen unique parent ID
  
  ####### Child variables
  cah <- cah %>%
    mutate(idchild = (CAH10 *1000) + CAH11) %>% #child id
    mutate(idchild = ifelse(CAH10 %in% c(0, 9999) | CAH11 %in% c(0, 999), NA_real_,
                            idchild))
  
  cah <- cah %>%
    rename(birth_order = CAH9,
           child_dobm = CAH13,
           child_doby = CAH15,
           child_type = CAH2) %>%
    mutate(birth_order = ifelse(birth_order %in% c(98,99), 
                                NA_real_, birth_order)) %>% # missing if adopted
    # birth month: jan if winter, april if spring, july if summer, oct if fall, sept if unknown
    mutate(child_dobm = case_when(child_dobm == 21 ~ 1,
                                  child_dobm == 22 ~ 4,
                                  child_dobm == 23 ~ 7,
                                  child_dobm == 24 ~ 10,
                                  child_dobm == 98 ~ 9,
                                  child_dobm == 99 ~ NA_real_,
                                  TRUE ~ child_dobm)) %>%
    mutate(child_doby = ifelse(child_doby %in% c(9998,9999), NA_real_, child_doby))
  
  
  ####### Sample selection
  
    # keep birth children only
  cah <- subset(cah, child_type == 1)
  
    #check for duplicates
  nrow(count(cah, id68,idchild)) == nrow(cah)
  
    # create date of birth variable
  cah$chdob <- as.Date(with(cah, paste(as.character(child_doby),as.character(child_dobm)
                                       ,"15",sep="-")),"%Y-%m-%d")
  
  #### NOTE: might need to check this and drop missing birth dates before doing all of this
    # correct birth order, create max children variable
  cah <- cah[order(cah$id68, cah$chdob),]
  # cah$order <- ave(cah$id,FUN = seq_along)
  cah <- cah %>%
    group_by(id68) %>%
    mutate(order = row_number()) %>%
    mutate(birth_order = order)
  
  cah_totals <- cah %>%
    filter(!is.na(child_doby)) %>%
    group_by(id68) %>%
    summarise(chtot = n())

  cah <- merge(cah, cah_totals,by="id68")
  
  cah <- subset(cah, select=c(hhid68, pid, id68, birth_order, child_doby, chdob, chtot))
  
  cah <- cah %>%
    pivot_wider(names_from = birth_order,
                values_from = c(child_doby, chdob)) %>%
    rename(ch1dob = chdob_1,
           ch2dob = chdob_2,
           ch1yob = child_doby_1,
           ch2yob = child_doby_2)
  
  cah <- cah[, -grep("chdob", colnames(cah))]
  cah <- cah[, -grep("child_doby", colnames(cah))]
  
########## Survey variables

  ####### IDs

# 1968 family interview ID number
  psid <- psid %>%
    mutate(hhid68 = round(ER30001))
# colnames(psid) <- sub("ER30001", "hhid", colnames(psid))

# 1968 individual ID number within household
# colnames(psid) <- sub("ER30002", "pid", colnames(psid))
  psid <- psid %>%
    mutate(pid = round(ER30002))

# unique id (1968)
  psid$id68 <- round((psid$hhid68*1000)+psid$pid)


# hhid over time
oldvars <- c("ER30001", "ER30020", "ER30043", "ER30067", "ER30091", 
             "ER30117", "ER30138", "ER30160", "ER30188", "ER30217", 
             "ER30246", "ER30283", "ER30313", "ER30343", "ER30373",
             "ER30399", "ER30429", "ER30463", "ER30498", "ER30535",
             "ER30570", "ER30606", "ER30642", "ER30689", "ER30733",
             "ER30806", "ER33101", "ER33201", "ER33301", "ER33401",
             "ER33501", "ER33601", "ER33701", "ER33801", "ER33901",
             "ER34001", "ER34101", "ER34201", "ER34301", "ER34501",
             "ER34701")

newvars <- c("hhid1968", "hhid1969", "hhid1970", "hhid1971","hhid1972", "hhid1973",
             "hhid1974", "hhid1975", "hhid1976", "hhid1977", "hhid1978", "hhid1979",
             "hhid1980", "hhid1981", "hhid1982", "hhid1983", "hhid1984", "hhid1985",
             "hhid1986", "hhid1987", "hhid1988", "hhid1989", "hhid1990", "hhid1991",
             "hhid1992", "hhid1993", "hhid1994", "hhid1995", "hhid1996", "hhid1997",
             "hhid1999", "hhid2001", "hhid2003", "hhid2005", "hhid2007", "hhid2009",
             "hhid2011", "hhid2013", "hhid2015", "hhid2017", "hhid2019")

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)



# sequence number
  # 1969-2019 ; // (from PSID Individual Data by Years);
      # /*Name: SEQUENCE NUMBER
      # detail: This variable provides a means of identifying the status of
      # an individual with regard to the FU at the time of interview.
      # ranges: 1 - 20, 51 - 59, 71 - 80, 81 - 89, 0  */

oldvars <- c("ER30021", "ER30044", "ER30068", "ER30092", "ER30118", 
             "ER30139", "ER30161", "ER30189", "ER30218", "ER30247", "ER30284",
             "ER30314", "ER30344", "ER30374", "ER30400", "ER30430", "ER30464",
             "ER30499", "ER30536", "ER30571", "ER30607", "ER30643", "ER30690",
             "ER30734", "ER30807", "ER33102", "ER33202", "ER33302", "ER33402",
             "ER33502", "ER33602", "ER33702", "ER33802", "ER33902", "ER34002",
             "ER34102", "ER34202", "ER34302", "ER34502","ER34702")
newvars <- c("seq1969", "seq1970", "seq1971", "seq1972", "seq1973", "seq1974", 
             "seq1975", "seq1976", "seq1977", "seq1978", "seq1979", "seq1980",
             "seq1981", "seq1982", "seq1983", "seq1984", "seq1985", "seq1986",
             "seq1987", "seq1988", "seq1989", "seq1990", "seq1991", "seq1992",
             "seq1993", "seq1994", "seq1995", "seq1996", "seq1997", "seq1999",
             "seq2001", "seq2003", "seq2005", "seq2007", "seq2009", "seq2011",
             "seq2013", "seq2015", "seq2017", "seq2019")

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

# relationship to head (household member), 1968-2017 
    # (from PSID Individual Data by Years) ;
    # /*Name: y68-y87: "RELATIONSHIP TO HEAD" y87-y15 "RELATION TO HEAD" 
    # y17 "RELATION TO REFERENCE PERSON"
    # values: y68-y82 [1	Head- 8	Husband or Wife ]   0
    # y83-y19 [10-98]
    # Individual from core sample who was born or moved  */

oldvars <- c("ER30003", "ER30022", "ER30045", "ER30069", "ER30093","ER30119",
             "ER30140", "ER30162", "ER30190", "ER30219", "ER30248", "ER30285",
             "ER30315", "ER30345", "ER30375", "ER30401", "ER30431", "ER30465",
             "ER30500", "ER30537", "ER30572", "ER30608", "ER30644", "ER30691",
             "ER30735", "ER30808", "ER33103", "ER33203", "ER33303", "ER33403",
             "ER33503", "ER33603", "ER33703", "ER33803", "ER33903", "ER34003",
             "ER34103", "ER34203", "ER34303", "ER34503", "ER34703")
  
newvars <- c("hhmem1968", "hhmem1969", "hhmem1970", "hhmem1971", "hhmem1972",
             "hhmem1973", "hhmem1974", "hhmem1975", "hhmem1976", "hhmem1977",
             "hhmem1978", "hhmem1979", "hhmem1980", "hhmem1981", "hhmem1982",
             "hhmem1983", "hhmem1984", "hhmem1985", "hhmem1986", "hhmem1987", 
             "hhmem1988", "hhmem1989", "hhmem1990", "hhmem1991", "hhmem1992",
             "hhmem1993", "hhmem1994", "hhmem1995", "hhmem1996", "hhmem1997",
             "hhmem1999", "hhmem2001", "hhmem2003", "hhmem2005", "hhmem2007",
             "hhmem2009", "hhmem2011", "hhmem2013", "hhmem2015", "hhmem2017",
             "hhmem2019")

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

  # in 1968: 9 == NA, in other years 9 == husband of head
psid <- psid %>%
  mutate(hhmem1968 = ifelse(hhmem1968 != 9, hhmem1968, NA_integer_)) # 9 == NA

  # recode 1983 - 2019, currently coded as: 10 = head, 20's = wife, 30's = child, 
    # 40's = sibling, 50's = parent, 60,65 = grandchildren, 66-69 = grandparent, 
    # 70's,95-97 = other relative, 83,88,98 = non-relative, 9 = husband of head

psid <- psid %>%
  mutate(across(c(contains("hhmem")), ~round(.))) %>%
  mutate(across(c(contains("hhmem")), ~as.factor(case_when(
            . %in% c(1, 10) ~ "Head",
            . %in% c(2,20, 22) ~ "Wife of head",
            . %in% c(3,30, 33, 35, 37, 38) ~ "Child of head",
            . %in% c(4, 40, 47, 48) ~ "Sibling of head",
            . %in% c(5, 50, 57, 58) ~ "Parent of head",
            . %in% c(6, 60, 65) ~ "Grandchild of head",
            . %in% c(7, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 95, 96, 97) ~ "Other",
            . %in% c(8, 83, 88, 98) ~ "Non-relative",
            . %in% c(9, 90, 92) ~ "Husband of head",
            . == 0 ~ "Immigrant or moved in after interview")), .names="relationhd_{col}"
            ))


colnames(psid) <- sub("_hhmem", "", colnames(psid))

###### weights

  # individual weights

      # 1968-1989; //  (from PSID Individual Data by Years);
      # /*Name: INDIVIDUAL WEIGHT
      # note: there are available 3 years more y90, y91, y92*/
  
oldvars_str <- "ER30019ER30042ER30066ER30090ER30116ER30137ER30159ER30187ER30216ER30245ER30282ER30312ER30342ER30372ER30398ER30428ER30462ER30497ER30534ER30569ER30605ER30641ER30686ER30730ER30803"
oldvars <- substring(oldvars_str, seq(1, nchar(oldvars_str), 7), seq(7, nchar(oldvars_str), 7))

newvars_str <- "i_wgt1968i_wgt1969i_wgt1970i_wgt1971i_wgt1972i_wgt1973i_wgt1974i_wgt1975i_wgt1976i_wgt1977i_wgt1978i_wgt1979i_wgt1980i_wgt1981i_wgt1982i_wgt1983i_wgt1984i_wgt1985i_wgt1986i_wgt1987i_wgt1988i_wgt1989i_wgt1990i_wgt1991i_wgt1992"
newvars <- substring(newvars_str, seq(1, nchar(newvars_str), 9), seq(9, nchar(newvars_str), 9))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

  # combined latino and core weights

    # 1990-1996  ; // (from PSID Individual Data by Years);
    # /*Name: COMBINED IND WEIGHT , y94: COMBO IND WEIGHT, y96: CORE INDIVIDUAL LONGITUDINAL WEIGHT
    # 1. Longitudinal> combined core and latino:y 90, y91, 92
    # 2. Longitudinal> combined core and latino>revised 1993: y93, y94, y95
    # 3. Longitudinal> core>revised 1993: y96
    # Note: y96 is individual sample weight not latino,  could be this a problem? */

oldvars_str <- "ER30688ER30732ER30805ER30866ER33121ER33277ER33318"
oldvars <- substring(oldvars_str, seq(1, nchar(oldvars_str), 7), seq(7, nchar(oldvars_str), 7))

newvars_str <- "i_c_wgt1990i_c_wgt1991i_c_wgt1992i_c_wgt1993i_c_wgt1994i_c_wgt1995i_c_wgt1996"
newvars <- substring(newvars_str, seq(1, nchar(newvars_str), 11), seq(11, nchar(newvars_str), 11))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)


  # combined longitudinal weights

#        1997-2019 (1996 is just core but it shouldn't matter) ;
# 			/*Name: "CORE/IMM INDIVIDUAL LONGITUDINAL WT"
# 				1.Longitudinal >combined core and immigrant: y97-y17
# 				Note: y97-05: Note that the weight variables are not comparable across waves.
# 				Three types of weights (core only, Latino only and combined core-Latino)
# 				were created for 1990 through 1995 because of the addition of the Latino sample*/

oldvars_str <- "ER33430ER33546ER33637ER33740ER33848ER33950ER34045ER34154ER34268ER34413ER34650ER34863"
newvars_str <- "i_clong_wgt1997i_clong_wgt1999i_clong_wgt2001i_clong_wgt2003i_clong_wgt2005i_clong_wgt2007i_clong_wgt2009i_clong_wgt2011i_clong_wgt2013i_clong_wgt2015i_clong_wgt2017i_clong_wgt2019"

oldvars <- substring(oldvars_str, seq(1, nchar(oldvars_str), 7), seq(7, nchar(oldvars_str), 7))
newvars <- substring(newvars_str, seq(1, nchar(newvars_str), 15), seq(15, nchar(newvars_str), 15))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)


  # combined cross sectional weights
#         1997-2019 (1996 is just core but it shouldn't matter) ;
# 			/*Name: "CORE/IMM INDIVIDUAL CROSS-SECTION WT"
# 				1.Cross-Sectional >combined core and immigrant: y97-17 */

oldvars_str <- "ER33438ER33547ER33639ER33742ER33849ER33951ER34046ER34155ER34269ER34414ER34651ER34864"
newvars_str <- "i_cx_wgt1997i_cx_wgt1999i_cx_wgt2001i_cx_wgt2003i_cx_wgt2005i_cx_wgt2007i_cx_wgt2009i_cx_wgt2011i_cx_wgt2013i_cx_wgt2015i_cx_wgt2017i_cx_wgt2019"

oldvars <- substring(oldvars_str, seq(1, nchar(oldvars_str), 7), seq(7, nchar(oldvars_str), 7))
newvars <- substring(newvars_str, seq(1, nchar(newvars_str), 12), seq(12, nchar(newvars_str), 12))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)


###### interview dates

  # month and date
      # 1968-2019 ; //(fromPSID Main Family Data) ;
      # /* Interview Information >date of interview >head: y68-96
      # choices: y68-y79 [1-8 months] , y80-y17:[month-day 4-digts]
      # Interview Information >date of interview >head: >month:
      #   values: [1 - 12	Actual month]*/

oldvars <- c("V99", "V553", "V1236", "V1939", "V2539", "V3092", "V3505", 
             "V3918", "V4433", "V5347", "V5847", "V6459", "V7064", "V7655",
             "V8349", "V8958", "V10416", "V11600", "V13008", "V14111", "V15127", 
             "V16628", "V18046", "V19346", "V20648", "V22403", "ER2005", 
             "ER5004", "ER7004", "ER10005", "ER13006", "ER17009", "ER21012",
             "ER25012", "ER36012", "ER42012", "ER47312", "ER53012", "ER60012", "ER66012",
             "ER72012")

newvars_str <- "doim1968doim1969doim1970doim1971doim1972doim1973doim1974doim1975doim1976doim1977doim1978doim1979doim1980doim1981doim1982doim1983doim1984doim1985doim1986doim1987doim1988doim1989doim1990doim1991doim1992doim1993doim1994doim1995doim1996doim1997doim1999doim2001doim2003doim2005doim2007doim2009doim2011doim2013doim2015doim2017doim2019"
newvars <- substring(newvars_str, seq(1, nchar(newvars_str), 8), seq(8, nchar(newvars_str), 8))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

    # round date vars

psid <- psid %>%
  mutate(across(c(contains("doim")), ~round(.)))
  
    # recoding: for 1968-1979 dates are in ranges of about 15 days rather than months exactly
        # we choose the month in which most of the 15 days are (eg: may 27th == june)

psid <- psid %>%
  mutate(doim1968 = case_when(!inrange(doim1968, 1, 9) ~ as.numeric(doim1968),
                              doim1968 %in% c(1,2) ~ 3,
                              doim1968 %in% c(3, 4) ~ 4,
                              doim1968 %in% c(5, 6) ~ 5,
                              doim1968 %in% c(7,8) ~ 6,
                              doim1968 == 9 ~ NA_real_),
         doim1969 = case_when(!inrange(doim1969, 1, 9) ~ as.numeric(doim1969),
                              doim1969 %in% c(2, 3) ~ 3,
                              doim1969 == 1 ~ 2,
                              doim1969 %in% c(4, 5, 6) ~ 4,
                              doim1969 %in% c(7,8) ~ 5,
                              doim1969 == 9 ~ NA_real_),
         doim1970 = case_when(!inrange(doim1970, 1, 9) ~ as.numeric(doim1970),
                              doim1970 %in% c(2, 3) ~ 3,
                              doim1970 == 1 ~ 2,
                              doim1970 %in% c(4, 5) ~ 4,
                              doim1970 %in% c(6, 7) ~ 5,
                              doim1970 == 8 ~ 6,
                              doim1970 == 9 ~ NA_real_))

for(years in c(as.character(1971:1979))) {
psid <- psid %>%
  mutate(across(c(contains("doim") & contains(years)), 
                ~case_when(. == 0 ~ 2,
                           . %in% c(1, 2) ~ 3,
                           . %in% c(3, 4) ~ 4,
                           . %in% c(5, 6) ~ 5,
                           . == 7 ~ 6,
                           . == 8 ~ 7,
                           . == 9 ~ NA_real_)))
    
}
# first two digits == month, rest == day
  # extract month only
for(years in c(as.character(1980:1996))) {
psid <- psid %>%
  # mutate(across(c(contains("doim") & contains(years)),
  #               ~ifelse(. == 9999, NA_real_, as.numeric(.)))) %>%
  mutate(across(c(contains("doim") & contains(years)),
                ~as.numeric(substr(sprintf("%04.0f",.),1,2)))) %>%
  mutate(across(c(contains("doim") & contains(years)),
                ~ifelse(round(.) == 99, NA_real_, as.numeric(.))))
}

# 1997-2017: don't need to adjust as they have the exact day

######## State Codes

  # FIPS Codes y1985-2019

oldvars <- c("V12380", "V13632", "V14679", "V16153", "V17539", "V18890", "V20190",
             "V21496", "V23328", "ER4157", "ER6997", "ER9248", "ER10004", "ER13005",
             "ER17005", "ER21004", "ER25004", "ER36004", "ER42004", "ER47304",
             "ER53004", "ER60004", "ER66004","ER72004")

newvars_str <- "statefip1985statefip1986statefip1987statefip1988statefip1989statefip1990statefip1991statefip1992statefip1993statefip1994statefip1995statefip1996statefip1997statefip1999statefip2001statefip2003statefip2005statefip2007statefip2009statefip2011statefip2013statefip2015statefip2017statefip2019"
newvars <- substring(newvars_str, seq(1, nchar(newvars_str), 12), seq(12, nchar(newvars_str), 12))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

  # PSID Codes
  # y68-19
  # state of residence at time of interview
oldvars <- c("V93", "V537", "V1103", "V1803", "V2403", "V3003", "V3403", "V3803",
             "V4303", "V5203", "V5703", "V6303", "V6903", "V7503", "V8203",
             "V8803", "V10003", "V11103", "V12503", "V13703", "V14803",
             "V16303", "V17703", "V19003", "V20303", "V21603", "ER4156", "ER6996",
             "ER9247", "ER12221", "ER13004", "ER17004", "ER21003", "ER25003", 
             "ER36003", "ER42003", "ER47303", "ER53003", "ER60003", "ER66003",
             "ER72003")

newvars_str <- "psid_state1968 psid_state1969 psid_state1970 psid_state1971 psid_state1972 psid_state1973 psid_state1974 psid_state1975 psid_state1976 psid_state1977 psid_state1978 psid_state1979 psid_state1980 psid_state1981 psid_state1982 psid_state1983 psid_state1984 psid_state1985 psid_state1986 psid_state1987 psid_state1988 psid_state1989 psid_state1990 psid_state1991 psid_state1992 psid_state1993 psid_state1994 psid_state1995 psid_state1996 psid_state1997 psid_state1999 psid_state2001 psid_state2003 psid_state2005 psid_state2007 psid_state2009 psid_state2011 psid_state2013 psid_state2015 psid_state2017 psid_state2019"
             
newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),14), seq(14,nchar(.),14))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)


######## Demographic variables

  # number of births
colnames(psid) <- sub("ER32022", "numbirths", colnames(psid))

  # sex of individual
psid <- psid %>%
  mutate(gender = as.factor(case_when(ER32000 == 2 ~ "Women",
                            ER32000 == 1 ~ "Men",
                            ER32000 %in% c(9, NA_integer_) ~ NA_character_)))

  # age
    # y68- y19  ;//(from PSID Individual Data by Years)
    # /*Name: "AGE OF INDIVIDUAL" ,
    # values: 1, Newborn up to second birthday, 2 - 125	Actual age, 0 missing */

oldvars_str <- "ER30004 ER30023 ER30046 ER30070 ER30094 ER30120 ER30141 ER30163 ER30191 ER30220 ER30249 ER30286 ER30316 ER30346 ER30376 ER30402 ER30432 ER30466 ER30501 ER30538 ER30573 ER30609 ER30645 ER30692 ER30736 ER30809 ER33104 ER33204 ER33304 ER33404 ER33504 ER33604 ER33704 ER33804 ER33904 ER34004 ER34104 ER34204 ER34305 ER34504 ER34704"
newvars_str <- "age1968 age1969 age1970 age1971 age1972 age1973 age1974 age1975 age1976 age1977 age1978 age1979 age1980 age1981 age1982 age1983 age1984 age1985 age1986 age1987 age1988 age1989 age1990 age1991 age1992 age1993 age1994 age1995 age1996 age1997 age1999 age2001 age2003 age2005 age2007 age2009 age2011 age2013 age2015 age2017 age2019"

oldvars <- gsub(" ","", oldvars_str,fixed=TRUE) %>%
  substring(., seq(1, nchar(.), 7), seq(7, nchar(.), 7))
newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),7), seq(7,nchar(.), 7))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)


  # month born
    # (only available 1983-2019) ;  // (from PSID Individual Data by Years )
    # /*Name:y83-y87, y92 "MONTH IND BORN" y88- "MONTH INDIVIDUAL BORN"
    # values: [1:12] 99 0 */

oldvars_str <- "ER30403 ER30433 ER30467 ER30502 ER30539 ER30574 ER30610 ER30646 ER30693 ER30737 ER30810 ER33105 ER33205 ER33305 ER33405 ER33505 ER33605 ER33705 ER33805 ER33905 ER34005 ER34105 ER34205 ER34306 ER34505 ER34705"
newvars_str <- "dobm1983 dobm1984 dobm1985 dobm1986 dobm1987 dobm1988 dobm1989 dobm1990 dobm1991 dobm1992 dobm1993 dobm1994 dobm1995 dobm1996 dobm1997 dobm1999 dobm2001 dobm2003 dobm2005 dobm2007 dobm2009 dobm2011 dobm2013 dobm2015 dobm2017 dobm2019"

oldvars <- gsub(" ","", oldvars_str,fixed=TRUE) %>%
  substring(., seq(1, nchar(.), 7), seq(7, nchar(.), 7))
newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),8), seq(8,nchar(.),8))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)


  # year born
    # (only available 1983-2019) ; //from (PSID Individual Data by Years)
    # /*Name: y83-y87 "YEAR IND BORN" , y88-y17  "YEAR INDIVIDUAL BORN" */
  
oldvars_str <- "ER30404 ER30434 ER30468 ER30503 ER30540 ER30575 ER30611 ER30647 ER30694 ER30738 ER30811 ER33106 ER33206 ER33306 ER33406 ER33506 ER33606 ER33706 ER33806 ER33906 ER34006 ER34106 ER34206 ER34307 ER34506 ER34706"
newvars_str <- "doby1983 doby1984 doby1985 doby1986 doby1987 doby1988 doby1989 doby1990 doby1991 doby1992 doby1993 doby1994 doby1995 doby1996 doby1997 doby1999 doby2001 doby2003 doby2005 doby2007 doby2009 doby2011 doby2013 doby2015 doby2017 doby2019"
  
oldvars <- gsub(" ","", oldvars_str,fixed=TRUE) %>%
  substring(., seq(1, nchar(.), 7), seq(7, nchar(.), 7))
newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),8), seq(8,nchar(.),8))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)


  # years of completed education, individual-level
    # y68-y19 ;
    # /*Name  "COMPLETED EDUC" "COMPLETED EDUC-IND"  "COMPLETED EDUCATION" "YRS COMPLETED EDUCATION" "YEARS COMPLETED EDUCATION"
    # FullN: How many years of school did (he/she) finish?
    #   EDUCATION 2>Completed Education 03>grades completed:y68-y17
    # value: 1 - 17	Highest grade or year of school completed
    # Note: years 1968-1980 are available and comparable on web, so we are adding them up
    # Not asked annually to heads and wives (missing from 1972-1975)

oldvars_str <- "ER30010 ER30052 ER30076 ER30100 ER30126 ER30147 ER30169 ER30197 ER30226 ER30255 ER30296 ER30326 ER30356 ER30384 ER30413 ER30443 ER30478 ER30513 ER30549 ER30584 ER30620 ER30657 ER30703 ER30748 ER30820 ER33115 ER33215 ER33315 ER33415 ER33516 ER33616 ER33716 ER33817 ER33917 ER34020 ER34119 ER34230 ER34349 ER34548 ER34752"
newvars_str <- "yrseduc1968 yrseduc1970 yrseduc1971 yrseduc1972 yrseduc1973 yrseduc1974 yrseduc1975 yrseduc1976 yrseduc1977 yrseduc1978 yrseduc1979 yrseduc1980 yrseduc1981 yrseduc1982 yrseduc1983 yrseduc1984 yrseduc1985 yrseduc1986 yrseduc1987 yrseduc1988 yrseduc1989 yrseduc1990 yrseduc1991 yrseduc1992 yrseduc1993 yrseduc1994 yrseduc1995 yrseduc1996 yrseduc1997 yrseduc1999 yrseduc2001 yrseduc2003 yrseduc2005 yrseduc2007 yrseduc2009 yrseduc2011 yrseduc2013 yrseduc2015 yrseduc2017 yrseduc2019"

oldvars <- gsub(" ","", oldvars_str,fixed=TRUE) %>%
  substring(., seq(1, nchar(.), 7), seq(7, nchar(.), 7))
newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),11), seq(11,nchar(.),11))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

  # grades of school completed, family-level
    # y69-19
    # value: 1 - 17 Highest grade or year of school completed

      # Head
oldvars <- c("V4093", "V4684", "V5608", "V6157", "V6754", "V7387", "V8039",
                "V8663", "V9349", "V10996", "V20198", "V21504", "V23333", "ER4158",
                "ER6998", "ER9249", "ER12222", "ER16516", "ER20457", "ER24148",
                "ER28047", "ER41037", "ER46981", "ER52405", "ER58223", "ER65459",
                "ER71538", "ER77599")
newvars_str <- "hd_yrseduc1975 hd_yrseduc1976 hd_yrseduc1977 hd_yrseduc1978 hd_yrseduc1979 hd_yrseduc1980 hd_yrseduc1981 hd_yrseduc1982 hd_yrseduc1983 hd_yrseduc1984 hd_yrseduc1991 hd_yrseduc1992 hd_yrseduc1993 hd_yrseduc1994 hd_yrseduc1995 hd_yrseduc1996 hd_yrseduc1997 hd_yrseduc1999 hd_yrseduc2001 hd_yrseduc2003 hd_yrseduc2005 hd_yrseduc2007 hd_yrseduc2009 hd_yrseduc2011 hd_yrseduc2013 hd_yrseduc2015 hd_yrseduc2017 hd_yrseduc2019"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),14), seq(14,nchar(.),14))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

    # Spouse
oldvars <- c("V4102", "V4695", "V5567", "V6116", "V6713", "V7346", "V7998", 
             "V8622", "V9308", "V10955", "V20199", "V21505", "V23334", "ER4159",
             "ER6999", "ER9250", "ER12223", "ER16517", "ER20458", "ER24149", 
             "ER28048", "ER41038", "ER46982", "ER52406", "ER58224", "ER65460",
             "ER71539", "ER77600")

newvars_str <- "wf_yrseduc1975 wf_yrseduc1976 wf_yrseduc1977 wf_yrseduc1978 wf_yrseduc1979 wf_yrseduc1980 wf_yrseduc1981 wf_yrseduc1982 wf_yrseduc1983 wf_yrseduc1984 wf_yrseduc1991 wf_yrseduc1992 wf_yrseduc1993 wf_yrseduc1994 wf_yrseduc1995 wf_yrseduc1996 wf_yrseduc1997 wf_yrseduc1999 wf_yrseduc2001 wf_yrseduc2003 wf_yrseduc2005 wf_yrseduc2007 wf_yrseduc2009 wf_yrseduc2011 wf_yrseduc2013 wf_yrseduc2015 wf_yrseduc2017 wf_yrseduc2019"


newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),14), seq(14,nchar(.),14))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)


  # race of head
    # y68-y17 ;  // (from PSID Main Family Data)
    # /*Name: RACE , "L32 RACE OF HD-1ST MENTION"  "RACE OF HEAD" "L40/95 RACE OF HEAD 1"
    # DEMOGRAPHIC 02>Race and Ethnicity 03>race 04>head 05>1st mention:y68-y17
    # values: 1	White, 2 Black, 3 American Indian, Aleut, Eskimo, 4	Asian, Pacific Islander,
    # 5 Mentions Latino origin or descent, 6 Mentions color other than black or white, 7	Other
    # */

oldvars <- c("V181", "V801", "V1490", "V2202", "V2828", "V3300", "V3720", "V4204", 
             "V5096", "V5662", "V6209", "V6802", "V7447", "V8099", "V8723", "V9408",
             "V11055", "V11938", "V13565", "V14612", "V16086", "V17483", "V18814",
             "V20114", "V21420", "V23276", "ER3944", "ER6814", "ER9060", "ER11848",
             "ER15928", "ER19989", "ER23426", "ER27393", "ER40565", "ER46543",
             "ER51904", "ER57659", "ER64810", "ER70882", "ER76897")

newvars_str <- "hd_race1968 hd_race1969 hd_race1970 hd_race1971 hd_race1972 hd_race1973 hd_race1974 hd_race1975 hd_race1976 hd_race1977 hd_race1978 hd_race1979 hd_race1980 hd_race1981 hd_race1982 hd_race1983 hd_race1984 hd_race1985 hd_race1986 hd_race1987 hd_race1988 hd_race1989 hd_race1990 hd_race1991 hd_race1992 hd_race1993 hd_race1994 hd_race1995 hd_race1996 hd_race1997 hd_race1999 hd_race2001 hd_race2003 hd_race2005 hd_race2007 hd_race2009 hd_race2011 hd_race2013 hd_race2015 hd_race2017 hd_race2019"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),11), seq(11,nchar(.),11))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

  # race of wife
    # y1985-y17 ;
    # /*DEMOGRAPHIC 02>Race and Ethnicity 03>race 04>spouse 05>1st mention:
    #   values: 1 White, 2 Black, 3 American Indian, Aleut, Eskimo, 4 Asian, Pacific Islander,
    # 5 Mentions Latino origin or descent, 6 Mentions color other than black or white, 7 Other */    

oldvars <- c("V12293", "V13500", "V14547", "V16021", "V17418", "V18749", "V20049",
             "V21355", "V23212", "ER3883", "ER6753", "ER8999", "ER11760", "ER15836",
             "ER19897", "ER23334", "ER27297", "ER40472", "ER46449", "ER51810", "ER57549",
             "ER64671", "ER70744", "ER76752")

newvars_str <- "wf_race1985 wf_race1986 wf_race1987 wf_race1988 wf_race1989 wf_race1990 wf_race1991 wf_race1992 wf_race1993 wf_race1994 wf_race1995 wf_race1996 wf_race1997 wf_race1999 wf_race2001 wf_race2003 wf_race2005 wf_race2007 wf_race2009 wf_race2011 wf_race2013 wf_race2015 wf_race2017 wf_race2019"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),11), seq(11,nchar(.),11))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)


  # hispanic status of head
    # y1985-1996, 2005-2017
    # 9: NA/ DK, 0: Inap/not hispanic

oldvars <- c("V11937", "V13564", "V14611", "V16085", "V17482", "V18813", "V20113",
             "V21419", "V23275", "ER3941", "ER6811", "ER9057", "ER27392", "ER40564",
             "ER46542", "ER51903", "ER57658", "ER64809", "ER70881", "ER76896")
newvars_str <- "hd_hisp1985 hd_hisp1986 hd_hisp1987 hd_hisp1988 hd_hisp1989 hd_hisp1990 hd_hisp1991 hd_hisp1992 hd_hisp1993 hd_hisp1994 hd_hisp1995 hd_hisp1996 hd_hisp2005 hd_hisp2007 hd_hisp2009 hd_hisp2011 hd_hisp2013 hd_hisp2015 hd_hisp2017 hd_hisp2019"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),11), seq(11,nchar(.),11))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)


  # hispanic status of wife
oldvars <- c("V12292", "V13499", "V14546", "V16020", "V17417", "V18748", "V20048",
             "V21354", "V23211", "ER3880", "ER6750", "ER8996", "ER27296", 
             "ER40471", "ER46448", "ER51809", "ER57548", "ER64670", "ER70743", "ER76751")

newvars_str <- "wf_hisp1985 wf_hisp1986 wf_hisp1987 wf_hisp1988 wf_hisp1989 wf_hisp1990 wf_hisp1991 wf_hisp1992 wf_hisp1993 wf_hisp1994 wf_hisp1995 wf_hisp1996 wf_hisp2005 wf_hisp2007 wf_hisp2009 wf_hisp2011 wf_hisp2013 wf_hisp2015 wf_hisp2017 wf_hisp2019"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),11), seq(11,nchar(.),11))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

  # marital status
    # /* 1968: 8 == married, spouse absent ;
    # * all other years: 
    #   1	Married or permanently cohabiting; Wife, "Wife", or Husband is present in the FU
    # 2	Single, never legally married and no Wife, "Wife", or Husband is present in the FU
    # 3	Widowed and no Wife, "Wife", or Husband is present in the FU
    # 4	Divorced and no Wife, "Wife", or Husband is present in the FU
    # 5	Separated; legally married but no Wife, "Wife", or Husband is present in the FU (the spouse may be in an institution)
    # 9	NA; DK */

oldvars <- c("V239", "V607", "V1365", "V2072", "V2670", "V3181", "V3598", "V4053",
             "V4603", "V5650", "V6197", "V6790", "V7435", "V8087", "V8711", 
             "V9419", "V11065", "V12426", "V13665", "V14712", "V16187", "V17565",
             "V18916", "V20216", "V21522", "V23336", "ER4159A", "ER6999A", "ER9250A",
             "ER12223A", "ER16423", "ER20369", "ER24150", "ER28049", "ER41039",
             "ER46983", "ER52407", "ER58225", "ER65461", "ER71540", "ER77601")

newvars_str <- "marst1968 marst1969 marst1970 marst1971 marst1972 marst1973 marst1974 marst1975 marst1976 marst1977 marst1978 marst1979 marst1980 marst1981 marst1982 marst1983 marst1984 marst1985 marst1986 marst1987 marst1988 marst1989 marst1990 marst1991 marst1992 marst1993 marst1994 marst1995 marst1996 marst1997 marst1999 marst2001 marst2003 marst2005 marst2007 marst2009 marst2011 marst2013 marst2015 marst2017 marst2019"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),9), seq(9,nchar(.),9))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

# Create a copy for married
tmp=grep("marst",colnames(psid))
psid <- cbind(psid, setNames(psid[,tmp], gsub("marst","married",colnames(psid)[tmp])))

psid <- psid %>%
  mutate(across(c(contains("married")), ~ round(.))) %>%
  mutate(across(c(contains("married")), 
                ~as.factor(case_when(. %in% c(1,8) ~ "Married",
                                     . %in% c(2,3,4,5) ~ "Single",
                                     . %in% c(9, NA_real_) ~ NA_character_))))
# Marst
psid <- psid %>%
  mutate(across(c(contains("marst")), ~ round(.))) %>%
  mutate(across(c(contains("marst")), 
                ~as.factor(case_when(. %in% c(8,5) ~ "Married, spouse absent",
                                     . == 2 ~ "Never married/single",
                                     . %in% c(4) ~ "Divorced",
                                     . == 3 ~ "Widowed",
                                     . == 1 ~ "Married, spouse present",
                                     . %in% c(9, NA_real_) ~ NA_character_))))


  # alternate marital status variable: reported by respondent
    # *1977- 1: legally married only, spouse present or absent ;
    # *all other years- 1: married, 2: single, 3: widowed, 4: divorced, 5: separated, 8: DK, 9: NA, refused, 0: wild code ;


oldvars <- c("V5502", "V6034", "V6659", "V7261", "V7952", "V8603", "V9276",
             "V10426", "V11612", "V13017", "V14120", "V15136", "V16637", "V18055",
             "V19355", "V20657", "V22412", "ER2014", "ER5013", "ER7013", "ER10016",
             "ER13021", "ER17024", "ER21023", "ER25023", "ER36023", "ER42023",
             "ER47323", "ER53023", "ER60024", "ER66024", "ER72024")

newvars_str <- "hd_marst1977 hd_marst1978 hd_marst1979 hd_marst1980 hd_marst1981 hd_marst1982 hd_marst1983 hd_marst1984 hd_marst1985 hd_marst1986 hd_marst1987 hd_marst1988 hd_marst1989 hd_marst1990 hd_marst1991 hd_marst1992 hd_marst1993 hd_marst1994 hd_marst1995 hd_marst1996 hd_marst1997 hd_marst1999 hd_marst2001 hd_marst2003 hd_marst2005 hd_marst2007 hd_marst2009 hd_marst2011 hd_marst2013 hd_marst2015 hd_marst2017 hd_marst2019"


newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),12), seq(12,nchar(.),12))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)


# births summary variable
# /*CHILDREN 02>Birth Dates 03>first/only 04>month:
#   Names: "month 1st/only child born" "year 1st/only child born "
# "month 2nd youngest child born " "year 2nd youngest child born"
# "month 3rd youngest child born" "year 3rd youngest child born"
# "month 4th youngest child born "year 4th youngest child born"
# 	--> not included	"MONTH YOUNGEST CHILD BORN" "YEAR YOUNGEST CHILD BORN"
# 				Note: order should be : 1sr, 4th yougenst, 3td youngest, 2 youngest, and the youngest
# 				 (see id = 5052049-> current oorder:
# 				 child1_yr	child2_yr child3_yr	child4_yr	childlast_yr
# 					2007	  	2013	2009		2007	2015 				*/


oldvars_str <- "ER32023 ER32024 ER32031 ER32032 ER32029 ER32030  ER32027 ER32028 ER32025 ER32026"
newvars_str <- "child1_mn child1_yr child2_mn child2_yr child3_mn child3_yr child4_mn child4_yr child5_mn child5_yr"

oldvars <- gsub(" ","",oldvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),7), seq(7,nchar(.),7))

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),9), seq(9,nchar(.),9))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

# household size
# y68-y2019;  //(from PSID Main Family Data)
# /*Name: "NUMBER IN FAMILY"  "TOTAL # IN FU" "# IN FU" "NUMBER IN FU"
# FAMILY COMPOSITION 02>Current: 03>number in family unit 04>total number in family unit:
#   values:1 - 19	Actual number of people */

oldvars <- c("V115", "V549", "V1238", "V1941", "V2541", "V3094", "V3507", "V3920",
             "V4435", "V5349", "V5849", "V6461", "V7066", "V7657", "V8351", "V8960",
             "V10418", "V11605", "V13010", "V14113", "V15129", "V16630", "V18048",
             "V19348", "V20650", "V22405", "ER2006", "ER5005", "ER7005", "ER10008",
             "ER13009", "ER17012", "ER21016", "ER25016", "ER36016", "ER42016",
             "ER47316", "ER53016", "ER60016", "ER66016", "ER72016")

newvars_str <- "hhsize1968 hhsize1969 hhsize1970 hhsize1971 hhsize1972 hhsize1973 hhsize1974 hhsize1975 hhsize1976 hhsize1977 hhsize1978 hhsize1979 hhsize1980 hhsize1981 hhsize1982 hhsize1983 hhsize1984 hhsize1985 hhsize1986 hhsize1987 hhsize1988 hhsize1989 hhsize1990 hhsize1991 hhsize1992 hhsize1993 hhsize1994 hhsize1995 hhsize1996 hhsize1997 hhsize1999 hhsize2001 hhsize2003 hhsize2005 hhsize2007 hhsize2009 hhsize2011 hhsize2013 hhsize2015 hhsize2017 hhsize2019"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),10), seq(10,nchar(.),10))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)


################### Employment ######################

# hours worked
# * hours indivudal worked in year t-1 , y67-y92;
# /* name: "HOURS WORKED IND" "TOT ANN HRS" "ANN WORK HRS"
# WORK 02>Hours 03>work, annual:
#   values: 1 - 5,840	Actual hours worked
# Note :there were 3: y73,  y75, y78 remaining years available on web , we are adding them up */

oldvars_str <- "ER30013 ER30034 ER30058 ER30082 ER30107 ER30131 ER30153 ER30177 ER30204 ER30233 ER30270 ER30300 ER30330 ER30360 ER30388 ER30417 ER30447 ER30482 ER30517 ER30553 ER30588 ER30624 ER30661 ER30709 ER30754 ER30823"
newvars_str <- "hrs_ly1968 hrs_ly1969 hrs_ly1970 hrs_ly1971 hrs_ly1972 hrs_ly1973 hrs_ly1974 hrs_ly1975 hrs_ly1976 hrs_ly1977 hrs_ly1978 hrs_ly1979 hrs_ly1980 hrs_ly1981 hrs_ly1982 hrs_ly1983 hrs_ly1984 hrs_ly1985 hrs_ly1986 hrs_ly1987 hrs_ly1988 hrs_ly1989 hrs_ly1990 hrs_ly1991 hrs_ly1992 hrs_ly1993"

oldvars <- gsub(" ","",oldvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),7), seq(7,nchar(.),7))

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),10), seq(10,nchar(.),10))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)


# hours head worked in year t-1
# y67-y16 ;
# /*name: "YRLY HEADS HRS" "HRS HEAD WORKED"
# fname: Head's annual hours working for money in t-1
# 			 values: 0	None, 1 - 9,998	Actual number of hours
# 			 note: this var refers to a previus year, but since y97 is not being correctly refering to the previous year */

oldvars <- c("V47", "V465", "V1138", "V1839", "V2439", "V3027", "V3423", "V3823",
             "V4332", "V5232", "V5731", "V6336", "V6934", "V7530", "V8228", 
             "V8830", "V10037", "V11146", "V12545", "V13745", "V14835", "V16335",
             "V17744", "V19044", "V20344", "V21634", "ER4096", "ER6936", "ER9187",
             "ER12174", "ER16471", "ER20399", "ER24080", "ER27886", "ER40876",
             "ER46767", "ER52175", "ER57976", "ER65156", "ER71233", "ER77255")
newvars_str <- "hd_hrs_ly1968 hd_hrs_ly1969 hd_hrs_ly1970 hd_hrs_ly1971 hd_hrs_ly1972 hd_hrs_ly1973 hd_hrs_ly1974 hd_hrs_ly1975 hd_hrs_ly1976 hd_hrs_ly1977 hd_hrs_ly1978 hd_hrs_ly1979 hd_hrs_ly1980 hd_hrs_ly1981 hd_hrs_ly1982 hd_hrs_ly1983 hd_hrs_ly1984 hd_hrs_ly1985 hd_hrs_ly1986 hd_hrs_ly1987 hd_hrs_ly1988 hd_hrs_ly1989 hd_hrs_ly1990 hd_hrs_ly1991 hd_hrs_ly1992 hd_hrs_ly1993 hd_hrs_ly1994 hd_hrs_ly1995 hd_hrs_ly1996 hd_hrs_ly1997 hd_hrs_ly1999 hd_hrs_ly2001 hd_hrs_ly2003 hd_hrs_ly2005 hd_hrs_ly2007 hd_hrs_ly2009 hd_hrs_ly2011 hd_hrs_ly2013 hd_hrs_ly2015 hd_hrs_ly2017 hd_hrs_ly2019"
newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),13), seq(13,nchar(.),13))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)


# hours spouse worked in yeart t-1
# y67-y16 ;
# /*names: "YRLY WIFE HRS" , "HRS WIFE WORKED" "WF ANN WRK HRS IN "
# fullname: Wife's annual hours working for money in t-1
# values: 0	None, 1 - 9,998	Actual number of hours
# note: this var refers to a previus year, but since y97 is not being correctly refering to the previous year */

oldvars <- c("V53", "V475", "V1148", "V1849", "V2449", "V3035", "V3431", "V3831",
             "V4344", "V5244", "V5743", "V6348", "V6946", "V7540", "V8238", 
             "V8840", "V10131", "V11258", "V12657", "V13809", "V14865", "V16365",
             "V17774", "V19074", "V20374", "V21670", "ER4107", "ER6947", "ER9198",
             "ER12185", "ER16482", "ER20410", "ER24091", "ER27897", "ER40887",
             "ER46788", "ER52196", "ER57997", "ER65177", "ER71254", "ER77276")

newvars_str <- "wf_hrs_ly1968 wf_hrs_ly1969 wf_hrs_ly1970 wf_hrs_ly1971 wf_hrs_ly1972 wf_hrs_ly1973 wf_hrs_ly1974 wf_hrs_ly1975 wf_hrs_ly1976 wf_hrs_ly1977 wf_hrs_ly1978 wf_hrs_ly1979 wf_hrs_ly1980 wf_hrs_ly1981 wf_hrs_ly1982 wf_hrs_ly1983 wf_hrs_ly1984 wf_hrs_ly1985 wf_hrs_ly1986 wf_hrs_ly1987 wf_hrs_ly1988 wf_hrs_ly1989 wf_hrs_ly1990 wf_hrs_ly1991 wf_hrs_ly1992 wf_hrs_ly1993 wf_hrs_ly1994 wf_hrs_ly1995 wf_hrs_ly1996 wf_hrs_ly1997 wf_hrs_ly1999 wf_hrs_ly2001 wf_hrs_ly2003 wf_hrs_ly2005 wf_hrs_ly2007 wf_hrs_ly2009 wf_hrs_ly2011 wf_hrs_ly2013 wf_hrs_ly2015 wf_hrs_ly2017 wf_hrs_ly2019"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),13), seq(13,nchar(.),13))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

# 9999 should be missing for 1993 and 1994 (used for Latino sample family) but not other years ;

psid <- psid %>%
  mutate(across(c(hd_hrs_ly1993,hd_hrs_ly1994, wf_hrs_ly1993, wf_hrs_ly1994),
                ~ifelse(round(.) == 9999, NA_real_, as.numeric(.))))


######## employment status

# * individual employment status, y79-y19 ;
# /*WORK 02>Employment Status:
#   values: 1 Working now, 2 Only temporarily laid off, 3 Looking for work, unemployed,
# 4 Retired, 5 Permanently disabled, 6	HouseWife; keeping house, 7	Student, 8	Other*/

oldvars_str <- "ER30293 ER30323 ER30353 ER30382 ER30411 ER30441 ER30474 ER30509 ER30545 ER30580 ER30616 ER30653 ER30699 ER30744 ER30816 ER33111 ER33211 ER33311 ER33411 ER33512 ER33612 ER33712 ER33813 ER33913 ER34016 ER34116 ER34216 ER34317 ER34516 ER34716"
newvars_str <- "employment1979 employment1980 employment1981 employment1982 employment1983 employment1984 employment1985 employment1986 employment1987 employment1988 employment1989 employment1990 employment1991 employment1992 employment1993 employment1994 employment1995 employment1996 employment1997 employment1999 employment2001 employment2003 employment2005 employment2007 employment2009 employment2011 employment2013 employment2015 employment2017 employment2019"

oldvars <- gsub(" ","",oldvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),7), seq(7,nchar(.),7))

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),14), seq(14,nchar(.),14))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

# * wife employment status y76-y96 ;
# /*WORK 02>Employment Status 03>spouse:
#   Values:1	Working now, 2 Only temporarily laid off, sick leave or maternity leave,
# 3	Looking for work, unemployed, 4	Retired, 5	Permanently disabled; temporarily disabled, 6 Keeping house, Student, 8 Other; "workfare"; in prison or jail, 9	NA; refused  */

  # 94-99: add 1st mention of employment status var

oldvars <- c("V4841", "V6591", "V7193", "V7879", "V8538", "V9188", "V10671", 
             "V12000", "V13225", "V14321", "V15456","V16974", "V18395", "V19695",
             "V20995", "V22801", "ER2562", "ER5561", "ER7657",
             "ER10563", "ER13717","ER17786","ER21373",
             "ER25362", "ER36367", "ER42392", "ER47705", "ER53411", "ER60426",
             "ER66439", "ER72441")
newvars_str <- "wf_employment1976 wf_employment1979 wf_employment1980 wf_employment1981 wf_employment1982 wf_employment1983 wf_employment1984 wf_employment1985 wf_employment1986 wf_employment1987 wf_employment1988 wf_employment1989 wf_employment1990 wf_employment1991 wf_employment1992 wf_employment1993 wf_employment1994 wf_employment1995 wf_employment1996 wf_employment1997 wf_employment1999 wf_employment2001 wf_employment2003 wf_employment2005 wf_employment2007 wf_employment2009 wf_employment2011 wf_employment2013 wf_employment2015 wf_employment2017 wf_employment2019"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),17), seq(17,nchar(.),17))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

# recode main and wife's employment var for all years

psid <- psid %>%
  mutate(across(c(contains("employment")), ~round(.))) %>%
  mutate(across(c(contains("employment")), 
                ~case_when(round(.) %in% c(1,2) ~ 1,
                                     inrange(round(.), 3,8) ~ 0,
                                     round(.) %in% c(98, 99, 9, 0, 32, 35) ~ NA_real_)))


# * head employment status, y68-y96 ;
# /*WORK 02>Employment Status 03>head:
#   values: y68-y75: 1 Working now, or only temporarily laid off, 2 Looking for work, unemployed, 3	Retired, permanently disabled, 4 Housewife, 5 Student, 6 Other
# Y76-96	:1 Working now, 2 Only temporarily laid off, 3 Looking for work, unemployed, 4 Retired, permanently disabled, 5 Permanently disabled, 6 Housewife, 7 Student, 8 Other


oldvars <- c("V196", "V639", "V1278", "V1983", "V2581", "V3114", "V3528", "V3967",
             "V4458", "V5373", "V5872", "V6492", "V7095", "V7706", "V8374", 
             "V9005", "V10453", "V11637", "V13046", "V14146", "V15154", "V16655",
             "V18093", "V19393", "V20693", "V22448", "ER2068", "ER5067", "ER7163",
             "ER10081", "ER13205", "ER17216", "ER21123","ER25104", "ER36109", 
             "ER42140", "ER47448","ER53148", "ER60163", "ER66164", "ER72164")
newvars_str <- "hd_employment1968 hd_employment1969 hd_employment1970 hd_employment1971 hd_employment1972 hd_employment1973 hd_employment1974 hd_employment1975 hd_employment1976 hd_employment1977 hd_employment1978 hd_employment1979 hd_employment1980 hd_employment1981 hd_employment1982 hd_employment1983 hd_employment1984 hd_employment1985 hd_employment1986 hd_employment1987 hd_employment1988 hd_employment1989 hd_employment1990 hd_employment1991 hd_employment1992 hd_employment1993 hd_employment1994 hd_employment1995 hd_employment1996 hd_employment1997 hd_employment1999 hd_employment2001 hd_employment2003 hd_employment2005 hd_employment2007 hd_employment2009 hd_employment2011 hd_employment2013 hd_employment2015 hd_employment2017 hd_employment2019"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),17), seq(17,nchar(.),17))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

psid <- psid %>%
  mutate(across(c(contains("hd_employment")), ~round(.)))
# recode 1976 - 1996
for(years in c(as.character(1976:2019))) {
  psid <- psid %>%
    mutate(across(c(contains("hd_employment") & contains(years)), 
                  ~case_when(round(.) %in% c(1,2) ~ 1,
                                       inrange(round(.), 3,8) ~ 0,
                                       round(.) %in% c(22, 98, 99, 9, 0) ~ NA_real_)))
}
# keep same coding, but change to character factor for early years
for(years in c(as.character(1968:1975))) {
  psid <- psid %>%
    mutate(across(c(contains("hd_employment") & contains(years)),
                  ~case_when(round(.) == 1 ~ 1,
                                       inrange(round(.),2, 8) ~ 0,
                                       round(.) %in% c(9,0, 98, 99) ~ NA_real_)))  
  
}


# employment last year
  # y70-84
  # During the last year (1969), did you do any work for money? (Retired.) (1970 question)
  # family data
  #1	Yes,	5	No, 9	NA, 0	Inap.: employed, unemployed

  # Head
oldvars <- c("V1350", "V2056", "V2654", "V3167", "V3583", "V4039", "V4575",
             "V5479", "V6017", "V6577", "V7179", "V7865", "V8525", "V9175", "V10658")

newvars_str <- "hd_work_ly1970 hd_work_ly1971 hd_work_ly1972 hd_work_ly1973 hd_work_ly1974 hd_work_ly1975 hd_work_ly1976 hd_work_ly1977 hd_work_ly1978 hd_work_ly1979 hd_work_ly1980 hd_work_ly1981 hd_work_ly1982 hd_work_ly1983 hd_work_ly1984"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),14), seq(14,nchar(.),14))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

  # Spouse
oldvars <- c("V608", "V1366", "V2073", "V2671", "V3182", "V3599", "V4054", "V4604", 
            "V5506", "V6038", "V6649", "V7251", "V7942", "V8593", "V9266", "V10855")

newvars_str <- "wf_work_ly1969 wf_work_ly1970 wf_work_ly1971 wf_work_ly1972 wf_work_ly1973 wf_work_ly1974 wf_work_ly1975 wf_work_ly1976 wf_work_ly1977 wf_work_ly1978 wf_work_ly1979 wf_work_ly1980 wf_work_ly1981 wf_work_ly1982 wf_work_ly1983 wf_work_ly1984"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),14), seq(14,nchar(.),14))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)


################# Income ###################


# * earnings (labor income) ;
# * total earnings t-1 , y90-y92, y04-y16;
# /*INCOME 02>Labor 03>total, last year:
#   values: [-999,997 - -1]	Actual amount of negative income, [1 - 9,999,997] Actual amount, [999,999] Income of $999,999 or more
# note: there are 7 years available on web that is being added now (y06-y16)*/

oldvars <- c("ER30705", "ER30750", "ER30821", "ER33838C", "ER33938C", "ER34032A",
             "ER34144A", "ER34251A", "ER34401A", "ER34636", "ER34845")

newvars_str <- "earn1991 earn1992 earn1993 earn2005 earn2007 earn2009 earn2011 earn2013 earn2015 earn2017 earn2019"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),8), seq(8,nchar(.),8))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

# * wife's earnings t-1 , y67-y92 ;
# 		/*INCOME 02>Labor 03>spouse 04>total (includes wages and other labor):
# 		values:0 None, [1 - 9,999,998] Actual amount, 9,999,999	$9,999,999 or more    */

oldvars <- c("V75", "V516", "V1198", "V1899", "V2500", "V3053", "V3465", "V3865",
             "V4379", "V5289", "V5788", "V6398", "V6988", "V7580", "V8273", 
             "V8881", "V10263", "V11404", "V12803", "V13905", "V14920", "V16420",
             "V17836", "V19136", "V20436", "V23324")

newvars_str <- "wf_earn1968 wf_earn1969 wf_earn1970 wf_earn1971 wf_earn1972 wf_earn1973 wf_earn1974 wf_earn1975 wf_earn1976 wf_earn1977 wf_earn1978 wf_earn1979 wf_earn1980 wf_earn1981 wf_earn1982 wf_earn1983 wf_earn1984 wf_earn1985 wf_earn1986 wf_earn1987 wf_earn1988 wf_earn1989 wf_earn1990 wf_earn1991 wf_earn1992 wf_earn1993"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),11), seq(11,nchar(.),11))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)


# * wife's earnings t-1 , excluding business and farming, y92-y16 ;
# 		/*INCOME 02>Labor 03>spouse 04>total excluding farm and business:
# 		values:0	Inap., [1 - 9,999,998] Actual amount, 9,999,999	$9,999,999 or more */

oldvars <- c("V21807", "ER4144", "ER6984", "ER9235", "ER12082", "ER16465",
             "ER20447", "ER24135", "ER27943", "ER40933", "ER46841", "ER52249",
             "ER58050", "ER65244", "ER71321", "ER77343")

newvars_str <- "wf_earn_ex1993 wf_earn_ex1994 wf_earn_ex1995 wf_earn_ex1996 wf_earn_ex1997 wf_earn_ex1999 wf_earn_ex2001 wf_earn_ex2003 wf_earn_ex2005 wf_earn_ex2007 wf_earn_ex2009 wf_earn_ex2011 wf_earn_ex2013 wf_earn_ex2015 wf_earn_ex2017 wf_earn_ex2019"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),14), seq(14,nchar(.),14))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)


# * wife's business income t-1, y92-y16 ;
# 		/*INCOME 02>Labor 03>spouse 04>business:
# 		values: [1 - 9,999,998]	Actual amount, [9,999,999]	$9,999,999 or more */

oldvars <- c("V21806", "ER4141", "ER6981", "ER9232", "ER12214", "ER16511",
             "ER20444", "ER24111", "ER27940", "ER40930", "ER46838", "ER52246",
             "ER58047", "ER65225", "ER71302", "ER77324")

newvars_str <- "wf_earn_bs1993 wf_earn_bs1994 wf_earn_bs1995 wf_earn_bs1996 wf_earn_bs1997 wf_earn_bs1999 wf_earn_bs2001 wf_earn_bs2003 wf_earn_bs2005 wf_earn_bs2007 wf_earn_bs2009 wf_earn_bs2011 wf_earn_bs2013 wf_earn_bs2015 wf_earn_bs2017 wf_earn_bs2019"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),14), seq(14,nchar(.),14))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

# * head's earnings t-1 , y67-y16;
# 		/*INCOME 02>Labor 03>head 04>total (includes wages and other labor):
# 		values:0 = No labor income , [1 - 9,999,998] =  Actual amount, [9,999,999] = $9,999,999 or more */

oldvars <- c("V74", "V514", "V1196", "V1897", "V2498", "V3051", "V3463", "V3863",
             "V5031", "V5627", "V6174", "V6767", "V7413", "V8066", "V8690", 
             "V9376", "V11023", "V12372", "V13624", "V14671", "V16145", "V17534",
             "V18878", "V20178", "V21484", "V23323", "ER4140", "ER6980", "ER9231",
             "ER12080", "ER16463", "ER20443", "ER24116", "ER27931", "ER40921",
             "ER46829", "ER52237", "ER58038", "ER65216", "ER71293", "ER77315")

newvars_str <- "hd_earn1968 hd_earn1969 hd_earn1970 hd_earn1971 hd_earn1972 hd_earn1973 hd_earn1974 hd_earn1975 hd_earn1976 hd_earn1977 hd_earn1978 hd_earn1979 hd_earn1980 hd_earn1981 hd_earn1982 hd_earn1983 hd_earn1984 hd_earn1985 hd_earn1986 hd_earn1987 hd_earn1988 hd_earn1989 hd_earn1990 hd_earn1991 hd_earn1992 hd_earn1993 hd_earn1994 hd_earn1995 hd_earn1996 hd_earn1997 hd_earn1999 hd_earn2001 hd_earn2003 hd_earn2005 hd_earn2007 hd_earn2009 hd_earn2011 hd_earn2013 hd_earn2015 hd_earn2017 hd_earn2019"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),11), seq(11,nchar(.),11))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

# * head's business income t-1 , y93-y17;
# 		/* INCOME 02>Labor 03>head 04>business Head's Labor Part of Unincorporated Business Income
# values:0 = Inap.: did not own a business; none; unincorporated business lost money; business is incorporated , 
# [1 - 9,999,998] = Actual amount, [9,999,999] = $9,999,999 or more */

oldvars <- c("V21738", "ER4119", "ER6959", "ER9210", "ER12193","ER16490", 
             "ER20422", "ER24109", "ER27910", "ER40900", "ER46808", "ER52216",
             "ER58017", "ER65197", "ER71274", "ER77296")
newvars_str <- "hd_earn_bs1993 hd_earn_bs1994 hd_earn_bs1995 hd_earn_bs1996 hd_earn_bs1997 hd_earn_bs1999 hd_earn_bs2001 hd_earn_bs2003 hd_earn_bs2005 hd_earn_bs2007 hd_earn_bs2009 hd_earn_bs2011 hd_earn_bs2013 hd_earn_bs2015 hd_earn_bs2017 hd_earn_bs2019"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),14), seq(14,nchar(.),14))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

# recode missings for 1994-1997 (latino sample family code)
psid <- psid %>%
  mutate(across(c(hd_earn_bs1994, hd_earn_bs1995, hd_earn_bs1997),
                ~ifelse(round(.) == 999999, NA_real_, as.numeric(.))))

# * income from farming t-1  , y92-y16;
# /*INCOME 02>Farming 03>head and spouse:
#   values: -999,999 Loss of $999,999 or more, [-999,998 - -1] 
# Actual loss, [1- 9,999,998] Actual amount, 9,999,999	$9,999,999 or more */

oldvars <- c("V21731", "ER4117", "ER6957", "ER9208", "ER12065", "ER16448",
             "ER20420", "ER24105", "ER27908", "ER40898", "ER46806", "ER52214",
             "ER58015", "ER65195", "ER71272", "ER77294")
newvars_str <- "inc_fm1993 inc_fm1994 inc_fm1995 inc_fm1996 inc_fm1997 inc_fm1999 inc_fm2001 inc_fm2003 inc_fm2005 inc_fm2007 inc_fm2009 inc_fm2011 inc_fm2013 inc_fm2015 inc_fm2017 inc_fm2019"

newvars <- gsub(" ","",newvars_str, fixed=TRUE) %>%
  substring(., seq(1, nchar(.),10), seq(10,nchar(.),10))

psid <- psid %>%
  rename_with(~ newvars[which(oldvars == .x)],.cols=oldvars)

  # in 1993 this code indicates a loss of an unknown amount
psid <- psid %>%
  mutate(inc_fm1993 = ifelse(round(inc_fm1993)==-999999,0,as.numeric(inc_fm1993)))

# earnings were not calculated for latino sample families in 1994 and 1995, codes for latino sample families should be missing 
# * wife's earnings: no recoding
# 			* wife's earnings excluding business and farming: 9,999,999
# * wife's business income: 999,999
# 			* joint farm income: 999,999
# 			* head's earnings: 9,999,999
# * head's business income: 999,999 in '94 and '95 as well as '97 ;

for(years in c(as.character(1994:1995))) {
  psid <- psid %>%
    mutate(across(c((contains("inc_fm") | contains("wf_earn_bs")) & contains(years)),
                  ~case_when(round(.) == 999999 ~ NA_real_,
                             TRUE ~ as.numeric(.)))) %>%
    mutate(across(c((contains("wf_earn_ex") | contains("hd_earn")) & contains(years)),
                  ~case_when(round(.) == 9999999 ~ NA_real_,
                             TRUE ~ as.numeric(.))))
  psid <- psid %>%
    mutate(across(c(contains("hd_earn_bs") & contains(years)),
                  ~ifelse(round(.) == 999999, NA_real_, .)))
  psid <- psid %>%
    mutate(across(c(contains("wf_earn_bs") & contains(years)),
                  ~ifelse(round(.) == 999999, NA_real_, .)))
}
for(years in c(as.character(1997))) {
  psid <- psid %>%
    mutate(across(c(contains("hd_earn_bs") & contains(years)),
                  ~ifelse(round(.) == 999999, NA_real_, .)))
  psid <- psid %>%
    mutate(across(c(contains("wf_earn_bs") & contains(years)),
                  ~ifelse(round(.) == 999999, NA_real_, .)))
}

############### Reshape ################

# drop unnecessary vars
psid <- psid[,!grepl("^V",names(psid)) & !grepl("^ER",names(psid))]
psid <- psid %>%
  subset(select=-c(child5_mn,child5_yr,child4_mn,child4_yr, child3_mn, child3_yr))

# reshape long
psid <- psid %>%
  relocate(id68, pid, hhid68, gender, numbirths, child1_mn, child1_yr, child2_mn,
           child2_yr)

#MAKE SURE ID VARS ARE FIRST 9 COLS ONLY
psid.reshape <- pivot_longer(psid, cols = 10:ncol(psid),
                             names_to = c(".value","doiy"),
                             names_pattern = '(.*)(\\d\\d\\d\\d)')
psid.reshape <- psid.reshape %>%
  mutate(doiy = as.numeric(doiy))
###### note: need childbirth and adoption file
psid.reshape <- merge(psid.reshape, cah, by=c("pid","hhid68","id68"),
                      all.x=T)

############# Recode missings ##############

psid.reshape <- psid.reshape %>%
  # replace missing interview month with most common month (april)
  mutate(doim = ifelse(is.na(doim) | doim == 0, 4, doim)) %>%
  # sequence number
  mutate(seq = ifelse(seq == 0, NA_real_, seq)) %>%
  # year of birth
  mutate(doby = ifelse(round(doby) %in% c(0, 9999), NA_real_, doby)) %>%
  # month of birth
  mutate(dobm = ifelse(round(dobm) %in% c(99, 0), NA_real_, dobm)) %>%
  # age == 0: from core sample, moved after interview
  mutate(age = ifelse(round(age) %in% c(0, 999), NA_real_, age)) %>%
  mutate(rawage = age) %>%
  # years of education
  mutate(yrseduc = ifelse(round(yrseduc) %in% c(0, 98, 99), NA_real_, yrseduc)) %>%
  mutate(hd_yrseduc = ifelse(round(hd_yrseduc) %in% c(99), NA_real_, hd_yrseduc)) %>%
  mutate(wf_yrseduc = ifelse(round(wf_yrseduc) %in% c(99), NA_real_, wf_yrseduc)) %>%
  # yearly hhid
  mutate(hhid = ifelse(hhid == 0, NA_real_, hhid)) #nonresponse

psid.reshape <- psid.reshape %>%
  # hours worked: wild codes
  mutate(across(c(hrs_ly, hd_hrs_ly, wf_hrs_ly), ~ifelse(round(.) %in% c(6730,7800),
                                                         NA_real_,.))) 

psid.reshape <- psid.reshape %>%
  # state
  mutate(statefip = ifelse(statefip %in% c(99, 0), NA_real_, statefip))

# marital status

# main:  1- Married, 2- Single, 3- Widowed, 4- Divorced, 5- Separated,
#  8 - Married, spouse absent, 9- NA
psid.reshape <- psid.reshape %>%
  mutate(hd_marst = as.factor(case_when(hd_marst == 1 ~ "Married, spouse present",
                                        # this is really separated, but we want names to match with CPS/ACS
                                        # in CPS/ACS we combine separated and married,spouse absent
                                        hd_marst == 5 ~ "Married, spouse absent",
                                        hd_marst == 4 ~ "Divorced",
                                        hd_marst == 3 ~ "Widowed",
                                        hd_marst == 2 ~ "Never married/single")))

# hispanic
psid.reshape <- psid.reshape %>%
  mutate(across(c(hd_hisp,wf_hisp), ~ ifelse(. %in% c(0,9), NA_real_, .)))

# keep only years in data
psid.reshape <- psid.reshape %>%
  filter(inrange(doiy, 1968, 1997) | doiy %in% c(1999,2001,2003,2005,2007,2009,2011,
                                                 2013,2015,2017,2019))

#sum(with(psid.reshape, round(hrs_ly)==6730))

############ Build individual vars #############

# head/spouse indicator
psid.reshape <- psid.reshape %>%
  mutate(head = case_when(relationhd == "Head" & round(seq) == 1 & doiy > 1968 ~ 1,
                          relationhd != "Head" & round(seq) != 1 & doiy > 1968 ~ 0,
                          relationhd == "Head" & doiy == 1968 ~ 1,
                          relationhd != "Head" & doiy == 1968 ~ 0),
         spouse = case_when((relationhd %in% c("Wife of head","Husband of head")) & round(seq) == 2
                            & doiy > 1968 ~ 1,
                            !(relationhd %in% c("Wife of head","Husband of head")) & round(seq) != 2
                            & doiy > 1968 ~ 0,
                            (relationhd %in% c("Wife of head","Husband of head")) & doiy == 1968 ~ 1,
                            !(relationhd %in% c("Wife of head","Husband of head")) & doiy == 1968 ~ 0))

# weights
# i_wgt -> individual sample weights, 1968-1989
# i_c_wgt ->combined latino and core weights, 1990-1996
# i_clong_wgt -> combined longitudinal weights, 1997-2017
# i_cx_wgt ->combined cross sectional weights, 1997-2017

psid.reshape <- psid.reshape %>%
  mutate(wgt = case_when(inrange(doiy, 1968, 1989) ~ i_wgt,
                         inrange(doiy, 1990, 1996) ~ i_c_wgt,
                         inrange(doiy, 1997,2019) ~ i_clong_wgt)) %>%
  # cross sectional
  mutate(xwgt = ifelse(inrange(doiy, 1968, 1996), wgt, i_cx_wgt))


# samples
psid.reshape <- psid.reshape %>%
  mutate(core_sample = ifelse(inrange(round(hhid68), 1, 2930), 1,0), #head, spouse, children or born into core sample
         immigrant_sample = ifelse(inrange(round(hhid68), 3001, 4851), 1,0), #hhm from immigrant sample
         census_sample = ifelse(inrange(round(hhid68), 5001, 6872), 1,0), #hhm from 1968 census sample
         latino_sample = ifelse(inrange(round(hhid68), 7001, 9308), 1,0)) %>% #hhm from Latino sample 
  mutate(booster = ifelse(immigrant_sample == 1 | latino_sample ==1, 1,0))


# true year and month of birth in missing interview years
# get most commonly reported birth year for each id
mode <- psid.reshape %>%
  group_by(id68) %>%
  count(doby) %>%
  filter(!is.na(doby))

mode <- mode[order(mode$id68, mode$doby),]

mode <- mode %>%
  group_by(id68) %>%
  slice(which.max(n)) %>%
  subset(select=-c(n)) %>%
  rename(truedoby = doby)

psid.reshape <- merge(psid.reshape, mode, by="id68",
                      all.x=T)

mode <- psid.reshape %>%
  group_by(id68) %>%
  count(dobm) %>%
  filter(!is.na(dobm))

mode <- mode[order(mode$id68, mode$dobm),]

mode <- mode %>%
  group_by(id68) %>%
  slice(which.max(n)) %>%
  subset(select=-c(n)) %>%
  rename(truedobm = dobm)

psid.reshape <- left_join(psid.reshape, mode, by="id68")

psid.reshape <- psid.reshape %>%
  mutate(dobm = truedobm,
         doby = truedoby) %>%
  # if missing birth month but not year treat as born in sept
  mutate(dobm = ifelse(is.na(dobm) & !is.na(doby), 9, dobm)) %>%
  subset(select=-c(truedoby,truedobm)) %>%
  mutate(dob = as.Date(paste(as.character(doby),as.character(dobm),"15",sep="-"),
                       "%Y-%m-%d"))

# employment
# fill in individual variables with spouse variables

psid.reshape <- psid.reshape %>%
  mutate(emp_lw = case_when(head == 1 & !is.na(hd_employment) ~ hd_employment,
                            spouse == 1 & !is.na(wf_employment) ~ wf_employment,
                            !inrange(age, 16,99) ~ NA_real_,
                            TRUE ~ employment))

# in labor force
psid.reshape <- psid.reshape %>%
  mutate(inlf_lw = emp_lw) %>%
  mutate(inlf_lw = ifelse(employment == "Unemployed", 1, inlf_lw))

# working last year
psid.reshape <- psid.reshape %>%
  mutate(emp_ly = case_when(head == 1 & hd_work_ly == 1 ~ 1,
                            head == 1 & hd_work_ly == 5 ~ 0,
                            head == 1 & hd_work_ly %in% c(0,9) ~ NA_real_,
                            spouse == 1 & wf_work_ly == 1 ~ 1,
                            spouse == 1 & wf_work_ly == 5 ~ 0,
                            spouse == 1 & wf_work_ly %in% c(0,9) ~ NA_real_))

# earnings
# always refers to year before and we dropped odd years after '97 so we're missing some years

# if head use head's earnings
psid.reshape <- psid.reshape %>%
  mutate(hd_earn = ifelse(round(hd_earn) == 9999999 & inrange(doiy, 1994, 1995), NA_real_, as.numeric(hd_earn)))


psid.reshape$inc_fm_split <- (psid.reshape$inc_fm)/2
psid.reshape$hd_unmarried <- rowSums(psid.reshape[,c("hd_earn","hd_earn_bs","inc_fm")],na.rm=T)
psid.reshape$hd_married <- rowSums(psid.reshape[,c("hd_earn","hd_earn_bs","inc_fm_split")],na.rm=T)
psid.reshape$wf_add <- rowSums(psid.reshape[,c("wf_earn_ex","wf_earn_bs","inc_fm_split")],na.rm=T)
psid.reshape <- psid.reshape %>%
  mutate(hd_unmarried = ifelse(is.na(hd_earn) & is.na(hd_earn_bs) & is.na(inc_fm), NA_real_, hd_unmarried)) %>%
  mutate(hd_married = ifelse(is.na(hd_earn) & is.na(hd_earn_bs) & is.na(inc_fm_split), NA_real_, hd_married)) %>%
  mutate(wf_add = ifelse(is.na(wf_earn_ex) & is.na(wf_earn_bs) & is.na(inc_fm),NA_real_,wf_add)) %>%
  mutate(wf_earn = ifelse(doiy > 1993, wf_add, wf_earn))  %>%
  mutate(earnings_ly = case_when(head == 1 & doiy < 1994 ~ hd_earn,# hd_earn var before 1994
                                 # 1994 onwards: add business, farm and labor income
                                 # split farm income in half if married
                                 head == 1 & doiy > 1993 & marst == "Married, spouse present"
                                 ~ hd_married,
                                 head == 1 & doiy > 1993 & (marst != "Married, spouse present" | is.na(marst))
                                 ~ hd_unmarried,
                                 spouse == 1 ~ wf_earn,
                                 )) %>%
    subset(select=-c(wf_add, hd_unmarried, hd_married, inc_fm_split))


# extensive margin earnings variable
psid.reshape <- psid.reshape %>%
  mutate(earn_ly = case_when(earnings_ly > 0 & !is.na(earnings_ly) ~ 1,
                             earnings_ly <= 0 & !is.na(earnings_ly) ~ 0,
                             is.na(earnings_ly) ~ NA_real_))


# race and ethnicity
# /*for head: y68-y84:  1 White, 2 Black, 3 Spanish-American, 7 Other, 9 NA
# y85-y89 : 1 White, 2 Black, 3 American Indian, 4 Asian, Pacific Islander, 7 Other, 8 More than 2 mentions, 9 NA; DK
# y90-2003 :1 White, 2 Black, 3 American Indian, 4 Asian, Pacific Islander, 5 Mentions Latino origin or descent, 6 Mentions color other than black or white, 7 Other, 9 NA
# y05-y17  :1 White, 2 Black, 3 American Indian, 4 Asian, 5 Native Hawaiian or Pacific Islander, 7 Other, 0 Wild code, 9 NA
# 
# for wf: y85-y89 : 1 White, 2 Black, 3 American Indian, 4 Asian, Pacific Islander,7 Other,	8 More than 2 mentions, 9 NA; DK, 0 Inap
# y90-03:   1 White, 2 Black, 3 American Indian, 4 Asian, Pacific Islander, 5 Mentions Latino origin or descent, 6 Mentions color other than black or white, 7 Other, 9 NA; DK, 0 inap
# y05-y17 : 1 White, 2 Black, 3 American Indian, 4 Asian, 5 Native Hawaiian or Pacific Islander, 7 Other, 9 NA, 0 inap
# Note: values change across years and they should be considered  in creation of new vars: latino  or homogenization
# */


psid.reshape <- psid.reshape %>%
  mutate(race = case_when(head == 1 ~ hd_race,
                          spouse == 1 ~ wf_race,
                          # # before 1983, we only know if person is child, sibling etc
                          # # children
                          # # if head and wife are same race, assume child is too
                          # hhmem == 3 & hd_race == wf_race ~ hd_race,
                          # # if head is one race and wife's is missing, assume child is that race
                          # hhmem == 3 & !is.na(hd_race)
                          # & wf_race %in% c(0, NA_real_) ~ hd_race,
                          # # siblings of head: assign same race
                          # hhmem == 4 ~ hd_race,
                          # # after 1983 we have more detail
                          # # 30 Son or daughter of Reference Person, 40 Brother or sister of Reference Person
                          # # if person is child or sibling of head, assume same race
                          # hhmem %in% c(30, 40) & hd_race != 0 & !is.na(hd_race) ~ hd_race,
                          # # 33 Stepson or stepdaughter, 5 Son or daughter of Partner but not Hd , 37 Son-in-law or daughter-in-law of hd
                          # # 47 Brother-in-law or sister-in-law of hd, 48 Brother or sister of  hd's cohabitor
                          # # if person is child or sibling of wife, assume same race
                          # hhmem %in% c(33, 35, 37, 47, 48) & wf_race != 0 & !is.na(wf_race) ~ wf_race
  ))

# latino indicator: codes that are related to hispanicity only appear from 68-94 and 90-93
  # create latino indicators based on these years
  # take max across all years for each person to determine whether they are latino
  # merge with full dataset to add latino dummy

latino <- psid.reshape %>%
  mutate(Ilatino = ifelse((race == 3 & inrange(doiy, 1968, 1984)) 
                          | (race == 5 & inrange(doiy, 1990, 2003)) |
                           (head == 1 & inrange(hd_hisp, 1, 7)) |
                           (spouse == 1 & inrange(wf_hisp, 1, 7)) , 1, 0))%>%
  group_by(id68) %>%
  summarise(Ilatino = max(Ilatino, na.rm = T)) %>%
  mutate(Ilatino = ifelse(Ilatino == -Inf, NA_real_, Ilatino))

psid.reshape <- merge(psid.reshape, latino, by="id68",
                      all.x=T)

# recode race variable for consistency over time: there is quite a bit of variation so have to be careful here
psid.reshape <- psid.reshape %>%
  mutate(temp = race) %>%
  mutate(race = case_when(round(race) == 9 ~ NA_real_,
                          round(race) == 8 & (inrange(doiy, 1994,2002) | doiy == 2011) ~ NA_real_,
                          race %in% c(6,7) | (race == 8 & doiy == 1985) | 
                            (race == 4 & doiy >= 1985) ~ 7, # Other
                          race == 0 ~ NA_real_, 
                          (race == 3 & inrange(doiy, 1968, 1984)) | 
                            (race == 5 & inrange(doiy, 1990,2003)) ~ 5, # hispanic
                          (race == 5 & doiy >= 2005) |
                            (race == 3 & doiy >= 1985) ~ 7, # Native Hawaiian or Pacific Islander, group with Asian category
                          TRUE ~ race))

# most commonly reported race for each id
racemax <- psid.reshape %>%
  group_by(id68) %>%
  count(race)%>%
  filter(!is.na(race))%>%
  group_by(id68) %>%
  slice(which.max(n)) %>% # keeps most frequently reported non-NA race
  subset(select=-c(n)) %>%
  rename(racemax = race)

psid.reshape <- merge(psid.reshape,racemax, by="id68",
                      all.x=T)

psid.reshape <- psid.reshape %>%
  mutate(race = as.factor(case_when(racemax == 1 ~ "White, non-hispanic",
                                    racemax == 2 ~ "Black, non-hispanic",
                                    racemax %in% c(7) ~ "Other",
                                    racemax == 5 ~ "Hispanic"))) %>%
  mutate(race = as.factor(ifelse(Ilatino == 1, "Hispanic",as.character(race)))) %>%
  mutate(race_old  = as.factor(ifelse(race == "Hispanic", "Other",as.character(race)))) %>%
  mutate(black = case_when(race == "Black, non-hispanic" ~ 1,
                           race != "Black, non-hispanic" & !is.na(race) ~ 0,
                           is.na(race) ~ NA_real_)) %>%
  mutate(white = as.factor(case_when(race == "White, non-hispanic" ~ "white",
                           race %in% c("Black, non-hispanic","Other","Hispanic") ~ "nonwhite"))) %>%
  subset(select=-c(racemax))

# state labels: using fips code (available for less years)
# state fips to name crosswalk
fips <- state.fips %>%
  mutate(statename = ifelse(str_count(polyname,":")==0, str_to_title(polyname), 
                            str_to_title(substring(polyname,1,regexpr(":",polyname)-1)))) %>%
  mutate(statename = ifelse(statename == "District Of Columbia", "District of Columbia", statename)) %>%
  rename(statefip = fips) %>%
  distinct(statefip,statename)

fips[nrow(fips) + 1,] = list(2, "Alaska")
fips[nrow(fips) + 1,] = list(15, "Hawaii")

psid.reshape <- psid.reshape %>%
  mutate(statefip = round(statefip))
fips <- fips %>%
  mutate(statefip = round(statefip))

psid.reshape <- merge(psid.reshape, fips, by="statefip",all.x=T) %>%
  mutate(statename = as.factor(as.character(statename)))

# use state psid code and compare, recode
# https://psidonline.isr.umich.edu/data/Documentation/PSIDStateCodes.pdf
psid.reshape <- psid.reshape %>%
  mutate(psid_state = round(psid_state)) %>%
  mutate(psid_statename = case_when(psid_state == 1 ~ "Alabama", psid_state == 2 ~ "Arizona",
                                    psid_state == 3 ~ "Arkansas", psid_state == 4 ~ "California",
                                    psid_state == 5 ~ "Colorado", psid_state == 6 ~ "Connecticut",
                                    psid_state == 7 ~ "Delaware", psid_state == 8 ~ "District of Columbia",
                                    psid_state == 9 ~ "Florida", psid_state == 10 ~ "Georgia",
                                    psid_state == 11 ~ "Idaho", psid_state == 12 ~ "Illinois",
                                    psid_state == 13 ~ "Indiana", psid_state == 14 ~ "Iowa",
                                    psid_state == 15 ~ "Kansas", psid_state == 16 ~ "Kentucky",
                                    psid_state == 17 ~ "Louisiana", psid_state == 18 ~ "Maine",
                                    psid_state == 19 ~ "Maryland", psid_state == 20 ~ "Massachusetts",
                                    psid_state == 21 ~ "Michigan", psid_state == 22 ~ "Minnesota",
                                    psid_state == 23 ~ "Mississippi", psid_state == 24 ~ "Missouri",
                                    psid_state == 25 ~ "Montana", psid_state == 26 ~ "Nebraska",
                                    psid_state == 27 ~ "Nevada", psid_state == 28 ~ "New Hampshire",
                                    psid_state == 29 ~ "New Jersey", psid_state == 30 ~ "New Mexico",
                                    psid_state == 31 ~ "New York", psid_state == 32 ~ "North Carolina",
                                    psid_state == 33 ~ "North Dakota", psid_state == 34 ~ "Ohio",
                                    psid_state == 35 ~ "Oklahoma", psid_state == 36 ~ "Oregon",
                                    psid_state == 37 ~ "Pennsylvania", psid_state == 38 ~ "Rhode Island",
                                    psid_state == 39 ~ "South Carolina", psid_state == 40 ~ "South Dakota",
                                    psid_state == 41 ~ "Tennessee", psid_state == 42 ~ "Texas",
                                    psid_state == 43 ~ "Utah", psid_state == 44 ~ "Vermont",
                                    psid_state == 45 ~ "Virginia", psid_state == 46 ~ "Washington",
                                    psid_state == 47 ~ "West Virginia", psid_state == 48 ~ "Wisconsin",
                                    psid_state == 49 ~ "Wyoming",psid_state == 50 ~ "Alaska",
                                    psid_state == 51 ~ "Hawaii",
                                    psid_state %in% c(99,0) ~ NA_character_))

statemax <- psid.reshape %>%
  group_by(id68) %>%
  count(statename) %>%
  filter(!is.na(statename)) %>%
  group_by(id68) %>%
  slice(which.max(n)) %>%
  subset(select=-c(n)) %>%
  rename(statemax = statename)


gsamax <- psid.reshape %>%
  group_by(id68) %>%
  count(psid_statename)%>%
  filter(!is.na(psid_statename))%>%
  group_by(id68) %>%
  slice(which.max(n)) %>%
  subset(select=-c(n)) %>%
  rename(gsamax = psid_statename)

statemax <- merge(statemax, gsamax, by="id68", all=T)

statemax <- statemax %>%
  mutate(statemax = ifelse(is.na(statemax), gsamax, as.character(statemax))) %>%
  subset(select=-c(gsamax))

psid.reshape <- merge(psid.reshape, statemax, by="id68",all.x=T)

# use mode state of residence to replace missings only
psid.reshape <- psid.reshape %>%
  mutate(state = as.factor(case_when(is.na(statename) & !is.na(psid_statename) ~ as.character(psid_statename),
                           !is.na(statename) ~ as.character(statename),
                           is.na(statename) & is.na(psid_statename) ~ as.character(statemax)))) %>%
  subset(select=-c(statename, statefip, psid_state, psid_statename)) %>%
  rename(statename = state) %>%
  merge(fips, by="statename", all.x=T)



# census division
psid.reshape <- psid.reshape %>%
  mutate(census = as.factor(case_when(statename %in% c("Connecticut","Maine","Massachusetts",
                                                       "New Hampshire","Rhode Island","Vermont",
                                                       "Maine-Massachusetts-New Hampshire-Rhode Island-Vermont",
                                                       "New Hampshire-Maine-Vermont-Rhode Island") 
                                      ~ "New England",
                                      statename %in% c("New Jersey", "New York", "Pennsylvania")
                                      ~ "Mid-Atlantic",
                                      statename %in% c("Illinois","Indiana","Michigan",
                                                       "Ohio", "Wisconsin","Michigan-Wisconsin") 
                                      ~ "East North Central",
                                      statename %in% c("Iowa", "Kansas","Minnesota","Missouri",
                                                       "Nebraska","North Dakota","South Dakota","Minnesota-Iowa",
                                                       "Nebraska-North Dakota-South Dakota-Kansas",
                                                       "Iowa-N Dakota-S Dakota-Nebraska-Kansas-Minnesota-Missouri")
                                      ~ "West North Central",
                                      statename %in% c("Delaware","Florida","Georgia","Maryland",
                                                       "North Carolina","South Carolina","Virginia",
                                                       "District of Columbia", "West Virginia","Delaware-Virginia",
                                                       "North Carolina-South Carolina","South Carolina-Georgia",
                                                       "Delaware-Maryland-Virginia-West Virginia")
                                      ~ "South Atlantic",
                                      statename %in% c("Alabama","Kentucky","Mississippi",
                                                       "Tennessee","Alabama-Mississippi","Kentucky-Tennessee") 
                                      ~ "East South Central",
                                      statename %in% c("Arkansas","Louisiana","Oklahoma",
                                                       "Texas","Arkansas-Oklahoma","Arkansas-Louisiana-Oklahoma")
                                      ~ "West South Central",
                                      statename %in% c("Arizona","Colorado","Idaho",
                                                       "Montana","Nevada","New Mexico","Utah","Wyoming",
                                                       "Arizona-New Mexico-Colorado","Idaho-Wyoming-Utah-Montana-Nevada",
                                                       "Montana-Wyoming-Colorado-New Mexico-Utah-Nevada-Arizona")
                                      ~ "Mountain",
                                      statename %in% c("Alaska","California","Hawaii",
                                                       "Oregon","Washington","Alaska-Washington-Hawaii",
                                                       "Washington-Oregon-Alaska-Hawaii")
                                      ~ "Pacific")))

# census region
psid.reshape <- psid.reshape %>%
  mutate(region = as.factor(case_when(census == "New England" | census == "Mid-Atlantic"
                                      ~ "Northeast",
                                      census %in% c("East North Central", "West North Central")
                                      ~ "Midwest",
                                      census %in% c("South Atlantic","East South Central",
                                                    "West South Central") ~ "South",
                                      census %in% c("Mountain","Pacific") ~ "West"))) %>%
  mutate(censusregion = as.factor(case_when(region %in% c("Northeast", "South") ~ "S-NE",
                                      region %in% c("West","Midwest") ~ "W-MW")))

# date of interview
# fictitious day of int: assume day is always 15th
psid.reshape$doi <- as.Date(with(psid.reshape, paste(as.character(doiy),as.character(doim)
                                                     ,"15",sep="-")),"%Y-%m-%d")

psid.reshape <- psid.reshape[order(psid.reshape$id68, psid.reshape$doiy),]

# fix age variable

psid.reshape <- psid.reshape %>%
  mutate(age = lubridate::year(as.period(interval(dob, doi), unit='year'))) 

# replace emp as missing outside age range
psid.reshape <- psid.reshape %>%
  mutate(emp_lw = case_when(!inrange(age, 16,99) ~ NA_real_,
                            TRUE ~ emp_lw))
  
# highest education achieved

  # alternative: using family variable to fill in
psid.reshape <- psid.reshape %>%
  mutate(fam_yrseduc = case_when(head == 1 ~ hd_yrseduc,
                              spouse == 1 ~ wf_yrseduc))


maxgrade <- psid.reshape %>%
  group_by(id68) %>%
  filter(!is.na(yrseduc))%>%
  summarise(maxgrade = max(yrseduc, na.rm=T),
            maxyear= max(doiy)) %>%
  mutate(maxgrade = ifelse(maxgrade==-Inf, NA_real_, round(maxgrade)))

maxgrade_fam <- psid.reshape %>%
  group_by(id68) %>%
  filter(!is.na(fam_yrseduc)) %>%
  summarise(maxgrade = max(fam_yrseduc, na.rm=T),
            maxyear_fam = max(doiy)) %>%
  mutate(maxgrade = ifelse(maxgrade==-Inf, NA_real_, round(maxgrade)),
         maxyear_fam = ifelse(is.na(maxyear_fam), 0, maxyear_fam)) %>%
  rename(fam = maxgrade)

maxgrade <- merge(maxgrade, maxgrade_fam, by="id68", all=T)

  # use individual variable unless it is missing
maxgrade <- maxgrade %>%
  mutate(maxyear = ifelse(is.na(maxyear), 0, maxyear)) %>%
  mutate(maxgrade = ifelse(!is.na(maxgrade), maxgrade, fam)) %>%
  subset(select=-c(fam, maxyear, maxyear_fam))

psid.reshape <- merge(psid.reshape, maxgrade, by="id68",all.x=T)

psid.reshape <- psid.reshape %>%
  mutate(edlevel = as.factor(case_when(maxgrade < 12 ~ "Below HS",
                                       maxgrade == 12 ~ "HS grad",
                                       inrange(maxgrade, 13, 15) ~ "Some college",
                                       inrange(maxgrade, 16, 17) ~ "College +"))) %>%
  mutate(below_college = as.factor(case_when(edlevel %in% c("Below HS", "HS grad","Some college") ~ "nocollege",
                                          edlevel == "College +" ~ "college"))) %>%
  # indicator for having graduated college
  mutate(college = case_when(inrange(maxgrade, 16, 17) ~ 1,
                             !inrange(maxgrade, 16, 17) & !is.na(maxgrade) ~ 0,
                             is.na(maxgrade) ~ NA_real_))
# event times
  # define t=0 to be 6 months before - 6 months after birth of child for worked last week
  # for earnings, since these are measured in a calendar year rather than at the time of intervew we do it differently
  # want to use earnings from the calendar year in which most of the event time was realized

psid.reshape <- psid.reshape %>%
  mutate(start = ch1dob %m-% months(6)) %>%
  mutate(t_es_lw = floor((interval(start, doi) %/% months(1))/12)) %>%
  mutate(t_es_ly = doiy - ch1yob - 1)


# post variable
psid.reshape <- psid.reshape %>%
  mutate(post = case_when(doi >= ch1dob & !is.na(ch1dob) ~ 1,
                          doi < ch1dob & !is.na(ch1dob) ~ 0,
                          is.na(ch1dob) ~ NA_real_))
# age at first birth
age1b_fix <- psid.reshape %>%
  mutate(temp = ifelse(!is.na(dob), floor((interval(dob, ch1dob) %/% months(1))/12), NA_real_)) %>%
  filter(!is.na(ch1dob)) %>%
  group_by(id68) %>%
  summarise(age1b = min(temp, na.rm=T)) 

psid.reshape <- merge(psid.reshape, age1b_fix, all.x=T, by="id68") %>%
  mutate(age1b = ifelse(age1b < 14, NA_real_, age1b))

# child indicator
psid.reshape <- psid.reshape %>%
  mutate(child = ifelse(!is.na(ch1dob), 1, 0))

########### Sampling restrictions ###########

# dataset label

psid.reshape <- psid.reshape %>%
  mutate(dataset = as.factor("PSID")) %>%
  mutate(dataset = factor(dataset, levels = c("CPS", "ACS", "NLSY", "PSID")))

# Save intermediate file

# foreign::write.dta(psid.reshape, file=file.path(wrkdir,"psid_intermediate.dta"))

# drop if missing or zero wgt
psid <- psid.reshape %>%
  filter(!is.na(wgt) & wgt > 0)

# missing birthday
psid <- psid %>%
  filter(!is.na(dob))

# keep head and spouse
psid <- psid %>%
  filter(head == 1 | spouse == 1) %>%
  
  # keep if we have employment or earnings info
  filter(!is.na(emp_lw) | !is.na(earnings_ly))
  
  # keep if age at first birth between 20 and 45
  # filter(inrange(age1b, min.age, max.age) | child == 0) %>% 
  
  # keep core, immigrant, and latino samples
psid <- psid %>%
  filter(core_sample == 1 | latino_sample == 1 | immigrant_sample == 1)


psid <- psid %>%
  rename(id = id68)

# variable labels
psid <- apply_labels(psid, earnings_ly = "Earnings",
                     earn_ly = "Annual Employment",
                     emp_lw = "Weekly Employment")

# factor variables for regression
psid <- psid %>%
  mutate(age_factor = as.factor(age),
         doiy_factor = as.factor(doiy),
         age_gender = interaction(age_factor, gender),
         doiy_gender = interaction(doiy_factor, gender))

# drop if missing vars used in matching
psid <- psid %>%
  drop_na(edlevel, marst, statename, race)


psid <- psid %>%
  subset(select = -c(hd_hrs_ly, wf_hrs_ly, hd_earn, wf_earn,
                     hd_race, hd_employment, hhmem, yrseduc,
                     hrs_ly, i_wgt, wf_work_ly, hd_work_ly,
                     hd_yrseduc, wf_yrseduc, wf_employment, hd_marst,
                     employment, hd_hisp,wf_hisp, wf_race,
                     i_c_wgt, inc_fm, hd_earn_bs, wf_earn_bs, wf_earn_ex,
                     i_clong_wgt, i_cx_wgt, rawage, xwgt, inlf_lw, emp_ly,
                     temp, race_old, statemax, fam_yrseduc, maxgrade,
                     numbirths, child1_mn, child1_yr,
                     child2_mn, child2_yr, hhid, seq, earn, relationhd)) %>%
  rename(hhid = hhid68,
         nchild = chtot)

# save dataset at this point for matching that keeps everyone without child as well
save(psid, file=file.path(cleandir,"psid_clean_all.RData"))
# foreign::write.dta(psid, file=file.path(wrkdir,"psid_match.dta"))

# additional cleaning for event times
psid <- psid %>%
  mutate(across(c(t_es_lw,t_es_ly), ~as.factor(case_when(inrange(., -5,10)
                                                         ~ as.character(.),
                                                         . < -5 ~ NA_character_,
                                                         . > 10 ~ NA_character_)))) %>%
  within(t_es_lw <- relevel(t_es_lw, ref = ref)) %>%
  within(t_es_ly <- relevel(t_es_ly, ref = ref)) %>%
  filter(!is.na(t_es_lw) | !is.na(t_es_ly))


# sample restrictions
obs_count <- psid %>%
  mutate(obs_pre_ly = ifelse(t_es_ly %in% c("-5","-4","-3","-2","-1") & !is.na(earnings_ly),1,0),
         obs_post_ly = ifelse(t_es_ly %in% c("0","1","2","3","4","5","6","7",
                                             "8","9","10") & !is.na(earnings_ly), 1,0)) %>%
  mutate(obs_pre_lw = ifelse(t_es_ly %in% c("-5","-4","-3","-2","-1") & !is.na(emp_lw),1,0),
         obs_post_lw = ifelse(t_es_ly %in% c("0","1","2","3","4","5","6","7",
                                             "8","9","10") & !is.na(emp_lw), 1,0)) %>%
  mutate(interviewed_ly = ifelse(!is.na(earnings_ly) & !is.na(t_es_ly), 1,0),
         interviewed_lw = ifelse(!is.na(emp_lw) & !is.na(t_es_lw), 1,0)) %>%
  group_by(id) %>%
  summarise(obs_post_lw = max(obs_post_lw,na.rm=T),
            obs_post_ly = max(obs_post_ly,na.rm=T),
            obs_pre_lw = max(obs_pre_lw, na.rm=T),
            obs_pre_ly = max(obs_pre_ly, na.rm=T),
            count_obs_ly = sum(interviewed_ly),
            count_obs_lw = sum(interviewed_lw))

psid <- merge(psid, obs_count, by="id", all.x=T)

psid <- psid %>%
  mutate(sample_lw = ifelse(obs_post_lw == 1 & obs_pre_lw == 1 & count_obs_lw >= 8, 1, 0),
         sample_ly = ifelse(obs_post_ly == 1 & obs_pre_ly == 1 & count_obs_ly >= 8, 1, 0))

# age at first birth 25-45
psid <- psid %>%
  subset(inrange(age1b, 25, 45))


save(psid, file=file.path(cleandir,"psid_clean_restricted.RData"))

# Label variables
psid <- apply_labels(psid, id = "Unique Identifier", statename = "State of Residence",
                     hhid = "Household ID", pid = "Person ID", 
                     doiy = "Year of Intervew", doim = "Month of Interview",
                     t_es_lw = "Event Time (Weekly)", t_es_ly = "Event Time (Annual)",
                     child = "Indicator for Parent",
                     statefip = "State of Residence (FIPS)", 
                     census = "Census Division of Residence",
                     region = "Census Region of Residence")

# save(psid, file=file.path(wrkdir,"psid_clean_labelled.RData"))
# 
# foreign::write.dta(psid, file=file.path(wrkdir,"psid_clean_labelled.dta"))

