#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates Panels A, C, E in Figure 2 of the paper
# (Validation using PSID and NLSY79 pseudo-panel)

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

#########################
# Functions
#########################

#------ Main matching function ------#

run_match <- function(data) {
  
  # skip bin if we don't have both a childless person and parent
  
  if(length(unique(data$child)) == 2) {
    
    # treatment variable: indicator for having a child or not
    
    match_out  <- Match(Y=NULL, Tr=data$child,
                        
                        # subset variables that we are matching on 
                          # don't really need all these vars listed b/c we have already
                          # split dfs into list by vars we want to match on
                        
                        X=subset(data, select=c(gender.num,age,doiy,matching_vars))
                        # replace = T and ties = F for matching with replacement, exact = T not really necessary
                          # b/c bins are split already
                        ,replace=T,ties=T,exact=T)
    
    # return dataset with both child == 0 and child == 1 observations
    
    matched <- data[c(match_out$index.treated, match_out$index.control),]
    
    # add an id variable for each matched_pair (within a given bin)
    
    matched$pair <- factor(rep(match_out$index.treated, 2))
    
    matched$wgt_match <- match_out$weights
    
    # don't want to keep the repeated parent obs
    
    matched_parent <- subset(matched, child == 1) %>%
      distinct() %>%
      mutate(wgt_match = 1)
    
    matched <- subset(matched, child == 0) %>%
      bind_rows(matched_parent)
    
    return(matched)
  }
}

#-------Function to create matched dataset--------#

match_age1b_steps <- function(df, matchvars, tvar) {
  
  # since this is a panel, people with negative event times are defined as having children
    # want to change this here to pretend we don't know whether they do eventually have children
  df <- df %>%
    mutate(child_actual = child,
           age1b_actual = age1b,
           t_actual = !!sym(tvar),
           ch1yob_actual = ch1yob) %>%
    mutate(child = ifelse(!!sym(tvar) < 0 | is.na(!!sym(tvar)), 0, child)) %>%
    
    # only keep parents with event time 10 or less but keep all negative event times
    
    filter(child == 0 | inrange(!!sym(tvar), 0, 10))
  
  # create numeric variable for every var we want to match on
  
  df <- df %>%
    mutate(gender.num = as.numeric(gender),
           marst.num = as.numeric(marst),
           edlevel.num = as.numeric(edlevel),
           race.num = as.numeric(race),
           statefip.num = statefip) %>%
    drop_na(marst, edlevel, race)
    
    # keep parents within selected age range and save first 5 years
      # if we match parents starting in min(interview year), we will not have t = -5
      # matches, and so on until min + 5, so we start at min + 5
  
  # age at first birth restriction
    df <- df %>%
      filter((child == 1 & inrange(age1b, min.age, max.age) & doiy >= min(doiy) + 5) 
             | (child == 0))
  
  temp <- df %>%
    droplevels()
  
  # if using psid we also need to drop state NAs
    # for NLSY we don't since state var is NA everywhere
  if(levels(temp$dataset)[1]=="PSID"){
    df <- df %>%
      drop_na(statename)
    
    # format statefip code
    
    df <- df %>%
      mutate(statefip.num = sprintf("%02d",statefip))
    
  }
  
  # select sample of parents we use for matching (people at t=0)
  
  
    # need to lag years differently depending on interview year
      # when interviews switch to every alternate year instead of yearly
      # t=-1 if interviewed 2 years before, 1 year younger
      # t=-2 if interviewed 2 years before, 2 years younger
      # t=-3 if interviewed 4 years before, 3 years younger
      # t=-3 if interviewed 4 years before, 4 years younger
      # t=-5 if interviewed 6 years before, 4 years younger
    
    child0 <- df %>%
      filter(!!sym(tvar)==0) %>%
      droplevels() %>%
      dplyr::rename(doiy_actual = doiy) %>%
      dplyr::rename(age_actual = age)
    
    # create variables for age and interview year - i, where i is from 0 to 5
    
    for(i in 1:5) {
      agevar <- paste0("agerange",as.character(i))
      doiyvar <- paste0("doiyrange",as.character(i))
      
      child0[agevar] <- child0["age_actual"] - i
      child0[doiyvar] <- child0["doiy_actual"] - i
      
      # if that interview year is unavailable, go back 1 year instead
      child0 <- child0 %>%
        mutate(doiytemp = ifelse(!(!!sym(doiyvar) %in% unique(df$doiy)), !!sym(doiyvar)-1, !!sym(doiyvar)))
      
      child0[doiyvar] <- child0["doiytemp"]
      
      child0 <- child0 %>%
        subset(select=-c(doiytemp))
      
    }
  
  # reshape long to get column with each age - i and year - i where i is 1:5
    # we repeat each parent 5 times so that we can more easily match each parent 5 times
    # to childless person 1 year younger 1 year earlier, 2 years younger 2 years earlier etc.
  
  child0 <- reshape(as.data.frame(child0), varying = 
                      list(c("agerange1","agerange2",
                             "agerange3","agerange4","agerange5"),
                           c("doiyrange1",
                             "doiyrange2","doiyrange3","doiyrange4","doiyrange5")), 
                    v.names=c("age","doiy"), new.row.names = 1:(nrow(child0)*5),
                    timevar="t_minus", 
                    direction="long")

  
  child0 <- child0 %>%
    mutate(t_minus = -1*t_minus)
  
  # dataframe of childless observations we use for matches
  
  childless <- df %>%
    filter(child == 0 & inrange(age, 20, 45)) %>%
    mutate(doiy_actual = doiy)
  
  # combine these dataframes
  
  combined <- bind_rows(child0, childless)
  
  # create unique identifier for bin
  
  combined <- combined %>%
    group_by_at(matchvars) %>%
    dplyr::mutate(matching_vars = cur_group_id()) %>%
    ungroup()
  
  combined <- combined[
    with(combined, order(-child, doiy_actual, id)),
  ]
  
  # split df into list by bin
  
  combined_bin <- dlply(combined,.(matching_vars))
  
  # apply matching function to each list element separately (match within bin), bind rows
  matched <- setDF(rbindlist(lapply(combined_bin, run_match)))
  matched <- matched %>%
    group_by(gender.num, doiy, age, matching_vars, pair) %>%
    dplyr::mutate(match_bin = cur_group_id()) %>%  # unique id for each matched pair within each bin
    ungroup()
  
  # separate childless and parent obs
  
  matched_childless <- matched %>%
    filter(child == 0) %>%
    rename(statefip_actual = statefip, statename_actual = statename) %>%
    subset(select=-c(doiy_actual,age_actual, t_minus)) %>%
    subset(select=-c(age1b, t_es_lw, t_es_ly, post, ch1yob,
                     region, censusregion))
  
  # df of people who are childless and unmatched
  id_childless <- matched_childless %>%
    subset(select=c(id, doiy)) %>%
    mutate(matched=TRUE) %>%
    distinct()
  
  childless_unmatched <- merge(childless, id_childless, by=c("id","doiy"), all=T) %>%
    subset(is.na(matched)) %>%
    subset(select=-c(matched)) %>%
    subset(select=-c(age1b, t_es_lw, t_es_ly, post, ch1yob)) %>%
    rename(statefip_actual = statefip,
           statename_actual = statename) %>%
    mutate(unmatched=TRUE)
  
  # extract obs with children, replace their value of some vars with values from matched person
  
  matched_child <- matched %>%
    subset(child == 1) %>%
    subset(select=c(age1b,match_bin,
                    region, censusregion, 
                    doiy_actual,doby,ch1yob, wgt, id, t_minus)) %>%
    dplyr::rename(match_wgt = wgt,
                  match_id = id,
                  match_doby = doby,
                  match_doiy = doiy_actual,
                  match_ch1yob = ch1yob)
  matched_child[tvar] <- matched_child["t_minus"]
  matched_child <- matched_child %>%
    subset(select=-c(t_minus))
  
  # create indicator that parent was matched to a person n years younger, n years before
  
  indicator_matched <- subset(matched, child == 1) %>%
    subset(select=c(doiy_actual, id, t_minus)) %>% 
    mutate(matched = 1) %>%
    pivot_wider(names_from = c(t_minus), values_from = matched, names_prefix="matched")%>%
    mutate(across(contains("matched"), ~ifelse(is.na(.), 0, 1))) %>%
    rename(doiy = doiy_actual)
  
  # add to df of parents: will be NA for everyone except people with eldch == 0
  df_child <- subset(df, child == 1) %>%
    merge(indicator_matched, by=c("doiy", "id"), all.x=T) %>%
    mutate(across(contains("matched"), ~ifelse(is.na(.) & !!sym(tvar)==0, 0, .)))%>%
    mutate(wgt_match = 1)
  
  
  # add matched age at first birth to childless df
  # we do all of this so that we can ignore the 5x multiplied parent obs and just extract age1b
  
  matched_final <- merge(matched_childless, matched_child,by="match_bin")
  
  # combine childless obs with original parent obs
  matched_final <- bind_rows(matched_final,df_child) 
  
  # rename and keep actual t
  tname <- paste0(tvar,"_actual")
  matched_final[tname] <- matched_final["t_actual"]
  
  # create match variables which doesn't change parents but gives childless people
  # the same value as their matched parent
  # wgt is multiplied by matching weight for childless people
  matched_final <- matched_final %>%
    subset(select=-c(matching_vars,gender.num,race.num,marst.num,edlevel.num, match_bin, statefip.num, pair, t_actual)) %>%
    mutate(match_wgt = ifelse(child==0, match_wgt, wgt),
           match_id = ifelse(child==0, match_id, id),
           match_doby = ifelse(child==0, match_doby, doby),
           match_doiy = ifelse(child==0, match_doiy, doiy),
           match_ch1yob = ifelse(child==0, match_ch1yob, ch1yob),
           wgt = ifelse(child == 0, wgt_match*wgt, wgt))
  
  # clean event time variable
  
  matched_final <- matched_final %>%
    mutate(t_temp = as.factor(as.numeric(!!sym(tvar)))) %>%
    mutate(t_numeric = !!sym(tvar))
  
  matched_final$t_temp <- relevel(matched_final$t_temp, ref="-2")
  
  matched_final[tvar] <- matched_final["t_temp"]
  
  matched_final <- matched_final %>%
    subset(select=-c(t_temp))
  
  return(matched_final)
}

#-------Function to run matching and create event studies for Figure 2--------#

reg_matching_steps <- function(tvar, plotname="") {
  
  # Load files
  load(file.path(cleandir,paste0("nlsy79_clean_all",".RData")))
  nlsy <- mutate(nlsy,across(where(~ "labelled" %in% class(.)), unclass))
  load(file.path(cleandir,paste0("psid_clean_all",".RData")))
  psid <- mutate(psid,across(where(~ "labelled" %in% class(.)), unclass))

  # Drop missings for outcome variable we're matching for (annual vs weekly)
  if(grepl("ly",tvar)){
    vars <- c("earn_ly","earnings_ly")
    psid <- psid %>%
      filter(!is.na(earnings_ly))
    nlsy <- nlsy %>%
      filter(!is.na(earnings_ly))
  }
  if(grepl("lw",tvar)){
    vars <- c("emp_lw")
    psid <- psid %>%
      filter(!is.na(emp_lw))
    nlsy <- nlsy %>%
      filter(!is.na(emp_lw))
  }
  

  # Define vector of variables we want to match on depending on specification  
  matchvars <- c("doiy", "age", "gender.num", "edlevel.num", "marst.num", "race.num", "statefip.num")
  
  # Run matching for PSID
  df_psid <- match_age1b_steps(df=psid, tvar={{tvar}}, matchvars={{matchvars}})
  
  # can't add state for nlsy, modify vector before running
  matchvars <- c("doiy", "age", "gender.num", "edlevel.num", "marst.num", "race.num")
  
  # Run matching for NLSY
  df_nlsy <- match_age1b_steps(df=nlsy, tvar={{tvar}}, matchvars={{matchvars}})
  
  # combine dataframes
  final <- bind_rows(df_psid, df_nlsy)
  
  # label variables
  final <- apply_labels(final, earnings_ly = "Earnings", emp_lw = "Weekly Employment", earn_ly = "Annual Employment",
                        wgt_match = "Weight from Matching", doiy = "Year of Interview",age1b = "Age at First Birth",
                        wgt = "Combined Survey and Matching Weight", id = "Unique Identifier",
                        statefip = "State of Residence (FIPS)", statename = "State of Residence")
  
  # Run event studies
  coef_both <- lapply(vars, reg_es, data = final, preadjust = F,
                      plotname = "validation_pseudo_psid_nlsy")
  
  return(final)
}

#######################################
# Run matching, save pseudo psid/nlsy data,
# and run left panels of Figure 2

#######################################


# Run weekly sample matching
matched_lw <- reg_matching_steps(tvar="t_es_lw", plotname="") %>%
  subset(select=-c(t_es_ly))

# Run annual sample matching
matched_ly <- reg_matching_steps(tvar="t_es_ly", plotname="") %>%
  subset(select=-c(t_es_lw))

# Save stacked pseudo-panel
pseudo_psid_nlsy <- bind_rows(matched_lw, matched_ly)
saveRDS(pseudo_psid_nlsy, file=file.path(wrkdir,"psid_nlsy_pseudo-panel.rds"))
