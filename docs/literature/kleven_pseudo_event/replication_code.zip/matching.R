#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file produces the CPS and ACS pseudo-panel dataset used throughout the paper.
# Section 1 defines the function run_match, which runs the matching within a bin.
# Section 2 defines the function fn_match, which prepares the data for matching by
  # splitting the data into bins, and it contains run_match within.
# Section 3 defines the function fn_pseudo_panel, which runs the matching on cps and acs data
  # using fn_match and saves the final pseudo-panel.
# Section 4 runs fn_pseudo_panel.

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))


####################################################
# 1. General function for matching within a bin

  # This function can be run on any bin that we want to perform matching on
    # it will match people with a treatment indicator ("child") == 1 
    # to controls (those with child == 0) on gender, age, year
    # and a grouped variable called "matching_vars" that represents all the other matching variables
  
  # It will match a parent to all potential childess matches
  # It will also skip any bins with only parents or only childless people that we cannot perform matching on

####################################################

run_match <- function(data) {
  
  # skip bin if we don't have both a childless person and parent
  
  if(length(unique(data$child)) == 2) {
    
    # treatment variable: indicator for having a child or not
    
    match_out  <- Match(Y=NULL, Tr=data$child,
                        
                        # subset variables that we are matching on 
                          # don't really need all these vars listed b/c we have already
                          # split dfs into list by vars we want to match on
                        
                        X=subset(data, select=c(gender.num,age,doiy,matching_vars))
                        # replace = T and ties = F for matching with replacement, exact = T not really necessary
                          # b/c bins are split already
                        ,replace=T,ties=T,exact=T)
    
    # return dataset with both child == 0 and child == 1 observations
    
    matched <- data[c(match_out$index.treated, match_out$index.control),]
    
    # add an id variable for each matched_pair (within a given bin)
    
    matched$pair <- factor(rep(match_out$index.treated, 2))
    
    # add vector of weights that indicates number of matches for each parent
    
    matched$wgt_match <- match_out$weights
    
    # drop repeated parent obs
    
    matched_parent <- subset(matched, child == 1) %>%
      distinct() %>%
      mutate(wgt_match = 1)
    
    # combine parents and non-parents
    matched <- subset(matched, child == 0) %>%
      bind_rows(matched_parent)
    
    return(matched)
  }
}

###################################################################
# 2. Function to prepare any dataset for matching
  # and split the data into bins

# the basic idea of this function is to separate the
  # sample with and w/o children, create 5 fake observations for people with children
  # then split bins by variable of interest into a list
  # apply run_match over entire list
  # combine all our matched bins together, create an indicator for each matched pair
  # extract desired info from matched person for our pre-period sample
  # drop all the fake observations for parents and combine this with our real observations
# contains run_match embedded within
  
###################################################################

fn_match <- function(df, name, tvar, matchvars) {
  
  # create numeric versions of the variables we want to match on for run_match function
  
  df <- df %>%
    mutate(gender.num = as.numeric(gender),
           marst.num = as.numeric(marst),
           edlevel.num = as.numeric(edlevel),
           race.num = as.numeric(race),
           stateagg.num = as.numeric(stateagg)) %>%
    
    # only keep parents 5 years post start year with age at birth b/w 25 and 45
    
    filter((child == 1 & inrange(age1b, min.age, max.age) & doiy >= min(doiy) + 5) 
           | (child == 0))
  
  df <- df %>%
    mutate(statefip.num = sprintf("%02d",statefip))
  
  # we match separately by our two dependent variables since one of them (earnings)
    # is not observed in every month
    # drop missing earnings/weekly emp values here
  
  if(grepl("ly",tvar)) {
    df <- df %>%
      filter(!is.na(earnings_ly))
  } else {
      df <- df %>%
        filter(!is.na(emp_lw))
  }
  
  # sort to uniquely identify
  
  df <- df[
    with(df, order(doiy, month, serial, pernum)),
  ]
  
  # extract sample of parents with child aged 0 we use in matching
  
  child0 <- df %>%
    filter(eldch == 0) %>%
    droplevels() %>%
    dplyr::rename(doiy_actual = doiy) %>%
    dplyr::rename(age_actual = age)
  
  # create fake age and calendar year vars
    # lag age and calendar year: we go from 0 to 5 because earnings is reported for previous year,
    # for earnings, to match someone with a child aged 0 to t = -1 we need to match them to someone
    # childless at same age in the same calendar year
  
    # loop creates new variables for age/year - i
  for(i in 0:5) {
    agevar <- paste0("agerange",as.character(i))
    doiyvar <- paste0("doiyrange",as.character(i))
    child0[agevar] <- child0["age1b"] - i
    child0[doiyvar] <- child0["doiy_actual"] - i
  }
  
  # reshape long to get column with each age - i and year - i where i is 0:5
    # we repeat each parent 6 times so that we can more easily match each parent 6 times
    # to childless person 1 year younger 1 year earlier, 2 years younger 2 years earlier etc.
  
  child0 <- reshape(as.data.frame(child0), varying = 
                      list(c("agerange0","agerange1","agerange2",
                             "agerange3","agerange4","agerange5"),
                           c("doiyrange0","doiyrange1",
                             "doiyrange2","doiyrange3","doiyrange4","doiyrange5")), 
                    v.names=c("age","doiy"), new.row.names = 1:(nrow(child0)*6),
                    timevar="t_minus", 
                    direction="long")
  
  # correct error in t values when we have n starting at 0
  
  child0 <- child0 %>%
    mutate(t_minus = t_minus -1)
  
  # extract childless obs we use in matching (range 20-45 since we want to be able to match
    # a 25 y/o with a child to a childless person 5 years younger)
  
  childless <- df %>%
    filter(child == 0 & inrange(age, min.age - 5, max.age)) %>%
    mutate(doiy_actual = doiy)
  
  # in the cps data we cannot observe state until 1977, but in the years before we can use a more
    # aggregated state variable instead
  
  ## cps: match before 77 using stateagg
    # the same parent in a given year, say 1980 will be matched to someone in 1979, 1978, 1977
    # in the same state, but in 1976, 1975 etc they will be matched to someone in same aggregated
    # geographic area
  
  if(grepl("cps",name)) {
    
    # can be matched on all demographics
    combined_all <- bind_rows(subset(child0, !inrange(doiy, 1968,1976)), childless) %>%
      mutate(matching_spec = 1) %>%
      group_by(doiy, age, gender.num, marst.num,
               edlevel.num,race.num,statefip) %>%
      dplyr::mutate(matching_vars = cur_group_id()) %>%
      ungroup()
    
             
    # sample where we cannot match on statefip yet
    combined_nostate <- bind_rows(subset(child0, inrange(doiy,1968,1976)), childless) %>%
      mutate(matching_spec = 2) %>%
      group_by(doiy, age, gender.num, marst.num,
               edlevel.num,race.num,stateagg.num) %>%
      dplyr::mutate(matching_vars = cur_group_id()) %>%
      ungroup()
    
    
    # split data into lists of many separate dataframes
      # each df in the list will have identical values of the variables we  want to match on
      # splitting the data by bin ex-ante just makes the matching code run faster
    all_bins <- dlply(combined_all,.(doiy,age,gender.num, marst.num, edlevel.num, race.num,statefip)) 
    bins_nostate <- dlply(combined_nostate,.(doiy,age,gender.num, marst.num, edlevel.num, race.num,stateagg.num))
    combined_bin <- append(all_bins, bins_nostate)
    
    # add indicators for missing matches to dataset
      # need a dataframe with all parents from both statefip and stateagg matching specifications
    combined <- bind_rows(combined_all, combined_nostate)
    
     
  } else { # ACS and other specs : use state for full period
    combined <- bind_rows(child0, childless)
    combined <- combined %>%
      mutate(matching_spec = 3) %>%
      group_by_at(matchvars) %>%
      dplyr::mutate(matching_vars = cur_group_id()) %>%
      ungroup()
    
    # split the dataframe by the following variables so we have a single dataframe for each bin
      # all the dataframes will be in a single list
    
    combined_bin <-  dlply(combined,.(matching_vars))
    
  }
  
  # match each bin separately, bind all dataframes into one (iterates over the list of dfs)
  matched <- setDF(rbindlist(lapply(combined_bin, run_match)))
  
  # create a group id based on bin and 'pair' variable so we can identify who each childless person
    # was matched to
    # (run_match ran on each bin separately, pair on its own is not unique)
  
  matched <- matched %>%
    group_by(gender.num, doiy, age, matching_vars,matching_spec, pair) %>%
    dplyr::mutate(match_bin = cur_group_id()) %>%  # unique id for each matched pair within each bin
    ungroup()
  
  # separate childless and parent obs
    # remove vars from childless df that we will be getting from parent they were matched to instead
  matched_childless <- matched %>%
    filter(child == 0) %>%
    subset(select=-c(age1b,
                     ch1yob, yr5, yr10,yr5_reform, yr10_reform, post_reform,
                     ch1yob5, ch1yob10, yrimmig,ageimmig,race_raw,
                     white_hisp, black_hisp, white, black,immigrant,usmover,
                     bpl_state,bpl_country, ancestry,fbpl_name, mbpl_name,
                     metro, bpl_census, doiy_actual, age_actual, t_minus,
                     classwkr, agriculture, industry))
  
  
    # extract obs for their matched parent, replace their value of some vars with values from matched person
  
  matched_child <- matched %>%
    subset(child == 1) %>%
    subset(select=c(age1b,match_bin,
                    doiy_actual,doby,ch1yob, yr5, yr10,yr5_reform, yr10_reform, post_reform,
                    ch1yob5, ch1yob10, yrimmig,ageimmig,race_raw,ancestry,
                    white_hisp, black_hisp, white, black,immigrant,usmover,
                    bpl_state,bpl_country, fbpl_name, mbpl_name,
                    metro,bpl_census, wgt, id, classwkr, agriculture, industry)) %>%
    dplyr::rename(match_wgt = wgt,
                  match_id = id,
                  match_doby = doby,
                  match_doiy = doiy_actual)
  
  # create indicator that parent was matched to a person n years younger, n years before
    # (we are taking the data from the matching function which dropped any bins
    # where we had parents but no possible childless matches)
    # so any parents we have here were definitely matched to someone
    # "t_minus" indicates which event time this match was for
    # since many parents will be matched at some but not all event times
  
  indicator_matched <- subset(matched, child == 1) %>%
    subset(select=c(doiy_actual, month, serial, pernum, id, t_minus)) %>% 
    mutate(matched = 1) %>%
    pivot_wider(names_from = c(t_minus), values_from = matched, names_prefix="matched") %>%
    mutate(across(contains("matched"), ~ifelse(is.na(.), 0, 1))) %>%
    rename(doiy = doiy_actual)
  
  # add to df of parents: will be NA for everyone except people with eldch == 0
  df_child <- subset(df, child == 1) %>%
    merge(indicator_matched, by=c("doiy", "month", "serial", "pernum", "id"), all.x=T) %>%
    # replaces matched indicators as 0 for people with child aged 0 who weren't matched to someone
      # these vars will be missing for anyone who is childless or not with eldch == 0
    mutate(across(contains("matched"), ~ifelse(is.na(.) & eldch == 0, 0, .))) %>%
    # fake matching weight for parents
    mutate(wgt_match = 1)
  
  # merge childless obs with df with info from parents we want
  matched_final <- merge(matched_childless,matched_child, by="match_bin",all.x=T) 
  
  # combine the childless obs with the true parents rather than the 5 fake obs we created for matching
  matched_final <- bind_rows(matched_final,df_child)
  
  # apply sample restrictions, clean up df
  matched_final <- matched_final %>%
    mutate(sample_childless = ifelse(inrange(age1b, min.age, max.age) & child == 0,1, 0)) %>%
    mutate(sample = ifelse(sample_childless == 1 | (child == 1 & inrange(age1b,min.age,max.age)), 1, 0)) %>%
    subset(select=-c(matching_spec,matching_vars,gender.num,race.num,marst.num,edlevel.num, match_bin, statefip.num, stateagg.num, pair)) %>%
    mutate(wgt_original = wgt) %>%
    mutate(match_wgt = ifelse(child==0 & sample_childless == 1, match_wgt, wgt),
           match_id = ifelse(child==0 & sample_childless == 1, match_id, id),
           match_doby = ifelse(child==0 & sample_childless == 1, match_doby, doby),
           match_doiy = ifelse(child==0 & sample_childless == 1, match_doiy, doiy),
          # redefine regression weights for childless people to take matching into account
           wgt = ifelse(child == 0 & sample_childless ==1, wgt_match*wgt, wgt))
  
  # create event time
  if(grepl("lw",tvar)){
    matched_final <- matched_final %>%
      mutate(eldch = as.numeric(unclass(eldch))) %>% 
      # define event time
      mutate(t_temp = as.numeric(case_when(child == 1 ~ eldch,
                                           child == 0 & (age - age1b != 0) ~ age - age1b,
                                           child == 0 & (age - age1b == 0) ~ NA_real_)))
    suffix <- "lw"
  } else {
    matched_final <- matched_final %>%
      mutate(eldch = as.numeric(unclass(eldch))) %>% 
      # define event time
      mutate(t_temp = as.numeric(case_when(child == 1 & inrange(eldch, 1, 98) ~ eldch - 1,
                                           child == 0~ age - age1b - 1)))
    suffix <- "ly"
    
  }
  
  matched_final <- matched_final %>%
    # cap event times - 6 and 11
    mutate(t_temp = case_when(t_temp<=-6 ~ NA_real_,
                              t_temp>=11 ~ NA_real_,
                              TRUE ~ t_temp)) %>%
    # convert to factor
    mutate(t_temp = as.factor(t_temp)) %>%
    # set -2 as first factor to omit it
    within(t_temp <- relevel(t_temp, ref = ref)) %>% 
    drop_na(t_temp) %>%
    # post variable
    mutate(post_temp = fct_collapse(t_temp, pre = c("-5", "-4", "-3", "-2","-1"), 
                                    post = c("0", "1", "2", "3","4", "5", "6", "7", "8", "9", "10")))
  
  # rename event time vars based on annual vs weekly matching
  matched_final[tvar] <- matched_final["t_temp"]
  matched_final[paste0("post_",suffix)] <- matched_final["post_temp"]
  
  matched_final <- matched_final %>%
    subset(select=-c(t_temp, post_temp))
  
  assign({{name}},matched_final)
  return(matched_final)
}

###################################################################
# 3. Function to create entire pseudo-panel with fn_match
# embedded within
###################################################################

fn_pseudo_panel <- function() {
  
  print(Sys.time())
  
  # Load CPS
  load(file.path(cleandir,"cps_clean.RData"))
  cps <- subset(cps, doiy < 2021)
  
  
  # define vector of vars we want to use in matching
  matchvars <- c("doiy", "age", "gender.num", "edlevel.num", "marst.num", "race.num", "statefip.num")
  
  # Match CPS monthly files and CPS march files separately
  cps_earn_matched <- fn_match(df=cps, name="cps_earn", tvar="t_es_ly", matchvars={{matchvars}})
  cps_matched <- fn_match(df=cps, name="cps", tvar="t_es_lw", matchvars={{matchvars}})
  
  # DF of CPS 1995-1999 with non-missing earnings obs to match ACS 2000-2004 to
  cps_merge <- cps %>%
    filter(child == 0 & inrange(doiy, 1995,1999)) %>%
    subset(select = -c(dataset)) %>%
    mutate(dataset = as.factor("ACS")) %>%
    mutate(dataset = factor(dataset, levels = c("CPS", "ACS", "NLSY79", "PSID"))) %>%
    mutate(from_cps = 1) 
  
  # Load ACS
  load(file.path(cleandir,"acs_clean.RData"))
  
  # Combine with CPS 1995-99
  acs <- bind_rows(cps_merge,acs)
  rm(cps, cps_merge)
  
  # Match ACS earnings and weekly emp samples separately
  acs_matched <- fn_match(df=acs, name="acs", tvar="t_es_lw", matchvars={{matchvars}})
  acs_earn_matched <- fn_match(df=acs, name="acs_earn", tvar="t_es_ly", matchvars={{matchvars}})
  
  # Create stacked pseudo-panel with annual and weekly samples together
  cps_acs <- bind_rows(acs_matched, cps_matched) %>%
    mutate(matching_sample = "Weekly") %>%
    bind_rows(cps_earn_matched) %>%
    bind_rows(acs_earn_matched) %>%
    mutate(matching_sample = ifelse(is.na(matching_sample),"Annual",as.character(matching_sample)))
  
  # clean up df
  # re-order education levels    
  cps_acs$edlevel <- factor(cps_acs$edlevel, levels=c("Below HS", "HS grad", "Some college",
                                                      "College +"))
  
  # Drop people outside event time range for both earnings and weekly emp
  cps_acs <- cps_acs %>%
    filter(!(is.na(t_es_lw) & is.na(t_es_ly)))
  
  # Converting variables to factors
  cps_acs <- cps_acs %>%
    mutate(bpl_census = as.factor(as.character(bpl_census)),
           ancestry = as.factor(as.character(ancestry)),
           usmover = as.factor(as.character(usmover)),
           immigrant = as.factor(as.character(immigrant)),
           bpl_state = as.factor(as.character(bpl_state)),
           mbpl_name = as.factor(as.character(mbpl_name)),
           fbpl_name = as.factor(as.character(fbpl_name))) %>%
    subset(select=-c(from_cps))
  
  
  # label variables
  cps_acs <- apply_labels(cps_acs, earnings_ly = "Earnings", emp_lw = "Weekly Employment", 
                          earn_ly = "Annual Employment", t_es_lw = "Event Time (Weekly)",
                          t_es_ly = "Event Time (Annual)",wgt_original="Survey Weight",
                          wgt_match = "Weight from Matching", doiy = "Year of Interview",
                          wgt = "Combined Survey and Matching Weight", id = "Unique Identifier",
                          statefip = "State of Residence (FIPS)", statename = "State of Residence",
                          stateagg = "State of Residence Groups",
                          age1b = "Age at First Birth", ch1yob = "Year of Birth of Oldest Child",
                          child = "Indicator for Parents", fbpl_name = "Father's Place of Birth",
                          mbpl_name = "Mother's Place of Birth", bpl_census = "Census Division of Birth",
                          bpl_country = "Country of Birth", census = "Census Division of Residence",
                          yrimmig = "Year of Immigration", ageimmig = "Age at Immigration",
                          region = "Census Region of Residence",
                          white = "Indicator for White, non-hispanic",
                          black = "Indicator for Black, non-hispanic",
                          white_hisp = "Indicator for White",
                          black_hisp = "Indicator for Black", hispanic="Indicator for Hispanic",
                          eldch = "Age of Oldest Child", edlevel = "Education Level",
                          marst = "Marital Status", ancestry = "Country of Ancestry",
                          mbpl_name = "Mother's Country of Birth",
                          fbpl_name = "Father's Country of Birth", classwkr = "Self-Employed", 
                          agriculture = "Agricultural Worker", industry = "Industrial Worker",
                          hrs_ly = "Hours Worked")
  
  # Reorder some factors
  cps_acs$yr5 <- fct_reorder(cps_acs$yr5, cps_acs$match_doiy)
  cps_acs$yr10 <- fct_reorder(cps_acs$yr10, cps_acs$match_doiy)
  
  cps_acs <- cps_acs %>%
    mutate(ch1yob10 = as_factor(case_when(inrange(ch1yob, 1972, 1979) ~ "1972-79",
                                          inrange(ch1yob, 1980, 1989) ~ "1980-89",
                                          inrange(ch1yob, 1990, 1999) ~ "1990-99",
                                          inrange(ch1yob, 2000, 2009) ~ "2000-09",
                                          inrange(ch1yob, 2010, 2021) ~ "2010-20"))) %>%
    mutate(ch1yob5 = floor(ch1yob/5)*5)
  
  cps_acs$ch1yob10 <- fct_reorder(cps_acs$ch1yob10, cps_acs$ch1yob)
  
  
  cps_acs <- cps_acs %>%
    mutate(race = ifelse(race == "Other, non-hispanic", "Other", as.character(race)))
  cps_acs$race = factor(cps_acs$race, # re-order levels
                        levels=c("Black, non-hispanic", "White, non-hispanic",
                                 "Hispanic", "Other"))
  
  cps_acs <- cps_acs %>%
    mutate(hsandbelow = as.factor(ifelse(edlevel %in% c("Below HS", "HS grad"), "Low-Educated", "High-Educated")))
  cps_acs$hsandbelow = factor(cps_acs$hsandbelow, # re-order levels
                              levels=c("Low-Educated","High-Educated"))
  cps_acs$married = factor(cps_acs$married, # re-order levels
                           levels=c("Single","Married"))
  
  
  # Save file
  saveRDS(cps_acs, file=file.path(wrkdir,paste0("cps_acs_pseudo-panel.rds")))
  
  return(cps_acs)
}

###################################################################
# 4. Run matching
###################################################################

fn_pseudo_panel()
