#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file uses CPS/ACS to estimate averages for some demographic
# variables by state and time which are eventually used as controls in Figure 11

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Load CPS/ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

# Define vector of outcome vars to run functions over
l.depvars <- c("earnings_ly", "emp_lw","earn_ly")

# Create numeric variables for some controls to easily take means over
cps_acs <- cps_acs %>%
  mutate(frac_married = ifelse(married == "Married", 1,0)) %>%
  mutate(hsandbelow = ifelse(edlevel %in% c("Below HS","HS grad"), 1,0)) %>%
  mutate(college = ifelse(edlevel == "College +",1,0))

  # Functions to get avg of controls within specific outcome var sample
get_controls <- function(data, depvar) {
  
  data["depvar"] = data[{{depvar}}]
  if(!grepl("pooled",depvar)){
    data["t_es"] = data[paste0("t_es_",substr({{depvar}}, nchar({{depvar}})-1, nchar({{depvar}})))]
  }
  
  data <- data %>%
    drop_na(depvar, age_factor, doiy_factor, t_es)
  
  # use all women
  data <- data %>%
    filter(gender == "Women")

# get fractions
  
    # Fraction hs or below and fraction college or above
  edcounts <- data %>%
    group_by(statename, yr10) %>%
    summarize(hsandbelow = weighted.mean(hsandbelow,wgt),
           college = weighted.mean(college,wgt))
  
    # Fraction women who are single
  marcounts <- data %>%
    group_by(statename, yr10) %>%
    summarize(frac_married = weighted.mean(frac_married, wgt))
  
    # Average age at first birth among all parents
  age1bavg <- data %>%
    filter(child == 1) %>%
    group_by(statename, yr10) %>%
    summarise(mean_age1b = mean(age1b),
              wgt_mean_age1b = weighted.mean(age1b, wgt))
  
    # Fraction black and white
  raceavg <- data %>%
    group_by(statename, yr10) %>%
    summarise(white_hisp= weighted.mean(white_hisp, wgt),
              black_hisp = weighted.mean(black_hisp, wgt))
  
  controls <- merge(marcounts, age1bavg, by=c("statename","yr10")) %>%
    merge(raceavg, by=c("statename","yr10")) %>%
    merge(edcounts, by=c("statename","yr10")) %>%
    mutate(yr10 = ifelse(yr10 == "1973-79", "1972-79", as.character(yr10))) %>%
    mutate(depvar={{depvar}})

}

# Save and get controls
controls <- setDF(rbindlist(lapply(l.depvars, get_controls, data=subset(cps_acs, statefip < 57))))

saveRDS(controls, file=file.path(wrkdir, "gss_controls_from_pseudo-panel.rds"))
