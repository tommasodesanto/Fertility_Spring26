#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates the heatmap of gender norms by state in Figure 9

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Function to create heatmap ------------------------
fn_stmap <- function(var) {
  
  # collapsed data for map ;
  
  stlevel <- gss %>% 
    mutate(varmean = !!sym(var)) %>%
    subset(select=c(statename, fips, varmean))
  
  # split gpi into deciles
  stlevel$decile <- ntile(stlevel$varmean,n=10)
  
  # calculate min and max gpi within each decile for legend labels
  stlevel <- stlevel %>%
    group_by(decile) %>% 
    mutate(min_group = min(varmean), max_group=max(varmean)) %>% 
    ungroup()
  
  max <- stlevel %>% 
    group_by(decile) %>% 
    summarise(max=mean(min_group))%>% 
    mutate(decile=dplyr::lag(decile))
  
  stlevel <- stlevel %>% 
    merge(max, by="decile", all.x=T)%>% 
    mutate(max_group = if_else(decile!=10, max, max_group)) %>% 
    mutate(lab = paste0(as.character(format(round(min_group,2), nsmall=2))," to "
                        , as.character(format(round(max_group,2), nsmall=2))))
  
  # Order the decile variable 
  vec <- stlevel %>% 
    group_by(decile, lab) %>% 
    summarise() %>% 
    arrange(decile) %>% 
    ungroup %>% 
    pull(lab)
  
  stlevel <- stlevel %>% 
    mutate(lab=factor(lab, levels =rev(vec)))  %>% 
    filter(!is.na(decile))
  
  # define colors to use in heatmap
  mycolors <- c('#ffffff','#ffffcc','#ffeda0','#fed976','#feb24c'
                ,'#e67016','#fc4e2a','#e31a1c','#bd0026','#800026')
  
  # map data
  heatmap <- plot_usmap(data = stlevel, values = "lab", labels = T) +
    scale_fill_manual(values=mycolors, name = "Gender Progressivity Index", guide = guide_legend(reverse = FALSE)) +
    theme(legend.key = element_rect(color="white"),
          legend.text = element_text(size=12),
          legend.key.size = unit(0.7, 'cm'))
  
  plot(heatmap)
  
  ggsave(paste0("gss_heatmap",".pdf"), path = file.path(outdir,"Figures"), width = 11, height = 8, units = "in")
  
  return(heatmap)
  
}


# load imputed GSS data collapsed by state
gss <- read_rds(file.path(wrkdir, "gss_imputed_state.rds"))  

# Create and Save Heatmap ----------------------------

lapply(c("index_ad"), fn_stmap)
