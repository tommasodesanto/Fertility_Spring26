#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates Figure A.23
# (Event Studies by Education for Immigrants)

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Define vector of outcome vars to run functions over
l.depvars <- c("emp_lw","earn_ly")

# Load CPS and ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

# Redefine hsandbelow dummy to re-order levels
cps_acs <- cps_acs %>%
  mutate(hsandbelow = as.factor(ifelse(edlevel %in% c("Below HS", "HS grad"), "Low-Educated", "High-Educated")))

# Keep immigrants only
cps_acs <- cps_acs %>%
  filter(immigrant == "Immigrant")

# Run event studies for Panels A and B
lapply(l.depvars, reg_es_immigrant_edu, data = subset(cps_acs, edlevel != "Some college"), 
       hetero = "hsandbelow", plotname="epidemiological_immigrants_child_penalties_educ")

# Prep pooled employment data for Panel C
pooled_data <- cps_acs %>%
  mutate(pooled_employment = ifelse(!is.na(t_es_ly) & !is.na(earn_ly), 
                                    earn_ly, emp_lw),
         t_es = as.factor(ifelse(!is.na(t_es_ly) & !is.na(earn_ly), 
                                 as.character(t_es_ly), as.character(t_es_lw))))
pooled_data <- apply_labels(pooled_data, pooled_employment="Employment")

pooled_data$t_es = factor(pooled_data$t_es, # re-order levels
                   levels=c("-2","-5", "-4", "-3", "-1",
                            "0", "1", "2", "3","4", "5", "6",
                            "7", "8", "9", "10"))

# Create Panel C
reg_es_immigrant_edu(data = subset(pooled_data, edlevel != "Some college"), depvar = "pooled_employment", 
                       hetero = "hsandbelow", plotname="epidemiological_immigrants_child_penalties_educ")
