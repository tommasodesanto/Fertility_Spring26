#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file contains all the main functions used to produce event study
# regressions and plots used in the paper

#############################################################################################

###############################################################
# 1. Function to clear labeled class

# use whenever issues with haven class and appending datasets occur

###############################################################

clear.labels <- function(x) {
  if(is.list(x)) {
    for(i in seq_along(x)) {
      class(x[[i]]) <- setdiff(class(x[[i]]), 'labelled') 
      attr(x[[i]],"label") <- NULL
    } 
  } else {
    class(x) <- setdiff(class(x), "labelled")
    attr(x, "label") <- NULL
  }
  return(x)
}


#####################################################
# 2. reg_es_setup

# Cleans data and preps it for regression(s)
# Used in reg_es and reg_es_immigrant

#####################################################

reg_es_setup <- function(data, depvar, splitvar = "", appendix = F) {
  
  #Drop levels
  data <- droplevels(data)
  
  # Re-define dependent variable
  data["depvar"] = data[{{depvar}}]
  
  # Graph labels
  if({{depvar}}=="earn_ly"){
    depvarlbl <<- "emp_annual"
  }
  if({{depvar}}=="emp_lw"){
    depvarlbl <<- "emp_weekly"
  }
  if({{depvar}}=="earnings_ly"){
    depvarlbl <<- "earnings"
  }
  if(grepl("pooled",depvar)){
    depvarlbl <<- "emp_pooled"
  }
  
  # Use corresponding event time except for pooled employment
  if (!grepl("pooled",depvar)) {
    data["t_es"] = data[paste0("t_es_",substr({{depvar}}, nchar({{depvar}})-1, nchar({{depvar}})))]
  }
  
  # Keep sample of interest only
  data <- data %>%
    drop_na(depvar, age_factor, doiy_factor, t_es) %>%
    filter(wgt!=0) %>%
    droplevels()
  
  # Use when splitting sample using lapply(split) to iterate over diff levels
  if (splitvar != "") {
    # Define var sample is split by
    data["splitvar"] <- data[{{splitvar}}]
    # Drop other levels
    data <- data %>%
      droplevels()
    print(levels(data$splitvar)[1])
  }
  
  # Smaller text size for appendix graphs
  if (appendix) {
    textsize <<- 10
  } else {
    textsize <<- 11
  }
  
  return(data)
}


###################################################
# 3. coef_es

# Takes event study regression as given and
# estimates counterfactuals and adjusts coefficients
# Used in reg_es, reg_es_immigrant, reg_es_demographics,
# reg_es_immigrant_edu, and event studies by fertility

###################################################


coef_es <- function(data, reg) {
  
  # Prediction omitting the contribution of event times
  data$prearn = reg$sumFE
  
  # Average counterfactual within event time and gender
  grid <- aggregate(prearn  ~  t_es + gender, data = subset(data, t_es != ref) , mean)
  
  #Weight counterfactuals by matching weights
  grid_weighted <- subset(data, t_es != ref) %>%
    group_by(gender, t_es) %>%
    summarize(prearn = weighted.mean(prearn, wgt_match))
  
  # Use desired weighting for counterfactuals
  grid <- grid %>%
    subset(select=-c(prearn)) %>%
    merge(grid_weighted, by=c("gender","t_es"))
  
  
  # Divide coefs by counterfactuals to get child penalty
  reg.coefs <- as.data.frame(tidy(reg)) %>%
    mutate(t_es=gsub("t_es","",term)) %>%
    merge(grid, by="t_es") %>%
    mutate(across(c(estimate,std.error),~./prearn))
  
  # Get 95% confidence intervals
  reg.coefs <- reg.coefs %>%
    mutate(conf.low = estimate + qnorm(0.025, 0, 1)*std.error,
           conf.high = estimate + qnorm(0.975, 0, 1)*std.error) %>%
    subset(select=c(t_es,gender,estimate,conf.low,conf.high))
  
  # Clean up coef dataframe
  omitted <- data.frame(t_es=ref, gender = levels(data$gender), 
                        estimate = 0, conf.low = 0, conf.high = 0)
  coef <- rbind(reg.coefs, omitted) # add omitted event time
  
  # Re-order levels
  coef$t_es = factor(coef$t_es,
                     levels=c("-5", "-4", "-3", "-2", "-1",
                              "0", "1", "2", "3","4", "5", "6",
                              "7", "8", "9", "10"))
  
  # Add variable label to df
  coef$depvar_lab = var_label(data$depvar)
  
  return(coef) # return coefficients
  
}



#####################################################
# 4. reg_es_end

# Calculates child penalty and produces event study plots 
# for men and women across an entire sample
# Used in reg_es and reg_es_immigrant

#####################################################

reg_es_end <- function(coef, data, depvar, plotname = "", export = T, splitvar = "", 
                       appendix = F, preadjust = T) {
  
  # calculate child penalty
  coef <- coef %>%
    mutate(post = ifelse(t_es %in% c("-5","-4","-3","-2","-1"), 0, 1))
  
  if (preadjust) { # penalty = post - pre coefs for women relative to men
    
    post_mean <- aggregate(estimate ~  gender+post, 
                           data=coef ,
                           mean)
    post_mean <- post_mean %>%
      spread(post, estimate) %>%
      mutate(estimate=`1`-`0`)
    
    penalty <- post_mean %>%
      subset(select=-c(`1`,`0`)) %>%
      spread(gender, estimate) %>%
      mutate(estimate = `Men` - `Women`) %>%
      subset(select=c(estimate))
    
  } else { # penalty = post period coefs for women relative to men
    
    post_mean <- aggregate(estimate ~  gender, 
                           data=subset(coef, t_es %in% c("0", "1", "2", "3", "4", "5","6", "7", "8", "9", "10")) ,
                           mean)
    penalty <- data.frame(estimate = subset(post_mean, gender == "Men")$estimate - subset(post_mean, gender == "Women")$estimate)
    
  }
  # Clean up dfs
  penalty$depvar = var_label(data$depvar)
  coef$gender <- factor(coef$gender,levels=c("Women","Men")) # Ensure that Men are drawn above Women
  coef <- coef[order(coef$gender, coef$t_es),]
  coef$depvar <- {{depvar}}
  
  # y-axis label 
  if(depvar == "emp_lw"){
    ylab <- "Weekly Employment"
  }
  if(depvar == "earnings_ly"){
    ylab <- "Earnings"
  }
  if(depvar == "earn_ly"){
    ylab <- "Annual Employment"
  }
  if(depvar == "pooled_employment"){
    ylab <- "Employment"
  }
  
  # if using lapply split to iterate many times
  if (splitvar != "") {
    coef <- coef %>%
      mutate(hetero = levels(data$splitvar)[1]) %>%
      mutate(penalty = mean(penalty$estimate))
    plotname <- paste0(plotname,"_",levels(data$splitvar)[1])
    penalty <- penalty %>%
      mutate(hetero = levels(data$splitvar)[1])
  }
  
  if (export) { # export graphs
    
    # plot
    plot <- ggplot(coef, aes(y=estimate, x=t_es, color=gender, group=gender)) + 
      # add confidence intervals
      geom_ribbon(aes(ymin=conf.low,ymax=conf.high,fill=gender),alpha=0.3,show.legend = F,
                  colour = NA) +
      # connect points
      geom_line(linewidth=1) +
      # point sizes
      geom_point(size=4) +
      # x-axis
      scale_x_discrete(labels=as.character(coef$t_es),breaks=coef$t_es)+
      # y-axis
      scale_y_continuous(labels=c("-0.8","-0.6","-0.4","-0.2","0.0",
                                  "0.2","0.4"),
                         breaks=seq(-0.8, 0.4, by=0.2))+# axis labels
      coord_cartesian(ylim = c(-0.8, 0.45))+
      # axis labels
      labs(x="Event Time (Years)", y=paste(ylab,"Impact (%)")) +
      # add red line at t=-0.5
      geom_vline(xintercept = 5.5, linetype="solid", color = "#D11809",linewidth=1.2) +
      # label next to line
      geom_text(aes(x=6.9,
                    label="First Child",y=0.45),
                size=8.5,color="grey25",check_overlap=T)+
      # white background
      theme_minimal() +
      # theme
      theme(axis.line = element_line(colour = "black"), # axis lines
            panel.grid.major.x = element_blank(),
            panel.grid.minor.y = element_blank(),
            legend.position = "bottom", # legend
            legend.key.size = unit(3,"lines"),
            text=element_text(size=25), # text size
            axis.text.x = element_text(vjust = -0.5),
            axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)),
            axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)))+
      # line color and legend labels
      scale_color_manual(name="",
                         breaks=c("Men","Women"),
                         values=c("Women"=rgb(193,5,52, maxColorValue = 255),"Men"="black"),
                         labels=c("Men","Women")) +
      scale_fill_manual(values=c("Women"=rgb(193,5,52, maxColorValue = 255),"Men"="black"),
                        breaks=c("Men","Women"),
                        name="")+
      # child penalty text
      annotate("text",x=13, y=-0.7, label=paste0("Child Penalty",": " ,round(penalty$estimate*100), "%"),fontface=2,size=textsize)
    
    #save 
    ggsave(paste0(plotname,"_",depvarlbl, ".pdf"), plot=last_plot(), device="pdf",
           width=11, height=8, units="in",path=file.path(outdir,"Figures"))
    
  }
  
  
  return(coef) # return all event time coefs
  
  
}


#####################################################
# 5. reg_es

# Produces event study plots for men and women
# across an entire sample
# reg_es_setup, coef_es, and reg_es_end are embedded within
# Used for Fig 1, 2, and A.1-A.3

#####################################################

reg_es <- function(data, depvar, plotname = "", export = T, splitvar = "", appendix = F,
                       preadjust = T) {
  
  #Run setup function
  data <- reg_es_setup(data = {{data}}, depvar = {{depvar}}, splitvar = {{splitvar}}, appendix = {{appendix}})
  
  #Empty dataframe to store results for men and women
  coef <- data.frame()
  
  for (i in c("Women", "Men")){
    reg_data <- subset(data, gender == i) %>%
      droplevels()
    
    # Regression
    reg <- feols(depvar ~ t_es | age_factor + doiy_factor, 
                 data =reg_data, weights=~wgt, se = "hetero")
    
    # Estimate counterfactuals and adjust coefficients
    # Append results to dataframe
    coef <- bind_rows(coef, coef_es(data = {{reg_data}}, reg = {{reg}}))
  }
  
  #Calculate child penalty and export graph
  coef <- reg_es_end(coef = {{coef}}, data = {{data}}, depvar = {{depvar}}, plotname = {{plotname}},
             export = {{export}}, splitvar = {{splitvar}}, appendix = {{appendix}},
             preadjust = {{preadjust}})
  
  return(coef)
  
}

################################################################

# 6. reg_es_hetero_setup

# Cleans data and preps it for regression(s) with hetero variable
# Used in reg_es_hetero, reg_es_movers,
# reg_es_demographics, reg_es_immigrant_edu, and reg_es_state

################################################################

reg_es_hetero_setup <- function(data, depvar, hetero) {
  
  ## clean up data, add interactions
  
  data["depvar"] = data[{{depvar}}]
  data["hetero"] = data[{{hetero}}] 
  if(!grepl("pooled",depvar)){
    data["t_es"] = data[paste0("t_es_",substr({{depvar}}, nchar({{depvar}})-1, nchar({{depvar}})))]
  }
  
  # Graph labels
  if({{depvar}}=="earn_ly"){
    depvarlbl <<- "emp_annual"
  }
  if({{depvar}}=="emp_lw"){
    depvarlbl <<- "emp_weekly"
  }
  if({{depvar}}=="earnings_ly"){
    depvarlbl <<- "earnings"
  }
  if(grepl("pooled",depvar)){
    depvarlbl <<- "emp_pooled"
  }
  
  # create interactions for event studies
  data <- data %>%
    drop_na(depvar, age_factor, doiy_factor, t_es, hetero)  %>%
    mutate(age_het = interaction(age_factor, hetero)) %>%
    mutate(doiy_het = interaction(doiy_factor, hetero))
  
  data <- droplevels(data)
  
  return(data)
  
}


######################################################
# 7. coef_es_hetero

# Takes event study regression as given (where it is interacted by some var
# that we want separate event studies for)
# estimates counterfactuals and adjusts coefficients 
# Used in reg_es_hetero, reg_es_movers,
# reg_es_demographics, reg_es_immigrant_edu, and reg_es_state

######################################################


coef_es_hetero <- function(data, reg, return_coef="coef") {
  
  data$prearn = reg$sumFE #prediction
  
  #grid of counterfactual earnings by event time, hetero, and gender
  grid <- aggregate(prearn  ~  t_es + hetero + gender, 
                    data=subset(data, t_es != ref) , mean)
  
  # weight the counterfactuals my matching weight
  grid_weighted <- subset(data, t_es != ref) %>%
    group_by(gender, hetero,t_es) %>%
    summarize(prearn = weighted.mean(prearn, wgt_match))
  
  grid <- grid %>%
    subset(select=-c(prearn)) %>%
    merge(grid_weighted, by=c("gender","hetero","t_es"))
  
  if (return_coef=="coef") {
    
    # clean up df to add event time and hetero
    reg.coefs <- as.data.frame(tidy(reg))%>%
      mutate(hetero = gsub(".*hetero(.+):.*", "\\1", term)) %>%
      mutate(t_es = sub(".*t_es","",term))
    
    # merge with counterfactuals, do adjustment
    coef <- reg.coefs %>%
      merge(grid,by=c("t_es","hetero"))  %>%
      mutate(across(c(estimate,std.error),~./prearn)) %>%
      mutate(conf.low = estimate + qnorm(0.025, 0, 1)*std.error,
             conf.high = estimate + qnorm(0.975, 0, 1)*std.error) %>%
      subset(select=c(t_es,hetero,gender,estimate,conf.low,conf.high, std.error))
    
    
    # clean up coef dataframe
    omitted <- data.frame(t_es=ref, hetero = levels(data$hetero), 
                          gender = as.factor(ifelse(data$gender[1] == "Women", "Women", "Men")), 
                          estimate = 0, conf.low = 0, conf.high = 0, std.error = 0)
    coef <- coef %>% #exclude prearn column
      rbind(., omitted) # add omitted event time
    
    
    coef$t_es = factor(coef$t_es, # re-order levels
                       levels=c("-5", "-4", "-3", "-2", "-1",
                                "0", "1", "2", "3","4", "5", "6",
                                "7", "8", "9", "10"))
    
    return(coef)
  }
  
  if (return_coef=="unadjust") { # to get unadjusted child penalties 
    
    # clean up df to add event time and hetero
    reg.coefs <- as.data.frame(tidy(reg))%>%
      mutate(hetero = gsub(".*hetero(.+):.*", "\\1", term)) %>%
      mutate(t_es = sub(".*t_es","",term))
    
    # merge with counterfactuals, do adjustment
    coef <- reg.coefs %>%
      merge(grid,by=c("t_es","hetero"))  %>%
      mutate(conf.low = estimate + qnorm(0.025, 0, 1)*std.error,
             conf.high = estimate + qnorm(0.975, 0, 1)*std.error) %>%
      subset(select=c(t_es,hetero,gender,estimate,conf.low,conf.high))
    
    
    # clean up coef dataframe
    omitted <- data.frame(t_es=ref, hetero = levels(data$hetero), 
                          gender = as.factor(ifelse(data$gender[1] == "Women", "Women", "Men")), 
                          estimate = 0, conf.low = 0, conf.high = 0)
    coef <- coef %>% #exclude prearn column
      rbind(., omitted) # add omitted event time
    
    
    coef$t_es = factor(coef$t_es, # re-order levels
                       levels=c("-5", "-4", "-3", "-2", "-1",
                                "0", "1", "2", "3","4", "5", "6",
                                "7", "8", "9", "10"))
    
    return(coef)
  }
  
  if (return_coef=="cf") { # return counterfactuals for mothers
    cf <- data %>%
      filter(t_es %in% c("0", "1", "2", "3", "4", "5","6", "7", "8", "9", "10")) %>%
      group_by(gender,hetero) %>%
      dplyr::summarise(mean_cf = mean(prearn))
    
    return(cf)
  }
}


################################################################

# 8. reg_es_hetero_end

# Calculates child penalty and exports plots for event studies
# with a hetero variable
# Used in reg_es_hetero and reg_es_movers

################################################################

reg_es_hetero_end <- function(coef, data, depvar, hetero, export = T, plotname = "",
                              scale = 0.5, return_final = "coef", preadjust = T) {
  
  # Penalty calculation
  coef <- coef %>%
    mutate(post = ifelse(t_es %in% c("-5","-4","-3","-2","-1"), 0, 1))
  
  if(preadjust) { # penalty = post - pre coefs for women relative to men
    
    post_mean <- aggregate(estimate ~  gender+post+hetero, 
                           data=coef ,
                           mean)
    post_mean <- post_mean %>%
      spread(post, estimate) %>%
      mutate(estimate=`1`-`0`)
    
    penalty <- post_mean %>%
      subset(select=-c(`1`,`0`)) %>%
      spread(gender, estimate) %>%
      mutate(estimate = `Men` - `Women`) %>%
      subset(select=c(hetero,estimate)) %>%
      mutate(depvar = {{depvar}},
             depvar_lab = var_label(data$depvar))
    
  } else { # penalty = post period coefs for women relative to men
    
    post_mean <- aggregate(estimate ~  gender + hetero, 
                           data=subset(coef, t_es %in% c("0", "1", "2", "3", "4", "5","6", "7", "8", "9", "10")) ,
                           mean)
    penalty <- post_mean %>%
      spread(gender, estimate) %>%
      mutate(estimate = `Men` - `Women`) %>%
      subset(select=c(hetero,estimate)) %>%
      mutate(depvar = {{depvar}},
             depvar_lab = var_label(data$depvar))
    
  }
  
  # Prep plot
  coef <- coef %>%
    mutate(hetero = as.factor(as.character(hetero)))
  
  coef$gender <- factor(coef$gender,levels=c("Women","Men")) # Ensure that Men are drawn above Women
  coef <- coef[order(coef$hetero, coef$gender, coef$t_es),] # sort by hetero, gender, time
  # label for of nobs in each hetero panel
  lab <- data.frame(x = rep("10", length(levels(coef$hetero))), # x is in levels, needs quotes
                    y = rep(-.8, length(levels(coef$hetero))), 
                    dplyr::count(coef, hetero))
  lab$n = comma(lab$n, big.mark = ",")
  lab <- merge(lab, penalty, by=c("hetero"))
  lab$txt = sprintf("Child Penalty: %1.0f%%", (lab$estimate)*100)
  
  penalty <- penalty %>%
    mutate(depvar = {{depvar}},
           depvar_lab = var_label(data$depvar))
  
  if(export){
    
    # plot levels separately
    
    for(st in levels(data$hetero)){
      
      # replace spaces and other unwanted chars in plot name
      stname <- gsub("\\+", "", st)
      if(hetero == "race"){
        stname <- sub("\\,.*","",stname)
      }
      
      # Labels, breaks, min, and max
      if(scale==0.4){
        mylabels <- c("-0.8","-0.6","-0.4","-0.2","0.0","0.2","0.4")
        mybreaks <- c(-0.8, -0.6, -0.4, -0.2, 0.0, 0.2, 0.4)
        ymin <- -0.8
        ymax <- 0.4
      }
      if(scale==0.5){
        mylabels <- c("-1.0","-0.5","0.0","0.5")
        mybreaks <- c(-1.0, -0.5, 0.0, 0.5)
        ymin <- -1
        ymax <- 0.5
      }
      
      # plot levels of hetero var
      ggplot(coef[coef$hetero==st,], aes(y=estimate, x=t_es, color=gender, group=gender))  + 
        # display all x values on axis
        scale_x_discrete(labels=as.character(coef[coef$hetero==st,"t_es"]), breaks=coef[coef$hetero==st,"t_es"])+
        # add confience intervals
        geom_ribbon(aes(ymin=conf.low,ymax=conf.high,fill=gender),alpha=0.3,show.legend = F,
                    colour = NA) +
        # line and point sizes
        geom_line(linewidth=1) + 
        geom_point(size=4) +
        # y-scale
        scale_y_continuous(labels = mylabels,breaks=mybreaks, limits=c(ymin,ymax+0.05))+
        # axis labels
        labs(x="Event Time (Years)", y=paste(var_label(data$depvar),"Impact (%)")) +
        # line at t=-0.5
        geom_vline(xintercept = 5.5, linetype="solid", color = "#D11809",linewidth=1.2) +
        # theme + grid lines
        theme_minimal() + 
        theme(axis.line = element_line(colour = "black",linewidth=0.4)) +
        theme(panel.grid.major.x = element_blank(),
              panel.grid.minor.y = element_blank(),
              legend.position = "bottom",
              panel.spacing = unit(-.2, "lines"),
              legend.key.size = unit(3,"lines")) +
        # label next to line
        geom_text(aes(x=6.9,
                      label="First Child",y=ymax+0.05),
                  size=8.5,color="grey25",check_overlap=T)+
        theme(axis.text.x = element_text(vjust = -0.5)
        ) +
        theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)),
              axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)))+
        theme(text=element_text(size=25)
        ) +
        # line color and legend labels
        scale_color_manual(name="",
                           breaks=c("Men","Women"),
                           values=c("Women"=rgb(193,5,52, maxColorValue = 255),"Men"="black"),
                           labels=c("Men","Women")) +
        scale_fill_manual(values=c("Women"=rgb(193,5,52, maxColorValue = 255),"Men"="black"),
                          breaks=c("Men","Women"),
                          name="")+
        # panel labels
        geom_text(aes(x, ymin+0.1, label=txt, group=NULL,fontface="bold"), size = 11, 
                  color = "black", hjust = 1, data=lab[lab$hetero==st,])
      ggsave(paste0(plotname, "_", stname, "_",{{depvarlbl}},".pdf"), plot=last_plot(), device="pdf",
             width=11, height=8, units="in",path=file.path(outdir,"Figures")) 
      
    }
    
  } 
  if(return_final=="penalty"){
    return(penalty)
  }
  if(return_final=="coef"){
    return(coef)
  }
}


################################################################

# 9. reg_es_hetero

# full function for event study plot by heterogeneity var
# reg_es_hetero_setup, coef_es_hetero, and reg_es_hetero_end are embedded within
# calculates penalty by hetero group
# generates separate plot for each level of hetero group
# return_final and return_coef together determine
# what the final output of the function is
# can be used to return event study coefficients, penalties,
# or counterfactuals
# Used for Figures 3, A.4-A.6, A.8-A.10, and A.11

################################################################

reg_es_hetero <- function(data, depvar, hetero, export = T, plotname = "",
                          scale = 0.5, return_final = "coef", return_coef = "coef",
                          preadjust = T) {
  
  #Run setup function
  data <- reg_es_hetero_setup(data = {{data}}, depvar = {{depvar}}, hetero = {{hetero}})
  
  # Empty dataframe to store results for men and women
  coef <- data.frame()
  
  if(return_coef %in% c("coef","unadjust")){ # return event study coefficients
    
    for (i in c("Men", "Women")){
      reg_data <- subset(data, gender == i) %>%
        droplevels()
      
      # Regression, interact age and year dummies w/ hetero var
      reg <- feols(depvar ~ hetero + t_es:hetero | age_het + doiy_het, data = reg_data, 
                   weights=~wgt, se="hetero")
      
      # Estimate counterfactuals and adjust coefficients
      # Append results to dataframe
      coef <- bind_rows(coef, coef_es_hetero(data = {{reg_data}}, reg = {{reg}}, return_coef={{return_coef}}))
      
    }
    
    # Add dependent variable label to dataframe
    coef <- coef %>%
      mutate(depvar = {{depvar}},
             depvar_lab = var_label(data$depvar))
    
    # Calculate child penalty and export graph
    coef <- reg_es_hetero_end(coef = {{coef}}, data = {{data}}, depvar = {{depvar}}, hetero = {{hetero}}, 
                              export = {{export}}, plotname = {{plotname}}, scale = {{scale}},
                              return_final = {{return_final}}, preadjust = {{preadjust}})
    
    return(coef)
  }
  
  if(return_coef == "cf"){ # return counterfactuals for women only
    
    #Regression
    reg_data <- subset(data, gender == "Women") %>%
      droplevels()
    
    # Regression, interact age and year dummies w/ hetero var
    reg <- feols(depvar ~ hetero + t_es:hetero | age_het + doiy_het, data = reg_data, 
                 weights=~wgt, se="hetero")
    
    cf_women <- coef_es_hetero(data = {{reg_data}},reg = {{reg}},return_coef="cf") %>%
      mutate(depvar = {{depvar}},
             depvar_lab = var_label(data$depvar))
    
    return(cf_women)
  }
}

######################################################
# 10. reg_es_state

# intermediate FE specification event studies
# used to estimate FE within census divisions
# in general can be used when we want to estimate
# FE over some other dimension rather than across
# the full sample or separately within all levels
# of some heterogeneity var
# reg_es_hetero_setup and coef_es_hetero are embedded within
# Used for Figures 4-7 and A.12-A.14

######################################################

reg_es_state <- function(data, depvar, hetero, interact, export = T, plotname = "",
                                   return_final = "all", return_coef = "coef") {
  
  #Run setup function
  data <- reg_es_hetero_setup(data = {{data}}, depvar = {{depvar}}, hetero = {{hetero}})
  
  # variable within which we want to interact fes
  data["interact"] = data[{{interact}}]
  
  if(return_coef %in% c("coef","unadjust")){
    
    #Empty dataframe to store results for men and women
    coef <- data.frame()
    
    # Run event studies for each gender and census division
    for (census_group in levels(data$interact)){
      for (i in c("Men", "Women")){
        # subset data for regression
        reg_data <- subset(data, interact == census_group & gender == i) %>%
          droplevels()
        
        # Regression
        # we estimate fixed effects over full sample rather than w/in group in state analysis
        reg <- feols(depvar ~ hetero + t_es:hetero | age_factor + doiy_factor, data = reg_data, 
                     weights=~wgt, se="hetero")
        
        # Estimate counterfactuals and adjust coefficients
        # Append results to dataframe
        coef <- bind_rows(coef, coef_es_hetero(data = {{reg_data}}, reg = {{reg}},
                                            return_coef = {{return_coef}}))
        
      }
    }
    
    # Add dependent variable labels
    coef <- coef %>%
      mutate(depvar_lab = var_label(data$depvar),
             depvar = {{depvar}})
    
    # penalty with pre-period adjustment
    coef <- coef %>%
      mutate(post = ifelse(t_es %in% c("-5","-4","-3","-2","-1"), 0, 1))
    
    post_mean <- aggregate(estimate ~  gender+post+hetero, 
                           data=coef ,
                           mean)
    post_mean <- post_mean %>%
      spread(post, estimate) %>%
      mutate(estimate=`1`-`0`)
    
    penalty <- post_mean %>%
      subset(select=-c(`1`,`0`)) %>%
      spread(gender, estimate) %>%
      mutate(estimate = `Men` - `Women`) %>%
      subset(select=c(hetero,estimate)) %>%
      mutate(depvar = {{depvar}},
             depvar_lab = var_label(data$depvar))
    
    # Prep plot
    nlevels = length(levels(data$hetero))
    ptsize <- 0.3
    lsize <- 0.5
    
    coef <- coef %>%
      mutate(hetero = as.factor(as.character(hetero)))
    
    coef <- coef[order(coef$hetero, coef$gender, coef$t_es),] # sort by hetero, gender, time
    # label for of nobs in each hetero panel
    lab <- data.frame(x = rep("10", length(levels(coef$hetero))), # x is in levels, needs quotes
                      y = rep(-.8, length(levels(coef$hetero))), 
                      dplyr::count(coef, hetero))
    lab$n = comma(lab$n, big.mark = ",")
    lab <- merge(lab, penalty, by=c("hetero"))
    lab$txt = sprintf("Child Penalty: %1.0f%%", (lab$estimate)*100)
    
    penalty <- penalty %>%
      mutate(depvar = {{depvar}},
             depvar_lab = var_label(data$depvar))
    
    coef$gender <- factor(coef$gender,levels=c("Women","Men")) # Ensure that Men are drawn above Women
    coef <- coef[order(coef$hetero, coef$gender, coef$t_es),] # sort by hetero, gender, time
    
    if(export){
      
      # create separate graphs for some states for paper
      for(st in c("North Dakota", "New Jersey", "Utah")){
        stname <- tolower(gsub(" ", "", st, fixed = TRUE))
        stname <- gsub("\\+", "", stname)
        ggplot(coef[coef$hetero==st,], aes(y=estimate, x=t_es, color=gender, group=gender))  + 
          # display all x values on axis
          scale_x_discrete(labels=as.character(coef[coef$hetero==st,"t_es"]), breaks=coef[coef$hetero==st,"t_es"])+
          # add confience intervals
          geom_ribbon(aes(ymin=conf.low,ymax=conf.high,fill=gender),alpha=0.3,show.legend = F,
                      colour = NA) +
          # line and point sizes
          geom_line(linewidth=1) + 
          geom_point(size=4) +
          # y-scale
          scale_y_continuous(labels=c("-1.0","-0.8","-0.6","-0.4","-0.2","0.0",
                                      "0.2","0.4"),
                             breaks=seq(-1, 0.4, by=0.2), limits=c(-1,0.5))+# axis labels# axis labels
          labs(x="Event Time (Years)", y=paste(var_label(data$depvar),"Impact (%)")) +
          # line at t=-0.5
          geom_vline(xintercept = 5.5, linetype="solid", color = "#D11809",linewidth=1.2) +
          # theme + grid lines
          theme_minimal() + 
          theme(axis.line = element_line(colour = "black",linewidth=0.4)) +
          theme(panel.grid.major.x = element_blank(),
                panel.grid.minor.y = element_blank(),
                legend.position = "bottom",
                panel.spacing = unit(-.2, "lines"),
                legend.key.size = unit(3,"lines")) +
          # label next to line
          geom_text(aes(x=6.9,
                        label="First Child",y=0.45),
                    size=8.5,color="grey25",check_overlap=T)+
          theme(axis.text.x = element_text(vjust = -0.5)
          ) +
          theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)),
                axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)))+
          theme(text=element_text(size=25)
          ) +
          # line color and legend labels
          scale_color_manual(name="",
                             breaks=c("Men","Women"),
                             values=c("black",rgb(193,5,52, maxColorValue = 255)),
                             labels=c("Men","Women")) +
          scale_fill_manual(values=c("black",
                                     rgb(193,5,52, maxColorValue = 255)),
                            breaks=c("Men","Women"),
                            name="")+
          # panel labels
          geom_text(x=16.2, y=-0.9, aes(label=txt, group=NULL,fontface="bold"), size =11, 
                    color = "black", hjust = 1, data=lab[lab$hetero==st,])
        ggsave(paste0(plotname, "_", stname, "_",{{depvarlbl}}, ".pdf"), plot=last_plot(), device="pdf",
               width=11, height=8, units="in",path=file.path(outdir,"Figures"))
      }
      
      # State graphs for slides
      for(st in c("California","New Jersey",
                  "North Dakota","Utah")){
        stname <- tolower(gsub(" ", "", st, fixed = TRUE))
        stname <- gsub("\\+", "", stname)
        # plot for slides with different sizing
        ggplot(coef[coef$hetero==st,], aes(y=estimate, x=t_es, color=gender, group=gender))  + 
          # display all x values on axis
          scale_x_discrete(labels=as.character(coef[coef$hetero==st,"t_es"]), breaks=coef[coef$hetero==st,"t_es"])+
          # add confience intervals
          geom_ribbon(aes(ymin=conf.low,ymax=conf.high,fill=gender),alpha=0.3,show.legend = F,
                      colour = NA) +
          # line and point sizes
          geom_line(linewidth=1.3) + 
          geom_point(size=4.6) +
          # y-scale
          scale_y_continuous(labels=c("-1.0","-0.8","-0.6","-0.4","-0.2","0.0",
                                      "0.2","0.4"),
                             breaks=seq(-1, 0.4, by=0.2), limits=c(-1,0.5))+# axis labels# axis labels
          labs(x="Event Time (Years)", y=paste(var_label(data$depvar),"Impact (%)")) +
          # line at t=-0.5
          geom_vline(xintercept = 5.5, linetype="solid", color = "#D11809",linewidth=1.2) +
          # theme + grid lines
          theme_minimal() + 
          theme(axis.line = element_line(colour = "black",linewidth=0.4)) +
          theme(panel.grid.major.x = element_blank(),
                panel.grid.minor.y = element_blank(),
                legend.position = "bottom",
                panel.spacing = unit(-.2, "lines"),
                legend.key.size = unit(3,"lines")) +
          # label next to line
          geom_text(aes(x=6.9,
                        label="First Child",y=0.45),
                    size=8.5,color="grey25",check_overlap=T)+
          theme(axis.text.x = element_text(vjust = -0.5)
          ) +
          theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)),
                axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)))+
          theme(text=element_text(size=25)
          ) +
          # line color and legend labels
          scale_color_manual(name="",
                             breaks=c("Men","Women"),
                             values=c("black",rgb(193,5,52, maxColorValue = 255)),
                             labels=c("Men","Women")) +
          scale_fill_manual(values=c("black",
                                     rgb(193,5,52, maxColorValue = 255)),
                            breaks=c("Men","Women"),
                            name="")+
          # panel labels
          geom_text(x=15.8, y=-0.9, aes(label=txt, group=NULL,fontface="bold"), size =12, 
                    color = "grey25", hjust = 1, data=lab[lab$hetero==st,])
        ggsave(paste0(plotname,"_",stname, "_",{{depvarlbl}},"_slides.pdf"), plot=last_plot(), device="pdf",
               width=11, height=8, units="in",path=file.path(outdir,"Figures"))
      }
      
      # facet-wrapped plot for all levels together
      mylabels <- c("","-4","","-2","","0","", "2","", "4","", "6","", "8","", "10")
      mybreaks <- c(-4, -2, 0, 2, 4, 6, 8, 10)
      
      plot <- ggplot(coef, aes(y=estimate, x=t_es, color=gender, group=gender))  + 
        facet_wrap(~ hetero, scales="free") +
        # display all x values on axis
        scale_x_discrete(labels=mylabels, breaks=levels(coef$t_es)) +
        # add confience intervals
        geom_errorbar(aes(ymin=conf.low, ymax=conf.high), size=0.2,width=0.3) +
        # line and point sizes
        geom_line(linewidth=.3) + 
        geom_point(size=.5) +
        # y-axis limits
        coord_cartesian(ylim=c(-1,0.6))+
        # axis labels
        labs(x="Event Time (Years)", y=paste(var_label(data$depvar),"Impact (%)")) +
        # line at t=-0.5
        geom_vline(xintercept = 5.5, linetype="solid", color = "#D11809",linewidth=.3) +
        annotate("text",x=7.9,y=0.5,label="First Child",size=max(2,10/nlevels)-0.1,color="grey25",check_overlap=T) +
        # theme + grid lines
        theme_minimal() + 
        theme(axis.line = element_line(colour = "black",linewidth=0.1)) +
        theme(panel.grid.major.x = element_blank(),
              panel.grid.minor.y = element_blank(),
              legend.position = "none",
              panel.spacing = unit(-.2, "lines"),
              axis.text.x = element_text(size=5),
              axis.text.y = element_text(size=5),
              axis.ticks = element_line(size = 0.1),
              axis.ticks.length=unit(.05, "cm")) +  
        # line color and legend labels
        scale_color_manual(breaks=c("Men","Women"),
                           values=c("grey49","black"),
                           labels=c("Men","Women")) +
        # panel labels
        geom_text(aes(x, y, label=txt, group=NULL), size = max(2, 12/nlevels), 
                  color = "black", hjust = 1, data=lab)
      ggsave(paste0(plotname,"_allstates_",{{depvarlbl}},".pdf"), plot=last_plot(), device="pdf",
             width=11, height=8, units="in",path=file.path(outdir,"Figures"))
    } 
    if(return_final=="all"){
      return(list(plot = plot, penalty = penalty, coef= coef))
    } 
    if(return_final=="penalty"){
      return(penalty)
    }
  }
  if(return_coef=="cf"){ # return counterfactuals
    
    # empty data frame to store counterfactuals for women
    cf_women <- data.frame()
    
    for (census_group in levels(data$interact)){
      # subset data for regression
      reg_data <- subset(data, interact == census_group & gender == "Women") %>%
        droplevels()
      
      # Regression
      # we estimate fixed effects over full sample rather than w/in group in state analysis
      reg <- feols(depvar ~ hetero + t_es:hetero | age_factor + doiy_factor, data = reg_data, 
                   weights=~wgt, se="hetero")
      
      # get counterfactuals and append to dataframe
      cf_women <- bind_rows(cf_women, coef_es_hetero(data = {{reg_data}}, reg = {{reg}},
                                                  return_coef = "cf"))
    }
    
    cf_women <- cf_women %>%
      mutate(depvar_lab = var_label(data$depvar),
             depvar = {{depvar}})
    
    return(cf_women)
  }
}

########################################
# 11. statemap

# Create heatmaps of child penalties
# Legend is split into deciles
# Used for Figure 5

#########################################


statemap <- function(data,plotname = "", outcome = "estimate", splitvar ="") {
  
  data <- droplevels(data)
  
  # if lapply(split) is used to create maps for many levels of a var
  if(splitvar != "") {
    data["splitvar"] <- data[{{splitvar}}]
    plotname <- paste0(plotname, "_", levels(data$splitvar)[1])
  }
  data["outcome"] <- data[{{outcome}}]
  d <- unique(data$depvar)[1]
  
  # Graph labels
  if({{d}}=="earn_ly"){
    depvarlbl <- "emp_annual"
  }
  if({{d}}=="emp_lw"){
    depvarlbl <- "emp_weekly"
  }
  if({{d}}=="earnings_ly"){
    depvarlbl <- "earnings"
  }
  if(grepl("pooled",{{d}})){
    depvarlbl <- "emp_pooled"
  }
  
  data <- data %>%
    drop_na(outcome)
  
  # prep map
  # split outcome into deciles
  mybreaks <- quantile(data$outcome, probs = seq(.1, 1, by = .1))
  # labels for legend
  mylabels <- vector()
  for(j in 1:10){
    if(j == 1) {
      mylabels[j] <- paste0(sprintf("%.1f",round(min(data$outcome,na.rm=T)*100,digits=1))
                            , "-", sprintf("%.1f",round(mybreaks[j]*100,digits=1)))
    } else {
      mylabels[j] <- paste0(sprintf("%.1f",round(mybreaks[j-1]*100,digits=1)),"-",
                            sprintf("%.1f",round(mybreaks[j]*100,digits=1)))
    }
  }
  
  # data frame of deciles of outcome
  deciles <- data.frame(quantile(data$outcome, probs = seq(.1, 1, by = .1)))
  colnames(deciles) <- c('decile')
  
  # dataframe of deciles and text for labels
  deciles <- deciles %>%
    mutate(decile_rank = ntile(decile, 10)) %>%
    mutate(decile = as.factor(as.numeric(round(decile, digits=3))))
  mylabels <- data.frame(mylabels) %>%
    mutate(mylabels = as.factor(mylabels)) %>%
    mutate(decile_rank = as.numeric(rownames(.)))
  
  # reorder labels by decile
  mylabels$mylabels <- reorder(mylabels$mylabels, mylabels$decile_rank)
  
  # add deciles to data
  data <- data %>%
    mutate(decile_rank = ntile(outcome,10)) %>%
    merge(deciles,by="decile_rank",all.x=T) %>%
    merge(mylabels,by="decile_rank",all.x=T)
  
  # vector of colors for heatmap
  mycolors <- c('white','#ffffcc','#ffeda0','#fed976','#feb24c'
                ,'#E67016','#fc4e2a','#e31a1c','#bd0026','#800026')
  
  # plot map
  plot_usmap(data = data, values = "mylabels", labels = TRUE) + 
    scale_fill_manual(values=mycolors,
                      name="Child Penalty (%)",
                      na.value="grey",
                      guide = guide_legend(reverse = TRUE))+
    theme(legend.key = element_rect(color="white"),
          legend.text = element_text(size=12),
          legend.key.size = unit(0.7, 'cm'))
  # save
  ggsave(paste0(plotname, "_", {{depvarlbl}},".pdf"), plot=last_plot(), device="pdf",
         width=11, height=8, units="in",path=file.path(outdir,"Figures"))
  
}

##################################################
# 12. gender_gaps

# get raw gender gaps by some heterogeneity var
# used in Figure 6

##################################################

# Write own apply_labels() function (package expss is not available on current R version)
apply_labels <- function(data, ...) {
  set_variable_labels(data, ...)
}

gender_gaps <- function(data, depvar, hetero) {
  
  ## clean up data, add interactions
  
  data["depvar"] = data[{{depvar}}]
  data["hetero"] = data[{{hetero}}] 
  data["t_es"] = data[paste0("t_es_",substr({{depvar}}, nchar({{depvar}})-1, nchar({{depvar}})))]
  
  data <- data %>%
    drop_na(depvar, age_factor, doiy_factor, t_es, hetero)
  
  data <- droplevels(data)
  
  if(hetero == "statename"){
    data_state <- subset(data, statefip < 57)
  }
  
  
  # filter out data for parents
  data <- subset(data, child == 1)
  
  # raw gap by gender and hetero
  gaps <- data %>%
    group_by(hetero,gender) %>%
    summarise(y = weighted.mean(depvar,wgt)) %>%
    spread(gender, y) %>%
    mutate(gap = (`Men`-`Women`)/(`Men`)) %>%
    subset(select=c(hetero,gap)) %>%
    mutate(depvar = {{depvar}})%>%
    rename(gender_gap = gap)
  
  
  gaps <- apply_labels(gaps,
                       gender_gap = "Gender Gap")
  
  gaps <- gaps %>%
    mutate(depvar = {{depvar}},
           depvar_lab = var_label(data$depvar))
  
  return(gaps)
}

######################################################
# 13. reg_es_demographics_end

# calculates long-run child penalty and exports
# event study plots where we split women
# based on some demographic and plot the series for all men
# Used in reg_es_demographics and reg_es_immigrant_edu

######################################################


reg_es_demographics_end <- function(coef, data, depvar, hetero, export = T, plotname = "",
                                    preadjust = T) {
  
  ## long-run penalty relative to all men
  t_penalty <- c("5","6", "7", "8", "9", "10")
  text_penalty <- "Long-Run Penalty:"
  coef <- coef %>%
    mutate(post = case_when(t_es %in% t_penalty ~ 1,
                            grepl("-",t_es) ~ 0))
  
  
  if (preadjust) { # penalty = post - pre coefs for women relative to men
    
    penalty <- aggregate(estimate ~  gender + hetero + post, 
                         data=subset(coef, !is.na(post)) ,
                         mean) %>%
      spread(post,estimate)  %>%
      mutate(estimate=`1`-`0`) %>%
      subset(select=-c(`1`,`0`)) %>%
      spread(gender, estimate) %>%
      mutate(estimate = `Men` - `Women`) %>%
      subset(select=c(hetero,estimate))  %>%
      mutate(gender = paste(hetero, "Women"))
    
  } else { # penalty = post period coefs for women relative to men
    
    penalty <- aggregate(estimate ~  gender + hetero, 
                         data=subset(coef, t_es %in% t_penalty) ,
                         mean) %>%
      spread(gender,estimate) %>%
      mutate(estimate=`Men`-`Women`) %>%
      subset(select=c(hetero,estimate)) %>%
      mutate(gender = paste(hetero, "Women"))
    
  }
  
  # drop duplicated coefs for all men
  coef <- coef %>%
    filter((hetero == levels(data$hetero)[1] & gender == "Men") | gender == "Women") %>%
    mutate(gender = as.factor(ifelse(gender == "Men", "Men", paste(hetero, gender))))
  
  # prep for plot
  coef$gender <- factor(coef$gender, levels=c(paste(levels(data$hetero)[2],"Women"),paste(levels(data$hetero)[1],"Women"),"Men"))
  coef <- coef[order(coef$gender, coef$t_es),] # sort by gender, time
  
  # colors
  firstcolor <- rgb(26,71,111, maxColorValue = 255)
  secondcolor <- rgb(193,5,52, maxColorValue = 255)
  
  # y-axis label 
  if(depvar == "emp_lw"){
    ylab <- "Weekly Employment"
  }
  if(depvar == "earnings_ly"){
    ylab <- "Earnings"
  }
  if(depvar == "earn_ly"){
    ylab <- "Annual Employment"
  }
  if(depvar == "pooled_employment"){
    ylab <- "Employment"
  }
  
  # plot
  plot <- ggplot(coef, aes(y=estimate, x=t_es, color=gender, group=gender))  +
    geom_ribbon(aes(ymin=conf.low,ymax=conf.high,fill=gender),alpha=0.3,show.legend = F,
                colour = NA) +
    # line and point sizes
    geom_line(linewidth=1) +
    geom_point(shape=16,size=4) +
    scale_fill_manual(values=c("black",
                               firstcolor,
                               secondcolor),
                      breaks=c("Men",
                               paste(levels(data$hetero)[1],"Women"),
                               paste(levels(data$hetero)[2],"Women")))+
    # line color and legend labels
    scale_color_manual(name="",
                       breaks=c("Men",
                                paste(levels(data$hetero)[1],"Women"),
                                paste(levels(data$hetero)[2],"Women")),
                       values=c("black",
                                firstcolor,
                                secondcolor),
                       labels=c("Men",
                                paste(levels(data$hetero)[1],"Women"),
                                paste(levels(data$hetero)[2],"Women")))+
    # panel labels
    annotate("richtext",x=8.92,y=-0.64,
             label = paste0("<b>",text_penalty,"</b><br>",
                            levels(data$hetero)[1], " Women: ", 
                            (round(penalty[penalty$hetero == paste(levels(data$hetero)[1]),"estimate"],digits=2))*100, "%<br>",
                            levels(data$hetero)[2], " Women: ", 
                            (round(penalty[penalty$hetero == paste(levels(data$hetero)[2]),"estimate"],digits=2))*100, "%"),
             fill = NA,
             label.color = NA,
             hjust=0,
             size=8,
             lineheight=1.45) +
    # display all x values on axis
    scale_x_discrete(labels=as.character(coef$t_es), breaks=coef$t_es)+
    # theme + grid lines
    theme_minimal() +
    theme(axis.line = element_line(colour = "black",linewidth=0.2)) +
    theme(
      panel.grid.major.x = element_blank(),
      panel.grid.minor.y = element_blank(),
      legend.position = "bottom",
      panel.spacing = unit(-.2, "lines"),
      legend.key.size = unit(2,"lines")) +
    theme(axis.text.x = element_text(vjust = -0.5)
    ) +
    theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)),
          axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)))+
    theme(text=element_text(size=25)
    ) +  
    # y-scale
    scale_y_continuous(labels=c("-0.8","-0.6","-0.4","-0.2","0.0",
                                "0.2","0.4"),
                       breaks=seq(-0.8, 0.4, by=0.2), limits=c(-0.8,0.45))+
    # axis labels
    labs(x="Event Time (Years)", y=paste(ylab, "Impact (%)")) +
    # line at t=-0.5
    annotate("text",x=6.8,y=0.45,label="First Child",size=8.5,color="grey25",check_overlap = T) +
    geom_vline(xintercept = 5.5, linetype="solid", color = "#D11809",linewidth=1)
  if(export) {
    ggsave(paste0(plotname, "_",{{depvarlbl}},".pdf"), plot=last_plot(), device="pdf",
           width=11, height=8, units="in",path=file.path(outdir,"Figures"))
  }
  return(coef)
}


######################################################
# 14. reg_es_demographics

# creates event study plots where we split women
# based on some demographic and plot the series for all men
# reg_es_hetero_setup, coef_es_hetero, coef_es, and reg_es_demographics_end
# are embedded within
# Used for Figure 8

######################################################


reg_es_demographics <- function(data, depvar, hetero, export = T, plotname = "",
                                preadjust = T) {
  
  #Run setup function
  data <- reg_es_hetero_setup(data = {{data}}, depvar = {{depvar}}, hetero = {{hetero}})
  
  # Run event study on women, split by hetero var
  reg_data <- subset(data, gender == "Women") %>%
    droplevels()
  
  # Regression, interact age and year dummies w/ hetero var
  reg <- feols(depvar ~ hetero + t_es:hetero | age_het + doiy_het, data = reg_data, 
               weights=~wgt, se="hetero")
  
  coef.women <- coef_es_hetero(data = {{reg_data}}, reg = {{reg}})
  
  # run event study for all men 
  # duplicate coefs for men to make it easier to estimate penalties
  reg_data <- subset(data, gender == "Men") %>%
    droplevels()
  
  # Regression
  reg <- feols(depvar ~ t_es | age_factor + doiy_factor, data = reg_data, 
               weights=~wgt, se="hetero")
  
  coef.men1 <- coef_es(data = {{reg_data}}, reg = {{reg}}) %>%
    mutate(hetero = levels(data$hetero)[1])
  coef.men2 <- coef.men1 %>%
    mutate(hetero = levels(data$hetero)[2])
  coef.men <- bind_rows(coef.men1,coef.men2) 
  # Removing std.error from women's df to match the columns with coef.men for data appending
  coef.women <- coef.women %>% 
    subset(select = -c(std.error))
  
  # combine dfs
  coef <- rbind(coef.women, coef.men) %>%
    mutate(depvar_lab = var_label(data$depvar),
           depvar = {{depvar}})
  
  coef <- reg_es_demographics_end(coef = {{coef}}, data = {{data}}, depvar = {{depvar}}, 
                           hetero = {{hetero}}, export = {{export}}, plotname = {{plotname}},
                           preadjust = {{preadjust}})
  
  return(coef)
}

######################################################
# 15. coef_es_statetime

# regression with pre and post dummy instead of event dummies
# used in reg_es_statetime

######################################################

coef_es_statetime <- function(data) {
  
  data <- droplevels(data)
  
  # regression and prediction
  # fe estimated across entire sample
  reg <- feols(depvar ~ hetero + post:hetero | age_factor + doiy_factor, data, weights=~wgt, se="hetero")
  
  data$prearn = reg$sumFE #prediction
  
  #grid of counterfactual earnings by event time, hetero, and gender
  grid <- aggregate(prearn  ~  post + hetero + gender, 
                    data=data , mean)
  
  grid <- filter(grid, post == "post")
  
  # weight counterfactuals by matching weights
  grid_weighted <- data %>%
    group_by(post, hetero, gender) %>%
    summarize(prearn = weighted.mean(prearn, wgt_match)) %>%
    subset(post=="post")
  
  grid <- grid %>%
    subset(select=-c(prearn)) %>%
    merge(grid_weighted, by=c("post","hetero","gender"))
  
  # Note: don't keep se on penalty here but this could be changed if se is needed
  coef <- as.data.frame(tidy(reg)) %>%
    filter(grepl("postpost",term))  %>%
    mutate(hetero = gsub(".*hetero(.+):.*", "\\1", term))  %>%
    merge(grid, by="hetero",all.x=T) %>%
    mutate(estimate = (estimate)/prearn,
           std.error = std.error/prearn) %>%
    subset(select=c(hetero, estimate, gender))
  
  return(coef)
} 

######################################################
# 16. reg_es_statetime

# coef_es_statetime is embedded within
# cleans df and calculates penalty as diff b/w
# men and women
# used to get data for GSS state by time analysis

######################################################

reg_es_statetime <- function(data, depvar, hetero, splitvar = "") {
  
  ## clean up data, add interactions
  
  data["depvar"] = data[{{depvar}}]
  data["hetero"] = data[{{hetero}}] 
  data["post"] = data[paste0("post_",substr({{depvar}}, nchar({{depvar}})-1, nchar({{depvar}})))]
  
  data <- data %>%
    drop_na(depvar, age_factor, doiy_factor, post, hetero)  %>%
    mutate(age_het = interaction(age_factor, hetero)) %>%
    mutate(doiy_het = interaction(doiy_factor, hetero)) %>%
    mutate(age_het_gender = interaction(age_factor, hetero, gender)) %>%
    mutate(doiy_het_gender = interaction(doiy_factor, hetero, gender))
  
  data <- droplevels(data)
  
  ## regression coefficients
  coef.women <- coef_es_statetime(subset(data, gender=="Women"))
  coef.men <- coef_es_statetime(subset(data, gender=="Men"))  
  
  coef <- rbind(coef.women, coef.men)
  
  ## penalty
  penalty <- coef %>%
    spread(gender, estimate) %>%
    mutate(penalty = `Men` - `Women`) %>%
    subset(select=c(hetero, penalty)) %>%
    mutate(depvar_lab = var_label(data$depvar)) %>%
    mutate(depvar = {{depvar}})
  
  if(splitvar != ""){
    data <- droplevels(data)
    data["splitvar"] <- data[{{splitvar}}]
    penalty$splitvar <- levels(data$splitvar)[1]
    print(levels(data$splitvar)[1])
  }
  
  
  return(penalty=penalty)
}


################################################################

# 17. reg_es_movers

# full function for event study plot by heterogeneity var
# reg_es_hetero_setup, coef_es_hetero, and reg_es_hetero_end are embedded within
# calculates penalty by hetero group
# generates separate plot for each level of hetero group
# return_final and return_coef together determine
# what the final output of the function is
# can be used to return event study coefficients, penalties,
# or counterfactuals
# Fixed effects are estimated over full sample and
# matching weights are used for the regressions
# Used to get data for Figures 12-14 and A.16-A.17

################################################################

reg_es_movers <- function(data, depvar, hetero, export = T, plotname = "",
                          scale = 0.5, return_final = "coef", return_coef = "coef",
                          preadjust = T) {
  
  #Run setup function
  data <- reg_es_hetero_setup(data = {{data}}, depvar = {{depvar}}, hetero = {{hetero}})
  
  # Empty dataframe to store results for men and women
  coef <- data.frame()
  
  if(return_coef == "coef"){ # return event study coefficients
    
    for (i in c("Men", "Women")){
      reg_data <- subset(data, gender == i) %>%
        droplevels()
      
      # Regression
      # we use matching weights for regressions in movers analysis
      # also estimate fixed effects over full sample rather than w/in group in movers analysis
      reg <- feols(depvar ~ hetero + t_es:hetero | age_factor + doiy_factor, data = reg_data, 
                   weights=~wgt_match, se="hetero")
      
      # Estimate counterfactuals and adjust coefficients
      # Append results to dataframe
      coef <- bind_rows(coef, coef_es_hetero(data = {{reg_data}}, reg = {{reg}}, return_coef={{return_coef}}))
      
    }
    
    # Add dependent variable label to dataframe
    coef <- coef %>%
      mutate(depvar = {{depvar}},
             depvar_lab = var_label(data$depvar))
    
    # Calculate child penalty and export graph
    coef <- reg_es_hetero_end(coef = {{coef}}, data = {{data}}, depvar = {{depvar}}, hetero = {{hetero}}, 
                              export = {{export}}, plotname = {{plotname}}, scale = {{scale}},
                              return_final = {{return_final}}, preadjust = {{preadjust}})
    
    return(coef)
  }
  
  if(return_coef == "cf"){ # return counterfactuals for women only
    
    #Regression
    reg_data <- subset(data, gender == "Women") %>%
      droplevels()
    
    # Regression, interact age and year dummies w/ hetero var
    reg <- feols(depvar ~ hetero + t_es:hetero | age_factor + doiy_factor, data = reg_data, 
                 weights=~wgt_match, se="hetero")
    
    cf_women <- coef_es_hetero(data = {{reg_data}},reg = {{reg}},return_coef="cf") %>%
      mutate(depvar = {{depvar}},
             depvar_lab = var_label(data$depvar))
    
    return(cf_women)
  }
}


#####################################################
# 18. reg_es_immigrant

# Produces event study plots for men and women
# across an entire sample
# Matching weights are used for the regressions
# reg_es_setup, coef_es, and reg_es_end are embedded within
# Used for Fig 15-18, A.18, A.19 and A.24

#####################################################

reg_es_immigrant <- function(data, depvar, plotname = "", export = T, splitvar = "", appendix = F,
                   preadjust = T) {
  
  #Run setup function
  data <- reg_es_setup(data = {{data}}, depvar = {{depvar}}, splitvar = {{splitvar}}, appendix = {{appendix}})
  
  #Empty dataframe to store results for men and women
  coef <- data.frame()
  
  for (i in c("Women", "Men")){
    reg_data <- subset(data, gender == i) %>%
      droplevels()
    
    # Regression
    # We use matching weights for the immigrant analysis
    reg <- feols(depvar ~ t_es | age_factor + doiy_factor, 
                 data =reg_data, weights=~wgt_match, se = "hetero")
    
    # Estimate counterfactuals and adjust coefficients
    # Append results to dataframe
    coef <- bind_rows(coef, coef_es(data = {{reg_data}}, reg = {{reg}}))
  }
  
  
  coef <- reg_es_end(coef = {{coef}}, data = {{data}}, depvar = {{depvar}}, plotname = {{plotname}},
                     export = {{export}}, splitvar = {{splitvar}}, appendix = {{appendix}},
                     preadjust = {{preadjust}})
  
  return(coef)
  
}


######################################################
# 19. reg_es_immigrant_edu

# creates event study plots where we split women
# based on some demographic and plot the series for all men
# reg_es_hetero_setup, coef_es_hetero, coef_es, and reg_es_demographics_end
# are embedded within
# Matching weights are used for the regressions
# Used for Figure A.20

######################################################


reg_es_immigrant_edu <- function(data, depvar, hetero, export = T, plotname = "",
                         preadjust = T) {
  
  #Run setup function
  data <- reg_es_hetero_setup(data = {{data}}, depvar = {{depvar}}, hetero = {{hetero}})
  
  # Run event study on women, split by hetero var
  reg_data <- subset(data, gender == "Women") %>%
    droplevels()
  
  # Regression
  # we use matching weights for regressions in immigrant analysis
  # interact age and year dummies w/ hetero var
  reg <- feols(depvar ~ hetero + t_es:hetero | age_het + doiy_het, data =reg_data, 
               weights=~wgt_match, se="hetero")
  
  coef.women <- coef_es_hetero(data = {{reg_data}}, reg = {{reg}})
  
  # run event study for all men 
  # duplicate coefs for men to make it easier to estimate penalties
  reg_data <- subset(data, gender == "Men") %>%
    droplevels()
  
  # Regression
  # we use matching weights for regressions in immigrant analysis
  reg <- feols(depvar ~ t_es | age_factor + doiy_factor, data = reg_data, 
               weights=~wgt_match, se="hetero")
  
  coef.men1 <- coef_es(data = {{reg_data}}, reg = {{reg}}) %>%
    mutate(hetero = levels(data$hetero)[1])
  coef.men2 <- coef.men1 %>%
    mutate(hetero = levels(data$hetero)[2])
  coef.men <- bind_rows(coef.men1,coef.men2) 
  coef.women <- coef.women %>% 
    subset(select=-c(std.error))
  
  # combine dfs
  coef <- rbind(coef.women, coef.men) %>%
    mutate(depvar_lab = var_label(data$depvar),
           depvar = {{depvar}})
  
  coef <- reg_es_demographics_end(coef = {{coef}}, data = {{data}}, depvar = {{depvar}}, 
                           hetero = {{hetero}}, export = {{export}}, plotname = {{plotname}},
                           preadjust = {{preadjust}})
  
  return(coef)
}