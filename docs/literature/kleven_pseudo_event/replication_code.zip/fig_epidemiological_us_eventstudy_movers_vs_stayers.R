#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"
# Author: Henrik Kleven
# Description: This file plots the event studies and saves the dataset of penalties for both
# state of birth (Figures 12 and A.18-A.19) and state of residence
#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Function to create event studies
fig_es_movers_stayers <- function(depvar, export = T, longrun = F, preadjust = T, final_filename = T, data_type = "birth") {
  # Graph labels
  if({{depvar}}=="earn_ly"){
    depvarlbl <- "emp_annual"
  }
  if({{depvar}}=="emp_lw"){
    depvarlbl <- "emp_weekly"
  }
  if(grepl("pooled",depvar)){
    depvarlbl <- "emp_pooled"
  }
  
  # Set file paths based on data type
  file_prefix <- ifelse(data_type == "birth", "bpl_state", "statename")
  
  # Read in coefficients for movers, stayers, all US born
  if(grepl("pooled",depvar)){
    coef <- bind_rows(readRDS(file=file.path(wrkdir,paste0("coef_movers_by_", file_prefix, "-",{{depvar}},".rds"))),
                      readRDS(file=file.path(wrkdir,paste0("coef_stayers_by_", file_prefix, "-",{{depvar}},".rds")))) %>%
      filter(depvar == {{depvar}}) %>%
      rename(state = hetero)
    coef_usborn <- readRDS(file=file.path(wrkdir,paste0("coef_usborn_by_", file_prefix, "-",{{depvar}},".rds")))  %>%
      filter(depvar == {{depvar}} & gender == "Men") %>%
      rename(state = hetero)
  } else {
    coef <- bind_rows(readRDS(file=file.path(wrkdir,paste0("coef_movers_by_", file_prefix, ".rds"))),
                      readRDS(file=file.path(wrkdir,paste0("coef_stayers_by_", file_prefix, ".rds")))) %>%
      filter(depvar == {{depvar}}) %>%
      rename(state = hetero)
    coef_usborn <- readRDS(file=file.path(wrkdir,paste0("coef_usborn_by_", file_prefix, ".rds")))  %>%
      filter(depvar == {{depvar}} & gender == "Men") %>%
      rename(state = hetero)
  }
  
  # Long-run penalty vs average across full period
  if(longrun){
    t_penalty <- c("5","6", "7", "8", "9", "10")
    text_penalty <- "Long-Run Penalty:"
  } else {
    t_penalty <- c("0", "1", "2", "3", "4", "5","6", "7", "8", "9", "10")
    text_penalty <- "Child Penalty:"
  }
  
  coef <- coef %>%
    mutate(post = case_when(t_es %in% t_penalty ~ 1, grepl("-",t_es) ~ 0))
  coef_usborn <- coef_usborn %>%
    mutate(post = case_when(t_es %in% t_penalty ~ 1, grepl("-",t_es) ~ 0))
  
  # Penalty relative to all US-born men
  coef <- coef %>%
    filter(gender == "Women") %>%
    mutate(spec_lbl = ifelse(grepl("movers",spec_lbl),"movers","stayers"))
  coef_men <- coef_usborn %>%
    mutate(spec_lbl = "movers") %>%
    bind_rows(coef_usborn) %>%
    mutate(spec_lbl = ifelse(grepl("USborn",spec_lbl), "stayers",as.character(spec_lbl)))
  coef <- bind_rows(coef, coef_men)
  coef <- coef %>%
    rename(hetero = spec_lbl)
  
  if(preadjust){
    penalty <- aggregate(estimate ~  gender + hetero + post + state, data=subset(coef, !is.na(post)), mean)%>%
      spread(post,estimate)  %>%
      mutate(estimate=`1`-`0`)%>%
      subset(select=-c(`1`,`0`))%>%
      spread(gender, estimate) %>%
      mutate(estimate = `Men` - `Women`) %>%
      subset(select=c(state, hetero,estimate))  %>%
      mutate(gender = ifelse(grepl("movers",hetero), "Mover Women", "Stayer Women"))
  } else {
    penalty <- aggregate(estimate ~  gender + hetero + state, data=subset(coef, t_es %in% t_penalty), mean) %>%
      spread(gender,estimate) %>%
      mutate(estimate=`Men`-`Women`) %>%
      subset(select=c(state, hetero,estimate)) %>%
      mutate(gender = ifelse(grepl("movers",hetero), "Mover Women", "Stayer Women"))
  }
  
  coef <- coef %>%
    filter(gender == "Women") %>%
    mutate(gender = ifelse(grepl("movers",hetero), "Mover Women", "Stayer Women")) %>%
    bind_rows(coef_usborn)
  coef$gender <- factor(coef$gender, levels=c("Mover Women","Stayer Women","Men"))
  coef <- coef[order(coef$state, coef$gender, coef$t_es),]
  firstcolor <- rgb(26,71,111, maxColorValue = 255) 
  secondcolor <- rgb(193,5,52, maxColorValue = 255)
  
  # y-axis label 
  if(depvar == "emp_lw"){
    ylab <- "Weekly Employment"
  }
  if(depvar == "earnings_ly"){
    ylab <- "Earnings"
  }
  if(depvar == "earn_ly"){
    ylab <- "Annual Employment"
  }
  
  # Plot (only if data_type is "birth")
  if(data_type == "birth" & !grepl("pooled",depvar)){
    # Single graphs for selected states
    for(st in c("North Dakota","New Jersey","Utah", "California")){
      stname <- tolower(gsub(" ", "", st, fixed = TRUE))
      stname <- gsub("\\+", "", stname)
      
      ggplot(coef[coef$state==st,], aes(y=estimate, x=t_es, color=gender, group=gender))  +
        geom_ribbon(aes(ymin=conf.low,ymax=conf.high,fill=gender),alpha=0.3,show.legend = F,
                    colour = NA) +
        geom_line(linewidth=1) +
        geom_point(shape=16,size=4) +
        scale_fill_manual(values=c(secondcolor,firstcolor,"black"), breaks=levels(coef$gender)) +
        scale_color_manual(name="", breaks=levels(coef$gender), values=c(secondcolor,firstcolor,"black"), labels=levels(coef$gender)) +
        annotate("richtext",x=8.92,y=-0.64,
                 label = paste0("<b>",text_penalty,"</b><br>",
                                levels(coef$gender)[2],": ",(round(penalty[penalty$gender == paste(levels(coef$gender)[2]) & penalty$state == st,"estimate"],digits=2))*100,"%<br>",
                                levels(coef$gender)[1],": ",(round(penalty[penalty$gender == paste(levels(coef$gender)[1]) & penalty$state == st,"estimate"],digits=2))*100,"%"),
                 fill=NA,
                 label.color=NA,
                 hjust=0,
                 size=8,
                 lineheight=1.45) +
        scale_x_discrete(labels=as.character(coef[coef$state==st,"t_es"]), breaks=coef[coef$state==st,"t_es"]) +
        theme_minimal() +
        theme(axis.line = element_line(colour = "black",linewidth=0.2)) +
        theme(panel.grid.major.x = element_blank(), panel.grid.minor.y = element_blank(), legend.position = "bottom", panel.spacing = unit(-.2, "lines"), legend.key.size = unit(2,"lines")) +
        theme(axis.text.x = element_text(vjust = -0.5)) +
        theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)), axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0))) +
        theme(text=element_text(size=25)) +
        scale_y_continuous(labels=c("-0.8","-0.6","-0.4","-0.2","0.0", "0.2","0.4"), breaks=seq(-0.8, 0.4, by=0.2)) +
        coord_cartesian(ylim = c(-0.8,0.45)) +
        labs(x="Event Time (Years)", y=paste(ylab, "Impact (%)")) +
        annotate("text", x = 6.9, y = 0.45, label="First Child", size=8.5,color="grey25") +
        geom_vline(xintercept = 5.5, linetype="solid", color = "#D11809",linewidth=1) + 
        guides(color=guide_legend(reverse = T))
      if(st != "California"){
        ggsave(paste0("epidemiological_movers_vs_stayers_",stname, "_",{{depvarlbl}},".pdf"), plot=last_plot(), device="pdf", width=11, height=8, units="in",path=file.path(outdir,"Figures"))
      } else{ # California is only for slides
        ggsave(paste0("epidemiological_movers_vs_stayers_",stname, "_",{{depvarlbl}},"_slides.pdf"), plot=last_plot(), device="pdf", width=11, height=8, units="in",path=file.path(outdir,"Figures"))
      }
    }
    penalty2 <- penalty %>%
      mutate(label = paste0(gender, ": ", as.character(round(estimate, digits = 2)*100), "%")) %>%
      subset(select=-c(hetero, estimate)) %>%
      spread(gender, label) %>%
      mutate(label = paste0(`Stayer Women`,"\n",`Mover Women`))
    
    # face-wrapped plot including all states
    ggplot(coef, aes(y=estimate, x=t_es, color=gender, group=gender))  +
      facet_wrap(~ state, scales="free") +
      geom_ribbon(aes(ymin=conf.low,ymax=conf.high,fill=gender),alpha=0.3,show.legend = F, colour = NA) +
      geom_line(linewidth=.3) +
      geom_point(size=.5) +
      coord_cartesian(ylim = c(-1, 0.6)) +
      scale_fill_manual(values=c(secondcolor,firstcolor,"black"), breaks=levels(coef$gender)) +
      scale_color_manual(name="", breaks=levels(coef$gender), values=c(secondcolor,firstcolor,"black"), labels=levels(coef$gender)) +
      scale_y_continuous(breaks=seq(-1,0.5,by=0.5)) +
      scale_x_discrete(breaks=-5:10,labels=ifelse((-5:10) %% 2 == 0, -5:10, "")) +
      geom_text(aes(x=6.4, y=-0.625, label=paste0(text_penalty)), size = 1.55,color="black",fontface="bold",hjust=0,check_overlap=T) +
      geom_text(aes(x=6.4, y=-0.77, label=`Stayer Women`, group=NULL), size = 1.55,color="black",check_overlap = T,hjust=0, data = penalty2) +
      geom_text(aes(x=6.4, y=-0.91, label=`Mover Women`, group=NULL), size = 1.55,color="black",check_overlap = T,hjust=0, data = penalty2) +
      theme_minimal() +
      theme(axis.line = element_line(colour = "black",linewidth=0.1)) +
      theme(panel.grid.major.x = element_blank(), panel.grid.minor.y = element_blank(), legend.position = "bottom", panel.spacing = unit(-.2, "lines"), axis.text.x = element_text(size=5), axis.text.y = element_text(size=5), axis.ticks = element_line(linewidth = 0.1), axis.ticks.length=unit(.05, "cm"), legend.margin=margin(t=-0.2, r=0, b=0, l=0, unit="cm")) +
      labs(x="Event Time (Years)", y=paste(ylab, "Impact (%)")) +
      annotate("text", x = 7.9, y = 0.5, label="First Child",size=max(2,10/51)-0.1,color="grey25") +
      geom_vline(xintercept = 5.5, linetype="solid", color = "#D11809",linewidth=.3) + 
      guides(color=guide_legend(reverse = T)) 
    ggsave(paste0("epidemiological_movers_vs_stayers_allstates_", {{depvarlbl}},".pdf"), plot=last_plot(), device="pdf", width=11, height=8, units="in",path=file.path(outdir,"Figures"))
  }
  
  penalty$depvar <- unique(coef$depvar)
  penalty$depvar_lab <- unique(coef$depvar_lab)
  penalty <- penalty %>%
    rename(spec_lbl = hetero, hetero = state, penalty = estimate)
  return(penalty)
}

create_dataset <- function(data_type = "birth") {
  
  penalties <- setDF(rbindlist(lapply(c("earn_ly","emp_lw"), 
                                      fig_es_movers_stayers,
                                      data_type = {{data_type}}))) %>%
    bind_rows(fig_es_movers_stayers(depvar="pooled_employment", 
                                    data_type = {{data_type}}))
  
  # Save dataset
  file_name <- ifelse(data_type == "birth", "penalties_movers_vs_stayers_state_of_birth", "penalties_movers_vs_stayers_state_of_residence")
  saveRDS(penalties, file=file.path(wrkdir,paste0(file_name,".rds")))
}

# Run function for state of birth
create_dataset(data_type = "birth")

# Run function for state of residence
create_dataset(data_type = "residence")
