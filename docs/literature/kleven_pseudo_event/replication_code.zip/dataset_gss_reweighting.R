#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates weights for the fraction of childbirths in each state
# in each decade in the CPS/ACS pseudo-panel which are later used to re-weight the GPI using GSS
# data when the GPI at the state-decade level is collapsed to the state level

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Load CPS and ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

# Create 10-year intervals of child birth
cps_acs <- cps_acs %>%
  mutate(ch1yob10 = as_factor(case_when(inrange(ch1yob, 1972, 1979) ~ "1972-79",
                                        inrange(ch1yob, 1980, 1989) ~ "1980-89",
                                        inrange(ch1yob, 1990, 1999) ~ "1990-99",
                                        inrange(ch1yob, 2000, 2009) ~ "2000-09",
                                        inrange(ch1yob, 2010, 2018) ~ "2010-20"))) %>%
  # use weekly employment sample
  filter(!is.na(t_es_lw))

###### Weights by state of residence

# Get weighted number of observations in each 10 year interval of childbirth and state
st_weights <- cps_acs %>%
  filter(child == 1 & statefip < 57) %>%
  group_by(statename, ch1yob10) %>%
  summarize(n = sum(wgt)) %>%
  drop_na(ch1yob10)

# get weighted number of observations in each state
st_totals <- cps_acs %>%
  filter(child == 1 & !is.na(ch1yob10) & statefip < 57) %>%
  group_by(statename) %>%
  summarize(total = sum(wgt))

# calculate fraction of people in each state giving birth in each interval
st_weights <- merge(st_weights, st_totals, by="statename") %>%
  mutate(birthwgt_st = n/total)%>%
  subset(select=-c(n, total))

###### Weights over entire country (don't vary over state)
  
# Subset data to use GSS year range only
cps_subset <-subset(cps_acs, child == 1 & !is.na(ch1yob10))

# Weighted number of obs in dataset  
nat_total <- sum(cps_subset$wgt)

# Weighted number of obs in each 10 year interval
nat_weights <- cps_subset %>%
  group_by(ch1yob10) %>%
  summarize(n = sum(wgt))

# Calculate fraction of people who give birth in each interval
nat_weights$nat_total <- nat_total
nat_weights <- nat_weights %>%
  mutate(birthwgt_nat = n/nat_total) %>%
  subset(select=-c(n, nat_total))


###### Merge state and country weights
weights <- merge(st_weights, nat_weights, by="ch1yob10") %>%
  rename(interval = ch1yob10)

# Save combined dataset
saveRDS(weights, file=file.path(wrkdir, "gss_reweighting_gpi.rds"))
