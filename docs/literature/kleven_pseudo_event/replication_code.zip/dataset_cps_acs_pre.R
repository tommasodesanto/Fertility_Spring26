#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file generates combined CPS and ACS raw data file

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))


# Load files
load(file.path(cleandir,paste0("cps_preselect",".RData"))) # read in dataset
load(file.path(cleandir,paste0("acs_preselect",".RData"))) # read in dataset

cps.sample <- cps.sample %>%
  filter(doiy < 2021)

cps_acs_pre <- bind_rows(acs.sample, cps.sample) %>%
  filter(inrange(age, 20, 50)) %>%
  droplevels() %>%
  mutate(two_year_intervals = floor(doiy/2)*2) %>%
  mutate(yr5 = floor(doiy/5)*5) %>%
  mutate(two_year_intervals = as.factor(paste0(as.character(two_year_intervals),"-",substr(two_year_intervals+1, 3, 4)))) %>%
  mutate(yr5 = as.factor(paste0(as.character(yr5),"-",substr(yr5+4, 3, 4)))) %>%
  mutate(yr5 = as.factor(ifelse(yr5 == "1975-79" | yr5 == 
                                  "1970-74",
                                "1973-79", as.character(yr5)))) %>%
  mutate(yr5 = as.factor(ifelse(yr5 == "2020-24" | yr5 == "2015-19", "2015-20",
                                as.character(yr5)))) %>%
  mutate(yr5 = as.factor(ifelse(doiy < 1973, "1968-72", as.character(yr5)))) %>%
  mutate(yr10 = as.factor(case_when(doiy < 1973 ~ "1968-72",
                                    inrange(doiy, 1973,1979) ~ "1973-79",
                                    inrange(doiy, 1980, 1989) ~ "1980-89",
                                    inrange(doiy, 1990, 1999) ~ "1990-99",
                                    inrange(doiy, 2000, 2009) ~ "2000-09",
                                    inrange(doiy, 2010, 2020) ~ "2010-20")))

cps_acs_pre <- apply_labels(cps_acs_pre, earnings_ly = "Earnings", emp_lw = "Weekly Employment", earn_ly = "Annual Employment")

saveRDS(cps_acs_pre, file=file.path(cleandir,"cps_acs_clean_aged20-50.rds"))
