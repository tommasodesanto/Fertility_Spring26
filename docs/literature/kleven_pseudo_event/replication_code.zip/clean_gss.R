#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file cleans GSS data

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Load data
gss_raw <- read_rds(file.path(rawdir, "GSS/GSS7218_R1.rds"))
gss_identifiers <- read_rds(file.path(rawdir, "GSS/cross7316geo.rds"))

gss <- full_join(gss_identifiers, gss_raw, c("id", "year"))

#rm(gss_raw, gss_identifiers)

# everything in lower case
gss <- gss %>% 
  rename_with(~ tolower(.x))

# exclude observations oversampled in 1982 and 1987
gss <- gss %>% 
  filter(!(sample %in% c(4,5,7)))

# Select relevant variables
# relevant_demo_var <- c("wrkstat", "hrs1", "hrs2", "wrkslf", "wrkgovt", "marital", "cowrksta", "childs", "age", 
#                        "agekdbrn", "educ", "maeduc", "paeduc", "degree", "sex", "race", "income", "rincome", "region")
relevant_demo_var <- c()
gender_var_all <- c("fehome", "fework", "fechld", "mawrkwrm", "fehelp", "fepresch", "kidsuffr", "fefam", "famsuffr",
                         "hapifwrk", "homekid", "fejobind", "twoincs", "hubbywrk", "wrkbaby", "wrksch", 
                         "hubbywk1", "mrmom", "tradmod", "fekids1", "fekids5", "mekdcare", "feworkif", "era", "eratell")

gender_var_cp <- c("fehome", "fework", "fechld", "mawrkwrm", "fehelp", "fepresch", "kidsuffr", "fefam", "homekid", 
                   "twoincs", "hubbywrk", "hubbywk1", "mrmom", "tradmod", "feworkif")

gender_var_ad <- c("fefam", "fechld", "fepresch")


all_gender_var <- c(gender_var_all)

gss <- gss %>% 
  dplyr::select(year, id, starts_with("fipsstat"), wtssall, all_of(relevant_demo_var), all_of(gender_var_all)
         ) %>% 
  rename(stfips = fipsstat, stfips16 = fipsstat16) %>% 
  mutate(year = as.numeric(year)
         , stfips = as.numeric(stfips)
         , stfips16 = as.numeric(stfips16)
         , wtssall = as.numeric(wtssall)) 

# Download stname and abbr variable 
stdta <- fips_info() %>%
  mutate(fips = as.numeric(as.character(fips)))

# Merge back into main variable 
gss<- gss %>% 
  left_join(stdta, by = c("stfips" = "fips")) %>% 
  rename("stname" = "full"
         , "stabbr" = "abbr"
  ) %>% 
  dplyr::select(year, id, stfips, stfips16, stname, stabbr, everything())

# readjust gender indicators so higher is more progressive
gss <- gss %>% 
  mutate(fehome = as.numeric(fehome)
         , fework = case_when(
           fework == 1 ~ 2,
           fework == 2 ~ 1,
           is.na(fework) ~ NA_real_
           )
         , fechld = case_when(
           fechld == 4 ~ 1,
           fechld == 3 ~ 2,
           fechld == 2 ~ 3,
           fechld == 1 ~ 4,
           is.na(fechld) ~ NA_real_
         )
         , mawrkwrm = case_when(
           mawrkwrm == 5 ~ 1,
           mawrkwrm == 4 ~ 2,
           mawrkwrm == 3 ~ 3,
           mawrkwrm == 2 ~ 4,
           mawrkwrm == 1 ~ 5,
           is.na(mawrkwrm) ~ NA_real_
         )
         , fehelp = as.numeric(fehelp)
         , fepresch = as.numeric(fepresch)
         , kidsuffr = as.numeric(kidsuffr)
         , fefam = as.numeric(fefam)
         , famsuffr = as.numeric(famsuffr)
         , hapifwrk = case_when(
           hapifwrk == 5 ~ 1,
           hapifwrk == 4 ~ 2,
           hapifwrk == 3 ~ 3,
           hapifwrk == 2 ~ 4,
           hapifwrk == 1 ~ 5,
           is.na(hapifwrk) ~ NA_real_
         )
         , homekid = as.numeric(homekid)
         , fejobind = case_when(
           fejobind == 5 ~ 1,
           fejobind == 4 ~ 2,
           fejobind == 3 ~ 3,
           fejobind == 2 ~ 4,
           fejobind == 1 ~ 5,
           is.na(fejobind) ~ NA_real_
         )
         , twoincs = case_when(
           twoincs == 5 ~ 1,
           twoincs == 4 ~ 2,
           twoincs == 3 ~ 3,
           twoincs == 2 ~ 4,
           twoincs == 1 ~ 5,
           is.na(twoincs) ~ NA_real_
         )
         , hubbywrk = as.numeric(hubbywrk)
         , wrkbaby = case_when(
           wrkbaby == 3 ~ 1,
           wrkbaby == 2 ~ 2,
           wrkbaby == 1 ~ 3,
           is.na(wrkbaby) ~ NA_real_
         )
         , wrksch = case_when(
           wrksch == 3 ~ 1,
           wrksch == 2 ~ 2,
           wrksch == 1 ~ 3,
           is.na(wrksch) ~ NA_real_
         )
         , hubbywk1 = as.numeric(hubbywk1)
         , mrmom = as.numeric(mrmom)
         , tradmod = as.numeric(tradmod)
         , fekids1 = as.numeric(fekids1)
         , fekids5 = as.numeric(fekids5)
         , mekdcare = case_when(
           mekdcare == 5 ~ 1,
           mekdcare == 4 ~ 2,
           mekdcare == 3 ~ 3,
           mekdcare == 2 ~ 4,
           mekdcare == 1 ~ 5,
           is.na(mekdcare) ~ NA_real_
         )
         , feworkif = case_when(
           feworkif==2 ~ 1,
           feworkif==1~2,
           is.na(feworkif) ~ NA_real_
         )
         , era = case_when(
           era == 4 ~ 1,
           era == 3 ~ 2,
           era == 2 ~ 3,
           era == 1 ~ 4,
           is.na(era) ~ NA_real_
         )
         , eratell = case_when(
           eratell == 4 ~ 1,
           eratell == 3 ~ 2,
           eratell == 2 ~ 3,
           eratell == 1 ~ 4,
           is.na(eratell) ~ NA_real_
         )
         )

# Standardize to have mean 0 and sd = 1
gss <- gss %>% 
  mutate(across(all_of(all_gender_var), .names = "{.col}_orig")) %>% 
  mutate(across(all_of(all_gender_var), ~((.x-weighted.mean(.x, wtssall, na.rm=T))/weightedSd(.x, wtssall, na.rm=T))))

# create  an index of all the gender-related variables
gss <- gss %>% 
  # index 1: all variables
  mutate(index_all = rowMeans(.[ , gender_var_all], na.rm=TRUE)
    ) %>% 
  mutate(index_all = if_else(is.na(index_all), NA_real_,index_all)) %>% 
  # index 3: variables directly related to child penalties
  mutate(index_cp = rowMeans(.[ , gender_var_cp], na.rm=TRUE)
  ) %>% 
  mutate(index_cp = if_else(is.na(index_cp), NA_real_,index_cp)) %>% 
  # index 4: variables available across all decades
  mutate(index_ad = rowMeans(.[ , gender_var_ad], na.rm=TRUE)
  ) %>% 
  mutate(index_ad = if_else(is.na(index_ad), NA_real_,index_ad))


# Remove all haven formatting
gss <- zap_formats(gss)

saveRDS(gss, file.path(cleandir,"gss_clean.rds"))
foreign::write.dta(gss, file.path(cleandir,"gss_clean.dta"))



