#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file calculates child penalties by state and decade used
# in Figure 11 of the paper
# (Child Penalties vs Gender Progressivity Across States and Time)

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Load CPS/ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

# Define vector of outcome vars to run functions over
l.depvars <- c("earnings_ly", "emp_lw","earn_ly")

#  Drop aggregated statefip codes
cps_acs <- cps_acs %>%
  filter(statefip < 57) %>%
  droplevels()

# Function for df of penalties by state and time

penalties_time_dataset <- function(matched_data, timevar) {
  
  matched_data["timevar"] <- matched_data[[{{timevar}}]]

  penalties_time <- setDF(rbindlist(lapply(split(matched_data, matched_data$timevar), reg_es_statetime,
                                           depvar = "earnings_ly", hetero = "statename", 
                                           splitvar = "timevar"))) %>%
    bind_rows(setDF(rbindlist(lapply(split(matched_data, matched_data$timevar), reg_es_statetime,
                                     depvar = "earn_ly", hetero = "statename", splitvar = "timevar")))) %>%
    bind_rows(setDF(rbindlist(lapply(split(matched_data, matched_data$timevar), reg_es_statetime,
                                     depvar = "emp_lw", hetero = "statename", splitvar = "timevar"))))
  
  
  penalties_time <- penalties_time %>%
    dplyr::rename(statename = hetero) %>%
    mutate(splitvar = as.factor(as.character(splitvar))) %>%
    mutate(across(where(is_character),as_factor)) %>%
    merge(data.frame(fips = ipums_val_labels(matched_data$statefip)$val, statename = ipums_val_labels(matched_data$statefip)$lbl),
          by="statename")
  
  penalties_time <- apply_labels(penalties_time,
                                  penalty = "Child Penalty")

  penalties_time[{{timevar}}] <- penalties_time["splitvar"]
  penalties_time <- penalties_time %>%
    subset(select=-c(splitvar))

  return(penalties_time)
}


# Decades
gender_gap_10yr <- penalties_time_dataset(matched_data = cps_acs, timevar = "yr10")

gender_gap_10yr <- gender_gap_10yr %>%
  mutate(yr10 = as.factor(ifelse(yr10 == "1973-79", "1972-79", as.character(yr10))))

  # Save
saveRDS(gender_gap_10yr, file=file.path(wrkdir, "penalties_state_by_decade.rds"))
