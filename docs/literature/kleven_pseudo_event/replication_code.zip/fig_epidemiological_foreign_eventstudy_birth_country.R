#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates Figure 14, A.21, and the estimates used in A.22 of the paper
# Event studies are run for 81 countries of birth separately, plots are 
# generated for all 81 countries in one graph, and selected countries
# are plotted separately
# The child penalties in each country of birth for immigrants are saved

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Function to produce event studies for immigrants from each country of birth
reg_es_hetero_split <- function(data, depvar, hetero) {
  
  #Droplevels
  data <- droplevels(data)
  
  # Graph labels
  depvarlbl <- "emp_pooled"
  
  #Create Scandinavia as pooled observations of Denmark, Norway, and Sweden in CPS/ACS
  data <- data %>%
    mutate(bpl_country = case_when(bpl_country == "Denmark" | bpl_country == "Norway" | 
                                     bpl_country == "Sweden" ~ "Scandinavia",
                                   TRUE ~ as.character(bpl_country)))
  data$bpl_country <- as.factor(data$bpl_country)
  
  
  # Define birth country var
  data["hetero"] <- data[{{hetero}}] 
  
  # prepare dataset for pooled employment
  data <- data %>%
    mutate(pooled_employment = ifelse(!is.na(t_es_ly) & !is.na(earn_ly), 
                                      earn_ly, emp_lw),
           t_es = as.factor(ifelse(!is.na(t_es_ly) & !is.na(earn_ly), 
                                   as.character(t_es_ly), as.character(t_es_lw))))
  data <- apply_labels(data, pooled_employment="Employment")
    
  # Load CP Atlas results (penalties IN country of birth)
    
  global_penalties <- read_excel(file.path(rawdir,"Global Child Penalties","global_penalties.xlsx")) %>%
    rename(hetero = country) %>%
    rename(penalty_global = penalty) %>%
    filter(!(hetero %in% c("Czech Republic","Slovakia", "Denmark",
                           "Norway","Sweden"))) %>%
    subset(select=c(hetero,penalty_global))
  
  
  # Vector of countries to use
  l.countries <- unique(global_penalties$hetero)
  
  # Treat negative penalties as zero
  global_penalties <- global_penalties %>%
    mutate(penalty_global = ifelse(penalty_global < 0, 0, penalty_global))
  
  # Only keep desired countries in our data
  data <- data %>%
    filter(hetero %in% l.countries) %>%
    droplevels()
  
  data$t_es = factor(data$t_es, # re-order levels
                     levels=c("-2","-5", "-4", "-3", "-1",
                              "0", "1", "2", "3","4", "5", "6",
                              "7", "8", "9", "10"))
  
  # Event studies for immigrants from each country separately
  coef <- setDF(rbindlist(lapply(split(data, data$hetero), reg_es_immigrant, depvar = {{depvar}},
                                 splitvar="hetero", export=F)))
  
  coef <- coef %>%
    mutate(hetero = as.factor(as.character(hetero)))
  
  coef$t_es = factor(coef$t_es, # re-order levels
                     levels=c("-5", "-4", "-3", "-2", "-1",
                              "0", "1", "2", "3","4", "5", "6",
                              "7", "8", "9", "10"))
  
  # Prep for plot (labels and penalty text)
  coef <- coef %>%
    mutate(post = ifelse(t_es %in% c("-5","-4","-3","-2","-1"), 0, 1))
  
  # Calculate penalty (with pre-period adjustment)
  data["depvar"] <- data[{{depvar}}]
  post_mean <- aggregate(estimate ~  gender+post+hetero, 
                         data=coef ,
                         mean)
  post_mean <- post_mean %>%
    spread(post, estimate) %>%
    mutate(estimate=`1`-`0`)
  
  penalty <- post_mean %>%
    subset(select=-c(`1`,`0`)) %>%
    spread(gender, estimate) %>%
    mutate(penalty = `Men` - `Women`) %>%
    subset(select=c(hetero,penalty)) %>%
    mutate(depvar = {{depvar}},
           depvar_lab = var_label(data$depvar))
  
  # save pooled employment results
  saveRDS(penalty, file=file.path(wrkdir,"penalties_immigrants.rds"))
  
  # Dataframe with penalty labels for plots
  lab <- data.frame(x = rep("10", length(levels(coef$hetero))), # x is in levels, needs quotes
                    y = rep(-.85, length(levels(coef$hetero))), 
                    dplyr::count(coef, hetero))
  lab <- merge(lab, penalty, by=c("hetero"))
  lab$txt = sprintf("Child Penalty: %1.0f%%", (lab$penalty)*100)
  lab <- merge(lab, global_penalties, by="hetero")
  lab <- lab %>%
    mutate(num = as.numeric(hetero)) %>%
    mutate(graph = ifelse(num <= 42, 1, 2))
  
  # Reoeder rows for plot
  coef <- coef[order(coef$hetero,coef$gender, coef$t_es),]
  
  # X axis labels
  mylabels <- c("","-4","","-2","","0","", "2","", "4","", "6","", "8","", "10")
  
  coef <- merge(coef, global_penalties, by="hetero")
  
  # Indicator for plot later where we want to split countries into 2 plots
  coef <- coef %>%
    mutate(num = as.numeric(hetero)) %>%
    mutate(graph = ifelse(num <= 42, 1, 2))

  # Plot all countries together in two separate graphs
  for (graph_num in c(1,2)){
    #Need to drop levels for each graph
    coef_sub <- coef %>%
      filter(graph == graph_num) %>%
      droplevels()
    nlevels <- length(levels(coef_sub$hetero))
    lab_sub <- lab %>%
      filter(graph == graph_num) %>%
      droplevels()

    #Make plots
    ggplot(coef_sub, aes(y=estimate, x=t_es, color=gender, group=gender))  +
      # do each country separately, free axes
      facet_wrap(~ hetero, scales="free") +
      # display all x values on axis
      scale_x_discrete(labels=mylabels, breaks=levels(coef_sub$t_es)) +
      # add confidence intervals
      geom_errorbar(aes(ymin=conf.low, ymax=conf.high), linewidth=0.2,width=0.3) +
      # line and point sizes
      geom_line(linewidth=.3) +
      geom_point(size=.5) +
      # y-scale
      #ylim(-1.3, 0.5) +
      scale_y_continuous(labels = c("-1.2","-0.8","-0.4"," 0.0"," 0.4"),breaks=c(-1.2,-0.8,-0.4,0,0.4), limits=c(-1.3,0.5))+
      # axis labels
      labs(x="Event Time (Years)", y=paste(var_label(data$depvar),"Impact (%)")) +
      # line at t=-0.5
      geom_vline(xintercept = 5.5, linetype="solid", color = "#D11809",linewidth=.3) +
      geom_text(aes(x = 7.9,
                    y = 0.4,
                    label="First Child",group=NULL),
                size=1.7,color="grey25",check_overlap=T)+
      # theme + grid lines
      theme_minimal() +
      theme(axis.line = element_line(colour = "black",linewidth=0.1)) +
      theme(panel.grid.major.x = element_blank(),
            panel.grid.minor.y = element_blank(),
            legend.position = "none",
            panel.spacing = unit(-.2, "lines"),
            axis.text.x = element_text(size=5),
            axis.text.y = element_text(size=5),
            axis.ticks = element_line(size = 0.1),
            axis.ticks.length=unit(.05, "cm")) +
      theme(strip.text.x = element_text(size = 9))+
      # line color and legend labels
      scale_color_manual(name="",
                         breaks=c("Men","Women"),
                         values=c("grey49","black"),) +
      # Child penalty
      geom_text(aes(x=7.8, y=-0.865, label=paste0("Child Penalty:"), group=NULL),
                size = max(1.4, 12/nlevels),color="black", fontface="bold",hjust=0,check_overlap=T, data=lab_sub)+
      geom_text(aes(x=7.8, y=-1, group=NULL,label=paste0(
        "US Immigrants: ",
        round(penalty*100),
        "%")),size = max(1.4, 12/nlevels),color="black",check_overlap = T,hjust=0, data=lab_sub)+
      geom_text(aes(x=7.8, y=-1.13, group=NULL,label=paste0(
        "Country of Birth: ",round(penalty_global*100), "%")),
        size = max(1.4, 12/nlevels),color="black",check_overlap = T,hjust=0, data=lab_sub)

    ggsave(paste0("epidemiological_immigrants_allcountries_",depvarlbl,
                  "_plot",graph_num,".pdf"), plot=last_plot(), device="pdf",
           width=11, height=8, units="in",path=file.path(outdir,"Figures"))
  }
  

  # Plot some countries separately
  l.countries2 <- c("Vietnam", "China", "Japan", "Jordan",
                    "Haiti", "Cuba", "Brazil", "Mexico",
                    "Nigeria", "Ethiopia", "South Africa", "Morocco")
  for(st in l.countries2){
    
    stname <- tolower(gsub(" ", "", st, fixed = TRUE))
    stname <- gsub("\\+", "", stname)
    stname <- gsub("/", "_", stname)
    
    ggplot(coef[coef$hetero==st,], aes(y=estimate, x=t_es, color=gender, group=gender))  + 
      # display all x values on axis
      scale_x_discrete(labels=as.character(coef[coef$hetero==st,"t_es"]), breaks=coef[coef$hetero==st,"t_es"])+
      # add confience intervals
      geom_ribbon(aes(ymin=conf.low,ymax=conf.high,fill=gender),alpha=0.3,show.legend = F,
                  colour = NA) +
      # line and point sizes
      geom_line(linewidth=1) + 
      geom_point(size=4) +
      # y-scale
      scale_y_continuous(labels = c("-1.2","-0.8","-0.4"," 0.0"," 0.4"),breaks=c(-1.2,-0.8,-0.4,0,0.4), limits=c(-1.3,0.5))+
      # axis labels
      labs(x="Event Time (Years)", y=paste(var_label(data$depvar),"Impact (%)")) +
      # line at t=-0.5
      geom_vline(xintercept = 5.5, linetype="solid", color = "#D11809",linewidth=1.2)+
      # theme + grid lines
      theme_minimal() + 
      theme(axis.line = element_line(colour = "black",linewidth=0.4)) +
      theme(panel.grid.major.x = element_blank(),
            panel.grid.minor.y = element_blank(),
            legend.position = "bottom",
            legend.key.size = unit(3,"lines")) +
      # label next to line
      geom_text(aes(x=6.9,
                    label="First Child",y=0.5),
                size=8.6,color="grey25",check_overlap=T)+
      theme(axis.text.x = element_text(vjust = -0.5),
      ) +
      theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)),
            axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)))+
      theme(text=element_text(size=25)
      ) +
      # line color and legend labels
      scale_color_manual(name="",
                         breaks=c("Men","Women"),
                         values=c("black",rgb(193,5,52, maxColorValue = 255)),
                         labels=c("Men","Women")) +
      scale_fill_manual(values=c("black",
                                 rgb(193,5,52, maxColorValue = 255)),
                        breaks=c("Men","Women"),
                        name="")+
      # panel labels
      geom_text(aes(x=8.92, y=-0.88, label=paste0("Child Penalty:")), 
                size=8,color="black",fontface="bold",hjust=0,check_overlap=T)+
      # Child penalty
      geom_text(aes(x=8.92, y=-1.04, group=NULL,label=paste0(
        "US Immigrants: ",
        round(penalty*100),"%"))
        ,size = 8,color="black",check_overlap = T,hjust=0, data=lab[lab$hetero==st,])+
      geom_text(aes(x=8.92, y=-1.2, group=NULL,label=paste0(
        "Country of Birth: ",round(penalty_global*100), "%"))
        ,size = 8,color="black",check_overlap = T,hjust=0, data=lab[lab$hetero==st,])
    ggsave(paste0("epidemiological_immigrants","_",stname,"_",{{depvarlbl}},
                  ".pdf"), plot=last_plot(), device="pdf",
           width=11, height=8, units="in",path=file.path(outdir,"Figures"))
      
  }
  
}

# Load CPS and ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

# Filter out to only keep foreign born people
cps_acs <- cps_acs %>%
  filter(immigrant == "Immigrant")

# Create Figures
reg_es_hetero_split(data=cps_acs, hetero="bpl_country", depvar="pooled_employment")
