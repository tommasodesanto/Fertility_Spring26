#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file installs packages used throughout the code.

#############################################################################################

############################################
# Functions, file paths, and packages
############################################

# Packages and versions
pkgs_versions = c(
  here              = "1.0.1",
  broom             = "1.0.9",
  data.table        = "1.17.8",
  dplyr             = "1.1.4",
  e1071             = "1.7.16",
  purrr             = "1.1.0",
  ggplot2           = "3.5.2",
  ggthemes          = "5.1.0",
  gridExtra         = "2.3",
  haven             = "2.5.5",
  ROCR              = "1.0.11",
  scales            = "1.4.0",
  tidyr             = "1.3.1",
  plm               = "2.6.6",
  survey            = "4.4.2",
  multcomp          = "1.4.28",
  car               = "3.1.3",
  ipumsr            = "0.9.0",
  fixest            = "0.12.1",
  xtable            = "1.8.4",
  usmap             = "0.8.0",
  usmapdata         = "0.6.0",
  RColorBrewer      = "1.1.3",
  maps              = "3.4.3",
  lubridate         = "1.9.4",
  MatchIt           = "4.7.2",
  easyPSID          = "0.1.2",
  Matching          = "4.10.15",
  stargazer         = "5.2.3",
  mlr               = "2.19.2",
  tigris            = "2.2.1",
  sf                = "1.0.23",
  kableExtra        = "1.4.0",
  AER               = "1.2.15",
  DT                = "0.33",
  RStata            = "1.1.2",
  directlabels      = "2025.6.24",
  matrixStats       = "1.5.0",
  gridGraphics      = "0.5.1",
  binsreg           = "1.1",
  conflicted        = "1.2.0",
  rnaturalearth     = "1.1.0",
  labelled          = "2.14.1",
  rnaturalearthdata = "1.0.0",
  cowplot           = "1.2.0",
  tidyverse         = "2.0.0",
  boot              = "1.3.31",
  plyr              = "1.8.9",
  readxl            = "1.4.5",
  foreign           = "0.8.90",
  ggtext            = "0.1.2",
  tictoc            = "1.2.1"
)

if (!requireNamespace("remotes", quietly = TRUE)) {
  install.packages("remotes")
}

for (pkg in names(pkgs_versions)) {
  current_version <- tryCatch(
    as.character(packageVersion(pkg)),
    error = function(e) NA
  )
  if (is.na(current_version) || current_version != pkgs_versions[[pkg]]) {
    message("Installing ", pkg, " @ ", pkgs_versions[[pkg]])
    remotes::install_version(
      pkg,
      version = pkgs_versions[[pkg]],
      upgrade = "never",
      dependencies = TRUE
    )
  } else {
    message(pkg, " already at version ", current_version)
  }
}

# user-written package with function to draw from truncated normal distribution
if (!requireNamespace("devtools", quietly = TRUE)) {
  install.packages("devtools")
}

if (!requireNamespace("truncnorm", quietly = TRUE)) {
  devtools::install_github("olafmersmann/truncnorm")
}