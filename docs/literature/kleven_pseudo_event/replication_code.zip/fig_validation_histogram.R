#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates Figure A.4 of the paper
# (Quality of Fertility Prediction)

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Read in matched annual employment data, keep childless people only
  # (i.e. people who are at negative event times in the actual panel
  # or never have children in the panel)

data <- readRDS(file=file.path(wrkdir,paste0("psid_nlsy_pseudo-panel",".rds"))) %>%
  subset(!is.na(t_es_ly)) %>%
  subset(child == 0) %>%
  mutate(origin="Imputed") %>%
  # calculate difference in predicted vs actual event times
  mutate(difference = t_numeric - t_es_ly_actual)

# If never have children in panel or difference is > 20, topcode at 21
data <- data %>%
  mutate(difference = ifelse(difference > 20 | is.na(t_es_ly_actual), 21, difference))

# Filter out those that never have kids in actual panel
    # Just keep one observation
neverparent <- data %>%
  subset(is.na(t_es_ly_actual)) %>%
  subset(select=c(id, dataset)) %>%
  distinct() %>%
  mutate(never = 1)

# Load full panel dataset to compare pseudo-panel to
load(file=file.path(cleandir,"psid_clean_all.RData"))
load(file=file.path(cleandir,"nlsy79_clean_all.RData"))
  
  # Merge panel with dataframe of people identified as non-parents
psid_nlsy <- bind_rows(psid, nlsy) %>%
  merge(neverparent, by=c("id","dataset"), all.x=T) %>%
  subset(never==1)

  # Get max age we obs people who never have children in panel
maxage <- psid_nlsy %>%
  group_by(id, dataset) %>%
  summarize(age = max(age, na.rm=T))

  # Indicator for which ones are interviewed late enough to know they don't have kids
      # Defined as people over 44
neverparent <- merge(neverparent, maxage, by=c("id","dataset"), all=T) %>%
  subset(age >= 45) %>%
  subset(select=-c(age))

  # Add indicator to full pseudo-panel dataset
data <- merge(data, neverparent, all=T, by=c("id","dataset"))

  # Only keep those that never have parents we observe over 44
    # i.e. those people were old enough when they were last obs in the panel
    # that we can safely assume they really do never have children
data <- data %>%
  subset(!is.na(t_es_ly_actual) | (is.na(t_es_ly_actual) & never == 1))

  # Count number of observations 
total <- sum(data$wgt_match)

  # Count number of obs with each value of diff b/w actual and predicted event time
    # for histogram
test2 <- data %>%
  group_by(difference) %>%
  summarize(n = sum(wgt_match)) %>%
  # calculate fraction of people in each histogram bin
  mutate(frac = n/total) %>%
  mutate(range = ifelse(inrange(difference, -4,4), 1,0))

  # Count fraction between -4 and 4 to mention in text of paper
test3 <- test2 %>%
  group_by(range) %>%
  summarize(sum = sum(frac))


# Plot histogram

  # vector of labels for histogram
labels <- seq(min(data$difference,na.rm=T),max(data$difference,na.rm=T),1)

labels_text <- seq(min(data$difference,na.rm=T),max(data$difference,na.rm=T),1)

  # Want the final label to say "Never" (the bin that includes people who are never observed as having kids)
labels_text[length(labels)] <- "    Never"

  # create a weighted histogram
ggplot(data, aes(x=difference, weight=wgt_match))+
  geom_histogram(aes(y=after_stat(density)),binwidth=1,alpha=0.7, position="identity",color=rgb(26,71,111, maxColorValue = 255), fill=rgb(26,71,111, maxColorValue = 255))+
  # display all x values on axis
  scale_x_continuous(breaks=labels, labels=labels_text,
                     minor_breaks=seq(-4.5,21.5,1))+
  scale_y_continuous(breaks=seq(0,0.35,0.05))+
  coord_cartesian(ylim=c(0,0.35), xlim=c(-4.3,21.3))+
  # axis labels
  labs(x="Predicted - Actual Event Time", y="Density") +
  # theme + grid lines
  theme_minimal() +
  theme(axis.line = element_line(colour = "black",size=0.4)) +
  theme(panel.grid.major.x = element_blank(),
        panel.grid.minor.y = element_blank(),
        legend.position = "none",
        panel.spacing = unit(-.2, "lines"),
        legend.key.size = unit(3,"lines"),
        legend.text=element_text(size=15),
        axis.text.y = element_text(size=15,vjust = -0.5),
        axis.text.x = element_text(size=13),
        axis.title.y = element_text(size=20,margin = margin(t = 0, r = 20, b = 0, l = 0)),
        axis.title.x = element_text(size=20,margin = margin(t = 20, r = 0, b = 0, l = 0)))

ggsave("fertility_prediction.pdf", plot=last_plot(), device="pdf",
       width=11, height=8, units="in",path=file.path(outdir,"Figures"))
