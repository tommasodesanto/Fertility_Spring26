#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates the event studies by state of residence in Figures
# 5 and A.11-A.13, heatmaps in Figure 6, and estimates the child penalties used in Figure 7

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Define vector of outcome vars
l.depvars <- c("earnings_ly", "emp_lw","earn_ly")

# Load CPS and ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))


# Crosswalk of state fips codes and names
xwalk = data.frame(fips = ipums_val_labels(cps_acs$statefip)$val, hetero = ipums_val_labels(cps_acs$statefip)$lbl)

# Run event studies for all vars by state, return child penalties
es.state <- setDF(rbindlist(lapply(l.depvars,
                                   reg_es_state, data=filter(cps_acs, statefip < 57),
                                   hetero="statename", interact="census",
                                   return_final="penalty", plotname="child_penalties_state"))) %>%
  rename(penalty = estimate) %>%
  merge(xwalk, by="hetero", all.x=T)

# Label child penalty var
es.state <- apply_labels(es.state, penalty = "Child Penalty")

# Figure 6: Create heat maps of child penalties
lapply(split(es.state, es.state$depvar), statemap, outcome = "penalty",
       plotname = "child_penalties_state_heatmap")

# Save child penalties
saveRDS(es.state, file=file.path(wrkdir,"penalties_state.rds"))




# Run event studies again to return child penalties unadjusted by counterfactual
  # for Figure 7
es.state.unadjust <- setDF(rbindlist(lapply(c("earnings_ly","earn_ly","emp_lw"),
                                             reg_es_state, data=subset(cps_acs, statefip < 57),
                                             hetero="statename", interact="census",return_coef="unadjust",
                                             export=F, return_final="penalty")))


# Save dataset of unadjusted penalties
saveRDS(es.state.unadjust, file=file.path(wrkdir,"penalties_state_unadjusted.rds"))
