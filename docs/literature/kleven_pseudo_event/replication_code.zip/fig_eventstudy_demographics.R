#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates Figure 8 in the paper
# (Child Penalties Across Demographic Groups)

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Define vector of outcome vars to run functions over
l.depvars <- c("earnings_ly", "emp_lw","earn_ly")

# Load CPS and ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

#########################

# Run event studies

#########################

# Education
    # compare those with a high school degree or less to those with a college degree or more
    # therefore, we exclude the "some college" category in the education variable completely
lapply(l.depvars, reg_es_demographics, data = subset(cps_acs, edlevel != "Some college"), 
       hetero = "hsandbelow", plotname = "child_penalties_educ")

# Marital status
cps_acs <- cps_acs %>%
  mutate(married_dummy = as.factor(case_when(married == "Married"~ "Married",
                                             married == "Single" ~ "Single")))
cps_acs$married_dummy <- factor(cps_acs$married_dummy, levels=c("Married", "Single"))
lapply(l.depvars, reg_es_demographics, data=cps_acs, hetero="married_dummy", plotname="child_penalties_marital")

# Race
  # Define new race dummy to use (Black vs White, missing for others)
cps_acs <- cps_acs %>%
  mutate(race_dummy = as.factor(case_when(race_raw == "White"~ "White",
                                          race_raw == "Black" ~ "Black")))
cps_acs$race_dummy <- factor(cps_acs$race_dummy, levels=c("White", "Black"))

lapply(l.depvars, reg_es_demographics, data = cps_acs, hetero="race_dummy", plotname="child_penalties_race")
