#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file cleans ACS data

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

#########################
#Load data
#########################

load(file.path(rawdir,"ACS","raw_acs.RData"))
acs <- data
rm(data)

# variable names
names(acs) <- tolower(names(acs))

#########################
#1. Demographics

#########################

# 1.1 Children

acs.clean <- acs %>%
  mutate(child = case_when(nchild>0 ~ 1,
                           nchild <= 0 ~ 0,
                           is.na(nchild) ~ NA_real_
  ),
  age1b = ifelse(eldch != 99, age - eldch, NA_real_),
  ch1yob = ifelse(eldch !=99, year - eldch, NA),
  chtot = nchild)

# Relationship to head: detailed var available 2008 onwards
acs.clean <- acs.clean %>%
  mutate(biochild = ifelse(related == 301 | relate == 3, 1, 0),
         stepchild = ifelse(related %in% c(302,303), 1, 0)) # adopted or stepchild

# 1.2 Education

acs.clean <- acs.clean %>%
  mutate(edlevel = as.factor(case_when(inrange(educd, 2, 61) ~ "Below HS",
                                       inrange(educd, 62,64) ~ "HS grad",
                                       inrange(educd, 65, 100) ~ "Some college",
                                       inrange(educd, 101, 116) ~ "College +"))) %>%
  mutate(edlevel_det = as.factor(case_when(inrange(educd, 2, 61) ~ "Below HS",
                                           inrange(educd, 62, 64) ~ "HS grad",
                                           inrange(educd, 65,80) | inrange(educd, 90,100)  ~ "College dropout",
                                           inrange(educd,81,83) ~ "Associate's degree",
                                           inrange(educd, 101, 113) ~ "Bachelor's degree",
                                           inrange(educd, 114,116) ~ "Post-graduate degree"))) %>%
  mutate(college = case_when(inrange(educd, 2, 100) ~ 0,
                              inrange(educd, 101, 116) ~ 1))
acs.clean <- acs.clean %>%
  mutate(hsandbelow = ifelse(edlevel %in% c("Below HS", "HS grad"), 1, 0))

# 1.3 Marital status

acs.clean <- acs.clean %>%
  mutate(marst = ifelse(marst == 9, NA_integer_, marst)) %>%
  mutate(single = case_when(inrange(marst, 2, 7) ~ 1,
                            !inrange(marst, 2, 7) & !is.na(marst) ~ 0,
                            is.na(marst) ~ NA_real_)) %>%
  mutate(married = as.factor(case_when(marst %in% c(1,2) ~ "Married",
                                       !inrange(marst, 1,2) & !is.na(marst) ~ "Single"))) %>%
  mutate(marst_det = as.factor(case_when(marst == 1 ~ "Married, spouse present",
                                         marst == 2 ~ "Married, spouse absent",
                                         marst == 3 ~ "Separated",
                                         marst == 4 ~ "Divorced",
                                         marst == 5 ~ "Widowed",
                                         marst == 6 ~ "Never married/single",
                                         marst == 7 ~ "Widowed or divorced"))) %>%
  mutate(marst = as.factor(case_when(marst == 1 ~ "Married, spouse present",
                                     inrange(marst, 2, 3) ~ "Married, spouse absent",
                                     marst %in% c(4) ~ "Divorced",
                                     marst == 5 ~ "Widowed",
                                     marst == 6 ~ "Never married/single",
                                     marst == 7 ~ "Divorced or widowed")))

# 1.4 Race

  # Hispanic dummy
acs.clean <- acs.clean %>%
  mutate(hispanic = ifelse(inrange(hispan, 1, 4), 1, 0))

names(acs.clean)[names(acs.clean) == 'race'] <- 'temp'

acs.clean <- acs.clean %>%
  # Create detailed race/ethnicity variable with 5 categories  
  mutate(raced = as.factor(case_when(temp == 1 & hispanic == 0 ~ "White, non-hispanic",
                                     temp == 2 & hispanic == 0 ~ "Black, non-hispanic",
                                     inrange(temp, 4, 6) & hispanic == 0 ~ "Asian/PI, non-hispanic",
                                     temp %in% c(3, 7, 8, 9) & hispanic == 0 ~ "Other, non-hispanic",
                                     hispanic == 1 ~ "Hispanic"))) %>%
  # Numeric version of same var
  mutate(raced.num = as.factor(case_when(temp == 1 & hispanic == 0 ~ 1,
                                         temp == 2 & hispanic == 0 ~ 2,
                                         inrange(temp, 4, 6) & hispanic == 0 ~ 3,
                                         temp %in% c(3, 7, 8, 9) & hispanic == 0 ~ 4,
                                         hispanic == 1 ~ 5)))

acs.clean <- acs.clean %>%
  # Create race/ethnicity variable with only 4 categories
  mutate(race = as.factor(case_when(temp == 1 & hispanic == 0 ~ "White, non-hispanic",
                                    temp == 2 & hispanic == 0 ~ "Black, non-hispanic",
                                    inrange(temp, 3, 9) & hispanic == 0 ~ "Other, non-hispanic",
                                    hispanic == 1 ~ "Hispanic"))) %>%
  mutate(race.num = as.factor(case_when(temp == 1 & hispanic == 0 ~ 1,
                                        temp == 2 & hispanic == 0 ~ 2,
                                        inrange(temp, 3, 9) & hispanic == 0 ~ 3,
                                        hispanic == 1 ~ 4)))

# Create race variable (Hispanic is not a separate category, 
# i.e. Hispanic people are kept within their actual racial category)
acs.clean <- acs.clean %>%
  mutate(race_raw = as.factor(case_when(temp == 1 ~ "White",
                              temp == 2 ~ "Black",
                              inrange(temp, 3, 9) ~ "Other")))

  # Race dummies
acs.clean <- acs.clean %>%
  mutate(white = ifelse(race == "White, non-hispanic", 1,0),
         black = ifelse(race == "Black, non-hispanic", 1,0),
         white_hisp = ifelse(race_raw == "White", 1,0),
         black_hisp = ifelse(race_raw == "Black", 1,0))

# 1.5 Other
acs.clean <- acs.clean %>%
  
  # Gender
  mutate(gender = as.factor(ifelse(sex==2, "Women", "Men"))) %>%
  
  # Age
  mutate(age = ifelse(age>90, 90, age)) %>%
  
  # Cohort
  mutate(doby = birthyr)
  
# State of residence 
acs.clean <- acs.clean %>%
  mutate(statefip = ifelse(statefip == 99, NA_real_, statefip))

acs.clean$statename = factor(acs.clean$statefip, 
                             levels = ipums_val_labels(acs$statefip)$val, 
                             labels = ipums_val_labels(acs$statefip)$lbl)

#########################
#2. Work and Income

#########################

acs.clean <- acs.clean %>%
  
  # 2.1 Income: use wage income for earnings var
  mutate(incwage = ifelse(incwage %in% c(999999, 999998),NA_real_,
                          incwage)) %>%
  
  mutate(earnings_ly = incwage)

    # Annual employment
acs.clean <- acs.clean %>%
  mutate(earn_ly = case_when(earnings_ly > 0 & !is.na(earnings_ly) ~ 1,
                             earnings_ly <= 0 & !is.na(earnings_ly) ~ 0,
                             is.na(earnings_ly) ~ NA_real_))

# 2.2 Labor Force Participation
acs.clean <- acs.clean %>%
  mutate(inlf_lw = case_when(inrange(empstat, 1,2) & !inrange(age, 0, 15) ~ 1,
                             empstat == 3 & !inrange(age, 0, 15) ~ 0,
                             inrange(age, 0, 15) ~ NA_real_)) %>%
    # Weekly Employment
  mutate(emp_lw = case_when(empstat == 1 & !inrange(age, 0, 15) ~ 1,
                            inrange(empstat, 2, 3) & !inrange(age, 0, 15) ~ 0,
                            inrange(age, 0, 15) ~ NA_real_))

# Usual hours worked per week, top coded at 99
acs.clean <- acs.clean %>%
  mutate(hrs_ly = uhrswork)

# # 2.3 Industry/occupation

# Self-Employed
# classwkr: 1- self-employed, 2-works for wages, 0-NA, available all years
acs.clean <- acs.clean %>%
   mutate(classwkr = as.factor(case_when(classwkr == 1 ~ "Self-employed",
                                         classwkr == 2 ~ "Works for wages",
                                         classwkr %in% c(0, NA_real_) ~ "Unknown or unemployed")))
# Works in agriculture

acs.clean <- acs.clean %>%
  mutate(agriculture = as.factor(case_when(ind1950 == 105 ~ "Agricultural worker",
                                 inrange(ind1950, 116, 936) ~ "Non-agricultural worker",
                                 ind1950 %in% c(0, NA_real_) ~ "Unknown or unemployed")))

# Works in industry- 306-499 is manufacturing

acs.clean <- acs.clean %>%
  mutate(industry = as.factor(case_when(inrange(ind1950, 306, 499) ~ "Manufactural worker",
                                           inrange(ind1950, 105, 246) | inrange(ind1950, 506, 936) ~ "Non-manufactural worker",
                                           ind1950 %in% c(0, NA_real_) ~ "Unknown or unemployed")))


#########################
#3. Define sample, ID and weights

#########################

# 3.1 ID
acs.sample <- acs.clean %>%
  group_by(year, serial, pernum) %>%
  mutate(id = cur_group_id()) %>%
  ungroup()

# 3.2 Weights
acs.sample <- acs.sample %>%
  mutate(wgt = perwt) 

# 3.3 Year of interview intervals

acs.sample <- acs.sample %>%
  mutate(doiy = year) %>%
  mutate(yr5 = as.factor(case_when(
    inrange(doiy, 1973, 1979) ~ "1973-79",
    inrange(doiy, 1980, 1984) ~ "1980-84",
    inrange(doiy, 1985, 1989) ~ "1985-89",
    inrange(doiy, 1990, 1994) ~ "1990-94",
    inrange(doiy, 1995, 1999) ~ "1995-99",
    inrange(doiy, 2000, 2004) ~ "2000-04",
    inrange(doiy, 2005, 2009) ~ "2005-09",
    inrange(doiy, 2010, 2014) ~ "2010-14",
    inrange(doiy, 2015, 2020) ~ "2015-20")))

acs.sample <- acs.sample %>%
  mutate(yr10 = as.factor(case_when(
    inrange(doiy, 1973, 1979) ~ "1973-79",
    inrange(doiy, 1980, 1989) ~ "1980-89",
    inrange(doiy, 1990, 1999) ~ "1990-99",
    inrange(doiy, 2000, 2009) ~ "2000-09",
    inrange(doiy, 2010, 2020) ~ "2010-20")))

# interval year intervals around welfare reform
acs.sample <- acs.sample %>%
  mutate(yr5_reform = as.factor(case_when(
    inrange(doiy, 1973, 1979) ~ "1973-79",
    inrange(doiy, 1980, 1984) ~ "1980-84",
    inrange(doiy, 1985, 1989) ~ "1985-89",
    inrange(doiy, 1990, 1994) ~ "1990-94",
    inrange(doiy, 1995, 1999) ~ "1995-99",
    inrange(doiy, 2000, 2004) ~ "2000-04",
    inrange(doiy, 2005, 2009) ~ "2005-09",
    inrange(doiy, 2010, 2020) ~ "2010-20")))

acs.sample <- acs.sample %>%
  mutate(yr10_reform = as.factor(case_when(
    inrange(doiy, 1973, 1980) ~ "1973-1980",
    inrange(doiy, 1981, 1990) ~ "1981-1990",
    inrange(doiy, 1991, 2000) ~ "1991-2000",
    inrange(doiy, 2001, 2010) ~ "2000-2010",
    inrange(doiy, 2011, 2020) ~ "2011-2020")))

acs.sample <- acs.sample %>%
  mutate(post_reform = as.factor(case_when(
    doiy < 1990 ~ "pre-94",
    inrange(doiy, 1990, 1994) ~ "1990-94",
    doiy > 1994 ~ "post-94")))


# 3.4 Year of immigration 
acs.sample <- acs.sample %>%
  mutate(yrimmig =ifelse(yrimmig == 0, NA_real_, yrimmig)) %>%
  mutate(ageimmig = yrimmig - doby)

# Years in USA
acs.sample <- acs.sample %>%
  mutate(yrsusa = ifelse(bpl < 100 & yrsusa1 == 0, NA_real_, yrsusa1)) %>%
  mutate(ageimmig2 = age - yrsusa)


# 3.5 Year of childbirth
acs.sample <- acs.sample %>%
  mutate(ch1yob10 = as_factor(case_when(inrange(ch1yob, 1972, 1979) ~ "1972-79",
                                        inrange(ch1yob, 1980, 1989) ~ "1980-89",
                                        inrange(ch1yob, 1990, 1999) ~ "1990-99",
                                        inrange(ch1yob, 2000, 2009) ~ "2000-09",
                                        inrange(ch1yob, 2010, 2018) ~ "2010-20")))%>%
  mutate(ch1yob5 = floor(ch1yob/5)*5)

##########################
#4. Geographic
##########################

# 4.1 Residence

  # State of residence groups
acs.sample <- acs.sample %>%
  mutate(stateagg = as.factor(case_when(
    statename %in% c("Georgia","North Carolina-South Carolina","North Carolina",
                     "South Carolina","South-Carolina-Georgia") ~ "North Carolina-South Carolina-Georgia",
    statename %in% c("Kentucky","Tennessee") ~ "Kentucky-Tennessee",
    statename %in% c("Louisiana","Arkansas-Oklahoma", "Arkansas",
                     "Oklahoma") ~ "Arkansas-Louisiana-Oklahoma",
    statename %in% c("Maryland","West Virginia","Delaware-Virginia",
                     "Delaware","Virginia") ~ "Delaware-Maryland-Virginia-West Virginia",
    statename %in% c("Missouri","Minnesota-Iowa","Nebraska-North Dakota-South Dakota-Kansas",
                     "Minnesota","Iowa","Nebraska","North Dakota","South Dakota","Kansas")
    ~ "Iowa-N Dakota-S Dakota-Nebraska-Kansas-Minnesota-Missouri",
    statename %in% c("Oregon","Alaska-Washington-Hawaii", "Washington","Hawaii","Alaska")
    ~ "Washington-Oregon-Alaska-Hawaii",
    statename %in% c("New Hampshire-Maine-Vermont-Rhode Island", "Massachusetts",
                     "New Hampshire","Maine","Vermont","Rhode Island")
    ~ "Maine-Massachusetts-New Hampshire-Rhode Island-Vermont",
    statename %in% c("Arizona-New Mexico-Colorado","Idaho-Wyoming-Utah-Montana-Nevada",
                     "Montana","Wyoming","Colorado","New Mexico","Utah","Nevada",
                     "Arizona", "Idaho","Montana-Wyoming-Colorado-New Mexico-Utah-Nevada-Arizona")
    ~ "Montana-Wyoming-Colorado-New Mexico-Utah-Nevada-Arizona-Idaho",
    statename %in% c("Michigan","Wisconsin") ~ "Michigan-Wisconsin",
    statename %in% c("Alabama","Mississippi") ~ "Alabama-Mississippi"))) 

acs.sample <- acs.sample %>%
  mutate(stateagg = as.factor(ifelse(is.na(stateagg), as.character(statename),as.character(stateagg))))

  # Census division of residence
acs.sample <- acs.sample %>%
  mutate(census = as.factor(case_when(statename %in% c("Connecticut","Maine","Massachusetts",
                                                       "New Hampshire","Rhode Island","Vermont",
                                                       "Maine-Massachusetts-New Hampshire-Rhode Island-Vermont",
                                                       "New Hampshire-Maine-Vermont-Rhode Island") 
                                      ~ "New England",
                                      statename %in% c("New Jersey", "New York", "Pennsylvania")
                                      ~ "Mid-Atlantic",
                                      statename %in% c("Illinois","Indiana","Michigan",
                                                       "Ohio", "Wisconsin","Michigan-Wisconsin") 
                                      ~ "East North Central",
                                      statename %in% c("Iowa", "Kansas","Minnesota","Missouri",
                                                       "Nebraska","North Dakota","South Dakota","Minnesota-Iowa",
                                                       "Nebraska-North Dakota-South Dakota-Kansas",
                                                       "Iowa-N Dakota-S Dakota-Nebraska-Kansas-Minnesota-Missouri")
                                      ~ "West North Central",
                                      statename %in% c("Delaware","Florida","Georgia","Maryland",
                                                       "North Carolina","South Carolina","Virginia",
                                                       "District of Columbia", "West Virginia","Delaware-Virginia",
                                                       "North Carolina-South Carolina","South Carolina-Georgia",
                                                       "Delaware-Maryland-Virginia-West Virginia")
                                      ~ "South Atlantic",
                                      statename %in% c("Alabama","Kentucky","Mississippi",
                                                       "Tennessee","Alabama-Mississippi","Kentucky-Tennessee") 
                                      ~ "East South Central",
                                      statename %in% c("Arkansas","Louisiana","Oklahoma",
                                                       "Texas","Arkansas-Oklahoma","Arkansas-Louisiana-Oklahoma")
                                      ~ "West South Central",
                                      statename %in% c("Arizona","Colorado","Idaho",
                                                       "Montana","Nevada","New Mexico","Utah","Wyoming",
                                                       "Arizona-New Mexico-Colorado","Idaho-Wyoming-Utah-Montana-Nevada",
                                                       "Montana-Wyoming-Colorado-New Mexico-Utah-Nevada-Arizona")
                                      ~ "Mountain",
                                      statename %in% c("Alaska","California","Hawaii",
                                                       "Oregon","Washington","Alaska-Washington-Hawaii",
                                                       "Washington-Oregon-Alaska-Hawaii")
                                      ~ "Pacific"))) %>%
  mutate(region = as.factor(case_when(census == "New England" | census == "Mid-Atlantic"
                                      ~ "Northeast",
                                      census %in% c("East North Central", "West North Central")
                                      ~ "Midwest",
                                      census %in% c("South Atlantic","East South Central",
                                                    "West South Central") ~ "South",
                                      census %in% c("Mountain","Pacific") ~ "West")))


  ## Modified census divisions of residence
acs.sample <- acs.sample %>%
  mutate(census_modified = as.factor(case_when(statename %in% c("Minnesota","Wisconsin","North Dakota", "South Dakota") 
                                               ~ "North Central",
                                               statename %in% c("Michigan", "Illinois","Indiana", "Ohio")
                                               ~ "Great Lakes",
                                               statename %in% c("New Jersey","New York","Pennsylvania","Delaware",
                                                                "Maryland","District of Columbia")
                                               ~ "Mid-Atlantic",
                                               statename %in% c("Connecticut","Maine","Massachusetts","New Hampshire",
                                                                "Rhode Island","Vermont") ~ "New England",
                                               statename %in% c("Alaska","Hawaii","California","Oregon","Washington") ~ "Pacific",
                                               statename %in% c("Utah","Colorado","Arizona","New Mexico","Nevada") ~
                                                 "Southwest",
                                               statename %in% c("Idaho","Wyoming","Montana") ~
                                                 "Northwest",
                                               statename %in% c("Nebraska","Iowa","Kansas","Missouri") ~
                                                 "Central",
                                               statename %in% c("Arkansas","Louisiana","Oklahoma","Texas","Alabama",
                                                                "Kentucky","Mississippi","Tennessee") ~
                                                 "South Central",
                                               statename %in% c("Virginia","West Virginia","Florida","Georgia",
                                                                "South Carolina","North Carolina") ~
                                                 "South Atlantic")))

  # Red, blue, swing states
acs.sample <- acs.sample %>%
  mutate(electoral = as.factor(case_when(statename %in% c("Washington","Oregon","California","Nevada","Colorado",
                                                          "New Mexico","Minnesota","Illinois","Virginia",
                                                          "Maine","New Hampshire","Vermont","Massachusetts",
                                                          "New York","Rhode Island","Connecticut",
                                                          "New Jersey","Delaware","Maryland","District of Columbia",
                                                          "Hawaii") ~ "Blue State",
                                         statename %in% c("Montana","Idaho","Wyoming","Utah","North Dakota",
                                                          "South Dakota","Nebraska","Kansas","Oklahoma",
                                                          "Texas","Arkansas","Mississippi","Alabama","Louisiana",
                                                          "Missouri","Kentucky","South Carolina","Alaska",
                                                          "West Virginia","Tennessee")
                                         ~ "Red State",
                                         statename %in% c("Arizona","Wisconsin","Michigan","Pennsylvania",
                                                          "Indiana","North Carolina","Florida","Iowa","Ohio",
                                                          "Georgia") ~
                                           "Swing State")))

## metro vs non-metro

acs.sample <- acs.sample %>%
  mutate(metro = as.factor(case_when(metro %in% c(2,3,4) ~ "Metro",
                                     metro == 1 ~ "Non-Metro",
                                     metro == 0 & !inrange(doiy, 2000,2004) ~ NA_character_)))

## county: available 2005 onwards, must be combined with state codes
  # comparable over time but doesn't impose uniform county boundary system on data
  # only differ from standard FIPS codes for Dade County, Florida (Had FIPS 025 until renamed to Miami-Dade),
  # 086 in all samples to be consistent with coding in later samples
  # combine with statefip to be comparable to cps
acs.sample <- acs.sample %>%
  mutate(countyfip = str_pad(as.character(countyfip), 3, pad = "0")) %>%
  mutate(county = ifelse(doiy >= 2005, paste0(str_pad(as.character(statefip), 2, pad="0"), countyfip),
                         NA_character_))

  # fix dade county change in florida (no other changes relevant to us based on census documentation)
acs.sample <- acs.sample %>%
  mutate(countyfip = ifelse(countyfip == "000", NA_character_, countyfip)) %>%
  mutate(county = ifelse(is.na(countyfip), NA_character_, county))

#### 4.2 Birthplace 
xwalk_bpl <- ipums_val_labels(acs.sample$bpld) %>%
  rename(bpld = val,
         bpl_name = lbl)

acs.sample <- merge(acs.sample, xwalk_bpl, by="bpld", all.x=T)

  # Clean Country of Birth var

acs.sample <- acs.sample %>%
  mutate(bpl_name = as.factor(case_when(bpl_name == "Idaho Territory" ~ "Idaho",
                                        bpl_name == "New Mexico Territory" ~ "New Mexico",
                                        bpl_name == "Indian Territory" ~ "Oklahoma",
                                        bpl_name == "Dakota Territory" ~ "Dakota",
                                        bpl_name == "Utah Territory" ~ "Utah",
                                        bpl_name == "Wyoming Territory" ~ "Wyoming",
                                        bpld == 9900 ~ "United States, n.s.",
                                        inrange(bpld, 10010, 10010) ~ "American Samoa",
                                        inrange(bpld, 11500, 11530) ~ "US Virgin Islands",
                                        inrange(bpld, 12000, 12056) ~ "US Outlying Areas/Territories",
                                        inrange(bpld, 12090, 12092) ~ "US Outlying Areas, n.s.",
                                        inrange(bpld, 15000, 15083) ~ "Canada",
                                        bpld == 19900 ~ "North America, n.s.",
                                        bpld == 21090 ~ "Central America, n.s.",
                                        inrange(bpld, 40000, 40010) ~ "Denmark",
                                        inrange(bpld, 71010, 71016) ~ "Melanesia",
                                        inrange(bpld, 71017, 71029) ~ "Polynesia",
                                        inrange(bpld, 71032, 71039) ~ "Micronesia",
                                        TRUE ~ as.character(bpl_name)))) %>%
  mutate(bpl_region = as.factor(case_when(inrange(bpld, 00100, 09900) ~ "United States",
                                          inrange(bpld, 10000, 10500) ~ "US Outlying Areas/Territories",
                                          bpld == 11000 ~ "Latin America",
                                          inrange(bpld, 11500, 12092) ~ "US Outlying Areas/Territories",
                                          inrange(bpld, 15000, 15083) ~ "North America",
                                          inrange(bpld, 15500, 16010) | inrange(bpld, 16030, 19900) ~ "North America",
                                          bpld == 16020 ~ "Africa",
                                          inrange(bpld, 20000, 20000) ~ "Latin America",
                                          inrange(bpld, 21000, 21010) ~ "Caribbean",
                                          bpld == 21090 ~ "Other Americas",
                                          inrange(bpld, 21020, 21071) | bpld == 26092 ~ "Latin America",
                                          inrange(bpld, 25000, 25000) | inrange(bpld, 26010, 26020) ~ "Latin America",
                                          inrange(bpld, 26000, 26000) | inrange(bpld, 26030, 26091) | bpld == 26091 | inrange(bpld, 26093, 26095) ~ "Caribbean",
                                          bpld == 29900 ~ "Other Americas",
                                          inrange(bpld, 30000, 30030) | bpld == 30050 ~ "Latin America",
                                          inrange(bpld, 30035, 30040) | bpld == 30055 | inrange(bpld, 30090, 30091) ~ "Other South America",
                                          inrange(bpld, 30045, 30065) ~ "Latin America",
                                          inrange(bpld, 40000, 46530) ~ "Europe",
                                          inrange(bpld, 46540, 46547) ~ "Asia",
                                          inrange(bpld, 46548, 49990) ~ "Europe",
                                          inrange(bpld, 50000, 50020) ~ "Asia",
                                          inrange(bpld, 50030, 52150) 
                                          | inrange(bpld, 52300, 52400) |
                                            inrange(bpld, 54800, 59900) ~ "Asia",
                                          bpld == 52200 | inrange(bpld, 53000, 54700) ~ "Middle East",
                                          inrange(bpld, 60000, 60099) ~ "Africa",
                                          inrange(bpld, 70000, 71090) ~ "Oceania",
                                          inrange(bpld, 80000, 80050) | bpld == 95000 | bpld == 999000 ~ "Other or Unknown",
                                          inrange(bpld, 90000, 90020) ~ "Abroad, unknown",
                                          bpld == 71047 ~ "Oceania",
                                          inrange(bpld, 99900, 99900) ~ NA_character_
  )))

## Census region of birthplace
acs.sample <- acs.sample %>%
    mutate(bpl_census = as.factor(case_when(bpl_name %in% c("Connecticut","Maine","Massachusetts",
                                                     "New Hampshire","Rhode Island","Vermont",
                                                     "Maine-Massachusetts-New Hampshire-Rhode Island-Vermont",
                                                     "New Hampshire-Maine-Vermont-Rhode Island") 
                                    ~ "New England",
                                    bpl_name %in% c("New Jersey", "New York", "Pennsylvania")
                                    ~ "Mid-Atlantic",
                                    bpl_name %in% c("Illinois","Indiana","Michigan",
                                                     "Ohio", "Wisconsin","Michigan-Wisconsin") 
                                    ~ "East North Central",
                                    bpl_name %in% c("Iowa", "Kansas","Minnesota","Missouri",
                                                     "Nebraska","North Dakota","South Dakota","Minnesota-Iowa",
                                                     "Nebraska-North Dakota-South Dakota-Kansas",
                                                     "Iowa-N Dakota-S Dakota-Nebraska-Kansas-Minnesota-Missouri")
                                    ~ "West North Central",
                                    bpl_name %in% c("Delaware","Florida","Georgia","Maryland",
                                                     "North Carolina","South Carolina","Virginia",
                                                     "District of Columbia", "West Virginia","Delaware-Virginia",
                                                     "North Carolina-South Carolina","South Carolina-Georgia",
                                                     "Delaware-Maryland-Virginia-West Virginia")
                                    ~ "South Atlantic",
                                    bpl_name %in% c("Alabama","Kentucky","Mississippi",
                                                     "Tennessee","Alabama-Mississippi","Kentucky-Tennessee") 
                                    ~ "East South Central",
                                    bpl_name %in% c("Arkansas","Louisiana","Oklahoma",
                                                     "Texas","Arkansas-Oklahoma","Arkansas-Louisiana-Oklahoma")
                                    ~ "West South Central",
                                    bpl_name %in% c("Arizona","Colorado","Idaho",
                                                     "Montana","Nevada","New Mexico","Utah","Wyoming",
                                                     "Arizona-New Mexico-Colorado","Idaho-Wyoming-Utah-Montana-Nevada",
                                                     "Montana-Wyoming-Colorado-New Mexico-Utah-Nevada-Arizona")
                                    ~ "Mountain",
                                    bpl_name %in% c("Alaska","California","Hawaii",
                                                     "Oregon","Washington","Alaska-Washington-Hawaii",
                                                     "Washington-Oregon-Alaska-Hawaii")
                                    ~ "Pacific")))


# Clean country variable
acs.sample <- acs.sample %>%
  mutate(bpl_name = as.factor(case_when(bpl_name == "Azores" ~ "Portugal",
                                        bpl_name == "Byelorussia" ~ "Belarus",
                                        bpl_name == "Cambodia (Kampuchea)" ~ "Cambodia",
                                        bpl_name == "Egypt/United Arab Rep." ~ "Egypt",
                                        bpl_name == "Belize/British Honduras" ~ "Belize",
                                        bpl_name == "Guyana/British Guiana" ~ "Guyana",
                                        bpl_name %in% c("Burma (Myanmar)","Burma") ~ "Myanmar",
                                        bpl_name %in% c("Israel/Palestine","Israel") ~ "Israel",
                                        bpl_name == "Kirghizia" ~ "Kyrgyzstan",
                                        bpl_name == "South Africa (Union of)" ~ "South Africa",
                                        bpl_name == "Sri Lanka (Ceylon)" ~ "Sri Lanka",
                                        bpl_name %in% c("Congo", "Zaire") ~ "Democratic Republic of Congo",
                                        bpl_name %in% c("Africa, ns/nec", "Africa, n.s./n.e.c.") ~ "Africa, unknown",
                                        bpl_name %in% c("Americas, ns", "Americas, n.s.") ~ "Americas, unknown",
                                        bpl_name %in% c("Asia Minor, ns") ~ "Asia Minor, unknown",
                                        bpl_name %in% c("Asia, nec/ns", "Asia, n.e.c./n.s.") ~ "Asia, unknown",
                                        bpl_name %in% c("Caribbean, ns", "Caribbean, n.s.") ~ "Caribbean, unknown",
                                        bpl_name %in% c("Central America, n.s.") ~ "Central America, unknown",
                                        bpl_name %in% c("Central Africa") ~ "Central Africa, unknown",
                                        bpl_name %in% c("East Asia, ns") ~ "East Asia, unknown",
                                        bpl_name %in% c("Eastern Africa, nec/ns") ~ "East Africa, unknown",
                                        bpl_name %in% c("Europe, ns.","Europe, n.s.") ~ "Europe, unknown",
                                        bpl_name %in% c("Korea") ~ "South Korea",
                                        bpl_name %in% c("North Africa, ns") ~ "North Africa, unknown",
                                        bpl_name %in% c("North America, n.s.") ~ "North America, unknown",
                                        bpl_name %in% c("Oceania, ns/nec") ~ "Oceania, unknown",
                                        bpl_name %in% c("Other, n.e.c.","Other, n.e.c. and unknown", "Other n.e.c.") ~ "Other/Unknown",
                                        bpl_name %in% c("South America, ns", "South America, n.s.") ~ "South America, unknown",
                                        bpl_name %in% c("Southwest Asia, nec/ns") ~ "Southwest Asia, unknown",
                                        bpl_name %in% c("USSR, ns", "Other USSR/Russia", "USSR, n.s.") ~ "Russia",
                                        bpl_name %in% c("West Indies, ns") ~ "West Indies, unknown",
                                        bpl_name %in% c("Western Africa, ns") ~ "West Africa, unknown",
                                        bpl_name %in% c("Western Europe, ns") ~ "Western Europe, unknown",
                                        bpl_name %in% c("Yemen Arab Republic (North)") ~ "Yemen",
                                        bpl_name %in% c("Bosnia") ~ "Bosnia and Herzegovina",
                                        bpl_name %in% c("Czechoslavakia","Czech Republic","Slovakia","Czechoslovakia") ~ "Czech/Slovakia",
                                        bpl_name %in% c("Middle East, n.s.") ~ "Middle East, unknown",
                                        bpl_name %in% c("Montenego") ~ "Montenegro",
                                        bpl_name %in% c("Northern Africa") ~ "North Africa, unknown",
                                        bpl_name == "St. Kitts--Nevis" ~ "St. Kitts-Nevis",
                                        bpl_name == "St. Vincent and the Grenadi" ~ "St. Vincent",
                                        bpl_name == "United States, n.s." ~ "United States, unknown",
                                        bpl_name %in% c("U.S. outlying areas, n.s.") ~ "US Territories, unknown",
                                        bpl_name %in% c("U.S. Virgin Islands","US Virgin Islands") ~ "US Virgin Islands",
                                        bpl_name %in% c("Antigua-Barbuda") ~ "Antigua and Barbuda",
                                        bpl_name %in% c("United Kingdom, ns", "United Kingdom, n.s.","UK, unknown", "England", "Wales", "Scotland", "Northern Ireland") ~ "UK",
                                        TRUE ~ as.character(bpl_name)
  ))) %>%
  mutate(bpl_region = as.factor(ifelse(bpl_name == "Cyprus", "Europe", as.character(bpl_region)))) %>%
  mutate(bpl_region = as.factor(ifelse(bpl_name == "Afghanistan", "Middle East", as.character(bpl_region))))


# Create separate country and state of birth vars

acs.sample <- acs.sample %>%
  mutate(bpl_state = as.factor(ifelse(bpl_region == "United States",as.character(bpl_name), NA_character_))) %>%
  mutate(bpl_country = as.factor(ifelse(bpl_region == "United States","United States",as.character(bpl_name))))%>%
  mutate(usmover = as.factor(ifelse(as.character(bpl_state) == as.character(statename), "Stayer","Mover")),
         immigrant = as.factor(ifelse(bpl_region == "United States", "US-Born","Immigrant"))) %>%
  mutate(immigrant = as.factor(ifelse(is.na(bpl_region) | bpl_region == "Other or Unknown", NA_character_, as.character(immigrant))))


### 4.3 Ancestry

xwalk_ancestry<- ipums_val_labels(acs.sample$ancestr1) %>%
  rename(ancestr1 = val,
         ancestry_name = lbl)

acs.sample <- merge(acs.sample, xwalk_ancestry, by="ancestr1", all.x=T)

acs.sample <- acs.sample %>%
  mutate(ancestry = as.factor(case_when(
      # France: Alsatian, French Basque, Corsican, Lorrainian, Breton
        ancestr1 %in% c(1, 6, 16, 26, 27, 28) ~ "France",
      # Andorra
        ancestr1 %in% c(2) ~ "Andorra",
      # Austria: Austrian, Tirolean
        ancestr1 %in% c(3, 4) ~ "Austria",
      # Spain: Basque, Spanish, Spanish American
        ancestr1 %in% c(5,291,295) | inrange(ancestr1, 200, 206) ~ "Spain",
      # Belgian: Belgian, Flemish, Walloon
        ancestr1 %in% c(8,9,10) ~ "Belgium",
      # UK: British, British Isles, Channel Islander, Gibraltan, Cornish,
        # Manx, Northern islander, Scottish, Scotch Irish, Welsh
        ancestr1 %in% c(11,12,13,14,15,79,81,87,88,97,22) ~ "UK",
      # Cyprus: Turkish or Greek Cypriot
        ancestr1 %in% c(17,18,19) ~ "Cyprus",
      # Denmark: Danish, Faroe Islander
        ancestr1 %in% c(20, 23) ~ "Denmark",
      # Netherlands: Dutch, Frisian
        ancestr1 %in% c(21, 29) ~ "Netherlands",
      # Finland
        ancestr1 %in% c(24) ~ "Finland",
      # Russia: Karelian, Cossack, Mordovian, Germans from Russia,
        # Soviet Turkic, Tatars
        ancestr1 %in% c(25, 108, 118, 122, 148, 150) 
        | inrange(ancestr1, 156, 164, 165) ~ "Russia",
      # Italy: Friulian
        ancestr1 %in% c(30) | inrange(ancestr1, 51, 73) ~ "Italy",
      # Germany: 
        inrange(ancestr1, 32, 43) ~ "Germany",
      # Greece: Greek, Cretan, Cycladic, Dodecanese, Peloponnesian
        ancestr1 %in% c(46, 47, 48) ~ "Greece",
      # Iceland
        ancestr1 %in% c(49) ~ "Iceland",
        ancestr1 %in% c(75) ~ "Lapland",
        ancestr1 %in% c(76) ~ "Liechtenstein",
        ancestr1 %in% c(77) ~ "Luxembourg",
        ancestr1 %in% c(78) ~ "Malta",
      # Ireland
        ancestr1 %in% c(50) ~ "Ireland",
      # Monaco
        ancestr1 %in% c(80) ~ "Monaco",
      # Norwegian
        ancestr1 %in% c(82) ~ "Norway",
      # Portugal
        ancestr1 %in% c(84, 85, 86) ~ "Portugal",
      # Sweden
        ancestr1 %in% c(89, 90) ~ "Sweden",
      # Switzerland
        ancestr1 %in% c(91, 92, 95, 96) ~ "Switzerland",
      
        ancestr1 %in% c(100) ~ "Albania",
        ancestr1 %in% c(101) ~ "Azerbaijan",
        ancestr1 %in% c(102) ~ "Belarus",
        ancestr1 %in% c(103) ~ "Bulgaria",
        ancestr1 %in% c(105) ~ "Carpathia",
        ancestr1 %in% c(109) ~ "Croatia",
        ancestr1 %in% c(111, 112) ~ "Czech/Slovakia",
        ancestr1 %in% c(115, 116) ~ "Estonia",
        ancestr1 %in% c(117, 199) ~ "Fenno-Ugria",
        ancestr1 %in% c(120, 123) ~ "Republic of Georgia",
        ancestr1 %in% c(124) ~ "Romani",
        ancestr1 %in% c(125, 126) ~ "Hungary",
        ancestr1 %in% c(128) ~ "Latvia",
        ancestr1 %in% c(129) ~ "Lithuania",
        ancestr1 %in% c(130) ~ "Macedonia",
        ancestr1 %in% c(142, 143) ~ "Poland",
        ancestr1 %in% c(144, 147) ~ "Romania",
        ancestr1 %in% c(146, 145) ~ "Moldova",
        ancestr1 %in% c(152) ~ "Serbia",
        ancestr1 %in% c(153) ~ "Slovakia",
        ancestr1 %in% c(154, 155) ~ "Slovenia",
        ancestr1 %in% c(169) ~ "Uzbekistan",
        ancestr1 %in% c(171) ~ "Ukraine",
        ancestr1 %in% c(176) ~ "Yugoslavia",
        inrange(ancestr1, 210, 219) ~ "Mexico",
        ancestr1 == 221 ~ "Costa Rica",
        ancestr1 == 222 ~ "Guatemala",
        ancestr1 == 223 ~ "Honduras",
        ancestr1 == 224 ~ "Nicaragua",
        ancestr1 == 225 ~ "Panama",
        ancestr1 == 226 ~ "El Salvador",
        ancestr1 == 231 ~ "Argentina",
        ancestr1 == 232 ~ "Bolivia",
        ancestr1 == 233 ~ "Chile",
      # Colombia: Colombian, San Andres, Providencia
        ancestr1 %in% c(234, 365, 375) ~ "Colombia",
        ancestr1 == 235 ~ "Ecuador",
        ancestr1 == 236 ~ "Paraguay",
        ancestr1 == 237 ~ "Peru",
        ancestr1 == 238 ~ "Uruguay",
        ancestr1 == 239 ~ "Venezuela",
        ancestr1 == 261 ~ "Puerto Rico",
        ancestr1 == 271 ~ "Cuba",
        ancestr1 == 275 ~ "Dominican Republic",
        ancestr1 == 300 ~ "Bahamas",
        ancestr1 == 301 ~ "Barbados",
        ancestr1 == 302 ~ "Belize",
        ancestr1 == 303 ~ "Bermuda",
        ancestr1 == 304 ~ "Cayman Islands",
        ancestr1 == 308 ~ "Jamaica",
        ancestr1 %in% c(310, 311, 312) ~ "Dutch West Indies",
        ancestr1 %in% c(314, 315, 316) ~ "Trinidad and Tobago",
        ancestr1 %in% c(317, 321) ~ "Virgin Islands",
        ancestr1 %in% c(322, 323) ~ "British West Indies",
        ancestr1 %in% c(324) ~ "Anguilla",
        ancestr1 %in% c(328) ~ "Dominica",
        ancestr1 %in% c(329) ~ "Grenada",
        ancestr1 %in% c(331) ~ "St. Lucia",
        ancestr1 %in% c(332, 333, 334) ~ "French West Indies",
        ancestr1 %in% c(336) ~ "Haiti",
        ancestr1 == 360 ~ "Brazil",
        ancestr1 == 370 ~ "Guyana",
        ancestr1 == 380 ~ "Suriname",
        ancestr1 == 400 ~ "Algeria",
        ancestr1 == 402 ~ "Egypt",
        ancestr1 == 404 ~ "Libya",
        ancestr1 %in% c(406, 407) ~ "Morocco",
        ancestr1 == 408 ~ "Tunisia",
        ancestr1 == 415 ~ "Bahrain",
        ancestr1 == 416 ~ "Iran",
        ancestr1 == 417 ~ "Iraq",
        ancestr1 == 419 ~ "Israel",
        ancestr1 == 421 ~ "Jordan",
        ancestr1 == 423 ~ "Kuwait",
        ancestr1 == 425 ~ "Lebanon",
        ancestr1 == 427 ~ "Saudi Arabia",
        ancestr1 %in% c(429,482) ~ "Syria",
        ancestr1 == 431 ~ "Armenia",
        ancestr1 == 434 ~ "Turkey",
        ancestr1 %in% c(435, 470, 471) ~ "Yemen",
        inrange(ancestr1, 436, 438) ~ "Oman",
        ancestr1 == 439 ~ "Qatar",
        ancestr1 %in% c(442, 444) ~ "Kurd",
        ancestr1 %in% c(465, 466, 467) ~ "Palestine",
        ancestr1 == 480 ~ "United Arab Emirates",
        ancestr1 == 500 ~ "Angola",
        ancestr1 == 502 ~ "Benin",
        ancestr1 == 504 ~ "Botswana",
        ancestr1 == 506 ~ "Burundi",
        ancestr1 == 508 ~ "Cameroon",
        ancestr1 == 510 ~ "Cape Verde",
        ancestr1 == 513 ~ "Chad",
        ancestr1 %in% c(515, 516, 591) ~ "Democratic Republic of Congo",
        ancestr1 == 519 ~ "Djibouti",
        ancestr1 == 520 ~ "Equatorial Guinea",
        ancestr1 == 522 ~ "Ethiopia",
        ancestr1 == 523 ~ "Eritrea",
        ancestr1 == 525 ~ "Gabon",
        ancestr1 == 527 ~ "Gambia",
        ancestr1 == 529 ~ "Ghana",
        ancestr1 == 530 ~ "Guinea",
        ancestr1 == 531 ~ "Guinea Bissau",
        ancestr1 == 532 ~ "Ivory Coast",
        ancestr1 == 534 ~ "Kenya",
        ancestr1 == 538 ~ "Lesotho",
        ancestr1 == 541 ~ "Liberia",
        ancestr1 == 543 ~ "Madagascar",
        ancestr1 == 545 ~ "Malawi",
        ancestr1 == 546 ~ "Mali",
        ancestr1 == 549 ~ "Mozambique",
        ancestr1 == 550 ~ "Namibia",
        ancestr1 == 551 ~ "Niger",
        ancestr1 %in% c(553, 554, 555, 556, 557) ~ "Nigeria",
        ancestr1 == 561 ~ "Rwanda",
        ancestr1 == 564 ~ "Senegal",
        ancestr1 == 566 ~ "Sierra Leone",
        ancestr1 == 568 ~ "Somalia",
        ancestr1 == 569 ~ "Eswatini",
        inrange(ancestr1, 570, 574) ~ "South Africa",
        inrange(ancestr1, 576, 579) ~ "Sudan",
        inrange(ancestr1, 582, 584) ~ "Tanzania",
        ancestr1 == 586 ~ "Togo",
        ancestr1 == 588 ~ "Uganda",
        ancestr1 == 589 ~ "Burkina Faso",
        ancestr1 == 592 ~ "Zambia",
        ancestr1 == 593 ~ "Zimbabwe",
        ancestr1 %in% c(600, 601, 602) ~ "Afghanistan",
        ancestr1d == 6031 ~ "Bangladesh",
        ancestr1 == 607 ~ "Bhutan",
        ancestr1 == 609 ~ "Nepal",
        inrange(ancestr1, 615, 656) | ancestr1d == 6032 ~ "India",
        ancestr1 == 680 ~ "Pakistan",
        inrange(ancestr1, 690, 692) ~ "Sri Lanka",
        inrange(ancestr1, 700, 702) ~ "Myanmar",
        inrange(ancestr1, 703, 704) ~ "Cambodia",
        inrange(ancestr1, 706, 709) ~ "China",
        ancestr1 == 712 ~ "Mongolia",
        ancestr1 == 714 ~ "Tibet",
        ancestr1 == 716 ~ "Hong Kong",
        ancestr1 == 718 ~ "Macao",
        ancestr1 == 720 ~ "Philippines",
        ancestr1 == 730 ~ "Indonesia",
        inrange(ancestr1, 740, 748) ~ "Japan",
        ancestr1 == 750 ~ "South Korea",
        inrange(ancestr1, 756, 768) ~ "Laos",
        ancestr1 == 770 ~ "Malaysia",
        ancestr1 == 774 ~ "Singapore",
        inrange(ancestr1,776,778) ~ "Thailand",
        ancestr1 == 782 ~ "Taiwan",
        inrange(ancestr1,785,790) ~ "Vietnam",
        inrange(ancestr1, 800,802) ~ "Australia",
        inrange(ancestr1, 803,803) ~ "New Zealand",
        inrange(ancestr1, 808,819) ~ "Polynesia",
        inrange(ancestr1, 820,834) ~ "Micronesia",
        inrange(ancestr1, 840,847) ~ "Melanesia",
        inrange(ancestr1, 850,870) ~ "Pacific Islands",
        inrange(ancestr1, 920,923) ~ "American Indian",
        inrange(ancestr1, 930,930) ~ "Greenland",
        inrange(ancestr1, 931,936) ~ "Canada",
        inrange(ancestr1, 940,993) ~ "United States",
      # Unknowns
      ancestr1 %in% c(98) ~ "Scandinavian/Nordic, unknown",
      ancestr1 %in% c(178, 179) ~ "Slavic, unknown",
      ancestr1 == 181 ~ "Central Europe, unknown",
      ancestr1 == 183 ~ "Northern Europe, unknown",
      ancestr1 == 185 ~ "Southern Europe, unknown",
      ancestr1 == 187 ~ "Western Europe, unknown",
      ancestr1 == 190 ~ "Eastern Europe, unknown",
      ancestr1 == 195 ~ "Europe, unknown",
      ancestr1 %in% c(227,290,296) ~ "Latin America, unknown",
      ancestr1 == 248 ~ "South America, unknown",
      ancestr1 %in% c(335,337) ~ "West Indies, unknown",
      inrange(ancestr1, 411, 414) ~ "North Africa, unknown",
      inrange(ancestr1, 490, 496) ~ "Middle East, unknown",
      ancestr1 %in% c(594, 599) ~ "Africa, unknown",
      ancestr1 %in% c(595) ~ "Subsaharan Africa, unknown",
      ancestr1 %in% c(596) ~ "Central Africa, unknown",
      ancestr1 %in% c(597) ~ "East Africa, unknown",
      ancestr1 %in% c(598) ~ "West Africa, unknown",
      ancestr1 == 675 ~ "East Indies, unknown",
      ancestr1 == 792 ~ "Indochina, unknown",
      ancestr1 == 793 ~ "Eurasia, unknown",
      ancestr1 %in% c(795,796) ~ "Asia, unknown",
      inrange(ancestr1, 900,902) ~ "African-American, unknown",
      inrange(ancestr1, 913,913) ~ "Central American Indian, unknown",
      inrange(ancestr1, 914,914) ~ "South American Indian, unknown",
      ancestr1 == 924 ~ "White/Caucasian, unknown",
      ancestr1 == 994 ~ "North American, unknown",
      ancestr1 %in% c(995,998,996,999) ~ "Other/Unknown")))


  # Create empty vars for place of birth of parents

acs.sample <- acs.sample %>%
  mutate(fbpl_name = NA_character_,
         mbpl_name = NA_character_)

# 4.4 Select variables
acs.sample <- acs.sample %>%
  subset(select=c(id, serial, pernum, doiy, wgt,  
                  yr5, yr10, yr5_reform, yr10_reform, post_reform,
                  emp_lw, earnings_ly, earn_ly,
                  age, gender, edlevel, college, hsandbelow, child, nchild, eldch, age1b, marst,
                  married, race, race_raw, hispanic, statefip, statename, stateagg,
                  white_hisp, white, black_hisp, black,
                  doby, ch1yob,ancestry,fbpl_name, mbpl_name,
                  bpl_state, bpl_country, usmover,
                  immigrant,bpl_census,
                  census,region, metro, yrimmig,ageimmig, classwkr, agriculture, industry, hrs_ly
  ))

acs.sample <- acs.sample %>%
  mutate(dataset = as.factor("ACS")) %>%
  mutate(dataset = factor(dataset, levels = c("CPS", "ACS", "NLSY79", "PSID")))

# Before full sample selection: calculate raw gender gap
save(acs.sample, file=file.path(cleandir,"acs_preselect.RData"))

# 3.5 Select samples

acs.sample <- acs.sample %>%
  #old: restrict to age1b between 20 and 40
  # subset(!(wgt <= 0 | is.na(wgt)) & !is.na(statefip) & !is.na(child) & inrange(age, 15, 65)
  #        & (inrange(age1b, min.age, max.age) | child == 0))
  # new: let age1b be greater than 40 and restrict when plotting
  subset(!(wgt <= 0 | is.na(wgt)) & !is.na(statefip) & !is.na(child) & inrange(age, 15, 65))

acs.sample <- acs.sample %>%
  mutate(month = NA_real_) %>% # Empty month variable for consistency with CPS
  drop_na(edlevel, married,marst,race)

# adjusted weight
# acs.sample <- acs.sample %>%
#   group_by(doiy, age, gender) %>% 
#   mutate(wgt_adj=ifelse(child==1, wgt, (sum(child)/sum(1-child))*wgt)) %>% 
#   ungroup()


# generate factor variables to use in heterogeneity regression
acs.sample <- acs.sample %>%
  mutate(age_factor = as.factor(age)) %>%
  mutate(doiy_factor = as.factor(doiy))  %>%
  mutate(age_gender = interaction(age_factor, gender)) %>%
  mutate(doiy_gender = interaction(doiy_factor, gender))

acs <- acs.sample

# save cleaned file
save(acs, file=file.path(cleandir,"acs_clean.RData"))


acs <- apply_labels(acs, emp_lw = "Weekly Employment", earn_ly = "Annual Employment",
                    earnings_ly = "Earnings", doiy = "Year of Intervew",
                    wgt = "Survey Weight", id = "Unique Identifier",
                    statefip = "State of Residence (FIPS)", statename = "State of Residence",
                    stateagg = "State of Residence Groups",
                    age1b = "Age at First Birth", ch1yob = "Year of Birth of Oldest Child",
                    child = "Indicator for Parents", fbpl_name = "Father's Place of Birth",
                    mbpl_name = "Mother's Place of Birth", bpl_census = "Census Division of Birth",
                    bpl_country = "Country of Birth", census = "Census Division of Residence",
                    yrimmig = "Year of Immigration", ageimmig = "Age at Immigration",
                    region = "Census Region of Residence")


# save(acs, file=file.path(wrkdir,"acs_clean_labelled.RData"))
# foreign::write.dta(acs, file=file.path(wrkdir,"acs_clean_labelled.dta"))
