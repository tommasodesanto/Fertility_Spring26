#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file cleans NLSY79 data

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

  # Load data

load(file.path(rawdir,"NLSY79","raw_nlsy.RData"))
nlsy <- new_data

##########################################################################
#                 1. Rename/label/recode vars

#########################################################################

# 1.1: Survey vars

# Identification
colnames(nlsy) <- sub("CASEID_1979", "id", colnames(nlsy))

# Interview month

# Rename
colnames(nlsy) <- sub("CURDATE~M_", "doim", colnames(nlsy))

# Treat missing month as March: replace NAs after reshape
# nlsy <- nlsy %>%
#   mutate(across(c(contains("doim")),~replace(.,(-5, -4, -3, -2, -1), 3)))
nlsy <- nlsy %>%
  mutate(across(c(contains("doim")), ~ifelse(. %in% c(-5, -4, -3, -2, -1, NA_real_), 3, .)))
  
# Sample weights

colnames(nlsy) <- sub("C_SAMPWEIGHT_", "xwgt", colnames(nlsy))
colnames(nlsy) <- sub("SAMPWEIGHT_", "wgt", colnames(nlsy))

nlsy <- nlsy %>%
  mutate(across(c(contains("wgt")), ~ifelse(. %in% c(-5, -4, -3, -2, -1), NA_real_, ./100))) 

# 1.2: Demographics

  # Gender
nlsy <- nlsy %>%
  mutate(gender = as.factor(ifelse(SAMPLE_SEX_1979 == 2, "Women", "Men"))) %>%
  rename(sex = SAMPLE_SEX_1979)

  # Race: use a combination of self reported race measure and interviewer measure
    # SAMPLE_RACE_78SCRN: 1: Hispanic, 2: Black, 3: Non-black, non-hispanic categories only
    # FAM_30_1_1979: self-reported race but lists country of ancestry rather than race

    # If someone is hispanic based on FAM we keep them as hispanic,
    # If they are anything else based on FAM but black or hispanic based on SAMPLE, we replace

nlsy <- nlsy %>%
  mutate(race = as.factor(case_when(`FAM-30_1_1979` %in% c(3,5,6,7,11,12,22,23,24,25,27,29)
                                    ~ "White, non-hispanic",
                            # english, french, german, greek, irish, italian, polish, portuguese etc.
                          (`FAM-30_1_1979` == 1) ~ "Black, non-hispanic",
                          `FAM-30_1_1979` %in% c(2,4,8,9,10,13,14,26,28) 
                          ~ "Other",
                            # indian-american/native american categories or other
                          # chinese, filipino, hawaiian pi, asian indian, japanese, korean, vieet
                          inrange(`FAM-30_1_1979`,15,21) ~ "Hispanic"))) %>%
  mutate(race = as.factor(case_when(SAMPLE_RACE_78SCRN == 2 & (race != "Hispanic" | is.na(race)) ~ "Black, non-hispanic",
                          SAMPLE_RACE_78SCRN == 1 ~ "Hispanic",
                          TRUE ~ as.character(race))))
  

  # Marital status
    # name: MARITAL STATUS
    # choices: 0 never married,  1 married, 2 separated,3 divorced,5 remarried, 6 wi6(2)16}
    # Note: there is an alternative version called "MARITAL STATUS (COLLAPSED)" but doesn't add up N
    # choices: 1  never married, 2  married, spouse present, 3  other

colnames(nlsy) <- sub("MARSTAT-KEY_","marst", colnames(nlsy))

# Create a copy for married
tmp=grep("marst",colnames(nlsy))
nlsy <- cbind(nlsy, setNames(nlsy[,tmp], gsub("marst","married",colnames(nlsy)[tmp])))

nlsy <- nlsy %>%
  mutate(across(c(contains("married")), ~as.factor(case_when(. %in% c(1, 5) ~ "Married",
                                                             . %in% c(0,2,3,6) ~ "Single"))))
# Marst
nlsy <- nlsy %>%
  mutate(across(c(contains("marst")), ~as.factor(case_when(. == 0 ~ "Never married/single",
                                                          . %in% c(1, 5) ~ "Married, spouse present",
                                                          . == 2 ~ "Married, spouse absent",
                                                          . == 3 ~ "Divorced",
                                                          . == 6 ~ "Widowed"))))

  # Age/cohort
nlsy <- nlsy %>%
  mutate(doby = 1900 + `Q1-3_A~Y_1979`) %>%
  mutate(dobm = ifelse(`Q1-3_A~M_1979` < 0, 3, `Q1-3_A~M_1979`))

nlsy$dob <- as.Date(with(nlsy, paste(as.character(doby), as.character(dobm),"15",sep="-")), "%Y-%m-%d")

colnames(nlsy) <- sub("AGEATINT_", "age", colnames(nlsy))

nlsy <- nlsy %>%
  mutate(across(c(contains("age")), ~ifelse(. < 0, NA_real_, .)))

  # Education

      # Highest grade completed 
          # Qname = Q3-4
          # Choices: [0 None - 20 Eight years college, 95 ungraded]
          # Available years: [1979-2016]

colnames(nlsy) <- sub("HGCREV.*_", "highest_grade", colnames(nlsy)) #.* excludes anything between V and _
nlsy <- nlsy %>%
  mutate(across(c(contains("highest_grade")), ~ifelse(. %in% c(-1, -2, -3, -4, -5, 95), NA_real_, .)))

        # take rowmax over all years
nlsy$max_grade <- invoke(pmax,as.list(nlsy[,grepl("^highest_grade",names(nlsy))]),na.rm=TRUE)

    # Highest degree
        # Name: HIGHEST DEGREE EVER RECEIVED
        # question: WHAT IS THE NAME OF THE HIGHEST DEGREE YOU HAVE (EVE EXP_2_1981R) RECEIVED SINCE (DATE OF LAST INTERVIEW)?
        #   choices: y88-14 :[0 None, 1 High school diploma, 2 Associate,3 BA, 4 BS, 5 ma, 6 PHD, 7 prof, 8 other]
        # y16:[0 None- 9 Professional]
        # Available years: [88-2016]
        # Note: for years 2008-16, there are 2 versions of the same question Q3_10B and Q3_10D.
        # The first one asks:  What is the name of the highest degree you have received since [Date of last interview]?
        #   the second one asks: What is the name of the highest degree you have ever received?
        #   Because later we want to capture the maximum degree and because the second variable has more obs, we update the status of
        # the variable highest_degree (Q3_10B = missing) with values declared by the second var (Q3_10D).
      # NOTE: many missings in each year (double-checked raw data here and in stata) but reduced when we use rowmax

colnames(nlsy) <- sub("Q3-10B_", "highest_degree",colnames(nlsy))
colnames(nlsy) <- sub("Q3-10D_", "highest_degree_upd", colnames(nlsy))

nlsy <- nlsy %>%
  mutate(across(c(contains("highest_degree")), ~as.numeric(as.character(.)))) %>%
  dplyr::mutate(across(c(contains("highest_degree")), ~case_when(round(.) %in% c(-1, -2, -3, -4, 
                                                                          -5, 8) ~ NA_real_,
                                                          round(.) %in% c(7, 9) ~ 6,
                                                          TRUE ~ as.numeric(as.character(.))
                                                          )))

  # take max of updated degree var or normal degree var
nlsy$max_degree <- invoke(pmax,as.list(nlsy[,grepl("^highest_degree",names(nlsy))]),na.rm=TRUE)

  # replace below 12th grade completed with 0
# nlsy <- nlsy %>%
#   mutate(max_degree = ifelse(max_grade < 12 & !is.na(max_grade), 0, max_degree))

# 1.3: Work

    # employment status recode;
    #   Name: EMPLOYMENT STATUS RECODE (COLLAPSED)
    #   Choices: 1 employed, 2 unemployed, 3 out of labor force,4 in active forces
    #   Available years: [y79:y94], {y96, y98,06}
    #   Note: there is the standard version, but here we're using the collapsed version
colnames(nlsy) <- sub("ESR_COL_", "ESR", colnames(nlsy))

nlsy <- nlsy %>%
  mutate(across(c(contains("ESR")), ~ifelse(. %in% c(-1, -2, -3, -4, -5), NA_real_,.)))
    
    # number of weeks worked last year ;
    #   Name:	NUMBER OF WEEKS WORKED IN PAST CALENDAR YEAR *KEY*
    #   Choices: [1-52]
    #   Available years:[y79:y94],{ y96(2)16}
    #   Note: There is an alternative version (WKSWK_SLI) called "NUMBER OF WEEKS WORKED SINCE LAST INT *KEY*"
    #   , but the lastone has more N for first years, so maybe we should use this version.
    #   Available years:[y79:y94],{ y96(2)16}

colnames(nlsy) <- sub("WKSWK-PCY_","weeks_wrk", colnames(nlsy))

nlsy <- nlsy %>%
  mutate(across(c(contains("weeks_wrk")), ~ifelse(. %in% c(-1, -2, -3, -4, -5), NA_real_,.)))

    # hours worked last year
    #   Name:	NUMBER OF HOURS WORKED IN PAST CALENDAR YEAR *KEY*
    #   Choices: [0-4999]
    #   Available years:[y79:y94],{ y96(2)16}
    #   Note: Again, there is another version (HRSWK_SLI) called: "NUMBER OF HOURS WORKED SINCE LAST INT *KEY*" ,
    #   this has more N, same choices, and same years available
colnames(nlsy) <- sub("HRSWK-PCY_", "hrs_ly", colnames(nlsy))

nlsy <- nlsy %>%
  mutate(across(c(contains("hrs_ly")), ~ifelse(. %in% c(-1, -2, -3, -4, -5), NA_real_,.)))


    # labor force status and hours worked in each week
    #   Name: LABOR FORCE STATUS (1978) WEEK *
    #   Choices: week1-week1499= [y1979-2017] :
    #   100 to 2715: actual survey round/job number, 0: no info reported for week, 2: not working (unemp v. olf not determined),
    #   3: assoc. with emp, gap dates missing, all time not acctd for,  4: unemployed, 5: out of labor force, 7: active military service
    #   Available years:[y1978-2017]
    #   Name: 	HOURS AT ALL JOBS (1978) WEEK *
    #   Choices: [0-99]
    #   Available years:[y1978-2017]
    #   Note: everything ok

start_yr <- 1978
start_wk <- 1
for(w_lab in 1:2184) {
  w_str <- str_pad(as.character(w_lab), 4, pad = "0")
  lab_yr <- as.numeric(substr(var_label(nlsy[, paste0("STATUS_WK_NUM",
                        w_str,
                        "_XRND")]), 21, 24))
  if(start_yr != lab_yr) {
    # reset week to be week 1 if its a new year
    start_yr <- lab_yr
    start_wk <- 1
  }
  w_str_adj <- str_pad(as.character(start_wk), 4, pad="0")
   # rename
  colnames(nlsy) <- sub(paste0("STATUS_WK_NUM",w_str,"_XRND"),
                        paste0("status_wk",w_str_adj,"_yr",as.character(start_yr)),
                        colnames(nlsy))
  colnames(nlsy) <- sub(paste0("HRS_WORKED_WK_NUM",w_str,"_XRND"),
                        paste0("wkly_hrs",w_str_adj,"_yr",as.character(start_yr)),
                        colnames(nlsy))
  # increase week by 1
  start_wk <- start_wk + 1
}

nlsy <- nlsy %>%
  mutate(across(c(contains("status_wk") | contains("wkly_hrs")), ~ifelse(. %in% c(-5, -4, -3, -2, -1), NA_real_, .)))

    # employment status week of interview
years <- c(seq(from=1979, to=1994, by=1), seq(from=1996, to=2018,by=2))
for(y in years){
  # don't know exact day so week is estimated to be middle of month always
  nlsy[,paste0("week_int",as.character(y))] = lubridate::week(as.Date(paste(as.character(y),as.character(nlsy[,paste0("doim",as.character(y))]),"15",sep="-"),"%Y-%m-%d"))
}

weekly_data <- nlsy %>%
  select_(.dots=c("id",'starts_with("week_int")', 'starts_with("doim")',
                  'starts_with("status_wk")', 'starts_with("wkly_hrs")'))

weekly_data <- weekly_data %>%
  relocate(id) %>%
  subset(select=-c(STATUS_WK_NUM0000_XRND))


#MAKE SURE ID VAR is in first col
weekly_data <- pivot_longer(weekly_data, cols = 2:ncol(weekly_data),
                             names_to = c(".value","doiy"),
                             names_pattern = '(.*)(\\d\\d\\d\\d)')

colnames(weekly_data) <- sub("*_yr","",colnames(weekly_data))

weekly_data <- pivot_longer(weekly_data, cols = 5:ncol(weekly_data),
                            names_to = c(".value","week_wrk"),
                            names_pattern = '(.*)(\\d\\d\\d\\d)')

weekly_data <- weekly_data %>%
  mutate(week_wrk = as.numeric(str_remove(week_wrk,"^0+")))

weekly_data <- weekly_data %>%
  filter(week_wrk == week_int) %>%
  subset(select=-c(week_int,week_wrk,doim))

weekly_data <- pivot_wider(data=weekly_data, id_cols=id,
                           names_from = doiy, values_from = c("status_wk",
                                                              "wkly_hrs"))
colnames(weekly_data) <- sub("status_wk_","status_wk",colnames(weekly_data))
colnames(weekly_data) <- sub("wkly_hrs_","wkly_hrs", colnames(weekly_data))


nlsy <- nlsy %>%
  dplyr::select(-starts_with("status_wk")) %>%
  dplyr::select(-starts_with("wkly_hrs"))

  # join back with full df
nlsy <- merge(nlsy, weekly_data, by="id",all.x=T)


# 1.4: Income: total income from wages and salary in past calendar year
	# Truncated for top 2% and revised (1982-2000)
colnames(nlsy) <- sub("Q13-5_TRUNC_REVISED_", "earnings_ly", colnames(nlsy))
	# Truncated for top 2%
colnames(nlsy) <- sub("Q13-5_TRUNC_", "earnings_ly", colnames(nlsy))
	# Standard version
nlsy <- nlsy %>%
  rename(earnings_ly1979 = `Q13-5_1979`,
         earnings_ly1980 = `Q13-5_1980`,
         earnings_ly1981 = `Q13-5_1981`)
# colnames(nlsy) <- sub("Q13-5.*_", "earnings_ly", colnames(nlsy))

# rownames(nlsy) <- make.names(nlsy[,"id"], unique = TRUE)
# 
# nlsy <- nlsy %>%
#   mutate(across(c(contains("earnings_ly")), ~ifelse(. %in% c(-5, -4, -3, -2, -1), NA_real_, .)))

# 1.5: Children

for(i in 1:11){
  colnames(nlsy) <- sub(paste0("C",as.character(i),"DOB~M_XRND"),paste0("dobm_child",as.character(i)), colnames(nlsy))
  colnames(nlsy) <- sub(paste0("C",as.character(i),"DOB~Y_XRND"),paste0("doby_child",as.character(i)), colnames(nlsy))
  colnames(nlsy) <- sub(paste0("C",as.character(i),"SEX_XRND"),paste0("sex_child",as.character(i)), colnames(nlsy))
}
colnames(nlsy) <- sub("NUMKID_XRND", "numbirths", colnames(nlsy))

# df of childbirth details
child <- nlsy %>% dplyr::select(id, contains("child") & (contains("sex") | contains("dob")))

# reshape long by children
child <- melt(as.data.table(child),             ## melt here requires a data.table 
              measure = patterns("dobm_child", "doby_child", "sex_child"), ## identify columns by patterns
              value.name = c("dobm_child", "doby_child", "sex_child"))
# if missing birth month but not year <- september
child <- child %>%
  mutate(dobm_child = ifelse(is.na(dobm_child) & !is.na(doby_child), 9, dobm_child)) %>%
  mutate(gender_child = ifelse(sex_child == 2, "Female", "Male"))
# child <- transform(child, dobmf_child = month.abb[dobm_child])
# child$dob_child <- lubridate::ymd(paste0(child$doby_child,child$dobmf_child,"15"))
child$dob_child <- as.Date(with(child, 
                                paste(as.character(doby_child), as.character(dobm_child),"15",sep="-")), "%Y-%m-%d")

child <- child %>%
  filter(!is.na(doby_child))
# number of children
count <- child %>%
  group_by(id) %>%
  summarize(nchild = n())
child <- merge(child, count, by="id", all.x=T)
# drop people who only have 1 child's birthday reported but it is not first child
child <- child %>%
  filter(!(nchild == 1 & as.numeric(as.character(variable)) > 1))

# reshape wide
child_final <- data.table::dcast(child, id + nchild ~ variable, value.var = c("dobm_child","doby_child","dob_child","sex_child", 
                                                                              "gender_child")) %>%
  subset(select=-c(dob_child_11, dob_child_10, doby_child_11, doby_child_10))
for(i in 1:11){
  colnames(child_final) <- sub(paste0("dob_child_",as.character(i)),paste0("ch",as.character(i), "dob"), colnames(child_final))
  colnames(child_final) <- sub(paste0("doby_child_",as.character(i)),paste0("ch",as.character(i), "yob"), colnames(child_final))
  }
child_final <- child_final %>%
  select_(.dots=c("id",'starts_with("nchild")', 'starts_with("ch")'))

# Region
colnames(nlsy) <- sub("REGION_", "region", colnames(nlsy))


nlsy <- nlsy %>%
  mutate(across(c(contains("region")), 
                ~as.factor(case_when(. == 1 ~ "Northeast",
                                     . == 2 ~ "Midwest",
                                     . == 3 ~ "South",
                                     . == 4 ~ "West")))) 

##########################################################################
#                 2. Reshape to long

#########################################################################
nlsy <- nlsy %>%
  select_(.dots=c("id","gender","doby","dobm", "dob","max_grade","max_degree",
                  "race","sex",'starts_with("age")','starts_with("region")',
                  'contains("wgt")', 'starts_with("weeks_wrk")',
                  'starts_with("marst")', 'starts_with("married")', 'starts_with("wkly_hrs")',
                  'starts_with("status_wk")', 'starts_with("hrs_ly")',
                  'starts_with("earnings_ly")', 'starts_with("doim")'))
nlsy <- nlsy %>%
  relocate(id, gender, doby, dobm, max_grade, max_degree, race) %>%
  rename(highest_grade = max_grade,
         highest_degree = max_degree) %>%
  subset(select=-c(AGE1M_XRND))

var_label(nlsy) <- NULL

nlsy.reshape <- pivot_longer(nlsy, cols = 10:ncol(nlsy),
                             names_to = c(".value","doiy"),
                             names_pattern = '(.*)(\\d\\d\\d\\d)')

nlsy <- nlsy.reshape %>%
  subset(select=-c(AGE1B18_, AGE1M18_, `MARSTAT-COL_`))

nlsy <- merge(nlsy, child_final, by="id", all.x=T) # add childbirth dates

##########################################################################
#                 3. New variables

#########################################################################

# survey vars: date and week of interview

nlsy <- nlsy %>%
  mutate(doim = ifelse(is.na(doim), 3, doim)) %>%
  mutate(doiy = as.numeric(doiy)) %>%
  mutate(doi = as.Date(paste(as.character(doiy), 
                             as.character(doim),"15",sep="-"), "%Y-%m-%d"))

# employment vars

  # worked last week
nlsy <- nlsy %>%
  mutate(emp_lw = case_when((status_wk >= 100 & !is.na(status_wk)) | status_wk == 7 ~ 1,
                            status_wk %in% c(2, 3, 4, 5) ~ 0))

 
  # in labor force last week
# nlsy <- nlsy %>%
#   mutate(inlf_lw = emp_lw) %>%
#   mutate(inlf_lw = case_when(status_wk %in% c(3, 4) ~ 1, #unemployed
#                              status_wk == 7 ~ NA_real_, # active military service
#                              TRUE ~ inlf_lw))

  # annual hours worked = hrs_ly

# income vars

  # earnings = earnings_ly

  # extensive margin earnings variable
nlsy <- nlsy %>%
  mutate(earn_ly = case_when(earnings_ly > 0 & !is.na(earnings_ly) ~ 1,
                             earnings_ly <= 0 & !is.na(earnings_ly) ~ 0,
                             is.na(earnings_ly) ~ NA_real_))

  # average earnings in a given year
wt_earn <- nlsy %>%
  group_by(doiy) %>%
  summarise(avg_earnings_ly = weighted.mean(earnings_ly, wgt, na.rm=T))

nlsy <- merge(nlsy, wt_earn, by="doiy",all.x=T)

# demographic vars

  # age

nlsy <- nlsy %>%
  mutate(ageA = floor((interval(dob,doi) %/% months(1))/12)) %>%
  mutate(age = ifelse(!is.na(dob) & !is.na(doi), ageA, age)) %>%
  subset(select=-c(ageA))

 # education
nlsy <- nlsy %>%
  mutate(college = ifelse(highest_degree > 2, 1, 0)) %>%
  mutate(edlevel = as.factor(case_when(
    # no degree or less than 12th grade completed  
    highest_grade < 12 & !inrange(highest_degree, 1, 7) ~ "Below HS",
    # have hs degree
    highest_degree == 1  ~ "HS grad",
    # some college if associate's degree or 1-2 years of college
    highest_degree == 2 ~ "Some college",
    # college if bachelor's or above
    inrange(highest_degree, 3, 7) ~ "College +"))) %>%
  # Fill in NAs using highest_grade
  mutate(edlevel = as.factor(case_when(
    # have hs degree
    is.na(edlevel) & highest_grade == 12 ~ "HS grad",
    # some college if associate's degree or 1-2 years of college
    is.na(edlevel) & inrange(highest_grade, 13, 15) ~ "Some college",
    # college if bachelor's or above
    is.na(edlevel) & highest_grade >= 16 ~ "College +",
    TRUE ~ as.character(edlevel))))
  

# age at first birth
nlsy <- nlsy %>%
  mutate(temp = floor((interval(dob, ch1dob) %/% months(1))/12))

age1bmax <- nlsy %>%
  group_by(id) %>%
  count(temp) %>%
  filter(!is.na(temp))%>%
  group_by(id) %>%
  slice(which.max(n)) %>%
  subset(select=-c(n)) %>%
  rename(age1b = temp) %>%
  mutate(age1b = ifelse(age1b < 14, NA_real_, age1b))
  
nlsy <- merge(nlsy, age1bmax, by="id",all.x=T)

# race
nlsy <- nlsy %>%
  mutate(black = ifelse(race == "Black, non-hispanic", 1, 0)) %>%
  mutate(white = as.factor(case_when(race == "White, non-hispanic" ~ "white",
                                     race %in% c("Black, non-hispanic","Other","Hispanic") ~ "nonwhite")))

# region
region <- nlsy %>%
  group_by(id) %>%
  count(region) %>%
  filter(!is.na(region))%>%
  group_by(id) %>%
  slice(which.max(n)) %>%
  subset(select=-c(n)) %>%
  rename(region_max = region)

nlsy <- merge(nlsy, region, by="id",all.x=T)

nlsy <- nlsy %>%
  mutate(region = as.factor(ifelse(is.na(region), as.character(region_max), as.character(region)))) %>%
  mutate(censusregion = as.factor(case_when(region %in% c("Northeast", "South") ~ "S-NE",
                                       region %in% c("West","Midwest") ~ "W-MW")))

###### event study vars

# event times
# define t=0 to be 6 months before - 6 months after birth of child for worked last week
# for earnings, since these are measured in a calendar year rather than at the time of intervew we do it differently
# want to use earnings from the calendar year in which most of the event time was realized
# nlsy <- nlsy %>%
#   mutate(t_es_lw = round((interval(ch1dob,doi) %/% months(1))/12)) %>%
#   mutate(t_es_ly = doiy - ch1yob - 1)

nlsy <- nlsy %>%
  mutate(start = ch1dob %m-% months(6)) %>%
  mutate(t_es_lw = floor((interval(start, doi) %/% months(1))/12)) %>%
  mutate(t_es_ly = doiy - ch1yob - 1)

nlsy <- nlsy %>%
  mutate(post = ifelse(doiy >= ch1dob, 1, 0))


### child variable
nlsy <- nlsy %>%
  mutate(child = ifelse(!is.na(ch1dob), 1,0))

### fix labelled variables
nlsy <- nlsy %>%
  mutate(id = as.factor(id)) %>%
  mutate(id = as.numeric(id)) %>%
  mutate(ch1yob = as.factor(ch1yob)) %>%
  mutate(ch1yob = as.numeric(as.character(ch1yob))) %>%
  subset(select=-c(ch2yob))

nlsy <- nlsy %>%
  mutate(earnings_ly = as.numeric(earnings_ly)) %>%
  mutate(doby = as.factor(doby)) %>%
  mutate(doby = as.numeric(as.character(doby)))

##########################################################################
#                 4. Sample selection and save

#########################################################################

# Save intermediate file

# foreign::write.dta(nlsy, file=file.path(wrkdir,"nlsy79_intermediate.dta"))

# drop obs we won't use

nlsy <- nlsy %>%
  # missing interview year
  filter(!is.na(doi)) %>%
  # missing weight
  filter(!is.na(wgt) & wgt > 0) %>%
  # outside age range
  # filter(inrange(age1b, min.age,max.age)) %>%
  # don't have earnings or employment obs
  filter(!is.na(emp_lw) | !is.na(earnings_ly))

# dataset variable

nlsy <- nlsy %>%
  mutate(dataset = as.factor("NLSY79")) %>%
  mutate(dataset = factor(dataset, levels = c("CPS", "ACS", "NLSY79","NLSY97", "PSID")))

nlsy <- clear.labels(nlsy)

nlsy <- apply_labels(nlsy, earnings_ly = "Earnings",
                     earn_ly = "Annual Employment",
                     emp_lw = "Weekly Employment")
  
# factor variables for regressions
nlsy <- nlsy %>%  
  mutate(age_factor = as.factor(age),
         doiy_factor = as.factor(doiy),
         age_gender = interaction(age_factor, gender),
         doiy_gender = interaction(doiy_factor, gender))

# create blank state vars
nlsy <- nlsy %>%
  mutate(statefip = NA_real_,
         statename = NA_character_)

# drop if missing vars used in matching
nlsy <- nlsy %>%
  drop_na(edlevel, marst, race) %>%
  mutate(below_college = as.factor(case_when(edlevel %in% c("Below HS", "HS grad","Some college") ~ "nocollege",
                                             edlevel == "College +" ~ "college")))

nlsy <- nlsy %>%
  subset(select=-c(highest_grade, highest_degree, xwgt, weeks_wrk, wkly_hrs,
                   status_wk, hrs_ly, ch3yob, ch4yob, ch5yob, ch6yob, 
                   ch7yob, ch8yob, ch9yob, ch3dob, ch4dob, ch5dob, ch6dob, 
                   ch7dob, ch8dob, ch9dob, avg_earnings_ly, temp,
                   region_max))


# dataset for matching that keeps everyone without child as well
save(nlsy, file=file.path(cleandir,"nlsy79_clean_all.RData"))
# foreign::write.dta(nlsy, file=file.path(wrkdir,"nlsy79_match.dta"))

# additional cleaning for event times
nlsy <- nlsy %>%
  mutate(across(c(t_es_lw,t_es_ly), ~as.factor(case_when(inrange(., -5,10)
                                                         ~ as.character(.),
                                                         . < -5 ~ NA_character_,
                                                         . > 10 ~ NA_character_)))) %>%
  within(t_es_lw <- relevel(t_es_lw, ref = ref)) %>%
  within(t_es_ly <- relevel(t_es_ly, ref = ref)) %>%
  filter(!is.na(t_es_lw) | !is.na(t_es_ly))
  

# sample restrictions
obs_count <- nlsy %>%
  mutate(obs_pre_ly = ifelse(t_es_ly %in% c("-5","-4","-3","-2","-1") & !is.na(earnings_ly),1,0),
         obs_post_ly = ifelse(t_es_ly %in% c("0","1","2","3","4","5","6","7",
                                             "8","9","10") & !is.na(earnings_ly), 1,0)) %>%
  mutate(obs_pre_lw = ifelse(t_es_ly %in% c("-5","-4","-3","-2","-1") & !is.na(emp_lw),1,0),
         obs_post_lw = ifelse(t_es_ly %in% c("0","1","2","3","4","5","6","7",
                                             "8","9","10") & !is.na(emp_lw), 1,0)) %>%
  mutate(interviewed_ly = ifelse(!is.na(earnings_ly) & !is.na(t_es_ly), 1,0),
         interviewed_lw = ifelse(!is.na(emp_lw) & !is.na(t_es_lw), 1,0)) %>%
  group_by(id) %>%
  summarise(obs_post_lw = max(obs_post_lw,na.rm=T),
            obs_post_ly = max(obs_post_ly,na.rm=T),
            obs_pre_lw = max(obs_pre_lw, na.rm=T),
            obs_pre_ly = max(obs_pre_ly, na.rm=T),
            count_obs_ly = sum(interviewed_ly),
            count_obs_lw = sum(interviewed_lw))

nlsy <- merge(nlsy, obs_count, by="id")

nlsy <- nlsy %>%
  mutate(sample_lw = ifelse(obs_post_lw == 1 & obs_pre_lw == 1 & count_obs_lw >= 8, 1, 0),
         sample_ly = ifelse(obs_post_ly == 1 & obs_pre_ly == 1 & count_obs_ly >= 8, 1, 0))

# age at first birth 25-45 only
nlsy <- nlsy %>%
  subset(inrange(age1b, 25, 45))

nlsy79 <- nlsy

save(nlsy79, file=file.path(cleandir,"nlsy79_clean_restricted.RData"))

# foreign::write.dta(nlsy79, file=file.path(wrkdir,"nlsy79_clean.dta"))

# Label variables
nlsy79 <- apply_labels(nlsy79, id = "Unique Identifier", statename = "State of Residence",
                     doiy = "Year of Intervew", doim = "Month of Interview",
                     t_es_lw = "Event Time (Weekly)", t_es_ly = "Event Time (Annual)",
                     child = "Indicator for Parent",
                     statefip = "State of Residence (FIPS)", 
                     region = "Census Region of Residence")

# save(nlsy79, file=file.path(wrkdir,"nlsy79_clean_labelled.RData"))
# 
# 
# foreign::write.dta(nlsy79, file=file.path(wrkdir,"nlsy79_clean_labelled.dta"))
