#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description:
# This file creates Figure 3: Within-panel validation scatterplot

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Define vector of outcome variables 
l.depvars <- c("earn_ly","earnings_ly","emp_lw")

coef_es_post <- function(data) {
  
  data <- droplevels(data)
  
  # regression and prediction
  reg <- feols(depvar ~ hetero + post:hetero | age_het + doiy_het, data, weights=~wgt, se="hetero") 
  
  data$prearn = reg$sumFE #prediction
  
  #grid of counterfactual earnings by event time, hetero, and gender
  grid <- aggregate(prearn  ~  post + hetero + gender, 
                    data=data , mean)
  
  grid <- filter(grid, post == 1)
  
  #weight the counterfactual by matching weights
    grid_weighted <- data %>%
      group_by(post, hetero, gender) %>%
      summarize(prearn = weighted.mean(prearn, wgt_match)) %>%
      subset(post==1)
    
    grid <- grid %>%
      subset(select=-c(prearn)) %>%
      merge(grid_weighted, by=c("post","hetero","gender"))
  
  coef <- as.data.frame(tidy(reg)) %>%
    mutate(hetero = gsub(".*hetero(.+):.*", "\\1", term))  %>%
    merge(grid, by="hetero",all.x=T) %>%
    mutate(estimate = (estimate)/prearn,
           std.error = std.error/prearn) %>%
    subset(select=c(hetero, estimate, gender))
  
  return(coef)
  
}

reg_es_post <- function(data, depvar, hetero, splitvar = "") {
  
  ## clean up data, add interactions
  
  data["depvar"] = data[{{depvar}}]
  data["hetero"] = data[{{hetero}}] 
  data["post"] = data[paste0("post_",substr({{depvar}}, nchar({{depvar}})-1, nchar({{depvar}})))]
  
  # Hetero label
  if ({{hetero}}=="region"){
    heterolbl <<- "Census Region"
  }
  if ({{hetero}}=="education"){
    heterolbl <<- "Education"
  }
  if ({{hetero}}=="race_scatter"){
    heterolbl <<- "Race"
  }
  if ({{hetero}}=="married"){
    heterolbl <<- "Marital Status"
  }
  if ({{hetero}}=="decade"){
    heterolbl <<- "Decade"
  }
  
  data <- data %>%
    drop_na(depvar, age_factor, doiy_factor, post, hetero)  %>%
    mutate(age_het = interaction(age_factor, hetero)) %>%
    mutate(doiy_het = interaction(doiy_factor, hetero)) %>%
    mutate(age_het_gender = interaction(age_factor, hetero, gender)) %>%
    mutate(doiy_het_gender = interaction(doiy_factor, hetero, gender))
  
  data <- droplevels(data)
  
  ## regression coefficients
  coef.women <- coef_es_post(subset(data, gender=="Women"))
  coef.men <- coef_es_post(subset(data, gender=="Men"))  
  
  coef <- rbind(coef.women, coef.men) %>%
    mutate(category = heterolbl)
  
  ## penalty
  penalty <- coef %>%
    spread(gender, estimate) %>%
    mutate(penalty = `Men` - `Women`) %>%
    subset(select=c(hetero, category, penalty)) %>%
    mutate(depvar_lab = var_label(data$depvar)) %>%
    mutate(depvar = {{depvar}})
  
  
  return(penalty=penalty)
}

  #########################################
  # 1. PSID and NLSY79 Actual
  
  #########################################
  
  # Load files
  load(file.path(cleandir,paste0("psid_clean_restricted",".RData"))) 
  load(file.path(cleandir,paste0("nlsy79_clean_restricted",".RData"))) 
  
  # Append and create matching wgt = 1 since there is no matching for panel
  psid_nlsy <- bind_rows(nlsy79, psid) %>%
    mutate(wgt_match = 1)
  psid_nlsy <- psid_nlsy %>%
    mutate(id_original = id) %>%
    group_by(id, dataset) %>%
    dplyr::mutate(id = cur_group_id()) %>%
    ungroup()
  
  # Creating post dummies
  psid_nlsy <- psid_nlsy %>%
    mutate(post_lw = case_when(!is.na(psid_nlsy$t_es_lw) & as.numeric(psid_nlsy$t_es_lw) >= 6 ~ 1,
                               !is.na(psid_nlsy$t_es_lw) & as.numeric(psid_nlsy$t_es_lw) < 6 ~ 0,
                               is.na(psid_nlsy$t_es_lw) ~ NA_real_))
  psid_nlsy <- psid_nlsy %>%
    mutate(post_ly = case_when(!is.na(psid_nlsy$t_es_ly) & as.numeric(psid_nlsy$t_es_ly) >= 6 ~ 1,
                               !is.na(psid_nlsy$t_es_ly) & as.numeric(psid_nlsy$t_es_ly) < 6 ~ 0,
                               is.na(psid_nlsy$t_es_ly) ~ NA_real_))
  
  # Define decades
  psid_nlsy <- psid_nlsy %>%
    mutate(decade = as.factor(case_when(
      inrange(doiy, 1973, 1979) ~ "1973-79",
      inrange(doiy, 1980, 1989) ~ "1980-89",
      inrange(doiy, 1990, 1999) ~ "1990-99",
      inrange(doiy, 2000, 2009) ~ "2000-09",
      inrange(doiy, 2010, 2019) ~ "2010-19",
      TRUE ~ NA_character_)))
  
  
  # Define education
  psid_nlsy <- psid_nlsy %>%
    mutate(education = as.factor(case_when(
      edlevel == "Below HS" | edlevel == "HS grad" ~ "HS or Less",
      edlevel == "College +" ~ "College",
      TRUE ~ NA_character_)))
  
  # Define race
  psid_nlsy <- psid_nlsy %>%
    mutate(race_scatter = as.factor(case_when(
      race == "White, non-hispanic" ~ "White, Non-Hisp.",
      race == "Black, non-hispanic" ~ "Black, Non-Hisp.",
      race == "Hispanic" ~ "Hispanic",
      race == "Other" ~ "Other Race",
      TRUE ~ NA_character_)))
  
  
  # Run function for the PSID/NLSY actual panel
  actual_estimates <- setDF(rbindlist(lapply(l.depvars, reg_es_post, data = psid_nlsy, hetero = "region"))) %>%
    bind_rows(setDF(rbindlist(lapply(l.depvars, reg_es_post, data = psid_nlsy, hetero = "education")))) %>%
    bind_rows(setDF(rbindlist(lapply(l.depvars, reg_es_post, data = psid_nlsy, hetero = "race_scatter")))) %>%
    bind_rows(setDF(rbindlist(lapply(l.depvars, reg_es_post, data = psid_nlsy, hetero = "married")))) %>%
    bind_rows(setDF(rbindlist(lapply(l.depvars, reg_es_post, data = psid_nlsy, hetero = "decade")))) %>%
    rename(penalty_actual = penalty)
  
  
  # Pseudo panel
  # Load files
  pseudo <- readRDS(file=file.path(wrkdir,"psid_nlsy_pseudo-panel.rds"))
  
  # Creating post dummies
  pseudo <- pseudo %>%
    mutate(post_lw = case_when(!is.na(pseudo$t_es_lw) & as.numeric(pseudo$t_es_lw) >= 6 ~ 1,
                               !is.na(pseudo$t_es_lw) & as.numeric(pseudo$t_es_lw) < 6 ~ 0,
                               is.na(pseudo$t_es_lw) ~ NA_real_))
  pseudo <- pseudo %>%
    mutate(post_ly = case_when(!is.na(pseudo$t_es_ly) & as.numeric(pseudo$t_es_ly) >= 6 ~ 1,
                               !is.na(pseudo$t_es_ly) & as.numeric(pseudo$t_es_ly) < 6 ~ 0,
                               is.na(pseudo$t_es_ly) ~ NA_real_))
  
  # Define decades
  pseudo <- pseudo %>%
    mutate(decade = as.factor(case_when(
      inrange(match_doiy, 1973, 1979) ~ "1973-79",
      inrange(match_doiy, 1980, 1989) ~ "1980-89",
      inrange(match_doiy, 1990, 1999) ~ "1990-99",
      inrange(match_doiy, 2000, 2009) ~ "2000-09",
      inrange(match_doiy, 2010, 2019) ~ "2010-19",
      TRUE ~ NA_character_)))
  
  
  # Define education
  pseudo <- pseudo %>%
    mutate(education = as.factor(case_when(
      edlevel == "Below HS" | edlevel == "HS grad" ~ "HS or Less",
      edlevel == "College +" ~ "College",
      TRUE ~ NA_character_)))
  
  # Define race
  pseudo <- pseudo %>%
    mutate(race_scatter = as.factor(case_when(
      race == "White, non-hispanic" ~ "White, Non-Hisp.",
      race == "Black, non-hispanic" ~ "Black, Non-Hisp.",
      race == "Hispanic" ~ "Hispanic",
      race == "Other" ~ "Other Race",
      TRUE ~ NA_character_)))
  
  
  
  # Run function for the PSID/NLSY pseudo panel
  pseudo_estimates <- setDF(rbindlist(lapply(l.depvars, reg_es_post, data = pseudo, hetero = "region"))) %>%
    bind_rows(setDF(rbindlist(lapply(l.depvars, reg_es_post, data = pseudo, hetero = "education")))) %>%
    bind_rows(setDF(rbindlist(lapply(l.depvars, reg_es_post, data = pseudo, hetero = "race_scatter")))) %>%
    bind_rows(setDF(rbindlist(lapply(l.depvars, reg_es_post, data = pseudo, hetero = "married")))) %>%
    bind_rows(setDF(rbindlist(lapply(l.depvars, reg_es_post, data = pseudo, hetero = "decade")))) %>%
    rename(penalty_pseudo = penalty)
  
  
  
  # Combine estimates into one dataset
  estimates <- join(actual_estimates, pseudo_estimates, by = c("hetero", "category", "depvar"), type = "inner")
  
  # To store results
  all_estimates <- data.frame()
  
  # Scatterplots
  for (d in c("earn_ly", "emp_lw", "earnings_ly")){
    # Graph labels
    if({{d}}=="earn_ly"){
      depvarlbl <- "emp_annual"
    }
    if({{d}}=="emp_lw"){
      depvarlbl <- "emp_weekly"
    }
    if({{d}}=="earnings_ly"){
      depvarlbl <- "earnings"
    }
    if(grepl("pooled",d)){
      depvarlbl <- "emp_pooled"
    }
    
    data <- subset(estimates, depvar == {{d}})
    data <- droplevels(data)
    
    xmin <- 0
    ymin <- 0
    
    if({{d}}=="earn_ly" | {{d}}=="emp_lw"){
      xmax <- .5
      ymax <- .5
      x45 <- 0.47
      y45 <- 0.515
      xr2 <- 0.45
      yr2 <- 0.05
      jumps <- .1
    }
    if({{d}}=="earnings_ly"){
      xmax <- .8
      ymax <- .8
      x45 <- 0.74
      y45 <- 0.81
      xr2 <- 0.7
      yr2 <- 0.1
      jumps <- .2
    }
    
    # Colors
    cols <- c("black", rgb(26,71,111, maxColorValue = 255), "#4591d3",
              rgb(128, 0, 32, maxColorValue = 255), "#1C6948")
    # Shapes
    shapes <- c(21, 24, 25, 22, 23)
    
    # Default position of labels
    xnudge <- -0.001
    ynudge <- 0.007
    
    # R^2 calculation
    reg <- lm(data=data, as.numeric(penalty_pseudo) ~ as.numeric(penalty_actual))
    summary(reg)
    r2 <- summary(reg)$r.squared
    rsquared <- sprintf('%.3f',r2)
    print(rsquared)
    
    data$rsquared <- r2
    
    # Graph
    ggplot(data=data, aes(x = penalty_actual, y = penalty_pseudo, color=category)) +
      # 45-degree line
      geom_abline(intercept = 0, slope = 1, linewidth = 0.5, color="#D11809")+
      geom_point(size = 4, aes(shape = category,fill = category))+
      # Axes labels
      labs(y = paste("Child Penalty (Pseudo ES)"), x = "Child Penalty (Actual ES)")+
      # Axes
      coord_cartesian(ylim=c(ymin-0.015,ymax+0.015),xlim=c(xmin-0.015,xmax+0.015))+
      scale_x_continuous(breaks=seq(xmin, xmax, by = jumps))+
      scale_y_continuous(breaks=seq(ymin, ymax, by = jumps))+
      # Theme
      theme_minimal()+
      # Other theme adjustments
      theme(axis.line = element_line(colour = "black",linewidth=0.2)) +
      theme(panel.grid.minor.x = element_blank(),
            panel.grid.minor.y = element_blank(),
            axis.text=element_text(size=18),
            axis.title=element_text(size=18),
            legend.position = "bottom",
            legend.title = element_blank(),
            legend.text = element_text(size=15))+
      guides(fill = guide_legend(override.aes = aes(label = "")))+
      theme(
        axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)),
        axis.text.x = element_text(vjust = -0.5),
        axis.text.y = element_text(margin = unit(c(0,0.4,0,0), "cm"))
      ) +
      theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)))+
      scale_color_manual(values = cols)+
      scale_shape_manual(values = shapes)+
      scale_fill_manual(values = cols)+
      # 45-degree
      annotate("text",x=x45, y=y45, label="45\u00B0 Line", size = 7, color="#D11809")+
      # R^2
      annotate("text", x = xr2, y = yr2, label = paste0("R^2 ==", deparse(rsquared)), size = 8, parse = TRUE, color = "black")+
      # position for text on points
      geom_text(aes(label=hetero, color=category), size=4,
                position = position_nudge(
                  x = case_when(
                    #annual employment
                    d == "earn_ly" & data$hetero %in% c("Midwest") ~ -0.003,
                    d == "earn_ly" & data$hetero %in% c("Northeast") ~ -0.007,
                    d == "earn_ly" & data$hetero %in% c("South") ~ 0.013,
                    d == "earn_ly" & data$hetero %in% c("West") ~ -0.005,
                    d == "earn_ly" & data$hetero %in% c("College") ~ -0.007,
                    d == "earn_ly" & data$hetero %in% c("HS or Less") ~ 0.028,
                    d == "earn_ly" & data$hetero %in% c("Black, Non-Hisp.") ~ -0.001,
                    d == "earn_ly" & data$hetero %in% c("White, Non-Hisp.") ~ 0.083,
                    d == "earn_ly" & data$hetero %in% c("Hispanic") ~ -0.008,
                    d == "earn_ly" & data$hetero %in% c("Other Race") ~ -0.005,
                    d == "earn_ly" & data$hetero %in% c("Married") ~ 0.04,
                    d == "earn_ly" & data$hetero %in% c("Single") ~ -0.008,
                    d == "earn_ly" & data$hetero %in% c("1973-79") ~ -0.007,
                    d == "earn_ly" & data$hetero %in% c("1980-89") ~ 0.045,
                    d == "earn_ly" & data$hetero %in% c("1990-99") ~ -0.005,
                    d == "earn_ly" & data$hetero %in% c("2000-09") ~ 0.045,
                    d == "earn_ly" & data$hetero %in% c("2010-19") ~ 0.04,
                    
                    #weekly employment
                    d == "emp_lw" & data$hetero %in% c("Midwest") ~ 0.04,
                    d == "emp_lw" & data$hetero %in% c("Northeast") ~ -0.007,
                    d == "emp_lw" & data$hetero %in% c("South") ~ 0.005,
                    d == "emp_lw" & data$hetero %in% c("West") ~ -0.006,
                    d == "emp_lw" & data$hetero %in% c("College") ~ 0.04,
                    d == "emp_lw" & data$hetero %in% c("HS or Less") ~ -0.007,
                    d == "emp_lw" & data$hetero %in% c("Black, Non-Hisp.") ~ 0.028,
                    d == "emp_lw" & data$hetero %in% c("White, Non-Hisp.") ~ 0.06,
                    d == "emp_lw" & data$hetero %in% c("Hispanic") ~ 0.02,
                    d == "emp_lw" & data$hetero %in% c("Other Race") ~ -0.005,
                    d == "emp_lw" & data$hetero %in% c("Married") ~ 0.045,
                    d == "emp_lw" & data$hetero %in% c("Single") ~ 0.013,
                    d == "emp_lw" & data$hetero %in% c("1973-79") ~ -0.007,
                    d == "emp_lw" & data$hetero %in% c("1980-89") ~ 0.045,
                    d == "emp_lw" & data$hetero %in% c("1990-99") ~ -0.005,
                    d == "emp_lw" & data$hetero %in% c("2000-09") ~ 0.025,
                    d == "emp_lw" & data$hetero %in% c("2010-19") ~ -0.007,
                    
                    #earnings
                    d == "earnings_ly" & data$hetero %in% c("Midwest") ~ 0.06,
                    d == "earnings_ly" & data$hetero %in% c("Northeast") ~ -0.01,
                    d == "earnings_ly" & data$hetero %in% c("South") ~ 0.048,
                    d == "earnings_ly" & data$hetero %in% c("West") ~ 0.044,
                    d == "earnings_ly" & data$hetero %in% c("College") ~ -0.012,
                    d == "earnings_ly" & data$hetero %in% c("HS or Less") ~ 0.02,
                    d == "earnings_ly" & data$hetero %in% c("Black, Non-Hisp.") ~ -0.005,
                    d == "earnings_ly" & data$hetero %in% c("White, Non-Hisp.") ~ 0.09,
                    d == "earnings_ly" & data$hetero %in% c("Hispanic") ~ -0.007,
                    d == "earnings_ly" & data$hetero %in% c("Other Race") ~ 0.056,
                    d == "earnings_ly" & data$hetero %in% c("Married") ~ 0.052,
                    d == "earnings_ly" & data$hetero %in% c("Single") ~ -0.01,
                    d == "earnings_ly" & data$hetero %in% c("1973-79") ~ 0.025,
                    d == "earnings_ly" & data$hetero %in% c("1980-89") ~ 0.07,
                    d == "earnings_ly" & data$hetero %in% c("1990-99") ~ 0.008,
                    d == "earnings_ly" & data$hetero %in% c("2000-09") ~ 0.07,
                    d == "earnings_ly" & data$hetero %in% c("2010-19") ~ -0.01,
                    TRUE ~ xnudge),
                  y=case_when(
                    #annual employment
                    d == "earn_ly" & data$hetero %in% c("Midwest") ~ 0.012,
                    d == "earn_ly" & data$hetero %in% c("Northeast") ~ 0.005,
                    d == "earn_ly" & data$hetero %in% c("South") ~ -0.015,
                    d == "earn_ly" & data$hetero %in% c("West") ~ 0.005,
                    d == "earn_ly" & data$hetero %in% c("College") ~ 0.003,
                    d == "earn_ly" & data$hetero %in% c("HS or Less") ~ 0.02,
                    d == "earn_ly" & data$hetero %in% c("Black, Non-Hisp.") ~ -0.013,
                    d == "earn_ly" & data$hetero %in% c("White, Non-Hisp.") ~ -0.005,
                    d == "earn_ly" & data$hetero %in% c("Hispanic") ~ 0.007,
                    d == "earn_ly" & data$hetero %in% c("Other Race") ~ 0.01,
                    d == "earn_ly" & data$hetero %in% c("Married") ~ -0.005,
                    d == "earn_ly" & data$hetero %in% c("Single") ~ 0.003,
                    d == "earn_ly" & data$hetero %in% c("1973-79") ~ 0.003,
                    d == "earn_ly" & data$hetero %in% c("1980-89") ~ 0.003,
                    d == "earn_ly" & data$hetero %in% c("1990-99") ~ 0.007,
                    d == "earn_ly" & data$hetero %in% c("2000-09") ~ 0.003,
                    d == "earn_ly" & data$hetero %in% c("2010-19") ~ -0.015,
                    
                    #weekly employment
                    d == "emp_lw" & data$hetero %in% c("Midwest") ~ -0.009,
                    d == "emp_lw" & data$hetero %in% c("Northeast") ~ 0.003,
                    d == "emp_lw" & data$hetero %in% c("South") ~ -0.015,
                    d == "emp_lw" & data$hetero %in% c("West") ~ 0.007,
                    d == "emp_lw" & data$hetero %in% c("College") ~ -0.003,
                    d == "emp_lw" & data$hetero %in% c("HS or Less") ~ -0.003,
                    d == "emp_lw" & data$hetero %in% c("Black, Non-Hisp.") ~ 0.017,
                    d == "emp_lw" & data$hetero %in% c("White, Non-Hisp.") ~ -0.017,
                    d == "emp_lw" & data$hetero %in% c("Hispanic") ~ -0.015,
                    d == "emp_lw" & data$hetero %in% c("Other Race") ~ 0.01,
                    d == "emp_lw" & data$hetero %in% c("Married") ~ 0.005,
                    d == "emp_lw" & data$hetero %in% c("Single") ~ -0.015,
                    d == "emp_lw" & data$hetero %in% c("1973-79") ~ 0.003,
                    d == "emp_lw" & data$hetero %in% c("1980-89") ~ 0.003,
                    d == "emp_lw" & data$hetero %in% c("1990-99") ~ 0.005,
                    d == "emp_lw" & data$hetero %in% c("2000-09") ~ -0.016,
                    d == "emp_lw" & data$hetero %in% c("2010-19") ~ 0.003,
                    
                    #earnings
                    d == "earnings_ly" & data$hetero %in% c("Midwest") ~ -0.015,
                    d == "earnings_ly" & data$hetero %in% c("Northeast") ~ 0.003,
                    d == "earnings_ly" & data$hetero %in% c("South") ~ 0.003,
                    d == "earnings_ly" & data$hetero %in% c("West") ~ 0.003,
                    d == "earnings_ly" & data$hetero %in% c("College") ~ 0.003,
                    d == "earnings_ly" & data$hetero %in% c("HS or Less") ~ 0.03,
                    d == "earnings_ly" & data$hetero %in% c("Black, Non-Hisp.") ~ 0.015,
                    d == "earnings_ly" & data$hetero %in% c("White, Non-Hisp.") ~ -0.025,
                    d == "earnings_ly" & data$hetero %in% c("Hispanic") ~ 0.015,
                    d == "earnings_ly" & data$hetero %in% c("Other Race") ~ 0.031,
                    d == "earnings_ly" & data$hetero %in% c("Married") ~ -0.02,
                    d == "earnings_ly" & data$hetero %in% c("Single") ~ 0.003,
                    d == "earnings_ly" & data$hetero %in% c("1973-79") ~ -0.023,
                    d == "earnings_ly" & data$hetero %in% c("1980-89") ~ 0.003,
                    d == "earnings_ly" & data$hetero %in% c("1990-99") ~ 0.03,
                    d == "earnings_ly" & data$hetero %in% c("2000-09") ~ 0.005,
                    d == "earnings_ly" & data$hetero %in% c("2010-19") ~ 0.005,
                    TRUE ~ ynudge)),
                hjust=1)
    
    ggsave(paste0("validation_scatter", "_", depvarlbl, ".pdf"), 
           plot=last_plot(), device="pdf",
           width=11, height=8, units="in",path=file.path(outdir,"Figures"))
    
    # Append to dataframe
    all_estimates <- rbind(all_estimates, data)
    
    
  }
