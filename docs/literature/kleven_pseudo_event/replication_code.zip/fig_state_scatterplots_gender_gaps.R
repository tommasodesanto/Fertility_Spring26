#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates Figure A.14 of the paper
# (Child Penalties vs Raw Gender Gaps Across States)

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Function to produce scatterplots
plot_rate_gap <- function(data, depvar, hetero) {
  
  # Graph labels
  if({{depvar}}=="earn_ly"){
    depvarlbl <- "emp_annual"
  }
  if({{depvar}}=="emp_lw"){
    depvarlbl <- "emp_weekly"
  }
  if({{depvar}}=="earnings_ly"){
    depvarlbl <- "earnings"
  }
  
  # Read in penalties
  penalty <- readRDS(file=file.path(wrkdir,"penalties_state.rds"))
  
  
  penalty <- penalty %>%
    filter(depvar == {{depvar}}) %>%
    merge(xwalk, by=c("hetero","fips"), all.x=T) %>%
    rename(estimate = penalty)
  
  rates <- gender_gaps(data=subset(data,statefip < 57),depvar={{depvar}},
                            hetero="statename") %>%
    filter(hetero != "US") %>%
    merge(penalty, by="hetero", all=T) %>%
    rename(rate = gender_gap)
  
  # estimate slope
  reg_penalty <- lm(estimate ~ rate, data = rates)
  
  rates_line <- rates %>%
    mutate(greypt="grey")
  rates <- rates %>%
    mutate(hetero_lbl = case_when(hetero %in% c("Utah","California","New York",
                                                "Texas","Florida","Illinois") ~ as.character(hetero),
                                  rate %in% c(max(rates$rate),min(rates$rate)) | 
                                    estimate %in% c(max(rates$estimate),min(rates$estimate))
                                  ~ as.character(hetero),
                                  depvar == "emp_lw" & hetero %in% c("Iowa",
                                                                     "Wisconsin","Vermont","Oregon","New Mexico","South Carolina","Maine",
                                                                     "Ohio","Alabama","New Jersey","Mississippi","Pennsylvania","Montana",
                                                                     "New Hampshire","West Virginia","Minnesota","Nebraska","Louisiana",
                                                                     "Missouri","Maryland") 
                                  ~ as.character(hetero),
                                  depvar == "earn_ly" & hetero %in% c("Minnesota","New Hampshire","Montana",
                                                                      "Georgia","Mississippi","Kentucky","Iowa","Idaho",
                                                                      "New Jersey","Colorado","Vermont",
                                                                      "Nevada","Washington","Nebraska",
                                                                      "Wyoming","West Virginia")
                                  ~ as.character(hetero),
                                  depvar == "earnings_ly" & hetero %in% c("Minnesota", "North Dakota","Colorado",
                                                                          "New Jersey","Tennessee","Washington",
                                                                          "Rhode Island","Vermont","Nebraska",
                                                                          "Maine","Connecticut","Pennsylvania",
                                                                          "Arizona","Mississippi","Kansas","Oklahoma",
                                                                          "Nevada")
                                  ~ as.character(hetero),
                                  hetero == "District of Columbia" ~ "D.C.")) %>%
    mutate(greypt = as.factor(ifelse(is.na(hetero_lbl), "grey", "black")))
  
  rates$greypt <- factor(rates$greypt, levels=c("grey","black"))
  
  if(depvar == "emp_lw"){
    ynudge <- 0.006
    xnudge <- 0
    ymin <- 0.1
    ymax <- 0.4
    ytext <- 0.125
    xmin <- 0.1
    xmax <- 0.4
    xtext <- 0.3281
      
  }
  if(depvar == "earnings_ly"){
    ynudge <- 0.01
    xnudge <- 0
    xmin <- 0.3
    xmax <- 0.7
    xtext <- 0.605
    ymin <- 0.1
    
    if (max(penalty$estimate) < .62){
      ymax <- 0.6
    }
    if (max(penalty$estimate) > .62 & max(penalty$estimate) < .65){
      ymax <- 0.65
    }
    if (max(penalty$estimate) > .65){
      ymax <- 0.68
    }
    
    ytext <- 0.141
    
  }
  if(depvar == "earn_ly"){
    ynudge <- 0.008
    xnudge <- 0
    xmin <- 0
    xmax <- 0.4
    xtext <- 0.3046
    ymin <- 0
    ymax <- 0.4
    ytext <- 0.0329
  }
  
  rates <- rates %>%
    arrange(greypt)
  scaleFUN <- function(x) sprintf("%.1f", x)
  
  rates_line <- clear.labels(rates_line)
  
  if(depvar == "earn_ly"){


    fakey <- (reg_penalty[["coefficients"]][["(Intercept)"]] + reg_penalty[["coefficients"]][["rate"]]*0.05)
    extra <- data.frame(hetero="fake", abb= "fake", estimate = fakey,
                        rate = 0.05, greypt = "#4591d3")
    rates_line <- bind_rows(rates_line, extra)

    fakey <- (reg_penalty[["coefficients"]][["(Intercept)"]] + reg_penalty[["coefficients"]][["rate"]]*0.35)
    extra <- data.frame(hetero="fake", abb= "fake", estimate = fakey,
                        rate = 0.35, greypt = "#4591d3")
    rates_line <- bind_rows(rates_line, extra)

  }
  if(depvar == "earnings_ly"){
    
    fakey <- (reg_penalty[["coefficients"]][["(Intercept)"]] + reg_penalty[["coefficients"]][["rate"]]*0.35)
    extra <- data.frame(hetero="fake", abb= "fake", estimate = fakey,
                        rate = 0.35, greypt = "#4591d3")
    rates_line <- bind_rows(rates_line, extra)
    
  }
  
  ggplot(rates, aes(y=estimate, x=rate,group=greypt,color=greypt))  +
    stat_smooth(data=rates_line, aes(x=rate, y=estimate),method="lm",
                formula = y ~ x, se=F,color="#D11809", fullrange=F) +
    # line and point sizes
    geom_point(size=3) +
    scale_colour_manual(values = c(grey = "#4591d3", black = rgb(26,71,111, maxColorValue = 255)))+
    coord_cartesian(xlim=c(xmin, xmax),ylim=c(ymin,ymax))+
    scale_y_continuous(breaks=seq(ymin, ymax, by = 0.1), labels=scaleFUN)+
    scale_x_continuous(labels=scaleFUN)+
    # axis labels
    labs(x="Raw Gender Gap for Parents", y=paste("Child Penalty")) +
    theme_minimal() +
    geom_text(aes(label=hetero_lbl), size=4,position = position_nudge(x = case_when(
      
      depvar == "earnings_ly" & rates$hetero_lbl == "New Jersey" ~ 0.034,
      depvar == "earnings_ly" & rates$hetero_lbl == "Hawaii" ~ 0.006,
      depvar == "earnings_ly" & rates$hetero_lbl == "Arizona" ~ 0.006,
      depvar == "earnings_ly" & rates$hetero_lbl == "Mississippi" ~ 0.008,
      depvar == "earnings_ly" & rates$hetero_lbl == "Kansas" ~ 0.012,
      depvar == "earnings_ly" & rates$hetero_lbl == "Connecticut" ~ 0.01,
      depvar == "earnings_ly" & rates$hetero_lbl == "Washington" ~ 0.039,
      depvar == "earnings_ly" & rates$hetero_lbl == "Oklahoma" ~ 0.035,
      depvar == "earnings_ly" & rates$hetero_lbl == "Vermont" ~ 0.009,
      depvar == "earnings_ly" & rates$hetero_lbl == "California" ~ 0.018,
      depvar == "earnings_ly" & rates$hetero_lbl == "New York" ~ 0.019,
      depvar == "earnings_ly" & rates$hetero_lbl == "Maine" ~ 0.009,
      depvar == "earnings_ly" & rates$hetero_lbl == "D.C." ~ 0.012,
      depvar == "earnings_ly" & rates$hetero_lbl == "Texas" ~ 0.02,
      depvar == "earnings_ly" & rates$hetero_lbl == "Illinois" ~ 0.023,
      depvar == "earnings_ly" & rates$hetero_lbl == "Rhode Island" ~ -0.004,
      depvar == "earn_ly" & rates$hetero_lbl == "New York" ~ 0.032,
      depvar == "earn_ly" & rates$hetero_lbl == "Nebraska" ~ 0.019,
      depvar == "earn_ly" & rates$hetero_lbl == "West Virginia" ~ 0.028,
      depvar == "earn_ly" & rates$hetero_lbl == "Kentucky" ~ 0.019,
      depvar == "earn_ly" & rates$hetero_lbl == "California" ~ 0.018,
      depvar == "earn_ly" & rates$hetero_lbl == "Washington" ~ 0.019,
      depvar == "earn_ly" & rates$hetero_lbl == "Georgia" ~ 0.015,
      depvar == "earn_ly" & rates$hetero_lbl == "Illinois" ~ 0.007,
      depvar == "earn_ly" & rates$hetero_lbl == "Nevada" ~ -0.003,
      depvar == "earn_ly" & rates$hetero_lbl == "Florida" ~ -0.003,
      depvar == "earn_ly" & rates$hetero_lbl == "Idaho" ~ -0.003,
      depvar == "earn_ly" & rates$hetero_lbl == "Pennsylvania" ~ 0.013,
      depvar == "earn_ly" & rates$hetero_lbl == "New Hampshire" ~ 0.013,
      depvar == "earn_ly" & rates$hetero_lbl == "Mississippi" ~ 0.013,
      depvar == "earn_ly" & rates$hetero_lbl == "Texas" ~ 0.01,
      depvar == "earn_ly" & rates$hetero_lbl == "D.C." ~ 0.003,
      depvar == "emp_lw" & rates$hetero_lbl == "North Dakota" ~ 0.02,
      depvar == "emp_lw" & rates$hetero_lbl == "Nebraska" ~ 0.02,
      depvar == "emp_lw" & rates$hetero_lbl == "Louisiana" ~ 0.015,
      depvar == "emp_lw" & rates$hetero_lbl == "New Mexico" ~ 0.015,
      depvar == "emp_lw" & rates$hetero_lbl == "California" ~ 0.015,
      depvar == "emp_lw" & rates$hetero_lbl == "Ohio" ~ 0.01,
      depvar == "emp_lw" & rates$hetero_lbl == "Alabama" ~ 0.018,
      depvar == "emp_lw" & rates$hetero_lbl == "New Jersey" ~ 0.018,
      depvar == "emp_lw" & rates$hetero_lbl == "New York" ~ 0.015,
      depvar == "emp_lw" & rates$hetero_lbl == "Mississippi" ~ 0.015,
      depvar == "emp_lw" & rates$hetero_lbl == "West Virginia" ~ 0.034,
      depvar == "emp_lw" & rates$hetero_lbl == "Pennsylvania" ~ 0.034,
      depvar == "emp_lw" & rates$hetero_lbl == "Florida" ~ 0.02,
      depvar == "emp_lw" & rates$hetero_lbl == "Illinois" ~ 0.015,
      depvar == "emp_lw" & rates$hetero_lbl == "Iowa" ~ 0.007,
      depvar == "emp_lw" & rates$hetero_lbl == "Missouri" ~ 0.007,
      TRUE ~ xnudge),
      y=case_when(
        depvar == "earnings_ly" & rates$hetero_lbl %in% c("Hawaii","New Jersey",
                                                          "New York","Maine",
                                                          "Mississippi","Vermont",
                                                          "California") ~ -0.01,
        depvar == "earnings_ly" & rates$hetero_lbl %in% c("Rhode Island","Oklahoma",
                                                          "Washington","Texas",
                                                          "Illinois","Florida") ~ 0,
        depvar == "earn_ly" & rates$hetero_lbl %in% c("Nebraska","Kentucky","West Virginia",
                                                      "Georgia","Texas","California",
                                                      "D.C.") ~ -0.008,
        depvar == "earn_ly" & rates$hetero_lbl %in% c("Florida","Idaho",
        "New York") ~ 0,
        depvar == "earn_ly" & rates$hetero_lbl %in% c("Illinois") ~ 0.006,
        depvar == "earn_ly" & rates$hetero_lbl %in% c("Nevada") ~ 0.003,
        depvar == "earn_ly" & rates$hetero_lbl %in% c("Iowa") ~ 0.01,
        depvar == "emp_lw" & rates$hetero_lbl %in% c("North Dakota","Nebraska","D.C.",
                                          "Louisiana","New Mexico","Texas","Iowa",
                                          "New Jersey","New York","Alabama",
                                          "Mississippi","Ohio","Illinois",
                                          "Missouri") ~ -0.006,
        depvar == "emp_lw" & rates$hetero_lbl %in% c("Florida",
                                                     "Pennsylvania") ~ 0,
        depvar == "emp_lw" & rates$hetero_lbl %in% c("West Virginia") ~ 0.002, 
        TRUE ~ ynudge)),hjust=1)+
    annotate("text",label=paste0("Slope = ",
                                 format(round(reg_penalty[["coefficients"]][["rate"]],digits=3),nsmall=3),
                                 " (", format(round(coef(summary(reg_penalty))[,"Std. Error"][["rate"]], digits=3),nsmall=3), ")"),
             x=xtext,y=ytext,
             size=8,color="black",check_overlap=T)+
    # theme + grid lines
    theme(axis.line = element_line(colour = "black",size=0.2)) +
    theme(panel.grid.minor.x = element_blank(),
          panel.grid.minor.y = element_blank(),
          legend.position = "none", legend.background=element_blank(),
          axis.text=element_text(size=18),
          axis.title=element_text(size=18))+
    theme(axis.text.x = element_text(vjust = -0.5),
          axis.text.y = element_text(margin = unit(c(0,0.4,0,0), "cm"))
    ) +
    theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)),
          axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)))
  
  ggsave(paste0("child_penalties_vs_gender_gaps","_",depvarlbl,".pdf"), plot=last_plot(), device="pdf",
         width=11, height=8, units="in",path=file.path(outdir,"Figures"))
  
  return(rates)
}

# Load CPS and ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

# Crosswalk of state names and fips codes
xwalk = data.frame(fips = ipums_val_labels(cps_acs$statefip)$val, hetero = ipums_val_labels(cps_acs$statefip)$lbl)
xwalk$abb <- state.abb[match(xwalk$hetero,state.name)]
xwalk <- xwalk %>%
  mutate(abb = ifelse(hetero == "District of Columbia", "DC", abb))



# Run function for each outcome
lapply(c("earn_ly","emp_lw","earnings_ly"), plot_rate_gap, 
       data=subset(cps_acs,statefip<57), hetero="statename")
