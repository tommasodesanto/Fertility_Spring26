#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file creates the timeseries in Figure 10 of the paper
# (Child Penalties vs Gender Progressivity Over Time)

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

  # Function for time series graph
  timfun <- function(vars, gss_time, value) {
    
    
    #### Load child penalty datasets
    
    # By decade
    cp_10yr <- read_rds(file=file.path(wrkdir,"penalties_yr10.rds")) %>%
      rename(penalty=estimate,
             interval=hetero)%>%
      mutate(interval_old = as.factor(ifelse(interval == "1973-79","1972-79",as.character(interval)))) %>%
      dplyr::mutate(depvar = depvar_lab, value=penalty) %>%
      mutate(interval = as.factor(case_when(interval_old == "1972-79" ~ "70s",
                                            interval_old == "1980-89" ~ "80s",
                                            interval_old == "1990-99" ~ "90s",
                                            interval_old == "2000-09" ~ "00s",
                                            interval_old == "2010-20" ~ "10s")))
    
    
    gss_time["value"] <- gss_time[{{value}}]
    
    # labels and breaks
    ymax <- 0.705
    shift <- 0
    mybreaks = c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7)
    mylabels=c("0.0","0.1","0.2","0.3","0.4","0.5","0.6","0.7")
    
    # prepare data
    gsscp <- gss_time %>% 
      bind_rows(cp_10yr) %>% 
      mutate(intorder = as.numeric(interval_old)) %>% 
      # for secondary GSS axis
        # note that it is not possible for now to add a secondary axis that has a
        # different scale in R so we have to re-scale the GPI values based on
        # the child penalty axis instead
      mutate(orig_value = value) %>% 
      mutate(value = case_when(
        depvar=="Gender Progressivity Index" ~ (((value+0.6)*ymax)/1.2)+shift
        , TRUE~value )
      )  %>%
      mutate(depvar = as.factor(case_when(depvar == "Gender Progressivity Index" ~ "Gender Progressivity Index",
                                          depvar == "Earnings" ~ "Earnings Penalty",
                                          depvar == "Annual Employment" ~ "Annual Employment Penalty",
                                          depvar == "Weekly Employment" ~ "Weekly Employment Penalty")))
    gsscp$depvar <- factor(gsscp$depvar, levels = c("Annual Employment Penalty","Weekly Employment Penalty",
                                                    "Earnings Penalty","Gender Progressivity Index"))
    intbreaks <- {seq(1,5,1)}
    
    gsscp$interval <- fct_reorder(gsscp$interval, gsscp$intorder)
    
    gsscp2 <- gsscp %>% 
      filter(depvar %in% vars) %>%
      droplevels()
    
    avg_gpi <- mean(gsscp$value)
    
    # figure
    fig<- ggplot(gsscp2) +
      geom_point(aes(x=intorder, y = value, color = depvar, shape = depvar), size=6) +
      geom_line(aes(x=intorder, y = value, color = depvar, linetype = depvar, size=depvar)) +
      theme_minimal() +
      theme(axis.line = element_line(colour = "black",size=0.2),
            panel.grid.major.x = element_blank(),
            panel.grid.minor.x = element_blank(),
            panel.grid.minor.y = element_blank(),
            legend.position = "bottom",
            panel.spacing = unit(-.2, "lines"),
            legend.key.size = unit(3,"lines"),
            axis.text=element_text(size=20),
            axis.title=element_text(size=20),
            axis.text.x=element_text(vjust = -0.5),
            axis.text.y.right = element_text(hjust=0.4),
            axis.text.y.left = element_text(margin = unit(c(0,0.4,0,0), "cm")),
            legend.title = element_blank(),
            axis.title.y.right = element_text(margin = margin(t = 0, r = 0, b = 0, l = 20)),
            legend.text = element_text(size=14),
            axis.title.y.left = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)),
            axis.title.x = element_text(margin = margin(t = 20, r = 0, b = 0, l = 0)))+
      labs(x = "Year") +
      guides(color=guide_legend(nrow=1)) +
      expand_limits(y = c(0,ymax)) +
      scale_x_continuous(breaks= intbreaks, labels=levels(gsscp$interval)) +
      scale_y_continuous(name = "Child Penalty", breaks = mybreaks,
                         labels=mylabels,
                         sec.axis = sec_axis(~., name = "Gender Progressivity Index",
                                             breaks=seq(0,0.7,0.7/6),
                                             labels=c("-0.6","-0.4","-0.2","0.0","0.2","0.4","0.6")
                         )) +
      scale_color_manual(values = c("black", "black", 
                                    "black",rgb(193,5,52, maxColorValue = 255)),labels = levels(gsscp2$depvar))+
      scale_shape_manual(values = c(16, 15, 17, 16))+
      scale_linetype_manual(values=c("solid", "longdash", "dashed", "solid"))+
      scale_size_manual(values = c(1, 1, 1, 1.5))
    
    plot(fig)
    
    ggsave(fig, filename =  paste0(outdir,"/Figures/gss_timeseries.pdf"), 
           width = 12, height = 8, units = "in")
    
  }
  
  # Load weights based on Census population by state in 2019
  stateweights <- read_rds(file=file.path(cleandir,"popweights_2019.rds"))
  
  # Load imputed GSS data by state and decade
  gss_state_10yr <- read_rds(file=file.path(wrkdir, "gss_imputed_state_by_decade.rds"))
  
  # Weight GSS data by state populations
  gss_10yr <- merge(gss_state_10yr, stateweights, by="statename") %>%
    group_by(interval) %>%
    summarise(mean_index_ad = mean(index_ad),
              index_ad_wgt = weighted.mean(index_ad, frac_stpop2019)) %>%
    rename(index_ad = mean_index_ad) %>%
    mutate(depvar = "Gender Progressivity Index") %>%
    rename(interval_old = interval) %>%
    mutate(interval = as.factor(case_when(interval_old == "1972-79" ~ "70s",
                                          interval_old == "1980-89" ~ "80s",
                                          interval_old == "1990-99" ~ "90s",
                                          interval_old == "2000-09" ~ "00s",
                                          interval_old == "2010-20" ~ "10s")))
  
  
  # Create graph
  timfun(c("Annual Employment Penalty", "Weekly Employment Penalty", "Earnings Penalty",
           "Gender Progressivity Index"), gss_time = gss_10yr, value = "index_ad_wgt")
