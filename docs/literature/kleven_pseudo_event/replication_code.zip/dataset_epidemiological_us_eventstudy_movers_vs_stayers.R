#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description: 
# This file estimates the event study coefficients used in Figures 12
# and A.18-A.19 for US-born movers and stayers by state of birth
# for weekly and annual employment
# The event study coefficients for pooled employment are also estimated
# which are eventually used in Table 3

#############################################################################################

# Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Define vector of outcome vars to run functions over
l.depvars <- c("emp_lw","earn_ly")

# Load CPS/ACS pseudo-panel
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

# Crosswalk of fips codes and birth state names
xwalk_bpl = data.frame(fips = ipums_val_labels(cps_acs$statefip)$val, hetero = ipums_val_labels(cps_acs$statefip)$lbl)
xwalk_bpl <- xwalk_bpl %>%
  rename(bpl_state = hetero,
         bpl_fips = fips)

# Crosswalk of fips codes and state of residence names
xwalk_statename = data.frame(fips = ipums_val_labels(cps_acs$statefip)$val, hetero = ipums_val_labels(cps_acs$statefip)$lbl)
xwalk_statename <- xwalk_statename %>%
  rename(statename = hetero,
         state_fips = fips)

# Filter out to keep US-born only
cps_acs <- cps_acs %>%
  filter(!is.na(bpl_state))

generate_dataset <- function(final_filename = T, hetero_var = "bpl_state"){
  
  # Crosswalk selection based on heterogeneity variable
  if (hetero_var == "bpl_state") {
    xwalk <- xwalk_bpl
    hetero_lbl <- "bpl_state"
    fips_lbl <- "bpl_fips"
  } else {
    xwalk <- xwalk_statename
    hetero_lbl <- "statename"
    fips_lbl <- "state_fips"
  }
  
  # Movers
  movers_FEUS <- setDF(rbindlist(lapply(l.depvars, reg_es_movers,
                                        data=subset(cps_acs, usmover == "Mover"),
                                        hetero = hetero_var, return_final="coef",
                                        plotname="-movers", export=F))) %>%
    merge(xwalk, by.x="hetero", by.y=hetero_lbl)%>%
    rename(fips = fips_lbl) %>%
    mutate(spec_lbl = "movers")
  saveRDS(movers_FEUS, file.path(wrkdir, paste0("coef_movers_by_", hetero_var, ".rds")))
  
  # Stayers
  stayers_FEUS <- setDF(rbindlist(lapply(l.depvars, reg_es_movers,
                                         data=subset(cps_acs, usmover == "Stayer"),
                                         hetero = hetero_var, return_final="coef",
                                         plotname="-stayers", export=F))) %>%
    merge(xwalk, by.x="hetero", by.y=hetero_lbl)%>%
    rename(fips = fips_lbl) %>%
    mutate(spec_lbl = "stayers")
  saveRDS(stayers_FEUS, file.path(wrkdir, paste0("coef_stayers_by_", hetero_var, ".rds")))
  
  # All US-Born
  both_FEUS <- setDF(rbindlist(lapply(l.depvars, reg_es_movers,
                                      data=cps_acs,
                                      hetero = hetero_var, return_final="coef",
                                      plotname="-USborn", 
                                      export=F))) %>%
    merge(xwalk, by.x="hetero", by.y=hetero_lbl)%>%
    rename(fips = fips_lbl) %>%
    mutate(spec_lbl = "USborn")
  saveRDS(both_FEUS, file.path(wrkdir, paste0("coef_usborn_by_", hetero_var, ".rds")))
  
  
  ###############################
  # Pooled employment
  ###############################
  
  # Prep pooled employment dataset
  data_pooled <- cps_acs %>%
    mutate(pooled_employment = ifelse(!is.na(t_es_ly) & !is.na(earn_ly), 
                                      earn_ly, emp_lw),
           t_es = as.factor(ifelse(!is.na(t_es_ly) & !is.na(earn_ly), 
                                   as.character(t_es_ly), as.character(t_es_lw))))
  data_pooled <- apply_labels(data_pooled, pooled_employment="Employment")
  
  data_pooled$t_es = factor(data_pooled$t_es, # re-order levels
                            levels=c("-2","-5", "-4", "-3", "-1",
                                     "0", "1", "2", "3","4", "5", "6",
                                     "7", "8", "9", "10"))
  
  # Stayers
  stayers_FEUS_pooled <- setDF(rbindlist(lapply(c("pooled_employment"), reg_es_movers,
                                                data=subset(data_pooled, usmover == "Stayer"),
                                                hetero = hetero_var,return_final="coef",
                                                plotname="-stayers",export=F))) %>%
    merge(xwalk, by.x="hetero", by.y=hetero_lbl)%>%
    rename(fips = fips_lbl) %>%
    mutate(spec_lbl = "stayers")
  saveRDS(stayers_FEUS_pooled, file.path(wrkdir, paste0("coef_stayers_by_", hetero_var, "-pooled_employment", ".rds")))
  
  # All US-Born
  usborn_FEUS_pooled <- setDF(rbindlist(lapply(c("pooled_employment"), reg_es_movers,
                                               data=data_pooled,
                                               hetero = hetero_var,return_final="coef",
                                               plotname="-USborn",export=F))) %>%
    merge(xwalk, by.x="hetero", by.y=hetero_lbl)%>%
    rename(fips = fips_lbl) %>%
    mutate(spec_lbl = "USborn")
  saveRDS(usborn_FEUS_pooled, file.path(wrkdir, paste0("coef_usborn_by_", hetero_var, "-pooled_employment", ".rds")))
  
  # Movers
  movers_FEUS_pooled <- setDF(rbindlist(lapply(c("pooled_employment"), reg_es_movers,
                                               data=subset(data_pooled, usmover == "Mover"),
                                               hetero = hetero_var,return_final="coef",
                                               plotname="-movers",export=F))) %>%
    merge(xwalk, by.x="hetero", by.y=hetero_lbl)%>%
    rename(fips = fips_lbl) %>%
    mutate(spec_lbl = "movers")
  saveRDS(movers_FEUS_pooled, file.path(wrkdir, paste0("coef_movers_by_", hetero_var, "-pooled_employment", ".rds")))
  
}

# Run function for both bpl_state and statename
hetero_vars <- c("bpl_state", "statename")
for (hetero_var in hetero_vars) {
  generate_dataset(final_filename = T, hetero_var = hetero_var)
}
