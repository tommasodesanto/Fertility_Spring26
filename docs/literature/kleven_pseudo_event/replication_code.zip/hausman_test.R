#############################################################################################
# Code for "The Geography of Child Penalties and Gender Norms: A Pseudo-Event Study Approach"

# Author: Henrik Kleven

# Description:
# Runs the Hausman test for the within-panel validation

#############################################################################################

#  Clear environment, set up paths and libraries
rm(list = setdiff(ls(), c("logdir", "logfile", "log_con")))
source(here::here("Code","setup.R"))

# Define vector of outcome variables 
l.depvars <- c("earn_ly","earnings_ly","emp_lw")


hausman <- function(data_pseudo, data_actual, depvar){
  
  # Actual dataset is PSID/NLSY actual
  # data_actual <- psid_nlsy
    
  # Re-define dependent variable
  data_actual["depvar"] = data_actual[{{depvar}}]
  data_pseudo["depvar"] = data_pseudo[{{depvar}}]
  
  # Use corresponding event time except for pooled employment
  if (!grepl("pooled",depvar)) {
    data_actual["t_es"] = data_actual[paste0("t_es_",substr({{depvar}}, nchar({{depvar}})-1, nchar({{depvar}})))]
    data_actual["post"] = data_actual[paste0("post_",substr({{depvar}}, nchar({{depvar}})-1, nchar({{depvar}})))]
  }
  if (!grepl("pooled",depvar)) {
    data_pseudo["t_es"] = data_pseudo[paste0("t_es_",substr({{depvar}}, nchar({{depvar}})-1, nchar({{depvar}})))]
    data_pseudo["post"] = data_pseudo[paste0("post_",substr({{depvar}}, nchar({{depvar}})-1, nchar({{depvar}})))]
  }
  
  # Keep sample of interest only
  data_actual <- data_actual %>%
    drop_na(depvar, age_factor, doiy_factor, t_es, post) %>%
    filter(wgt!=0) %>%
    droplevels()
  data_pseudo <- data_pseudo %>%
    drop_na(depvar, age_factor, doiy_factor, t_es, post) %>%
    filter(wgt!=0) %>%
    droplevels()
  
  # Create empty dataframe to store Hausman statistics in
  store_hausman <- setNames(data.frame(matrix(ncol = 3, nrow = 0)), c("hausman", "depvar", "p-values"))
  
  # Drop unused factor levels
  data_actual <- data_actual %>%
    droplevels()
  data_pseudo <- data_pseudo %>%
    droplevels()
  
  # Regression
  reg_actual <- feols(depvar ~ post + i(post, gender, ref = 0, ref2 = "Men") | age_factor + doiy_factor + age_gender + doiy_gender, 
                      data =data_actual, weights=~wgt, se = "hetero")
  reg_pseudo <- feols(depvar ~ post + i(post, gender, ref = 0, ref2 = "Men") | age_factor + doiy_factor + age_gender + doiy_gender, 
                      data =data_pseudo, weights=~wgt, se = "hetero")
  
  # Save variance-covariance matrix
  vcov_actual <- vcov(reg_actual)
  vcov_pseudo <- vcov(reg_pseudo)
  
  # Subset the part of the vcov matrix we want to keep
  vcov_actual <- as.data.frame(vcov_actual) %>% select(contains("gender"))
  vcov_actual <- as.matrix(vcov_actual[2:2, ])
  vcov_pseudo <- as.data.frame(vcov_pseudo) %>% select(contains("gender"))
  vcov_pseudo <- as.matrix(vcov_pseudo[2:2, ])
  
  
  # Get inverse of matrix
  vcov_matrix <- vcov_actual - vcov_pseudo
  inv_vcov <- solve(vcov_matrix)
  
  # Get 1 x k matrix
  matrix_1k_actual <- matrix(reg_actual$coefficients[2:2], nrow = 1, ncol = 1)
  matrix_1k_pseudo <- matrix(reg_pseudo$coefficients[2:2], nrow = 1, ncol = 1)
  matrix_1k <- matrix_1k_actual - matrix_1k_pseudo
  
  # Get k x 1 matrix
  matrix_k1_actual <- matrix(reg_actual$coefficients[2:2], nrow = 1, ncol = 1)
  matrix_k1_pseudo <- matrix(reg_pseudo$coefficients[2:2], nrow = 1, ncol = 1)
  matrix_k1 <- matrix_k1_actual - matrix_k1_pseudo
  
  # Calculate Hausman statistic
  hausman_stat <- abs(matrix_1k %*% inv_vcov %*% matrix_k1)
  
  # Calculate p-value
  pval <- pchisq(hausman_stat, df = 1, lower.tail = FALSE)
  
  # Store results
  store_hausman[nrow(store_hausman) + 1,] = c(hausman_stat, depvar, pval)
  
  # Converting to numeric
  store_hausman$hausman <- as.numeric(store_hausman$hausman)
  store_hausman$`p-values` <- as.numeric(store_hausman$`p-values`)
  
  return(store_hausman)
}

# Load PSID/NLSY actual
load(file.path(cleandir,paste0("psid_clean_restricted",".RData")))
load(file.path(cleandir,paste0("nlsy79_clean_restricted",".RData")))

# Append and create matching wgt = 1 since there is no matching for panel
psid_nlsy <- bind_rows(nlsy79, psid) %>%
  mutate(wgt_match = 1)
psid_nlsy <- psid_nlsy %>%
  mutate(id_original = id) %>%
  group_by(id, dataset) %>%
  dplyr::mutate(id = cur_group_id()) %>%
  ungroup()

# Re-order factor levels
psid_nlsy$t_es_lw <- factor(psid_nlsy$t_es_lw, levels = c("-2", "-5", "-4", "-3", "-1", "0", "1",
                                                          "2", "3", "4", "5", "6", "7", "8", "9", "10"))
psid_nlsy$t_es_ly <- factor(psid_nlsy$t_es_ly, levels = c("-2", "-5", "-4", "-3", "-1", "0", "1",
                                                       "2", "3", "4", "5", "6", "7", "8", "9", "10"))

# Load PSID/NLSY pseudo
psid_nlsy_pseudo <- readRDS(file.path(wrkdir,"psid_nlsy_pseudo-panel.rds"))

# Load CPS/ACS pseudo
cps_acs <- readRDS(file.path(wrkdir,"cps_acs_pseudo-panel.rds"))

# Creating post dummies
psid_nlsy <- psid_nlsy %>%
  mutate(post_lw = case_when(!is.na(psid_nlsy$t_es_lw) & as.numeric(psid_nlsy$t_es_lw) >= 6 ~ 1,
                             !is.na(psid_nlsy$t_es_lw) & as.numeric(psid_nlsy$t_es_lw) < 6 ~ 0,
                             is.na(psid_nlsy$t_es_lw) ~ NA_real_))
psid_nlsy <- psid_nlsy %>%
  mutate(post_ly = case_when(!is.na(psid_nlsy$t_es_ly) & as.numeric(psid_nlsy$t_es_ly) >= 6 ~ 1,
                             !is.na(psid_nlsy$t_es_ly) & as.numeric(psid_nlsy$t_es_ly) < 6 ~ 0,
                             is.na(psid_nlsy$t_es_ly) ~ NA_real_))
psid_nlsy_pseudo <- psid_nlsy_pseudo %>%
  mutate(post_lw = case_when(!is.na(psid_nlsy_pseudo$t_es_lw) & as.numeric(psid_nlsy_pseudo$t_es_lw) >= 6 ~ 1,
                             !is.na(psid_nlsy_pseudo$t_es_lw) & as.numeric(psid_nlsy_pseudo$t_es_lw) < 6 ~ 0,
                             is.na(psid_nlsy_pseudo$t_es_lw) ~ NA_real_))
psid_nlsy_pseudo <- psid_nlsy_pseudo %>%
  mutate(post_ly = case_when(!is.na(psid_nlsy_pseudo$t_es_ly) & as.numeric(psid_nlsy_pseudo$t_es_ly) >= 6 ~ 1,
                             !is.na(psid_nlsy_pseudo$t_es_ly) & as.numeric(psid_nlsy_pseudo$t_es_ly) < 6 ~ 0,
                             is.na(psid_nlsy_pseudo$t_es_ly) ~ NA_real_))

cps_acs <- cps_acs %>%
  mutate(post_lw = case_when(!is.na(cps_acs$t_es_lw) & as.numeric(cps_acs$t_es_lw) >= 6 ~ 1,
                             !is.na(cps_acs$t_es_lw) & as.numeric(cps_acs$t_es_lw) < 6 ~ 0,
                             is.na(cps_acs$t_es_lw) ~ NA_real_))
cps_acs <- cps_acs %>%
  mutate(post_ly = case_when(!is.na(cps_acs$t_es_ly) & as.numeric(cps_acs$t_es_ly) >= 6 ~ 1,
                             !is.na(cps_acs$t_es_ly) & as.numeric(cps_acs$t_es_ly) < 6 ~ 0,
                             is.na(cps_acs$t_es_ly) ~ NA_real_))

# Run function
# Post variable, interact with gender
hausman_stats <- setDF(rbindlist(lapply(l.depvars, hausman, data_pseudo = psid_nlsy_pseudo, data_actual = psid_nlsy)))
hausman_stats <- hausman_stats %>%
                    mutate(compare = "Pseudo PSID-NLSY vs Actual PSID-NLSY")

hausman_stats2 <- setDF(rbindlist(lapply(l.depvars, hausman, data_pseudo = cps_acs, data_actual = psid_nlsy)))
hausman_stats2 <- hausman_stats2 %>%
                    mutate(compare = "Pseudo CPS-ACS vs Actual PSID-NLSY")

hausman_stats3 <- setDF(rbindlist(lapply(l.depvars, hausman, data_pseudo = cps_acs, data_actual = psid_nlsy_pseudo)))
hausman_stats3 <- hausman_stats3 %>%
  mutate(compare = "Pseudo CPS-ACS vs Pseudo PSID-NLSY")

hausman_stats <- rbind(hausman_stats, hausman_stats2, hausman_stats3)

# Save to working data
saveRDS(hausman_stats, file=file.path(wrkdir,paste0("hausman_stats.rds")))
