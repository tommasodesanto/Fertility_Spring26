# Corina progress presentation

Separate adviser update covering **September 17–October 2, 2026**, prepared for Corina
Boar. This dated presentation was explicitly requested and does not replace the
continuing [JMP Slides](../JMP_slides/JMP_slides.tex).

- [Presentation PDF](corina_progress.pdf)
- [Editable standalone Beamer source](corina_progress.tex)
- [Source and evidence bundle](corina_progress_source_bundle.zip)
- [Slide-by-slide provenance](source_map.md)
- [Verification receipt](verification.json)

## Verified scientific facts

The displayed results compare the October 2 fresh-postchecked hard-closing and
quarter-saving purchase-rule calibrations. Authoritative full packets are in
[overnight readout](../../output/model/fixed_reference_economics_20260928/purchase_rules_overnight_v1/collection/readout/),
with unchanged local copies under `evidence/overnight_*`. Each has all fourteen
fit rows, thirty-one parameter rows and seventeen standard plots. The copied
identity receipt records byte-identical selected-root/repeat tables and closure.
Estimates remain provisional: postchecks do not certify optimizer convergence
or paper-baseline adoption.

Both use the same original target values and weights: hard loss
97.01121981277964 and quarter-saving loss 51.55603604909936. These can be
compared within this paired contract. They are not improvement comparisons
with the earlier 31.284 or 19.581 objectives, whose economic/weighting contracts
differ. Ten parameters, including the child-benefit level, are jointly free.
Ten moments are scored, three are validation, and one checks birth renewal.
Housing supply scale is now derived at population normalized to one: H0 is
7.546002524007095 (hard) and 7.288573389887633 (quarter). Price clears birth renewal.

The parenthood-only Stone–Geary specification retains constant expenditure
shares, the power equivalence scale and nonlinear child benefit, with no
compensated-share factor. The housing-floor search bound is now [0.1,2.6];
estimates 2.562319632969801 and 2.49169824815624 are not at the upper bound.
Nonnegative mean-preserving entrant wealth, the common 2% annual real rate and
no unsecured renter borrowing are retained. Both purchase rules enforce buyer
end-of-period net-estate solvency. These changed closure, purchase-rule and
bound settings must be distinguished from the earlier fixed-H0 floor point.

The hard purchase test is A >= .2Q. The quarter-saving test is
A + .25[b'−(A−Q)] >= .2Q, where A is financial wealth plus net sale proceeds,
Q the chosen home's price and b' the end-of-period financial balance. The
quarter refers to the eligible fraction of net saving, not quarterly fertility.
No new policy-response result is claimed.

## Review and changes

The fourteen-frame narrative explains the model, joint identification, complete
paired calibration, purchase-credit timing and remaining fit:

1. Model review and revisions
2. Household decisions
3. Children and housing needs
4. Demographic and market equilibrium
5. Housing around the first birth
6. Calibration strategy and inputs
7. Identification
8. Stone–Geary calibration
9. Household policies and lifecycle paths (figure slot)
10. Housing supply and borrowing constraints (figure slot)
11. Transition dynamics (figure slot)
12. Parameter estimates
13. Credit timing
14. Calibration comparison

Identification discusses all ten parameters and all ten scored moments as joint
sources of information, not a one-parameter/one-moment mapping. H0 is derived
and theta1 externally restricted; child-benefit curvature and tenure taste
scale are free. The old main JMP identification text describes a different
parameter contract and remains unchanged. The fit uses
`Moment | Target | Hard | Quarter-saving`; all fourteen rows remain, with three
validation rows separated below. Full gaps, weights, contributions, restrictions
and bound flags remain in supporting CSVs. Three titled figure slots remain
pending; no transition estimate is implied by a placeholder.

The prior preference-alternatives section is replaced by credit timing. The
PSID figure and private empirical provenance are preserved. No visible source
footers, internal failure history or dedicated computation section are added.
All seventeen standard plots per selected arm have a saved visual review at
[plot review](../../output/model/fixed_reference_economics_20260928/purchase_rules_overnight_v1/collection/readout/visual_review/REVIEW.md).
It documents boundary/support limitations; visual screening is not a convergence
or policy-acceptance certificate. Earlier receipts describe preserved versions.
Final deck verification checked the candidate identities, equations,
all paired table cells and all fourteen rendered pages. No model, test suite, benchmark, cluster
job or job stop was run for this documentation update. The main JMP deck and
manuscripts remain outside this task's edit scope.

## Preservation and build

The received source, PDF, source map, QA receipt and original source bundle are
preserved in `archive/received/`. `archive/transfer_manifest.json` records the
incoming hashes. The original task directory is also preserved:
`/Users/tommasodesanto/Documents/Codex/2026-09-30/task-4/corina_progress_20260930/`.
Its transient build products were moved out of this new active folder to the
review's temporary build directory.

Compile the source twice with `pdflatex -interaction=nonstopmode -halt-on-error`,
directing auxiliary files to a temporary build directory. The final document
must contain fourteen pages and fourteen frames with no overlays. The final
verification receipt records compilation, rendered-page inspection, source
hashes, preservation checks and Library delivery availability.


Three titled illustration slots follow the calibration table (pages 9–11):
household policies and lifecycle paths; housing supply and borrowing constraints;
and transition dynamics. Figure selection and insertion remain pending.
No fixed slide-count limit remains.
