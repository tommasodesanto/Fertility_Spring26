#!/usr/bin/env bash
set -euo pipefail
remote=/scratch/td2248/projects/utility_floor_psi_continuous_v1
cd "$remote"
[[ ! -e submission_receipt.json ]] || { echo 'Refusing duplicate submission'; exit 2; }
submission_epoch=$(date +%s)
job=$(sbatch --parsable --array=0-3 launch_torch.sh)
job=${job%%;*}
/share/apps/anaconda3/2025.06/bin/python - "$job" "$submission_epoch" <<'PYREC'
import json,sys
from pathlib import Path
r=dict(status='submitted',array_job_id=sys.argv[1],chains=4,wall_seconds=7200,cpus_per_chain=1,memory_GiB_per_chain=24,maximum_objective_calls_per_chain=100,final_reserve_seconds=900,profiles='original_baseline_weights',free_psi=True,experimental_not_adopted=True,submission_epoch=int(sys.argv[2]),deadline_basis='each actual launcher start plus7200 seconds',nearby_nm_chains=4,broader_pso_chains=0,no_auto_retry=True)
Path('submission_receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
PYREC
