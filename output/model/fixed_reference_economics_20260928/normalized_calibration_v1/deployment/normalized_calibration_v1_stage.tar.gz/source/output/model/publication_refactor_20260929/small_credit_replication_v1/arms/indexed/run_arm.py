import sys
import driver
OriginalBudget=driver.Budget
class PairBudget(OriginalBudget):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        if self.smoke: (self.out / "phase_b_ge").mkdir(parents=True, exist_ok=True)
        else: self.max_lifecycle=6
driver.Budget=PairBudget
driver.main()
