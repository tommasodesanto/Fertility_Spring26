#!/usr/bin/env bash
set -euo pipefail
remote=/scratch/td2248/projects/utility_floor_psi_overnight_v1
cd "$remote"
[[ ! -e submission_receipt.json ]] || { echo 'Refusing duplicate submission'; exit 2; }
submission_epoch=$(date +%s)
common_deadline_epoch=1790863200
[[ "$submission_epoch" -lt "$common_deadline_epoch" ]] || { echo "Author cutoff already passed"; exit 2; }
printf "%s\n" "$common_deadline_epoch" > common_deadline_epoch
job=$(sbatch --parsable --array=0-23 launch_torch.sh)
job=${job%%;*}
/share/apps/anaconda3/2025.06/bin/python - "$job" "$common_deadline_epoch" "$submission_epoch" <<'PY'
import json,sys,time
from pathlib import Path
r=dict(common_deadline_epoch=int(sys.argv[2]),status='submitted',array_job_id=sys.argv[1],chains=24,wall_seconds=36000,cpus_per_chain=1,memory_GiB_per_chain=24,maximum_objective_calls_per_chain=400,free_psi=True,profiles='four_existing_profiles_NM_original_baseline_PSO',experimental_not_adopted=True,submission_epoch=int(sys.argv[3]),submission_deadline_basis=False,absolute_author_cutoff=True,cutoff_timezone='America/New_York',cutoff_iso='2026-10-01T10:00:00-04:00',nearby_nm_chains=16,broader_pso_chains=8,no_auto_retry=True)
Path('submission_receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
PY
