"""Pure controller/seed tests; no native lifecycle solve."""
import csv,json,time
from pathlib import Path
import numpy as np
from scipy.stats import qmc
import run_psi as r
HERE=Path(__file__).resolve().parent

def main():
 c=r.CONFIG;coords=c['free_coordinates'];bounds=c['bounds'];center=c['center'];old=json.loads((HERE.parent/'utility_floor_psi_overnight_v1/plan.json').read_text());assert c['base_target_contract']==old['base_target_contract'] and c['bounds']==old['bounds'] and c['profiles']=={'base_control':{}} and c['chains']==8 and not c['pso_swarms']
 actual={x['parameter']:float(x['estimate']) for x in csv.DictReader((HERE/'center/parameters.csv').open())};assert center=={k:actual[k] for k in coords};assert center['h_P']==bounds['h_P'][1]==2.3
 samples=2*qmc.LatinHypercube(d=10,seed=20261002).random(n=7)-1
 for i,x in enumerate(c['nearby_starts']):
  r.inputs.check_point(x['parameters'],bounds);assert x['profile']=='base_control' and x['initial_price']==c['initial_price']
  if i:
   delta={k:float(samples[i-1,j])*c['nearby_design']['halfwidths'][k] for j,k in enumerate(coords)};delta['h_P']=-abs(delta['h_P'])
   assert x['parameters']=={k:center[k]+x['joint_scale_factor']*delta[k] for k in coords} and x['parameters']['h_P']<2.3
  else:assert x['parameters']==center
 lane='floor_s0';r.inputs.LANES[lane].update(bounds=bounds,free_coordinates=coords);P,grid=r.inputs.proposal(lane);P,entry=r.inputs.entry(P,grid,'nonnegative_mean')
 receipts=[]
 for chain,x in enumerate(c['nearby_starts']):
  Q=r.inputs.bind(P,x['parameters'],bounds,'floor');assert Q.psi_child==x['parameters']['psi_child'] and Q.child_room_floor and Q.hbar_first_child_jump==x['parameters']['h_P']
  out=HERE/'toy'/f'chain_{chain}'
  def evaluate(label,point,end):
   rr=np.array([(point[k]-center[k])/(bounds[k][1]-bounds[k][0])+.01 for k in coords]);return dict(status='passed',residual=rr.tolist(),lifecycle_solves=0,report='mock')
  result=r.optimize(out,x['parameters'],bounds,coords,evaluate,time.time()+7200,toy=True,maxeval=100,chain=chain)
  assert result['objective_calls']<=100 and result['completed_full_ge']>10 and result['lifecycle_solves']==0
  rows=json.loads((out/'cases.json').read_text());assert all(z['base_loss']==z['loss'] for z in rows)
  receipts.append(dict(chain=chain,calls=result['objective_calls'],cases=result['completed_full_ge'],lifecycle_solves=0))
 no_call=lambda *a:(_ for _ in ()).throw(AssertionError('Reserve failed'))
 result=r.optimize(HERE/'toy/budget',center,bounds,coords,no_call,time.time()+899,toy=True,maxeval=100,chain=0);assert result['completed_full_ge']==0
 try:r.optimize(HERE/'toy/fatal',center,bounds,coords,lambda *a:(_ for _ in ()).throw(RuntimeError('mock_fatal')),time.time()+7200,toy=True,maxeval=100,chain=0)
 except RuntimeError as exc:assert str(exc)=='mock_fatal'
 else:raise AssertionError('Fatal swallowed')
 source=(HERE/'run_psi.py').read_text();launch=(HERE/'deployment/launch_torch.sh').read_text();assert 'MAX_EVAL = 100' in source and 'deadline=min(args.deadline_epoch,start+7200)' in source and 'deadline_epoch=$((start_epoch+7200))' in launch and 'common_deadline' not in launch
 receipt=dict(status='passed_zero_lifecycle',chains=8,controllers=receipts,base_objective_only=True,hard_bounds_exact=True,h_P_bound_not_widened=True,h_P_inward_joint_starts=True,actual_start_two_hour_clock=True,reserve900_verified=True,fatal_propagation=True,lifecycle_solves=0)
 (HERE/'configuration_check.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
if __name__=='__main__':main()
