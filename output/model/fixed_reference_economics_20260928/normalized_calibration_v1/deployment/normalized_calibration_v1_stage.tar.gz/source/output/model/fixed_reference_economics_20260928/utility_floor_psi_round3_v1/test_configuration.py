"""Bounded zero-lifecycle checks for the reviewed sixteen-chain dispatch."""
import csv,json,time
from pathlib import Path
import numpy as np
from scipy.stats import qmc
import run_psi as r
HERE=Path(__file__).resolve().parent

def main():
 c=r.CONFIG;coords=c['free_coordinates'];bounds=c['bounds'];old=json.loads((HERE.parent/'utility_floor_psi_v1/plan.json').read_text());prev=json.loads((HERE.parent/'utility_floor_psi_multistart_v1/plan.json').read_text())
 assert c['base_target_contract']==old['base_target_contract'] and c['profiles']==old['profiles'] and c['bounds']==prev['bounds'] and c['pso_initialization_ranges']==prev['pso_initialization_ranges']
 assert len(c['nearby_starts'])==12 and len(c['pso_swarms'])==4
 for group,center in enumerate(c['centers']):
  rows=list(csv.DictReader((HERE/'centers'/center['name']/'parameters.csv').open()));pars={x['parameter']:float(x['estimate']) for x in rows};assert center['parameters']=={k:pars[k] for k in coords}
  starts=c['nearby_starts'][group*3:group*3+3];assert starts[0]['parameters']==center['parameters']
  samples=2*qmc.LatinHypercube(d=10,seed=20261001+group).random(n=2)-1
  for i,row in enumerate(starts):
   assert row['profile']==center['profile'] and row['initial_price']==center['price'];r.inputs.check_point(row['parameters'],bounds)
   if i:
    for j,k in enumerate(coords):assert row['parameters'][k]==center['parameters'][k]+row['joint_scale_factor']*float(samples[i-1,j])*c['nearby_design']['halfwidths'][k]
 for swarm in c['pso_swarms']:
  assert swarm['profile']=='base_control' and len(swarm['particles'])==8
  center=next(x for x in c['centers'] if x['name']==swarm['center_name']);assert swarm['particles'][0]==center['parameters'] and swarm['initial_price']==center['price']
  for point in swarm['particles']:r.inputs.check_point(point,bounds)
 lane='floor_s0';r.inputs.LANES[lane].update(bounds=bounds,free_coordinates=coords);P,grid=r.inputs.proposal(lane);P,entry=r.inputs.entry(P,grid,'nonnegative_mean')
 vectors=[x['parameters'] for x in c['nearby_starts']]+[p for x in c['pso_swarms'] for p in x['particles']]
 for point in vectors:
  Q=r.inputs.bind(P,point,bounds,'floor');assert Q.psi_child==point['psi_child'] and Q.child_room_floor and Q.hbar_first_child_jump==point['h_P'] and Q.beta==point['beta_annual']**Q.period_years
 receipts=[]
 for chain in range(16):
  design=c['nearby_starts'][chain] if chain<12 else c['pso_swarms'][chain-12];seed=design['parameters'] if chain<12 else design['particles'][0];profile=design['profile'];out=HERE/'toy'/f'chain_{chain}';counter=[0]
  def evaluate(label,point,end):
   counter[0]+=1
   if chain==15 and counter[0]==2:return dict(status='inadmissible_numerical',reason='mock_rejection',lifecycle_solves=0)
   rr=np.array([(point[k]-seed[k])/(bounds[k][1]-bounds[k][0])+.01 for k in coords]);return dict(status='passed',residual=rr.tolist(),lifecycle_solves=0,report=str(out/label))
  result=r.optimize(out,seed,bounds,coords,evaluate,time.time()+7200,toy=True,maxeval=40,multipliers=c['profiles'][profile],chain=chain)
  assert result['objective_calls']==40 and result['lifecycle_solves']==0 and result['completed_full_ge']>10
  for row in json.loads((out/'cases.json').read_text()):
   if row['status']=='passed':
    rr=np.array(row['base_residual']);assert row['base_loss']==float(rr@rr);weighted=r.weighted_residual(rr,c['profiles'][profile]);assert row['loss']==float(weighted@weighted)
  if chain>=12:assert json.loads((out/'pso_state.json').read_text())['generation']>=1
  receipts.append(dict(chain=chain,profile=profile,calls=result['objective_calls'],cases=result['completed_full_ge'],lifecycle_solves=0))
 no_call=lambda *a: (_ for _ in ()).throw(AssertionError('Reserve failed'))
 budget=r.optimize(HERE/'toy/budget',c['center'],bounds,coords,no_call,time.time()+899,toy=True,maxeval=40,chain=12);assert budget['completed_full_ge']==0
 try:r.optimize(HERE/'toy/failure',c['center'],bounds,coords,lambda *a: (_ for _ in ()).throw(RuntimeError('mock_fatal')),time.time()+7200,toy=True,maxeval=40,chain=12)
 except RuntimeError as exc:assert str(exc)=='mock_fatal'
 else:raise AssertionError('Fatal swallowed')
 receipt=dict(status='passed_zero_lifecycle',parameter_binding_vectors=len(vectors),controllers=receipts,target_contract_exact=True,profiles_exact=True,bounds_exact=True,broad_ranges_exact=True,reserve_stop=True,fatal_propagation=True,numerical_rejection=True,lifecycle_solves=0)
 (HERE/'configuration_check.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
if __name__=='__main__':main()
