"""Bounded zero-lifecycle checks for the reviewed twenty-four-chain dispatch."""
import csv,json,time
from pathlib import Path
import numpy as np
from scipy.stats import qmc
import run_psi as r
HERE=Path(__file__).resolve().parent

def main():
 c=r.CONFIG;coords=c['free_coordinates'];bounds=c['bounds'];old=json.loads((HERE.parent/'utility_floor_psi_v1/plan.json').read_text());prev=json.loads((HERE.parent/'utility_floor_psi_multistart_v1/plan.json').read_text())
 assert c['base_target_contract']==old['base_target_contract'] and c['profiles']==old['profiles'] and c['bounds']==prev['bounds'] and c['pso_initialization_ranges']==prev['pso_initialization_ranges']
 assert len(c['nearby_starts'])==16 and len(c['pso_swarms'])==8
 for group,center in enumerate(c['centers']):
  rows=list(csv.DictReader((HERE/'centers'/center['name']/'parameters.csv').open()));pars={x['parameter']:float(x['estimate']) for x in rows};assert center['parameters']=={k:pars[k] for k in coords}
  starts=c['nearby_starts'][group*4:group*4+4];assert starts[0]['parameters']==center['parameters']
  samples=2*qmc.LatinHypercube(d=10,seed=20261021+group).random(n=3)-1
  for i,row in enumerate(starts):
   assert row['profile']==center['profile'];r.inputs.check_point(row['parameters'],bounds)
   if row.get('provisional_seed'):
    provisional=json.loads((HERE/'provisional_seed/receipt.json').read_text());assert row['parameters']==provisional['parameters'] and row['initial_price']==provisional['price'] and provisional['exploration_unverified'];continue
   assert row['initial_price']==center['price']
   if i:
    for j,k in enumerate(coords):assert row['parameters'][k]==center['parameters'][k]+row['joint_scale_factor']*float(samples[i-1,j])*c['nearby_design']['halfwidths'][k]
 for swarm in c['pso_swarms']:
  assert swarm['profile']=='base_control' and len(swarm['particles'])==8
  center=next(x for x in c['centers'] if x['name']==swarm['center_name']);assert swarm['particles'][0]==center['parameters'] and swarm['initial_price']==center['price']
  for point in swarm['particles']:r.inputs.check_point(point,bounds)
 lane='floor_s0';r.inputs.LANES[lane].update(bounds=bounds,free_coordinates=coords);P,grid=r.inputs.proposal(lane);P,entry=r.inputs.entry(P,grid,'nonnegative_mean')
 vectors=[x['parameters'] for x in c['nearby_starts']]+[p for x in c['pso_swarms'] for p in x['particles']]
 for point in vectors:
  Q=r.inputs.bind(P,point,bounds,'floor');assert Q.psi_child==point['psi_child'] and Q.child_room_floor and Q.hbar_first_child_jump==point['h_P'] and Q.beta==point['beta_annual']**Q.period_years
 receipts=[]
 for chain in range(24):
  design=c['nearby_starts'][chain] if chain<16 else c['pso_swarms'][chain-16];seed=design['parameters'] if chain<16 else design['particles'][0];profile=design['profile'];out=HERE/'toy'/f'chain_{chain}';counter=[0]
  def evaluate(label,point,end):
   counter[0]+=1
   if chain==23 and counter[0]==2:return dict(status='inadmissible_numerical',reason='mock_rejection',lifecycle_solves=0)
   rr=np.array([(point[k]-seed[k])/(bounds[k][1]-bounds[k][0])+.01 for k in coords]);return dict(status='passed',residual=rr.tolist(),lifecycle_solves=0,report=str(out/label))
  result=r.optimize(out,seed,bounds,coords,evaluate,time.time()+7200,toy=True,maxeval=40,multipliers=c['profiles'][profile],chain=chain)
  assert result['objective_calls']==40 and result['lifecycle_solves']==0 and result['completed_full_ge']>10
  for row in json.loads((out/'cases.json').read_text()):
   if row['status']=='passed':
    rr=np.array(row['base_residual']);assert row['base_loss']==float(rr@rr);weighted=r.weighted_residual(rr,c['profiles'][profile]);assert row['loss']==float(weighted@weighted)
  if chain>=16:assert json.loads((out/'pso_state.json').read_text())['generation']>=1
  receipts.append(dict(chain=chain,profile=profile,calls=result['objective_calls'],cases=result['completed_full_ge'],lifecycle_solves=0))
 no_call=lambda *a: (_ for _ in ()).throw(AssertionError('Reserve failed'))
 budget=r.optimize(HERE/'toy/budget',c['center'],bounds,coords,no_call,time.time()+899,toy=True,maxeval=40,chain=16);assert budget['completed_full_ge']==0
 try:r.optimize(HERE/'toy/failure',c['center'],bounds,coords,lambda *a: (_ for _ in ()).throw(RuntimeError('mock_fatal')),time.time()+7200,toy=True,maxeval=40,chain=16)
 except RuntimeError as exc:assert str(exc)=='mock_fatal'
 else:raise AssertionError('Fatal swallowed')
 from datetime import datetime
 from zoneinfo import ZoneInfo
 assert c['absolute_cutoff_epoch']==int(datetime(2026,10,1,10,0,tzinfo=ZoneInfo('America/New_York')).timestamp())
 source=(HERE/'run_psi.py').read_text();assert 'start+7200' not in source and 'MAX_EVAL = 400' in source and "deadline=min(args.deadline_epoch,float(CONFIG['absolute_cutoff_epoch']))" in source
 # Four hours of fake runtime must be allowed; only the absolute 900s reserve stops it.
 real_time=r.time.time;clock=[c['absolute_cutoff_epoch']-14400.]
 def slow_mock(label,point,end):
  assert end==c['absolute_cutoff_epoch']-900.;clock[0]+=600
  return dict(status='passed',residual=[.01]*10,lifecycle_solves=0,report='mock')
 try:
  r.time.time=lambda:clock[0]
  long_result=r.optimize(HERE/'toy/long_deadline',c['center'],bounds,coords,slow_mock,c['absolute_cutoff_epoch'],toy=True,maxeval=400,chain=16)
 finally:r.time.time=real_time
 assert long_result['elapsed_seconds']>7200 and long_result['search_stop_reason']=='overnight_absolute_cutoff_final_reserve' and long_result['lifecycle_solves']==0
 for chain in [0,16]:
  def cap_mock(label,point,end):return dict(status='passed',residual=[.01]*10,lifecycle_solves=0,report='mock')
  cap=r.optimize(HERE/'toy'/f'cap400_{chain}',c['center'],bounds,coords,cap_mock,real_time()+40000,toy=True,maxeval=400,chain=chain)
  assert cap['objective_calls']<=400 and cap['lifecycle_solves']==0
  if chain==16:assert cap['objective_calls']==400
 receipt=dict(status='passed_zero_lifecycle',parameter_binding_vectors=len(vectors),controllers=receipts,target_contract_exact=True,profiles_exact=True,bounds_exact=True,broad_ranges_exact=True,reserve_stop=True,fatal_propagation=True,numerical_rejection=True,lifecycle_solves=0,absolute_timezone_cutoff_exact=True,more_than_two_hour_mock_allowed=True,objective_cap400_verified=True,long_budget_elapsed_seconds=long_result['elapsed_seconds'])
 (HERE/'configuration_check.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
if __name__=='__main__':main()
